# -*- coding: utf-8 -*-
import re
import requests
import datetime 
import json
import time 
import sys 
import boto
import gc

import aws_insert
from mtranslate import translate

def trans(to_translate):
    try:
        Translated = (translate(to_translate,'en'))
        return Translated
    except:
        return to_translate   

# url="https://www.pegipegi.com/hotel/singapore/fragrance_hotel_royal_118125/?stayYear=2018&stayMonth=11&stayDay=24&stayCount=1&roomCrack=100000&hotelNameKey=Fragrance%20Hotel%20-%20Royal,%20Singapore,%20Singapore#checkin=2018-11-24&checkout=2018-11-25#"
# inputid='Testing'
# id_update='12345'
# proxyip='user-34068:214859b73da0e174@45.64.106.38:1212'

def fetchrates(url ,inputid, id_update, proxyip):
    array = []
    israteperstay = ''
    intime=re.sub(r'\s','T',str(datetime.datetime.now()))
    Domainname='Pegipegi.com'
    Websitecode='310'
    region=''
    statuscode=''
    adults=re.search(r"roomCrack=(\d)",url).group(1)
    conn = boto.connect_s3(aws_access_key_id= 'AKIAIXEGZVXCWE2FV3SQ',aws_secret_access_key = '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') 
    bucket = conn.get_bucket("rmapi")
    StartDate = datetime.date.today()
    EndDate  = datetime.date.today() + datetime.timedelta(days=29)
    try:
        if re.search(r"checkin=(.*?)&checkout=(.*?)#", url):
            chkin=re.search(r'checkin=(.*?)&checkout=(.*?)#',url).group(1)
            chkout=re.search(r'checkin=(.*?)&checkout=(.*?)#',url).group(2)
            cin_day=datetime.datetime.strptime(chkin,"%Y-%m-%d").strftime("%d")
            cin_mnth=datetime.datetime.strptime(chkin,"%Y-%m-%d").strftime("%m")
            cin_year=datetime.datetime.strptime(chkin,"%Y-%m-%d").strftime("%Y")
            
        checkins=datetime.datetime.strptime(chkin, str("%Y-%m-%d")).strftime("%Y, %m, %d")
        checkouts=datetime.datetime.strptime(chkout, str("%Y-%m-%d")).strftime("%Y, %m, %d")
        ccin = datetime.datetime.strptime(checkins,'%Y, %m, %d')
        ccout = datetime.datetime.strptime(checkouts,'%Y, %m, %d')
        LOS = ccout - ccin
        LOS = LOS.days
        ##print "LOS=",LOS
        
        url= re.sub(r'stayYear=.*?&stayMonth=.*?&stayDay=.*?&stayCount=.*?&room','stayYear='+cin_year+'&stayMonth='+cin_mnth+'&stayDay='+cin_day+'&stayCount='+str(LOS)+'&room',url)
        #print url
        
        RteDate = chkin
        RoomType        =""
        RateDate        = re.sub(r'-|\-','',str(RteDate))    
        Guests          =adults
        OnsiteRate      =0
        NetRate         =0
        GrossRate       =0
        Curr            =""
        RateDescription =""
        url             = re.sub(r"'","''",url)
        url_insert      =url
        RoomAmenity_Type=""
        Meal            =""
        MaxOccupancy    =""
        isPromotionalRate="N"
        Closed          ="Y"
        StartDate       =StartDate
        EndDate         =EndDate
        isAvailable     =""
        Taxtype         =""
        Tax_status      =""
        TaxAmount       ="0"
        Ratetype        =""
        Discount        ="0"
        Promotion_Name  =""
        Curr='IDR'
        block1  = re.compile(r'class="slideShowRoom".*?<!--.*?Hide List Room End -->',re.DOTALL)
        proxies = {"http": "http://{}".format(proxyip)}

        ip=re.sub(r"\{'.*?@|'\}|:\d+","",str(proxies))
        try:
            try:
                r = requests.get('http://freegeoip.net/json/'+ip,timeout=30)
            except Exception,e:
                r = requests.get('http://freegeoip.net/json/'+ip,timeout=30)
            js = r.json()
            region=js['country_name']
        except Exception,e:
            region=''

        try:
            input_result = requests.get(url, proxies = proxies,timeout=30)
        except Exception as e: 
            print e,"Re-run"
            try:
                input_result = requests.get(url, proxies = proxies,timeout=30)                
            except Exception as e: 
                print e,"Re-run"
                value_error=str(re.sub(r"'",'"',str(e)))
                stacktrace=sys.exc_traceback.tb_lineno
                insert_value_error=str(value_error)+'Where line number '+str(stacktrace)+str(proxyip)
                print insert_value_error
                keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(Websitecode,datetime.datetime.now(),id_update)
                key = bucket.new_key(keyvalue)
                key.set_contents_from_string(str(e))
                statuscode=5
                Guests=adults
                array.append(aws_insert.insert(id_update, inputid ,Domainname,Websitecode,insert_value_error,"", "", "", Guests, "", "", "", "", "",url_insert, url_insert, url_insert, "", "", "", "", "", "",StartDate, EndDate , "", "", "", "", "", "",  "", "", "",region,statuscode, israteperstay))
                return json.dumps(array)
        if (input_result.status_code<> 200):
            input_result = requests.get(url, proxies = proxies,timeout=30)
        if (input_result.status_code == 403 or input_result.status_code == 407 or input_result.status_code <> 200):
            try:
                input_result = requests.get(url)
            except Exception as e:
                print e,"Re-run"
                value_error=str(re.sub(r"'",'"',str(e)))
                stacktrace=sys.exc_traceback.tb_lineno
                insert_value_error=str(value_error)+'Where line number '+str(stacktrace)+str(proxyip)
                print insert_value_error
                keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(Websitecode,datetime.datetime.now(),id_update)
                key = bucket.new_key(keyvalue)
                key.set_contents_from_string(str(e))
                statuscode=5
                Guests=adults
                array.append(aws_insert.insert(id_update, inputid ,Domainname,Websitecode, "","", "", insert_value_error, Guests, "", "", "", "", "",url_insert, url_insert, url_insert, "", "", "", "", "", "",StartDate, EndDate , "", "", "", "", "", "",  "", "", "",region,statuscode, israteperstay))
                return json.dumps(array)

        time.sleep(2)
        html         = input_result.text.encode('ascii', 'ignore')
        ##print html
#         fo = open('pegi.html','w').write(html)
#         print input_result.status_code
        Rtdate=re.sub(r'-|\-','',str(RateDate))
        keyvalue = "ondemand/{}/{:%Y%m%d}/source/{}.html".format(Websitecode,datetime.datetime.now(),str(inputid)+'_'+str(Rtdate)+'_'+id_update)
        key = bucket.new_key(keyvalue)
        key.set_contents_from_string(html)    
        #fo = open('sam.html','w')
        #fo.write(str(html))
        ##print html
        if block1.findall(html):
            Closed ="N"
            for blck1 in block1.findall(html):
                room_serch = re.search(r'class="slideShowRoom">.*?>.*?>\s*(.*?)\s*<',blck1,re.DOTALL)
                if room_serch:
                    RoomType = re.sub(r'\s\s+','',re.sub(r"'","''",room_serch.group(1)))
                    ##print RoomType
                else:
                    RoomType = ''
                    
                ratetyp = re.search(r'[P|p]embatalan\s*</td>\s*<td>\s*(.*?)\s*</',blck1,re.DOTALL)
                if ratetyp:
                    Ratetype = 'Pembatalan '+re.sub(r"'","''", re.sub(r"\s\s+", r" ",re.sub(r";",'',ratetyp.group(1))))
                else:
                    Ratetype = ''

                '''ROOM_ID_search = re.search(r'href="javascript:.*?" data-roomid="(.*?)">.*?\s*</a><div class="room-attribute-icons-box">',blck1)
                if ROOM_ID_search:
                    ROOM_IDs = ROOM_ID_search.group(1)
                else:
                    ROOM_IDs = '''''
                desc_con = '<div class="subContent">\s*(.*?)\s*<b'
                desc_ser = re.search(desc_con,blck1)
                if desc_ser:
                    RateDescription = re.sub(r'"|<.*?>','',re.sub(r'":"',':',re.sub(r'","',',',re.sub(r'^","','',re.sub(r"'","''",desc_ser.group(1))))))
                else:
                    RateDescription = ''
                    
                amein_con = r'<ul>\s*<li>(.*?)</li>\s*</ul>'
                amein     = re.search(amein_con,blck1)
                if amein:
                    RoomAmenity_Type = re.sub('^|$','"',re.sub('</li><li>','", "',re.sub(r"'","''",amein.group(1))))
                else:
                    RoomAmenity_Type = ''
                Maxocpy  = re.search(r'<td>\s*<i class="fa fa-user">(.*?)</td>',blck1,re.DOTALL)
                if Maxocpy:
                    Guest1       = Maxocpy.group(1)
                    Guest_clean1 = re.sub(r"<.*?>|\(|\)","",Guest1)
                    MaxOccupancy = re.sub(r"\s\s+","",Guest_clean1)
                else:
                    MaxOccupancy = ''
                Onrate = re.search(r'normalPrice">[A-z].*?(\d.*?)</div>',blck1)
                if Onrate:
                    OnsiteRate = re.sub(r",|'",'',Onrate.group(1))
                else:
                    OnsiteRate = 0
                    
                NetRates = re.search(r'diskonPrice">[A-z].*?(\d.*?)<',blck1)
                if NetRates:
                    NetRate = re.sub(r"'|,","",NetRates.group(1))
                    if NetRate:
                        isPromotionalRate="Y"
                    else:
                        isPromotionalRate="N"
                else:
                    NetRate = 0
                    isPromotionalRate="N"
                #curr_concn = re.search(r'normalPrice">([A-z].*?)\d.*?</div>',blck1)
                #if curr_concn:
                #    Curr = re.sub(r"'","''",curr_concn.group(1))
                
                promoname_cc = re.search(r'discountListRoom">(.*?\d+.*?)<',blck1)
                if promoname_cc:
                    Promotion_Name = re.sub(r"'","",promoname_cc.group(1))+' Off'
                    if Promotion_Name:
                        isPromotionalRate="Y"
                    else:
                        isPromotionalRate="N"
                else:
                    Promotion_Name = ''
                isavailabl_cc = re.search(r'<option value=.*?(\d+)</option>\s*</select></div>',blck1)
                if isavailabl_cc:
                    isAvailable = isavailabl_cc.group(1)
                else:
                    isAvailable = ''
                Meal_option = re.search(r'<td>[s|S]arapan<.*?>\s*<.*?><.*?><.*?>\s*(.*?)\s*</',blck1,re.DOTALL)
                if Meal_option:
                    Meal_group   = Meal_option.group(1)
                    Meal         = re.sub(r"\s\s+", r" ",Meal_group)
                else:
                    Meal          = str(RateDescription)+' '+str(RoomAmenity_Type)+' '+str(RoomType)+' '+str(Ratetype)
                        
                GrossRate = OnsiteRate
                Discount  = NetRate
                Promotion_Name = re.sub(r'<.*?>','',str(Promotion_Name))
                MaxOccupancy   = re.sub(r'\D','',str(MaxOccupancy))
                RoomType = trans(RoomType)
                Ratetype = trans(Ratetype)
                Meal     = trans(Meal)
                RateDescription = trans(RateDescription)
                RoomAmenity_Type= trans(RoomAmenity_Type)
                if LOS >1:
                    israteperstay = 'N'
                else:
                    israteperstay = 'Y'
                if OnsiteRate==0 or str(OnsiteRate)=='0':
                    statuscode=1
                    Closed_up = 'Y'
                if (NetRate == 0 or NetRate == '') and (Promotion_Name == 0 or Promotion_Name == ''):
                    isPromotionalRate = 'N'
                #insert (ReportDate,RoomType,RoomTypeMapped,LOS,                                RateDate,Guests,OnsiteRate,NetRate,GrossRate,Curr,RateDescription,urlRate,urlInclusions,urlAmenities,RoomAmenity_Type,Meal,MaxOccupancy,isPromotionalRate,Closed,NumberOfDays,StartDate,EndDate,StarCategory,Rooms,PageOnRank,Featured,LastModified,isUpdated,isAvailable,Taxtype,TaxAmount,HotelBlock,Ratetype,Discount,Promotion_Name)
#                 print (id_update, inputid , Domainname, Websitecode, StartDate, RoomType, LOS, RateDate, Guests, OnsiteRate, NetRate, GrossRate, Curr, RateDescription, url_insert, url_insert, url_insert, RoomAmenity_Type, Meal, MaxOccupancy, isPromotionalRate, Closed,30, StartDate , EndDate, intime, isAvailable, Taxtype, TaxAmount, Tax_status, None, Ratetype, Discount,Promotion_Name,region,statuscode, israteperstay)
                array.append(aws_insert.insert(id_update, inputid , Domainname, Websitecode, StartDate, RoomType, LOS, RateDate, Guests, OnsiteRate, NetRate, GrossRate, Curr, RateDescription, url_insert, url_insert, url_insert, RoomAmenity_Type, Meal, MaxOccupancy, isPromotionalRate, Closed,30, StartDate , EndDate, intime, isAvailable, Taxtype, TaxAmount, Tax_status, None, Ratetype, Discount,Promotion_Name,region,statuscode, israteperstay))
        else:
            statuscode = 2
            Closed      = "Y"
#             print (id_update, inputid , Domainname, Websitecode, StartDate, RoomType, LOS, RateDate, Guests, OnsiteRate, NetRate, GrossRate, Curr, RateDescription, url_insert, url_insert, url_insert, RoomAmenity_Type, Meal, MaxOccupancy, isPromotionalRate, Closed,30, StartDate , EndDate, intime, isAvailable, Taxtype, TaxAmount, Tax_status, None, Ratetype, Discount,Promotion_Name,region,statuscode, israteperstay)
            array.append(aws_insert.insert(id_update, inputid , Domainname, Websitecode, StartDate, RoomType, LOS, RateDate, Guests, OnsiteRate, NetRate, GrossRate, Curr, RateDescription, url_insert, url_insert, url_insert, RoomAmenity_Type, Meal, MaxOccupancy, isPromotionalRate, Closed,30, StartDate , EndDate, intime, isAvailable, Taxtype, TaxAmount, Tax_status, None, Ratetype, Discount,Promotion_Name,region,statuscode, israteperstay))
            #insert(ReportDate,RoomType,RoomTypeMapped,LOS,RateDate,Guests,OnsiteRate,NetRate,GrossRate,Curr,RateDescription,urlRate,urlInclusions,urlAmenities,RoomAmenity_Type,Meal,MaxOccupancy,isPromotionalRate,Closed,NumberOfDays,StartDate,EndDate,StarCategory,Rooms,PageOnRank,Featured,LastModified,isUpdated,isAvailable,Taxtype,TaxAmount,HotelBlock,Ratetype,Discount,Promotion_Name)
        keyvalue = "ondemand/{}/{:%Y%m%d}/delivery/{}.json".format(Websitecode,datetime.datetime.now(),str(inputid)+'_'+str(Rtdate)+'_'+id_update)
        key = bucket.new_key(keyvalue)
        key.set_contents_from_string(json.dumps(array))
        gc.collect()
        return json.dumps(array)
    except Exception as e:
        print e
        value_error=str(re.sub(r"'",'"',str(e)))
        stacktrace=sys.exc_traceback.tb_lineno
        Guests =adults
        insert_value_error=str(value_error)+'Where line number '+str(stacktrace)+str(proxyip)
        print insert_value_error
        statuscode='4'
        print insert_value_error
        keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(Websitecode,datetime.datetime.now(),id_update)
        key = bucket.new_key(keyvalue)
        key.set_contents_from_string(insert_value_error)
        array.append(aws_insert.insert(id_update, inputid ,Domainname,Websitecode, "","", "", "", Guests, "", "", "", "", "",url_insert, url_insert, url_insert, "", "", "", "", "", "",StartDate, EndDate , "", "", "", "", "", "",  "", "", "",region,statuscode, israteperstay))
        return json.dumps(array)


# fetchrates(url ,inputid, id_update, proxyip)
