# -*- coding: utf-8 -*-
import re
import requests
import datetime
import json
import sys 
import boto
import gc

from xml.etree import ElementTree as ET
from unidecode import unidecode
import aws_insert

'''
url = 'https://crs.booklogic.net/ws/ta/htl/service.cfm?requestxml=<MetaAvailInfoRQ><RequestorID><UserName>ratemetrics</UserName><Password>r@t3metr1cs!</Password></RequestorID>%20<language>EN</language>%20<AvailInfo>%20<Hotel>BILEKIST</Hotel>%20<city></city>%20<region></region>%20<Country></Country>%20<city_district></city_district>%20<DateIn>2017-10-31</DateIn>%20<DateOut>2017-11-01</DateOut>%20<Rooms%20num="1">%20<Room>%20<adult%20num="2"></adult>%20</Room>%20</Rooms>%20<marketCountry>US</marketCountry>%20</AvailInfo>%20</MetaAvailInfoRQ>'
inputid = 2
id_update = '25'
proxyip = 'media:M3diAproxy@107.175.37.101:80'
'''

def fetchrates(url ,inputid, id_update, proxyip):
    array = []
    israteperstay = ''
    StartDate = datetime.date.today()
    EndDate  = datetime.date.today()+datetime.timedelta(days=29)
    conn = boto.connect_s3(aws_access_key_id= 'AKIAIXEGZVXCWE2FV3SQ',aws_secret_access_key = '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') 
    bucket = conn.get_bucket("rmapi")
    intime=re.sub(r'\s','T',str(datetime.datetime.now()))
    Websitecode = 374
    region=''
    head = {'User-Agent' :'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:12.0) Gecko/20100101 Firefox/48.0'}
    delta = datetime.datetime.strptime(re.search(r"<DateOut>(.*?)</DateOut>", url).group(1), "%Y-%m-%d") - datetime.datetime.strptime(re.search(r"<DateIn>(.*?)</DateIn>", url).group(1), "%Y-%m-%d")
    LOS = delta.days
    try:
        adults =re.search(r'adult.20num="(.*?)">',url).group(1)
        #print url
        #print LOS
        Domainname="bilekistanbul"
        RoomType = ""
        RateType=''
        Guests = adults
        OnsiteRate = 0
        Closed_up = 'N'
        MealInclusion_Type = " "
        RoomAmenityType = ""
        NetRate=0
        isAvailable=''
        MaxOccupancy=None
        Curr='INR'
        ispromupdate = 'N'
        statuscode=''
        promotion=''
        RateDesc=''
        Taxtype=''
        Taxamount=''
        Tax_status=''
        proxies = {"https": "http://{}".format(proxyip)}
        region=''
        ip=re.sub(r"\{'.*?@|'\}|:\d+","",str(proxies))
        try:
            try:
                r = requests.get('http://freegeoip.net/json/'+ip,timeout=30)
            except Exception,e:
                r = requests.get('http://freegeoip.net/json/'+ip,timeout=30)
            js = r.json()
            region=js['country_name']
        except Exception,e:
            region=''
        Rtdate=str(re.search(r"<DateIn>(.*?)</DateIn>", url).group(1))
        #if re.search(r"(checkin=.*?&)", url):
        RateDate = Rtdate
        #url = re.sub("https", "http", re.sub(r"&roomStayQualifier.*?&", "&roomStayQualifier=1e0e&", re.sub("&amp;|&amp;\%+", "&", url).replace('%20', '%%20')))
        try:
            json_load = requests.get(url, headers = head, proxies = proxies,timeout=10)
            #print json_load.status_code
        except Exception,e:
            value_error=str(re.sub("'",'"',str(e)))
            stacktrace=sys.exc_traceback.tb_lineno
            try:
                proxies = {"http": "http://{}".format(proxyip)}
                json_load = requests.get(url, headers = head, proxies = proxies,timeout=10)
            except Exception,e:
                value_error=str(re.sub("'",'"',str(e)))
                stacktrace=sys.exc_traceback.tb_lineno
                keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(Websitecode,datetime.datetime.now(),id_update)
                #print keyvalue
                key = bucket.new_key(keyvalue)
                error= str(e)+'\n'+str(proxies)
                key.set_contents_from_string(error)
                statuscode=5
                Guests=adults
                array.append(aws_insert.insert(id_update, inputid ,"",Websitecode, "", "", "", "", Guests, "", "", "", "", "",url,url,url, "", "", "", "", "", "",StartDate, EndDate , "", "", "", "", "",  "", "", "","",region,statuscode, israteperstay))
                #array.append(aws_insert.insert(id_update, inputid ,"","", "", "", "", "", "", "", "", "", "", "","", "", "", "", "", "", "", "", "",StartDate, EndDate , "", "", "", "", "",  "", "", "",statuscode))
                return json.dumps(array)
        if (json_load.status_code <> 200):   
            json_load = requests.get(url, headers = head, proxies = proxies)
        if (json_load.status_code == 403 or json_load.status_code == 407):
            try:
                #jproxy = json.loads(requests.get('http://www.gimmeproxy.com/api/getProxy?protocol=http').content)
                #proxies = { "http": jproxy["curl"] }
                session_request = requests.Session()
                session_request.get('http://www.makemytrip.com', headers = head, proxies=proxies)
                json_load = requests.get(url, headers = head, proxies = proxies)
                if (json_load.status_code != 200):
                    json_load = requests.get(url, headers = head)
            except Exception,e:
                value_error=str(re.sub("'",'"',str(e)))
                value_error=str(e).enode('ascii','ignore')
                stacktrace=sys.exc_traceback.tb_lineno
                keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(Websitecode,datetime.datetime.now(),id_update)
                key = bucket.new_key(keyvalue)
                error= str(e)+'\n'+str(proxies)
                key.set_contents_from_string(error)
                statuscode=5
                Guests=adults
                array.append(aws_insert.insert(id_update, inputid ,"",Websitecode, "", "", "", "", Guests, "", "", "", "", "",url,url,url, "", "", "", "", "", "",StartDate, EndDate , "", "", "", "", "",  "", "", "","",region,statuscode, israteperstay))
                return json.dumps(array)
        ##print json_load.text
        #print json_load.status_code
        try: 
            Guests=adults
            keyvalue="ondemand/{}/{:%Y%m%d}/source/{}.txt".format(Websitecode,datetime.datetime.now(),str(inputid)+'_'+str(Rtdate)+'_'+id_update)
            key = bucket.new_key(keyvalue)
            key.set_contents_from_string(json_load.text)
            if '<MetaAvailInfoRS>' in json_load.text:
                root = ET.fromstring(unidecode(json_load.text).encode('ascii'))
                for rooms in root.getiterator('Room'):
                    for content in rooms:

                        Closed_up = 'Y'  
                        if  content.tag == 'RoomDescr':
                            RoomType = content.text
                        if content.tag == 'deepLink':
                            url = content.text
                        if content.tag == 'RateDescr':
                            RateDesc = content.text
                        if content.tag == 'RateName':
                            RateType = content.text
                        if content.tag == 'meal':
                            MealInclusion_Type = content.text
                        if content.tag  == 'HotelPrice':
                            Curr =  content.attrib['cur_code']
                        if content.tag == 'Price':
                            OnsiteRate = content.text
                        if content.tag == 'Discount':
                            Discountamnt = content.text
                            NetRate = float(OnsiteRate)+float(Discountamnt)
			    ispromupdate = 'Y'
                        if content.tag == 'Avl_Stat':
                            if content.text == 'AV':
                                Closed_up = 'N' 
                    da_time = datetime.datetime.now()
                    intime = re.sub(r'\s','T',str(da_time))
                    if str(OnsiteRate) == '0' or str(OnsiteRate) == '' or OnsiteRate==0:
                        statuscode=1
                        Closed_up='Y'
                        Tax_status = '-1'
                    else:
                        statuscode=''
                        Closed_up='N'
                        Tax_status = '1'
                        israteperstay = 'Y'
                    #print (id_update, inputid , Domainname, Websitecode, StartDate, RoomType, LOS, RateDate, Guests, OnsiteRate, NetRate, OnsiteRate, Curr, RateDesc, url, url, url, RoomAmenityType, MealInclusion_Type, MaxOccupancy, ispromupdate, Closed_up, 30, StartDate , EndDate, intime, isAvailable, Taxtype, Taxamount,Tax_status, None, RateType, NetRate,promotion,region,statuscode)
                    array.append(aws_insert.insert(id_update, inputid , Domainname, Websitecode, StartDate, RoomType, LOS, RateDate, Guests, OnsiteRate, NetRate, OnsiteRate, Curr, RateDesc, url, url, url, RoomAmenityType, MealInclusion_Type, MaxOccupancy, ispromupdate, Closed_up, 30, StartDate , EndDate, intime, isAvailable,Taxtype, Taxamount,Tax_status,  None, RateType, NetRate,promotion,region,statuscode, israteperstay))
            else:
                statuscode = '2'
                Closed_up = 'Y'
                array.append(aws_insert.insert(id_update, inputid , Domainname, Websitecode, StartDate, RoomType, LOS, RateDate, Guests, OnsiteRate, NetRate, OnsiteRate, Curr, RateDesc, url, url, url, RoomAmenityType, MealInclusion_Type, MaxOccupancy, ispromupdate, Closed_up, 30, StartDate , EndDate, intime, isAvailable,Taxtype, Taxamount,Tax_status,  None, RateType, NetRate,promotion,region,statuscode, israteperstay))
        except Exception,e:
            value_error=str(re.sub(r"'",'"',str(e)))
            stacktrace=sys.exc_traceback.tb_lineno
            insert_value_error=str(value_error)+'Where line number '+str(stacktrace)+' - '+str(proxyip)
            print insert_value_error
            statuscode='4'
            keyvalue = "ondemand/{}/{:%Y%m%d}/delivery/Error{}.json".format(Websitecode,datetime.datetime.now(),str(inputid)+'_'+str(RateDate)+'_'+id_update)
            key = bucket.new_key(keyvalue)
            key.set_contents_from_string(insert_value_error) 
            Closed_up = 'Y'
            array.append(aws_insert.insert(id_update, inputid , Domainname, Websitecode, StartDate, RoomType, LOS, RateDate, Guests, OnsiteRate, NetRate, OnsiteRate, Curr, RateDesc, url, url, url, RoomAmenityType, MealInclusion_Type, MaxOccupancy, ispromupdate, Closed_up, 30, StartDate , EndDate, intime, isAvailable,Taxtype, Taxamount,Tax_status,  None, RateType, NetRate,promotion,region,statuscode, israteperstay))
        keyvalue = "ondemand/{}/{:%Y%m%d}/delivery/{}.json".format(Websitecode,datetime.datetime.now(),str(inputid)+'_'+str(Rtdate)+'_'+id_update)
        key = bucket.new_key(keyvalue)
        key.set_contents_from_string(json.dumps(array))
        return json.dumps(array)
        gc.collect()
    except Exception as e:
        value_error=str(re.sub(r"'",'"',str(e)))
        stacktrace=sys.exc_traceback.tb_lineno
        insert_value_error=str(value_error)+'Where line number '+str(stacktrace)+' - '+str(proxyip)
        print insert_value_error
        statuscode='4'
        keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(Websitecode,datetime.datetime.now(),id_update)
        key = bucket.new_key(keyvalue)
        key.set_contents_from_string(insert_value_error)
        Guests='1'
        array.append(aws_insert.insert(id_update, inputid ,"",Websitecode, "", "", "", "", Guests, "", "", "", "", "",url,url,url, "", "", "", "", "", "",StartDate, EndDate , "", "", "", "", "",  "", "", "","",region,statuscode, israteperstay))
        return json.dumps(array)
#fetchrates(url ,inputid, id_update, proxyip)
