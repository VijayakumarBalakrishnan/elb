# -*- coding: utf-8 -*-
import re
import requests
import datetime
import json
import boto

import sys 
import gc
import aws_insert
seson = requests.Session()
def fetchrates(url ,inputid, id_update, proxyip):
    array      = []
    israteperstay = ''
    proxies    = {"http": "http://{}".format(proxyip)}
    intime     = re.sub(r'\s','T',str(datetime.datetime.now()))
    Domainname = 'adelaidemeridien.com'
    Websitecode= '345'
    region     = ''
    statuscode = ''
    Mealtype   = ''
    conn       = boto.connect_s3(aws_access_key_id= 'AKIAIXEGZVXCWE2FV3SQ',aws_secret_access_key = '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') 
    bucket     = conn.get_bucket("rmapi")
    StartDate  = datetime.date.today()
    EndDate    = datetime.date.today() + datetime.timedelta(days=29)
    try:
        CheckIn_Check_OT_re = re.search(r'#checkin=(.*?)&checkout=(.*?)&',url)
        if CheckIn_Check_OT_re:
            Checkin = CheckIn_Check_OT_re.group(1)
            CheckOT = CheckIn_Check_OT_re.group(2)
        else:
            Checkin = ''
            CheckOT = ''
        RateDate = Checkin
        delta    = datetime.datetime.strptime(CheckOT, "%Y-%m-%d") - datetime.datetime.strptime(Checkin, "%Y-%m-%d")
        LOS      = delta.days
        RoomType = ''
        Guests   = re.search(r'guests=(\d+)', url).group(1)
        Ratetype = ''
        RateDescription = ''
        Meal     = ''
        Taxtype  = ''
        Curr     = ""
        MaxOccupancy  = None
        isPromotionalRate  = 'N'
        Closed   = 'Y'
        NetRate  = 0
        Taxstatus= -1
        TaxAmount= 0
        Discount = 0
        GrossRate= 0
        OnsiteRate = 0
        Promotion_Name= ''
        isAvailable = ''
        RoomAmenity_Type = ''
        #print url
        dates     = re.search(r'checkin=(.*?)&checkout=(.*?)&guests=(\d+)', url)
        if dates:
            Date_in = dates.group(1)
            Date_ot = dates.group(2)
            Guests  = dates.group(3)
        else:
            Guests  = ''
            Date_in = ''
            Date_ot = ''
        H_Url     = re.sub(r'#.*$','', url)
        url_insert= url
        proxyip   = re.sub(r':.*','',str(proxyip))
        Post_url  = 'https://www.bookonthenet.net/east/premium/WSEResData.asmx/getResultList'
        head      = {'Host':'www.bookonthenet.net', 'User-Agent':'Mozilla/5.0 (X11; Linux i686; rv:45.0) Gecko/20100101 Firefox/45.0'}
        respons1  = seson.get(H_Url,proxies=proxies,headers=head)
        Checkin  = datetime.datetime.strftime(datetime.datetime.strptime(Date_in,"%Y-%m-%d"),"%b %d, %Y")
        Checkout = datetime.datetime.strftime(datetime.datetime.strptime(Date_ot,"%Y-%m-%d"),"%b %d, %Y")
        data     = re.search(r'guesthistory\.aspx\?id=(.*?)"', respons1.text).group(1)
        head     = {'Host':'www.bookonthenet.net', 'User-Agent':'Mozilla/5.0 (X11; Linux i686; rv:45.0) Gecko/20100101 Firefox/45.0', 'Accept':'application/json, text/javascript, */*; q=0.01', 'Accept-Language':'en-US,en;q=0.5', 'Accept-Encoding':'gzip, deflate, br', 'Content-Type':'application/json; charset=utf-8', 'X-Requested-With':'XMLHttpRequest', 'Referer':H_Url}
        pay      = {"p1": str(data),'p2': str(Checkin),'p3': str(Checkout),'p4': str(Guests),'p5': 0,'p6': "",'p7': [-1],'p8': [],'p9': False}
        try:
            try:
                r = requests.get('http://freegeoip.net/json/' + proxyip, timeout=30)
            except Exception, e:
                r = requests.get('http://freegeoip.net/json/' + proxyip, timeout=30)
            js = r.json()
            region = js['country_name']
        except Exception, e:
            region = ''
        try:
            hml = seson.post(Post_url,proxies=proxies,headers=head,json=pay,timeout=50)
        except Exception, e:
            value_error = str(re.sub("'", '', str(e)))
            stacktrace = sys.exc_traceback.tb_lineno
            try:
                hml = seson.post(Post_url,proxies=proxies,headers=head,json=pay,timeout=50)
            except Exception, e:
                value_error = str(re.sub("'", '', str(e)))
                stacktrace = sys.exc_traceback.tb_lineno
                keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(Websitecode, datetime.datetime.now(), id_update)
                key = bucket.new_key(keyvalue)
                key.set_contents_from_string(str(e) + 'Where Line number' + str(stacktrace) + str(proxies))
                statuscode = 5
                Guests = ''
                array.append(aws_insert.insert(id_update, inputid , Domainname, Websitecode, "", "", "", "", Guests, "", "", "", "", "", url, url, url, "", "", "", "", "", "", StartDate, EndDate , "", "", "", "", "", "", "", "", "", region, statuscode,israteperstay))
                return json.dumps(array)
        if hml.status_code <> 200:
            hml = seson.post(Post_url,proxies=proxies,headers=head,json=pay,timeout=50)
        if (hml.status_code == 403 or hml.status_code == 407) or hml.status_code <> 200:
            try:
                if hml.status_code <> 200:
                    hml = seson.post(Post_url,headers=head,json=pay,timeout=50)
            except Exception, e:
                print e
                value_error = str(re.sub("'", '', str(e)))
                stacktrace = sys.exc_traceback.tb_lineno
                keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(Websitecode, datetime.datetime.now(), id_update)
                key = bucket.new_key(keyvalue)
                key.set_contents_from_string(str(e) + 'Where Line number' + str(stacktrace) + str(proxies))
                statuscode = 5
                Guests = ''
                array.append(aws_insert.insert(id_update, inputid , Domainname, Websitecode, "", "", "", "", Guests, "", "", "", "", "", url, url, url, "", "", "", "", "", "", StartDate, EndDate , "", "", "", "", "", "", "", "", "", region, statuscode,israteperstay))
                return json.dumps(array)
        json_data_c = (hml.text.decode('unicode_escape').replace('\\/', '/'))
        if 'selected" value="1">Daily Rates<' in json_data_c:
            json_data = json_data_c
        else:
            pay      = {"p1": str(data),'p2': str(Checkin),'p3': str(Checkout),'p4': str(Guests),'p5': 0,'p6': "",'p7': [1],'p8': [],'p9': False}
            try:
                try:
                    r = requests.get('http://freegeoip.net/json/' + proxyip, timeout=30)
                except Exception, e:
                    r = requests.get('http://freegeoip.net/json/' + proxyip, timeout=30)
                js = r.json()
                region = js['country_name']
            except Exception, e:
                region = ''
            try:
                hml = seson.post(Post_url,proxies=proxies,headers=head,json=pay,timeout=50)
            except Exception, e:
                stacktrace = sys.exc_traceback.tb_lineno
                try:
                    hml = seson.post(Post_url,proxies=proxies,headers=head,json=pay,timeout=50)
                except Exception, e:
                    stacktrace = sys.exc_traceback.tb_lineno
                    keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(Websitecode, datetime.datetime.now(), id_update)
                    key = bucket.new_key(keyvalue)
                    key.set_contents_from_string(str(e) + 'Where Line number' + str(stacktrace) + str(proxies))
                    statuscode = 5
                    Guests = ''
                    array.append(aws_insert.insert(id_update, inputid , Domainname, Websitecode, "", "", "", "", Guests, "", "", "", "", "", url, url, url, "", "", "", "", "", "", StartDate, EndDate , "", "", "", "", "", "", "", "", "", region, statuscode,israteperstay))
                    return json.dumps(array)
            if hml.status_code <> 200:
                hml = seson.post(Post_url,proxies=proxies,headers=head,json=pay,timeout=50)
            if (hml.status_code == 403 or hml.status_code == 407) or hml.status_code <> 200:
                try:
                    if hml.status_code <> 200:
                        hml = seson.post(Post_url,headers=head,json=pay,timeout=50)
                except Exception, e:
                    print e
                    stacktrace = sys.exc_traceback.tb_lineno
                    keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(Websitecode, datetime.datetime.now(), id_update)
                    key = bucket.new_key(keyvalue)
                    key.set_contents_from_string(str(e) + 'Where Line number' + str(stacktrace) + str(proxies))
                    statuscode = 5
                    Guests = ''
                    array.append(aws_insert.insert(id_update, inputid , Domainname, Websitecode, "", "", "", "", Guests, "", "", "", "", "", url, url, url, "", "", "", "", "", "", StartDate, EndDate , "", "", "", "", "", "", "", "", "", region, statuscode,israteperstay))
                    return json.dumps(array)
            json_data = (hml.text.decode('unicode_escape').replace('\\/', '/'))
        if 'Currently we do not have availability for your selected criteria' in json_data:
            pay      = {"p1": str(data),'p2': str(Checkin),'p3': str(Checkout),'p4': str(Guests),'p5': 0,'p6': "",'p7': [-1],'p8': [],'p9': False}
            try:
                try:
                    r = requests.get('http://freegeoip.net/json/' + proxyip, timeout=30)
                except Exception, e:
                    r = requests.get('http://freegeoip.net/json/' + proxyip, timeout=30)
                js = r.json()
                region = js['country_name']
            except Exception, e:
                region = ''
            try:
                hml = seson.post(Post_url,proxies=proxies,headers=head,json=pay,timeout=50)
            except Exception, e:
                stacktrace = sys.exc_traceback.tb_lineno
                try:
                    hml = seson.post(Post_url,proxies=proxies,headers=head,json=pay,timeout=50)
                except Exception, e:
                    stacktrace = sys.exc_traceback.tb_lineno
                    keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(Websitecode, datetime.datetime.now(), id_update)
                    key = bucket.new_key(keyvalue)
                    key.set_contents_from_string(str(e) + 'Where Line number' + str(stacktrace) + str(proxies))
                    statuscode = 5
                    Guests = ''
                    array.append(aws_insert.insert(id_update, inputid , Domainname, Websitecode, "", "", "", "", Guests, "", "", "", "", "", url, url, url, "", "", "", "", "", "", StartDate, EndDate , "", "", "", "", "", "", "", "", "", region, statuscode,israteperstay))
                    return json.dumps(array)
            if hml.status_code <> 200:
                hml = seson.post(Post_url,proxies=proxies,headers=head,json=pay,timeout=50)
            if (hml.status_code == 403 or hml.status_code == 407) or hml.status_code <> 200:
                try:
                    if hml.status_code <> 200:
                        hml = seson.post(Post_url,headers=head,json=pay,timeout=50)
                except Exception, e:
                    print e
                    stacktrace = sys.exc_traceback.tb_lineno
                    keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(Websitecode, datetime.datetime.now(), id_update)
                    key = bucket.new_key(keyvalue)
                    key.set_contents_from_string(str(e) + 'Where Line number' + str(stacktrace) + str(proxies))
                    statuscode = 5
                    Guests = ''
                    array.append(aws_insert.insert(id_update, inputid , Domainname, Websitecode, "", "", "", "", Guests, "", "", "", "", "", url, url, url, "", "", "", "", "", "", StartDate, EndDate , "", "", "", "", "", "", "", "", "", region, statuscode,israteperstay))
                    return json.dumps(array)
            json_data = (hml.text.decode('unicode_escape').replace('\\/', '/'))
        '''fo = open('name.html','w')
        fo.write(json_data)'''
        Rtdate=re.sub(r'-|\-','',str(RateDate))
        keyvalue = "ondemand/{}/{:%Y%m%d}/source{}.html".format(Websitecode,datetime.datetime.now(),str(inputid)+'_'+str(Rtdate)+'_'+id_update)
        key = bucket.new_key(keyvalue)
        key.set_contents_from_string(json_data)
        if re.compile(r'ns lblRoomType">.*?Book Now.*?lblRateName">.*?</span>\s*</div>', re.DOTALL).findall(json_data):
            for RoomBlock in re.compile(r'ns lblRoomType">.*?Book Now.*?lblRateName">.*?</span>\s*</div>', re.DOTALL).findall(json_data):
                RoomType_re = re.search(r'ns lblRoomType">(.*?)<', RoomBlock)
                if RoomType_re:
                    RoomType = RoomType_re.group(1)
                else:
                    RoomType = ""
                Curr_re = re.search(r'lblPropertyCurrency".*?>(.*?)<', json_data)
                if Curr_re:
                    Curr = Curr_re.group(1)
                else:
                    Curr = ""
                RateDescription_re = re.search(r'olumns">\s*<p class="result_descriptions">(.*?)<', RoomBlock,re.DOTALL)
                if RateDescription_re:
                    RateDescription = re.sub(r"'","''",re.sub(r'\s\s\s*','',re.sub(r'<.*?>','',str(RateDescription_re.group(1)))))
                else:
                    RateDescription = ""
                RateType_re_re = re.search(r'lblRateName">(.*?)<', RoomBlock)
                if RateType_re_re:
                    Ratetype = RateType_re_re.group(1)
                else:
                    Ratetype = ""
                OnsiteRate_re = re.search(r'"lblAverageRate">(.*?)<', RoomBlock)
                if OnsiteRate_re:
                    OnsiteRate = OnsiteRate_re.group(1)
                else:
                    OnsiteRate = 0
                Mealtypes          = str(RateDescription)+' '+str(RoomType)+' '+str(Ratetype)
                if Mealtypes !=None:
                    Mealtype_str = str(Mealtypes)
                    if 'breakfast' in Mealtype_str.lower() and 'dinner' in Mealtype_str.lower()  and 'lunch' in Mealtype_str.lower():
                        Meal = 'Breakfast, Lunch and Dinner'
                    elif 'breakfast' in Mealtype_str.lower() and 'dinner' in Mealtype_str.lower():
                        Meal = 'Breakfast and dinner'
                    elif 'breakfast included' in Mealtype_str.lower():
                        Meal = 'Breakfast included'
                    elif 'BREAKFAST' in Mealtype_str:
                        Meal = 'Breakfast'
                    elif 'breakfast' in Mealtype_str.lower() and 'lunch' in Mealtype_str.lower():
                        Meal = 'Breakfast and Lunch'
                    elif 'Lunch' in Mealtype_str and 'Dinner' in Mealtype_str :
                        Meal = "Lunch and Dinner"
                    elif 'breakfast' in Mealtype_str.lower() and 'lunch' in Mealtype_str.lower() and 'dinner' in Mealtype_str.lower():
                        Meal = 'Breakfast, Lunch and dinner'
                    elif 'Break fast' in Mealtype_str:
                        Meal = 'BreakFast' 
                    elif 'breakfast' in Mealtype_str.lower():
                        Meal = 'BreakFast' 
                    elif 'halfboard' in Mealtype_str.lower():
                        Meal = 'Halfboard'
                    elif 'half board' in Mealtype_str.lower():
                        Meal = 'Half board' 
                    elif 'full board' in Mealtype_str.lower():
                        Meal = 'Full Board'
                    elif 'fullboard' in Mealtype_str.lower():
                        Meal = 'FullBoard'
                    elif 'All-Inclusive' in Mealtype_str:
                        Meal = 'All-Inclusive'
                    elif 'All Inclusive' in Mealtype_str:
                        Meal = 'All Inclusive'
                    elif 'All Meals' in Mealtype_str:
                        Meal = 'All Meals'
                    elif 'All Meal' in Mealtype_str:
                        Meal = 'All Meal'
                    else:
                        Meal = ''
                else:
                    Meal = ''    
                if OnsiteRate==0:
                    statuscode = 1
                    Closed='Y'
                else:
                    statuscode = ''
                    Closed='N'
                #print "RoomType :-",RoomType
                #print "Ratetype :-",Ratetype
                #print "RateDesc :-",RateDescription
                #print "Amount   :-",OnsiteRate
                #print "Prmotion :-",Promotion_Name
                #print "isPromo  :-",isPromotionalRate
                #print "NetRate  :-",NetRate
                #print "Currency :-",Curr
                #print "Discount :-",Discount
                #print "MealType :-",Meal
                #print "Closed   :-",Closed
                #print "Taxstatus:-",Taxstatus
                #print "status_cd:-",statuscode
                #print "_"*30
                GrossRate = OnsiteRate
                Mealtype  = Meal
                RateDate  = Checkin
                LOS = int(LOS)
                if int(LOS)>1:
                    israteperstay = 'N'
                else:
                    israteperstay ='Y'
                ##print (id_update, inputid , Domainname, Websitecode, StartDate, RoomType, LOS, RateDate, Guests, OnsiteRate, NetRate, GrossRate, Curr, RateDescription, url_insert, url_insert, url_insert, RoomAmenity_Type, Mealtype, MaxOccupancy, isPromotionalRate, Closed, 30, StartDate , EndDate, intime, isAvailable, Taxtype, TaxAmount, Taxstatus, None, Ratetype, Discount,Promotion_Name,region,statuscode,israteperstay)
                array.append(aws_insert.insert(id_update, inputid , Domainname, Websitecode, StartDate, RoomType, LOS, RateDate, Guests, OnsiteRate, NetRate, GrossRate, Curr, RateDescription, url_insert, url_insert, url_insert, RoomAmenity_Type, Mealtype, MaxOccupancy, isPromotionalRate, Closed, 30, StartDate , EndDate, intime, isAvailable, Taxtype, TaxAmount, Taxstatus, None, Ratetype, Discount,Promotion_Name,region,statuscode,israteperstay))
        else:
            Closed     = 'Y'
            statuscode = '2'
            array.append(aws_insert.insert(id_update, inputid , Domainname, Websitecode, StartDate, RoomType, LOS, RateDate, Guests, OnsiteRate, NetRate, GrossRate, Curr, RateDescription, url_insert, url_insert, url_insert, RoomAmenity_Type, Mealtype, MaxOccupancy, isPromotionalRate, Closed, 30, StartDate , EndDate, intime, isAvailable, Taxtype, TaxAmount, Taxstatus, None, Ratetype, Discount,Promotion_Name,region,statuscode,israteperstay))
        Rtdate = re.sub(r'-|\-', '', str(RateDate))
        keyvalue = "ondemand/{}/{:%Y%m%d}/delivery/{}.json".format(Websitecode,datetime.datetime.now(),str(inputid)+'_'+str(Rtdate)+'_'+id_update)
        key = bucket.new_key(keyvalue)
        key.set_contents_from_string(json.dumps(array))
        return json.dumps(array)
        gc.collect()
    except Exception,e:
        print e
        value_error = str(re.sub(r"'", '"', str(e)))
        stacktrace = sys.exc_traceback.tb_lineno
        Guests = ''
        region = ''
        insert_value_error = str(value_error) + 'Where line number ' + str(stacktrace) + str(proxyip)
        statuscode = '4'
        keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(Websitecode, datetime.datetime.now(), id_update)
        key = bucket.new_key(keyvalue)
        key.set_contents_from_string(insert_value_error)
        array.append(aws_insert.insert(id_update, inputid , Domainname, Websitecode, "", "", "", "", Guests, "", "", "", "", "", url, url, url, "", "", "", "", "", "", StartDate, EndDate , "", "", "", "", "", "", "", "", "", region, statuscode,israteperstay))
        return json.dumps(array)                  
'''url       = 'https://www.bookonthenet.net/east/premium/eresmain.aspx?id=x3HwxWhkQUTe45DLnZa3tIzlogYE5vQQBA3l7pvE%2BaM%3D&#checkin=2017-11-01&checkout=2017-11-02&guests=1#'
inputid   = 'Test'            
id_update = ''
proxyip   = ''
fetchrates(url ,inputid, id_update, proxyip)'''
