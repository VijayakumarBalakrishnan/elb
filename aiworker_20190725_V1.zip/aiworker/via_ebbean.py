# -*- coding: utf-8 -*-
import re
import requests
import datetime
import json
import boto
import gc

import sys
import aws_insert
'''
inputid='Gokul'
id_update='12345'
proxyip='media:M3diAproxy@198.56.181.142:80'
url='https://in.via.com/hotels/search/9H22641/2017-08-12/2017-08-13/1/3-0/137/137#hotel'
'''
def fetchrates(url ,inputid, id_update, proxyip):    
    #print url
    array = []
    intime=re.sub(r'\s','T',str(datetime.datetime.now()))
    Domainname='Via.com'
    Websitecode='298'
    region=''
    israteperstay = ''
    statuscode=''
    conn = boto.connect_s3(aws_access_key_id= 'AKIAIXEGZVXCWE2FV3SQ',aws_secret_access_key = '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') 
    bucket = conn.get_bucket("rmapi")
    StartDate = datetime.date.today()
    EndDate  = datetime.date.today() + datetime.timedelta(days=29)
    try:
        proxies={"http": "http://{}".format(proxyip)}
        region=''
        ip=re.sub(r"\{'.*?@|'\}|:\d+","",str(proxies))
        try:
            try:
                r = requests.get('http://freegeoip.net/json/'+ip,timeout=30)
            except Exception,e:
                r = requests.get('http://freegeoip.net/json/'+ip,timeout=30)
            js = r.json()
            region=js['country_name']
        except Exception,e:
            region=''
        if re.search(r'search/(.*?)/(.*?)/(.*?)/', url):
            RateDate = re.search(r'search/(.*?)/(.*?)/(.*?)/', url).group(2)
            regionid = re.search(r'search/(.*?)/(.*?)/(.*?)/', url).group(1)
            Chkout   = re.search(r'search/(.*?)/(.*?)/(.*?)/', url).group(3)
        else:
            RateDate = ''
            regionid = ''
            Chkout   = ''
        delta = datetime.datetime.strptime(re.search(r'search/(.*?)/(.*?)/(.*?)/', url).group(3), "%Y-%m-%d") - datetime.datetime.strptime(re.search(r'search/(.*?)/(.*?)/(.*?)/', url).group(2), "%Y-%m-%d")
        LOS = delta.days
        Guests          = re.search(r'/(\d+)-0/', url).group(1)
        checkInDate     = datetime.datetime.strptime(str(RateDate),'%Y-%m-%d').strftime('%d/%m/%Y')
        checkOutDate    = datetime.datetime.strptime(str(Chkout),'%Y-%m-%d').strftime('%d/%m/%Y')
        J_URL           = 'https://in.via.com/apiv2/hotels/search?Room1Adults='+str(Guests)+'&Room1Children=0&residence=137&nationality=137&GAR=true&flowType=NODE&ajax=true&jsonData=false&authToken=553f5767-373f-4d98-9e6d-08fa87400a42&requestSource=NODE_B2C&__xreq__=true&action1=HOTELSEARCHRESULT&regionId='+str(regionid)+'&checkInDate='+str(checkInDate)+'&checkOutDate='+str(checkOutDate)+'&checkIn='+RateDate+'&checkOut='+str(Chkout)+'&rooms=1&guest[]='+str(Guests)+'-0&guest[]=137&guest[]=137'
        head = {'User-Agent':'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:12.0) Gecko/20100101 Firefox/31.0'}
        
        try:
            json_dat = requests.get(J_URL,headers=head,proxies=proxies,timeout=30)
            #print json_dat.status_code
        except Exception,e:
            print e
            try:
                json_dat = requests.get(J_URL,headers=head,proxies=proxies,timeout=30)
            except Exception,e:
                print e
                value_error=str(re.sub("'",'"',str(e)))
                stacktrace=sys.exc_traceback.tb_lineno
                insert_value_error=str(value_error)+'Where line number '+str(stacktrace)+str(proxyip)
                print insert_value_error
                keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(Websitecode,datetime.datetime.now(),id_update)
                key = bucket.new_key(keyvalue)
                key.set_contents_from_string(insert_value_error)
                statuscode=5
                Guests='1'
                array.append(aws_insert.insert(id_update, inputid ,Domainname,Websitecode, "","", "", "", Guests, "", "", "", "", "",url, url, url, "", "", "", "", "", "",StartDate, EndDate , "", "", "", "", "", "",  "", "", "",region,statuscode, israteperstay))
                return json.dumps(array)
        if (json_dat.status_code<> 200):
            json_dat = requests.get(J_URL,headers=head,proxies=proxies)
        if (json_dat.status_code == 403 or json_dat.status_code == 407 or json_dat.status_code <> 200):
            try:
                json_dat = requests.get(J_URL,headers=head,proxies=proxies)
            except Exception as e:
                json_dat = requests.get(J_URL,headers=head)
                if json_dat.status_code <> 200:
                    value_error=str(re.sub("'",'"',str(e)))
                    stacktrace=sys.exc_traceback.tb_lineno
                    insert_value_error=str(value_error)+'Where line number '+str(stacktrace)+str(proxyip)
                    print insert_value_error
                    keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(Websitecode,datetime.datetime.now(),id_update)
                    key = bucket.new_key(keyvalue)
                    key.set_contents_from_string(insert_value_error)
                    statuscode=5
                    Guests='1'
                    array.append(aws_insert.insert(id_update, inputid ,Domainname,Websitecode, "","", "", "", Guests, "", "", "", "", "",url, url, url, "", "", "", "", "", "",StartDate, EndDate , "", "", "", "", "", "",  "", "", "",region,statuscode, israteperstay))
                    return json.dumps(array)
            
        json_data=json_dat.text.encode('utf-8')
        json_data = json.loads(json_data)
        Rtdate=re.sub(r'-|\-','',RateDate)
        keyvalue = "ondemand/{}/{:%Y%m%d}/source/{}.json".format(Websitecode,datetime.datetime.now(),str(inputid)+'_'+str(Rtdate)+'_'+id_update)
        key = bucket.new_key(keyvalue)
        key.set_contents_from_string(str(json_data))
        Roomtype = " "
        RateDescription=''
        OnsiteRate = 0
        GrossRate = 0
        NetRate=0
        Closed_up = 'N'
        RoomAmenityType = ""
        Curr='INR'
        Maxocp = None
        isPromotionalRate = 'N'
        Spaceblock=''
        promotion=''
        Roomavilable = ''
        Taxtype = ''
        MealInclusion_Type=''
        Taxamount = 0
        Ratetype = ''
        Tax_status=''
        TotalResellerNetPrice=0    

        if 'HotelList' in json_data:
            hsq       = json_data['hsq']
            HotelList = json_data['HotelList']
            RoomID    = len(HotelList[0]['Results'])
            if RoomID!=0:
                i = 0
                for i in range(RoomID):
                    Closed_up          ="N" 
                    Rooms = HotelList[0]['Results'][i]
                    if 'BookingFlowId' in Rooms:
                        BookingFlowId = Rooms['BookingFlowId']
                    else:
                        BookingFlowId = ''
                    if 'ProductId' in Rooms:
                        ProductId = Rooms['ProductId']
                    else:
                        ProductId = ''
                    if 'SkuCode' in Rooms:
                        SkuCode = Rooms['SkuCode']
                    else:
                        SkuCode = ''    
                    RoomId = Rooms['RoomId']
                    if re.search(r'RoomId":"'+str(RoomId)+'".*?RoomExtraParams":({.*?}),"Inc', str(json_dat)):
                        Params  = re.search(r'RoomId":"'+str(RoomId)+'".*?RoomExtraParams":({.*?}),"Inc', str(json_dat)).group(1)
                    else:
                        Params  = ''
                    Cancel_URL  = 'https://in.via.com/apiv2/hotels/fare-policies?&flowType=NODE&ajax=true&jsonData=false&authToken=553f5767-373f-4d98-9e6d-08fa87400a42&requestSource=NODE_B2C&__xreq__=true&action1=FETCH_CANCELLATION_POLICIES&search_query='+str(hsq)+'&bookingFlow='+str(BookingFlowId)+'&apiParams='+str(Params)+'&skuCode='+str(SkuCode)+'&roomId='+str(RoomId)+'&productId='+str(ProductId)
                    if 'RoomName' in Rooms:
                        Roomtype = Rooms['RoomName']
                    else:
                        Roomtype = ''
                    if 'TotalPrice' in Rooms:
                        OnsiteRate = Rooms['TotalPrice']
                    else:
                        OnsiteRate = 0
                    
                    if 'TotalTaxes' in Rooms:
                        Taxamount = Rooms['TotalTaxes']
                        Tax_status=1
                    else:
                        Taxamount = 0  
                           
                    if 'TotalResellerNetPrice' in Rooms:
                        TotalResellerNetPrice = Rooms['TotalResellerNetPrice']
                    else:
                        TotalResellerNetPrice = 0
                        
                    if 'MealPlan' in Rooms:
                        MealPlan = Rooms['MealPlan']
                    else:
                        MealPlan = ''      

                    if 'Inclusions' in Rooms:
                        inclusions = re.sub(r"\u'","'",re.sub(r"\[|\]",'',str(Rooms['Inclusions'])))
                        inclusions = str(inclusions)+' '+str(MealPlan)
                    else:
                        inclusions = ''
                        inclusions = MealPlan
                    if Rooms.has_key('RoomDeals'):
                        if Rooms['RoomDeals']:
                            promotion=Rooms['RoomDeals'][0]['DealText']
                        ##print"promotion :",promotion
                        else:
                            promotion=''
                    else:
                        promotion=''     
                    
                    
                    if 'nonRefundable'in Rooms['RoomExtraParams']:
                        nonRefundable = Rooms['RoomExtraParams']['nonRefundable']
                    else:
                        nonRefundable = ''
                    if nonRefundable:
                        Ratetype = 'Non Refundable'
                    elif re.search(r'Non Refundable|NonRefundable|Non-Refundable',str(Roomtype)):
                        Ratetype = 'Non Refundable'
                    elif nonRefundable == False:
                        Ratetype = 'Refundable'
                    else:
                        if 'Refundable' in Rooms:
                            if Rooms['Refundable'] == False:
                                Ratetype = "Non Refundable"
                            if Rooms['Refundable'] == True:
                                Ratetype = "Refundable"
                        else:
                            RatetypeHtml = requests.get(Cancel_URL,headers=head,proxies=proxies).text
                            if re.search(r'(?sim)Non Refundable|NonRefundable|Non-Refundable',str(RatetypeHtml)):
                                Ratetype = 'Non Refundable'
                            else:
                                Ratetype = ''
                    Mealtype_str = str(inclusions)+' ' +str(Roomtype)
                    MealInclusion_Type=Mealtype_str
                    if re.search(r"All Applicable Taxes", str(inclusions), re.IGNORECASE):
                        if OnsiteRate==TotalResellerNetPrice:
                            Taxtype = 'Include'
                            Tax_status = 1
                        else:
                            Taxtype = 'Not Include'
                            Tax_status = 2
                    else:
                        Taxtype = 'Not Include'
                        Tax_status = 2         
                    if OnsiteRate == 0:
                        Tax_status = -1
                        Closed_up ="Y"
                    if LOS > 1:
                        israteperstay = 'N'
                    else:    
                        israteperstay = 'Y'
                    if (NetRate == 0 or NetRate == '') and (promotion == 0 or promotion == ''):
                        isPromotionalRate = 'N'
                    ##print (id_update, inputid , Domainname, Websitecode, StartDate, Roomtype, LOS, RateDate, Guests, OnsiteRate, NetRate, GrossRate, Curr, RateDescription, url, url, url, RoomAmenityType, MealInclusion_Type, Maxocp, isPromotionalRate, Closed_up, 30, StartDate , EndDate, intime, Roomavilable, Taxtype, Taxamount, Tax_status, Spaceblock, Ratetype, NetRate,promotion,region,statuscode)
                    array.append(aws_insert.insert(id_update, inputid , Domainname, Websitecode, StartDate, Roomtype, LOS, RateDate, Guests, OnsiteRate, NetRate, GrossRate, Curr, RateDescription, url, url, url, RoomAmenityType, MealInclusion_Type, Maxocp, isPromotionalRate, Closed_up, 30, StartDate , EndDate, intime, Roomavilable, Taxtype, Taxamount, Tax_status, Spaceblock, Ratetype, NetRate,promotion,region,statuscode, israteperstay))
                    i=i+1        
            else:
                Closed_up = 'Y'
                statuscode='2'
                array.append(aws_insert.insert(id_update, inputid , Domainname, Websitecode, StartDate, Roomtype, LOS, RateDate, Guests, OnsiteRate, NetRate, GrossRate, Curr, RateDescription, url, url, url, RoomAmenityType, MealInclusion_Type, Maxocp, isPromotionalRate, Closed_up, 30, StartDate , EndDate, intime, Roomavilable, Taxtype, Taxamount, Tax_status, Spaceblock, Ratetype, NetRate,promotion,region,statuscode, israteperstay))
        else:
            Closed_up = 'Y'
            statuscode='2'
            array.append(aws_insert.insert(id_update, inputid , Domainname, Websitecode, StartDate, Roomtype, LOS, RateDate, Guests, OnsiteRate, NetRate, GrossRate, Curr, RateDescription, url, url, url, RoomAmenityType, MealInclusion_Type, Maxocp, isPromotionalRate, Closed_up, 30, StartDate , EndDate, intime, Roomavilable, Taxtype, Taxamount, Tax_status, Spaceblock, Ratetype, NetRate,promotion,region,statuscode, israteperstay))
        Rtdate=re.sub(r'-|\-','',RateDate)
        keyvalue = "ondemand/{}/{:%Y%m%d}/delivery/{}.json".format(Websitecode,datetime.datetime.now(),str(inputid)+'_'+str(Rtdate)+'_'+id_update)
        key = bucket.new_key(keyvalue)
        key.set_contents_from_string(json.dumps(array))
        gc.collect()
        return json.dumps(array)    
    except Exception as e:
        print e
        insert_value_error=str(str(re.sub(r"'",'"',str(e))))+'Where line number '+str(sys.exc_traceback.tb_lineno)+str(proxyip)
        print insert_value_error
        statuscode='4'
        Guests='1'
        keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(Websitecode,datetime.datetime.now(),id_update)
        key = bucket.new_key(keyvalue)
        key.set_contents_from_string(insert_value_error)
        array.append(aws_insert.insert(id_update, inputid ,Domainname,Websitecode, "","", "", "", Guests, "", "", "", "", "",url, url, url, "", "", "", "", "", "",StartDate, EndDate , "", "", "", "", "", "",  "", "", "",region,statuscode, israteperstay))
        return json.dumps(array)


#fetchrates(url ,inputid, id_update, proxyip)
