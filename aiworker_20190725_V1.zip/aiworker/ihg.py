# -*- coding: utf-8 -*-
import re
import requests
import datetime
import operator
import json
import sys 
import boto
import gc

import aws_insert

def fetchrates(url , inputid, id_update, proxyip):
    array = []
    intime = re.sub(r'\s', 'T', str(datetime.datetime.now()))
    functionname = 'IHG.crowneplaza'
    Websitecode = 371
    LastModified = intime
    israteperstay = ''
    try:
        conn = boto.connect_s3(aws_access_key_id='AKIAIXEGZVXCWE2FV3SQ', aws_secret_access_key='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') 
        bucket = conn.get_bucket("rmapi")
        StartDate = datetime.date.today()
        EndDate = datetime.date.today() + datetime.timedelta(days=29)
        Websitecode = 371
        Domainname = "IHG.crowneplaza"
        chkins = re.search(r'checkin=(.*?)&', url).group(1)
        chkouts = re.search(r'checkout=(.*?)&', url).group(1)
        txtadult = re.search(r'adult=(.*?)$', url).group(1)
        checkins = datetime.datetime.strptime(chkins, str("%Y-%m-%d")).strftime("%Y, %m, %d")
        checkouts = datetime.datetime.strptime(chkouts, str("%Y-%m-%d")).strftime("%Y, %m, %d")
        ccin = datetime.datetime.strptime(checkins, '%Y, %m, %d')
        ccout = datetime.datetime.strptime(checkouts, '%Y, %m, %d')
        LOS = ccout - ccin
        LOS = LOS.days
        RateDate = chkins
        a1 = datetime.datetime.strptime(str(chkins),'%Y-%m-%d').strftime('%d')
        b1 = datetime.datetime.strptime(str(chkins),'%Y-%m-%d').strftime('%m')
        c1 = datetime.datetime.strptime(str(chkins),'%Y-%m-%d').strftime('%Y')
        ##print a1
        if "01" in b1:
            monn = "00"
        elif "02" in b1:
            monn = "01"
        elif "03" in b1:
            monn = "02"
        elif "04" in b1:
            monn = "03"
        elif "05" in b1:
            monn = "04"
        elif "06" in b1:
            monn = "05"
        elif "07" in b1:
            monn = "06"
        elif "08" in b1:
            monn = "07"
        elif "09" in b1:
            monn = "08"
        elif "10" in b1:
            monn = "09"
        elif "11" in b1:
            monn = "10"
        elif "12" in b1:
            monn = "11"
        #print "day:", str(a1)
        #print "month:",str(b1)
        #print "year:",str(c1)
        d = datetime.datetime.strptime(str(chkouts),'%Y-%m-%d').strftime('%d')
        e = datetime.datetime.strptime(str(chkouts),'%Y-%m-%d').strftime('%m')
        f = datetime.datetime.strptime(str(chkouts),'%Y-%m-%d').strftime('%Y')
        #print "day:", str(d)
        #print "month:",str(e)
        #print "year:",str(f)
        if "01" in e:
            mon = "00"
        elif "02" in e:
            mon = "01"
        elif "03" in e:
            mon = "02"
        elif "04" in e:
            mon = "03"
        elif "05" in e:
            mon = "04"
        elif "06" in e:
            mon = "05"
        elif "07" in e:
            mon = "06"
        elif "08" in e:
            mon = "07"
        elif "09" in e:
            mon = "08"
        elif "10" in e:
            mon = "09"
        elif "11" in e:
            mon = "10"
        elif "12" in e:
            mon = "11"
        main_url = url
        main_url = re.sub(r"qCiD=.*?&", "qCiD="+a1+"&",main_url)
        main_url = re.sub(r"qCiMy.*?&", "qCiMy="+monn+c1+"&",main_url)
        main_url = re.sub(r"qCoD=.*?&", "qCoD="+d+"&",main_url)
        main_url = re.sub(r"qCoMy.*?&", "qCoMy="+mon+f+"&",main_url)
        main_url = re.sub(r"qAdlt.*?&", "qAdlt="+txtadult+"&",main_url)
        main_url = re.sub(r"#.*", "",main_url)
        #print "changed: ", main_url
        url = main_url
        '''if 'holiday' in url_db.lower():
            cookies_head = 'akaas_RBF=2147483647~rv=92~id=d290e099ebc16ec8f34bfc60f4fdff5a; UXER=3j9uNEOtb0i_m-rWeW9A1BU5Ke998R-hWgfywLVQ8_PXJ5vzR_BO3Yg; AMCV_8EAD67C25245B1870A490D4C%40AdobeOrg=2096510701%7CMCMID%7C10409503876335106273561442059404778417%7CMCAAMLH-1502344221%7C3%7CMCAAMB-1502344221%7CNRX38WO0n5BH8Th-nqAG_A%7CMCOPTOUT-1501746621s%7CNONE%7CMCAID%7CNONE%7CMCSYNCSOP%7C411-17389%7CvVersion%7C2.0.0; mbox=session#a580660b629d44eb95ab83fdb1572685#1501741286|PC#a580660b629d44eb95ab83fdb1572685.22_22#1564984226; country_language="in$:en"; aam_tnt=seg6%3DgenericVisitor; aam_interact=seg%3D1493298; aam_uuid=10121984268616517123536160687749989458; __CT_Data=gpv=5&apv_16508_www03=5&cpv_16508_www03=5&rpv_16508_www03=5; WRUIDReset20160501=1338065481670722; recentSearch=cYNX0rvChvz-LkQo9lCBuZn_BsJEWykFiNTug4u5mnAK0B-BIS8H6bSHlFf4vu313e4lfuBbxHRKc5YkGZRx7UW6F8rfkNdVcZUK9GwpHRLpXursuRwqhN8EELa42bGN3oQizNvqD4bXHoxvydTxN4bglKxrnnTphuhi-bcl_xd3zmrbtq8CLa3OUHBsXOKVpuGWLaEi_I7-GBVvdeSebZx3KamJUzFbBhEs2U95iUpxLa7qAqvgzDEqOMKDfzpqwNO427M_XyLf72jjwUBd6gC-N555qyDWwvJoIbdu5vUYVB_34OAH3ohnaaCFc_3jTcXaACMlMUAqCAgw0hQQmIHwW7bwsx4p0--Cm9OeYzyvG__ohn_ORk0dKHGbshyOighSV27Koz4ibhLa'
        elif 'intercontinental' in url_db.lower():
            cookies_head = 'recentSearch=cYNX0rvChvz-LkQo9lCBuZn_BsJEWykFiNTug4u5mnAK0BOaIS8H6bSHlFf4vu313e43ZOZbxTokJrAtCJtltQqBVYP9kMEYTY8frCkPUVe_U-3u0EoqhckfU7jnnfDYjIR6w4_vAIaQEJ4qkcX5fJW036Jz3yv9jPJg-rYh7wtkmieEoK9dar_MGWI8HeLS7KKVLuY0pcHtTA1lP6eAf9thKfK4M0o5aRFymgwxiUZpMsOaI_vu1HIwc9a9Wjg60Y_zgr80RiLT-Wji0EBX_gC-MZ4mpiDTzvJ-Ordm-fkCFVnxrPRQxtR5ZazaIaP9C9GJCS0rcEd4EEkw1hZHx5HsVeTu4QYjn--CgMieYzP_Huq3wWGFSB0SLDbx4kLYnBkCTyDWozczP23URhHUmAW2xngxZxKusPq7M55gkjd1vUHuyDqsZIW0ZZS4XQYw8ROZvB9uuWVwk5REZ6-iBZbuNNQs9njH14XmkWk3ziL9xbiHRSq9pUNwzL4Kpg7B_2bn7LopKB7bceq_Y0W6dkNAL1yvJuXDcYvD32s94TVDjIVgSAjlR-1Vn0Hm5wtLlLJvtN-Ju0gRfKQ92jcBgUdTSVyqxDGSDkW01a4AZjdttFJiqxReLwSLnDQX19LuGCxv8D2mVG2urW-u6hyT7RqPE2P-JepX6eV-1p3cKkRaNraqGTQs54YdOrRZFmHgWrX9qPZnyr3NBWUYk64sycpoqZBZe7A9tvptdZk2PCnxHQjkXSfA16YeGcW8vgiAxxBysMrgz6Qe51pt20XC3IdPzsNIzK6_QfLLOJV4Ucgar5OZHkqH43qIa_1-_1Lfq5Y5wFwX-alMeGbEPlfNBtb_mR4mLV2AgC9ZiZ2CgUN-2VzLuuFXiatEn5jQ1GLQk5dbLGTgKGnU6bZyobzHUbYmeCqA6ybFjd-WK-tsLg1Z3xNusgoIODh10GIOnAkf65YFdrYXTnRMAWCS7V3y14-F7Xd5rDtoYpOtNYLmNqJEeJkrbrqpUKC0Noe6RIqE2a3cTzl2Hd6BqxKcAW8_Pq4QvPmElIg5v6-7V6UV0nYyWXZHEcbh6i5mog-xW67cOc3vAT_kz5rerKGYgF9VuNoj_EpdOA56HEgzwRBt45u6kFgNLgO_Re0T1Jh5lljsjR2Dqh0R8UpK3_rgtAqSVS0yO-wcctDO_KyW6KKe9Xe6dFIZBgw4bU6_dyNmIW-nlxIadvYXGIvnV6dxJ98UMBohs2ut6GKLmrc9BfHYBxTJkEFRtyjE_Sl2uxKSqx0ruduV7RaGf5k_pcOprxRmn4htKWIIOnCaLBo9g6NG457KLwvlxeG0EfzgVzuIaV-em1MMDwaP7CSDijMGbPszzG21DJYwn8UvGoTnG0zrpG5cy_MnEbidYa5D0WKriFk424L6yAVEQVfqmMsQ-KHKOBt5lpxOjJXpoBDrE9Wk6NLn4p6DOJoaVl8K2dsEzWDigXD4w5Lf9vzqVeAJAfzRRezxVPg6RnRKCgMaDZ1IHy7HdG6sU62mqADFjswz2bsjn3vllLBjD80gU4uMrAFwe01tKIzQ7C0tqsqiUwup-7E7Sju48oaEzxa1ZnRzhAoi9bhV_fc87y0MeRAHO4K63OPgnGxyxkRcaHy4FHU5jSKxBMwlq1l6W4ieoNgo4_mfboZBDgL5etWBjetMYzS8gmxh_GW6; mbox=PC#1481777248796-692912.22_15#1496228113|session#1488450765856-661819#1488453973|check#true#1488452173; AMCV_8EAD67C25245B1870A490D4C%40AdobeOrg=1256414278%7CMCMID%7C68717993967779822036072920536111277084%7CMCAID%7CNONE%7CMCAAMLH-1489035165%7C3%7CMCAAMB-1489035165%7CNRX38WO0n5BH8Th-nqAG_A; s_nr=1488452114604-Repeat; cvp_cha_n=%5B%5B%27Google%2520Places%27%2C%271485868315828%27%5D%2C%5B%27Direct%2520Type%2FBookmark%27%2C%271488430368202%27%5D%2C%5B%27Google%2520Places%27%2C%271488448500605%27%5D%2C%5B%27Direct%2520Type%2FBookmark%27%2C%271488448696754%27%5D%2C%5B%27Google%2520Places%27%2C%271488452090818%27%5D%5D; country_language="in$:en"; ipe_v=443206ac-1c2a-3277-0361-b0b3a7596d70; atgRecVisitorId=134BMRTP7mDWEAMwLjBQHM2FPaRlro37po0EHwMDXE0fs6YEEFE; recentlyViewed=WSSUT**HYDHY**AUSHA; s_v38=GoogleMaps-_-IC-_-USA-_-AUSHA; aam_tnt=seg6%3DgenericVisitor; aam_uuid=68555241455447508726068994993595972607; __CT_Data=gpv=30&apv_16508_www03=30&cpv_16508_www03=30&rpv_16508_www03=29; WRUIDReset20160501=1078033185120822; datacenternode=us-va-iadd1; X-IHG-SRV=iadd1plb2cwb013; BlueStripe.PVN=8b755baf00013304; JSESSIONID=1E4BC2CD5D62D76A398F7EF7339B981F; hotelicopterCookie=isEligibleForRoomkey^false**isInSplitTraffic^false**isOverridePopunder^; ibean=F-ICbMW0yzOKvAw0napofjl3a5t-vAA0mYptRST36gjDx-L-rPnpaDA_Igr7dnZe7hdXBQwAh9P_-THvq6RRV_FeGTPBWQwuM_WwSPxy1nVCObQlrCo3B9-nT_v7zU9KdfrliNKCqstu2iHtz7o-fmofVgMt4wobw9UOSN1qwivzeNnQICmbb_qbZvDydqwCxUCrDCXMGM_Mxha5j_aJ7R10L_aIaBXVA63iwQZ-xbVb75IdQ28e5l97lmTo3j8idIHJnHykg610NtmZmfHXzX-f2bBWN6p25XJ8VrVjbJN2bFVULXnW3fYa4XkbTrgGbqBIOcuV5bGPdRM; akamaiCountryCode=IN; ensUID=06171022kilGjKHESDli; UXER=3GWVSLIDI0xDAm4fU1eVFo63LWO8NWMgF7f1H6IQATi9M3n34X0KT6g; uhf_userstate=ANONYMOUS; c_m=GoogleMaps-_-IC-_-USA-_-AUSHAwww.google.co.inPaid%20Search; s_cc=true; s_sq=%5B%5BB%5D%5D; X-IHG-TrueClient_IP=202.129.198.133; X-IHG-GAPI-SRV=iadd1plapiwb010; ipe_s=a3445e4f-7b27-657f-2c24-8a446e81048f; ipe.335.pageViewedCount=11; eu_cookie=; ADRUM=s=1488451104351&r=https%3A%2F%2Fwww.ihg.com%2Fhotels%2Fgb%2Fen%2Freservation%2Fbook%3F-540006026; CopterConnect=9CE97F10-B97A-4F45-907A-3EF6029BD56E%7Cae020d407073c7e711f5649ef9844ec4%7CIHGRoomkeypop; roomKeyCookie=1488434017797; xdVisitorId=134BMRTP7mDWEAMwLjBQHM2FPaRlro37po0EHwMDXE0fs6YEEFE; atgPlatoStop=1; fs_nocache_guid=DD9255411BA9B361B8F2426D583E8420; s_v0=GoogleMaps-_-IC-_-USA-_-AUSHA; s_v37=GoogleMaps-_-IC-_-USA-_-AUSHA; ak_bmsc=FFB08787BD0C78AE1ED4C9A1A4262FEA170BD74703480000F0EBB758CE575C53~plTz+p4t16v6ANR3rszm9+tnfkk2+tT7XFX9SLoLaNE2PMZWlJ48vQL3DQYdFg+e4xQD+CQdO+pQpRzmq8/dMbya8HWOxslXyfyMryCSVE2bClIEHbkoCv/0uleb+4QoutLeWeekjsNzmBLNorJScWYyNavMsy6+Q3z/322dM1ekbRfxnRVSbHMyi5MBvvn2140aSp+YYQSaowefvkXZLOZg==; c_m_d=1; prevPageName=IC%3A%20RESERVATION%20%3A%20ROOMRATE; BTT_X0siD=726746858686164688; BTT_Collect=on; BTT_WCD_Collect=off; adimpressions=OSMGL-GB-EN-MAN-Footer-AppDownload'
        '''
        cookies_head = ''
        head = {'User-Agent':'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:12.0) Gecko/20100101 Firefox/12.0','Host':'www.ihg.com','Cookie': str(cookies_head)}
        proxies = {"http": "http://{}".format(proxyip)}
        region = ''
        ip = re.sub(r"\{'.*?@|'\}|:\d+", "", str(proxies))
        try:
            try:
                r = requests.get('http://freegeoip.net/json/' + ip, timeout=30)
            except Exception, e:
                r = requests.get('http://freegeoip.net/json/' + ip, timeout=30)
            js = r.json()
            region = js['country_name']
        except Exception, e:
            region = ''
        try:
            hml = requests.get(url,headers=head, proxies=proxies, timeout=100)
        except Exception, e:
            value_error = str(re.sub("'", '', str(e)))
            stacktrace = sys.exc_traceback.tb_lineno
            try:
                hml = requests.get(url, headers=head, proxies=proxies, timeout=120)
            except Exception, e:
                try:
                    hml = requests.get(url, headers=head, proxies=proxies, timeout=150)
                except Exception, e:
                    value_error = str(re.sub("'", '', str(e)))
                    stacktrace = sys.exc_traceback.tb_lineno
                    keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(Websitecode, datetime.datetime.now(), id_update)
                    key = bucket.new_key(keyvalue)
                    key.set_contents_from_string(str(e) + 'Where Line number' + str(stacktrace) + str(proxies))
                    statuscode = 5
                    Guests = ''
                    array.append(aws_insert.insert(id_update, inputid , functionname, Websitecode, "", "", "", "", Guests, "", "", "", "", "", url, url, url, "", "", "", "", "", "", StartDate, EndDate , "", "", "", "", "", "", "", "", "", region, statuscode, israteperstay))
                    return json.dumps(array)
        if hml.status_code <> 200:
            hml = requests.get(url, headers=head, proxies=proxies)
        if (hml.status_code == 403 or hml.status_code == 407) or hml.status_code <> 200:
            try:
                if hml.status_code <> 200:
                    hml = requests.get(url, headers=head)
            except Exception, e:
                value_error = str(re.sub("'", '', str(e)))
                stacktrace = sys.exc_traceback.tb_lineno
                keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(Websitecode, datetime.datetime.now(), id_update)
                key = bucket.new_key(keyvalue)
                key.set_contents_from_string(str(e) + 'Where Line number' + str(stacktrace) + str(proxies))
                statuscode = 5
                Guests = ''
                array.append(aws_insert.insert(id_update, inputid , functionname, Websitecode, "", "", "", "", Guests, "", "", "", "", "", url, url, url, "", "", "", "", "", "", StartDate, EndDate , "", "", "", "", "", "", "", "", "", region, statuscode, israteperstay))
                return json.dumps(array)
        html = hml.text
        html = html.encode('ascii', 'ignore')
        if 'Loading...' in html:
            hml = requests.get(url, headers=head ,timeout = 50)
        html = hml.text
        html = html.encode('ascii', 'ignore')
        if 'Loading...' in html:
            hml = requests.get(url, headers=head , proxies=proxies, timeout = 50)
        html = hml.text
        html = html.encode('ascii', 'ignore')
        Rtdate=re.sub(r'-|\-','',str(RateDate))
        keyvalue = "ondemand/{}/{:%Y%m%d}/source/{}.html".format(Websitecode, datetime.datetime.now(), str(inputid) + '_' + str(Rtdate) + '_' + id_update)
        #print keyvalue
        key = bucket.new_key(keyvalue)
        key.set_contents_from_string(html)     
        Websitecode = Websitecode
        RoomType = ""
        Guests = txtadult
        OnsiteRate = 0
        NetRate = 0
        Curr = ""
        RateDescription = ""
        RoomAmenity_Type = ""
        MealInclusion_Type = ""
        MaxOccupancy = None
        isPromotionalRate = "N"
        Closed_up = "Y"
        LastModified = LastModified
        isAvailable = ""
        Taxtype = ""
        TaxAmount = 0
        RateType = ""
        Promotion_Name = ""
        Tax_status = ''
        OnsiteRate_back = 0
        if 'Loading...' not in html:
            reg_block = re.search('DescriptionToggle">.*?<div class="viewAllRatesLink">',html,re.DOTALL)
            if reg_block:
                for block in re.compile(r'DescriptionToggle">.*?<div class="viewAllRatesLink">',re.DOTALL).findall(html):
                    for blocks in re.compile(r'<div class="rateTypeLine.*?Nightly Rate.*?Book This Room',re.DOTALL).findall(block):
                        if "Bonus Points for Any Stay" not in blocks:
                            RoomType=""
                            OnsiteRate= 0
                            NetRate= 0
                            Curr=""
                            RateDescription=""
                            RoomAmenity_Type=""
                            MealInclusion_Type=""
                            MaxOccupancy= None
                            isPromotionalRate="N"
                            Closed_up="N"
                            isAvailable=""
                            Taxtype=""
                            TaxAmount= 0
                            Promotion_Name=""
                            statuscode = ''
                            RateType=""
                            room_type=re.search('DescriptionToggle">(.*?)</a>',block)
                            if room_type:
                                rooms=room_type.group(1)
                                RoomType=re.sub('Room Type|\'','',rooms)
                                #print "Room_Type        :",RoomType
                            rooms=re.search('Only\s*.*?(\d+).*?room',block)
                            if rooms:
                                isAvailable1=rooms.group(1)
                                isAvailable=re.sub('<.*?>|\s+','',isAvailable1)
                                #print "Room_Left        :",isAvailable
                            Max=re.search('<span class="rateDetailsMaxOccupancy">\s*(.*?)\s*</span>',block,re.DOTALL)
                            if Max:
                                MaxOccupancy_1=Max.group(1)
                                MaxOccupancy_2=re.sub('<.*?>','',MaxOccupancy_1)
                                MaxOccupancy=re.sub('\s+',' ',MaxOccupancy_2)
                                #print "Max_Occupancy        :",MaxOccupancy
                            descript=re.search('<span class="roomLongDescription"\s*>\s*(.*?)\s*</span>',block,re.DOTALL)
                            if descript:
                                RateDescription_1=descript.group(1)
                                RateDescription = re.sub("\$|<.*?>","",RateDescription_1)
                                #print "Descriptipon        :",RateDescription
                            Ratetyp=re.search('<img src="/hotels/images/ex/icn_checkmark\.png"/>(.*?)</span>',blocks,re.DOTALL)
                            Ratetyp1=re.search('<ul>\s*<div><li.*?>(.*?)<',blocks,re.DOTALL)
                            if Ratetyp:
                                price_typ=Ratetyp.group(1)
                                price = re.sub("<.*?>","",price_typ)
                                RateType = re.sub("\s+","",price)
                                #print "Price_Type        :",RateType
                            elif Ratetyp1:
                                price_typ=Ratetyp1.group(1)
                                price = re.sub("<.*?>","",price_typ)
                                RateType = re.sub("\s+","",price)
                                #print "Price_Type        :",RateType
                            Ratetype2 = ''
                            Ratetype_reg_block = re.search('GroupHeader">\s*<span class="notranslate">\s*(.*?)\s*</span>',blocks,re.DOTALL)
                            if Ratetype_reg_block:
                                Ratetype_reg = Ratetype_reg_block.group(1)
                                Ratetype_ = re.sub("<.*?>","",Ratetype_reg)
                                Ratetype2 = re.sub("\s+"," ",Ratetype_)
                                #print "Price_Type2       :",Ratetype2
                                RateType = str(RateType)+' ('+str(Ratetype2)+')'
                                #print RateType
                            else:
                                Ratetype_reg_block = re.search('class="rateCategory roomOrder".*?>\s*(.*?)\s*</span>',blocks,re.DOTALL)
                                if Ratetype_reg_block:
                                    Ratetype_reg = Ratetype_reg_block.group(1)
                                    Ratetype_ = re.sub("<.*?>","",Ratetype_reg)
                                    Ratetype2 = re.sub("\s+"," ",Ratetype_)
                                    #print "Price_Type2       :",Ratetype2
                                    RateType = str(RateType)+' ('+str(Ratetype2)+')'
                                    #print RateType
                            curr_re = re.search('code">(.*?)</span>',blocks)
                            if curr_re:
                                Curr= curr_re.group(1)
                                #print"Currency   :",Curr
                            old_price=re.search('<span class="cc_lrm">.*?cc_number">(.*?)</span>.*?code">.*?</span>.*?<!--',blocks,re.DOTALL)
                            if old_price:
                                price=old_price.group(1)
                                OnsiteRate = re.sub("\$|,","",price)
                                #print "Room_Price        :",OnsiteRate
                            meals=re.search('<li class="BREAKFAST_.*?"\s*>(.*?)</li></div>',blocks)
                            if meals:
                                MealInclusion_Type1=meals.group(1)
                                MealInclusion_Type = re.sub("\$|<.*?>","",MealInclusion_Type1)
                                #print "Meal_type        :",MealInclusion_Type
                            if 'Add Breakfast' in blocks:
                                MealInclusion_Type = ''
                            if OnsiteRate <> 0:
                                statuscode = ''
                            else:
                                statuscode = 1
                            LOS = int(LOS)
                            if int(LOS) >1:
                                israteperstay = 'N'
                            else:
                                israteperstay ='Y'
                            Tax_status = 1
                            if OnsiteRate_back != OnsiteRate:
                                #print (id_update, inputid , Domainname, Websitecode, StartDate, RoomType, LOS, RateDate, Guests, OnsiteRate, NetRate, OnsiteRate, Curr, RateDescription, url, url, url, RoomAmenity_Type, MealInclusion_Type, MaxOccupancy, isPromotionalRate, Closed_up, 30, StartDate , EndDate, intime, isAvailable, Taxtype, TaxAmount, Tax_status, None, RateType, NetRate, Promotion_Name, region, statuscode, israteperstay)
                                array.append(aws_insert.insert(id_update, inputid , Domainname, Websitecode, StartDate, RoomType, LOS, RateDate, Guests, OnsiteRate, NetRate, OnsiteRate, Curr, RateDescription, url, url, url, RoomAmenity_Type, MealInclusion_Type, MaxOccupancy, isPromotionalRate, Closed_up, 30, StartDate , EndDate, intime, isAvailable, Taxtype, TaxAmount, Tax_status, None, RateType, NetRate, Promotion_Name, region, statuscode, israteperstay))
                            OnsiteRate_back = OnsiteRate
            else:
                statuscode = '2'
                #print "statuscode    :", statuscode
                Closed_up = "Y"
                da_time = datetime.datetime.now()
                LastModified = re.sub(r'\s', 'T', str(da_time))
                Tax_status = ''
                # insert(HotelCode,Websitecode,ReportDate,RoomType,LOS,RateDate,Guests,OnsiteRate,NetRate,GrossRate,Curr,RateDescription,HotelId,urlRate,urlInclusions,urlAmenities,RoomAmenity_Type,MealInclusion_Type,MaxOccupancy,isPromotionalRate,Closed,NumberOfDays,StartDate,EndDate,LastModified,isAvailable,Taxtype,TaxAmount,HotelBlock,RateType,Discount,Promotion_Name)
                ##print (id_update, inputid , Domainname, Websitecode, StartDate, RoomType, LOS, RateDate, Guests, OnsiteRate, NetRate, OnsiteRate, Curr, RateDescription, url, url, url, RoomAmenity_Type, MealInclusion_Type, MaxOccupancy, isPromotionalRate, Closed_up, 30, StartDate , EndDate, intime, isAvailable, Taxtype, TaxAmount, Tax_status, None, RateType, NetRate, Promotion_Name, region, statuscode, israteperstay)
                array.append(aws_insert.insert(id_update, inputid , Domainname, Websitecode, StartDate, RoomType, LOS, RateDate, Guests, OnsiteRate, NetRate, OnsiteRate, Curr, RateDescription, url, url, url, RoomAmenity_Type, MealInclusion_Type, MaxOccupancy, isPromotionalRate, Closed_up, 30, StartDate , EndDate, intime, isAvailable, Taxtype, TaxAmount, Tax_status, None, RateType, NetRate, Promotion_Name, region, statuscode, israteperstay))
                # #print ("UPDATE
        else:
            statuscode = '4'
            #print "statuscode    :", statuscode
            Closed_up = "Y"
            da_time = datetime.datetime.now()
            LastModified = re.sub(r'\s', 'T', str(da_time))
            Tax_status = ''
            # insert(HotelCode,Websitecode,ReportDate,RoomType,LOS,RateDate,Guests,OnsiteRate,NetRate,GrossRate,Curr,RateDescription,HotelId,urlRate,urlInclusions,urlAmenities,RoomAmenity_Type,MealInclusion_Type,MaxOccupancy,isPromotionalRate,Closed,NumberOfDays,StartDate,EndDate,LastModified,isAvailable,Taxtype,TaxAmount,HotelBlock,RateType,Discount,Promotion_Name)
            ##print (id_update, inputid , Domainname, Websitecode, StartDate, RoomType, LOS, RateDate, Guests, OnsiteRate, NetRate, OnsiteRate, Curr, RateDescription, url, url, url, RoomAmenity_Type, MealInclusion_Type, MaxOccupancy, isPromotionalRate, Closed_up, 30, StartDate , EndDate, intime, isAvailable, Taxtype, TaxAmount, Tax_status, None, RateType, NetRate, Promotion_Name, region, statuscode, israteperstay)
            array.append(aws_insert.insert(id_update, inputid , Domainname, Websitecode, StartDate, RoomType, LOS, RateDate, Guests, OnsiteRate, NetRate, OnsiteRate, Curr, RateDescription, url, url, url, RoomAmenity_Type, MealInclusion_Type, MaxOccupancy, isPromotionalRate, Closed_up, 30, StartDate , EndDate, intime, isAvailable, Taxtype, TaxAmount, Tax_status, None, RateType, NetRate, Promotion_Name, region, statuscode, israteperstay))
            # #print ("UPDATE
        #print "completed"
        Rtdate = re.sub(r'-|\-', '', str(RateDate))
        keyvalue = "ondemand/{}/{:%Y%m%d}/delivery/{}.json".format(Websitecode, datetime.datetime.now(), str(inputid) + '_' + str(Rtdate) + '_' + id_update)
        key = bucket.new_key(keyvalue)
        key.set_contents_from_string(json.dumps(array))
        return json.dumps(array)
        gc.collect()

    except Exception as e:
        print e
        value_error = str(re.sub(r"'", '"', str(e)))
        stacktrace = sys.exc_traceback.tb_lineno
        Guests = ''
        region = ''
        Websitecode = '371'
        insert_value_error = str(value_error) + 'Where line number ' + str(stacktrace) + str(proxyip)
        print insert_value_error
        #print "Websitecode =", Websitecode
        statuscode = '4'
        keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(Websitecode, datetime.datetime.now(), id_update)
        key = bucket.new_key(keyvalue)
        key.set_contents_from_string(insert_value_error)
        # array.append(aws_insert.insert(id_update,inputid ,Domainname,Websitecode,StartDate,'',LOS,RateDate,Guests,OnsiteRate,Netrate,OnsiteRate,Curr,RateDescription,url,url,url,RoomAmenity_Type,MealInclusion_Type,MaxOccupancy,isPromotionalRate,Closed_up,30,StartDate ,EndDate,intime,isAvailable,None,None,None,RateType,Netrate,promotion,region,statuscode, israteperstay))
        array.append(aws_insert.insert(id_update, inputid , functionname, Websitecode, "", "", "", "", Guests, "", "", "", "", "", url, url, url, "", "", "", "", "", "", StartDate, EndDate , "", "", "", "", "", "", "", "", "", region, statuscode, israteperstay))
        return json.dumps(array)
    
'''url= 'https://www.ihg.com/crowneplaza/hotels/gb/en/reservation/book?qGRM=0&qBrs=hi.ex.rs.ic.cp.in.sb.cw.cv.6c.vn.ul.ki.sp.nd.ct&qRtP=6CBARC&qSlH=romsp&qAdlt=1&qRpn=1&qHtlC=romsp&qSrt=sBR&srb_u=1&qCoMy=092017&qSmP=3&qCoD=28&qRms=1&qPSt=0&qRpp=20&qChld=1&qRef=df&qCiD=27&qRRSrt=rt&qCiMy=092017&qSHp=1&qWch=0&method=roomRate#roomratestitle#checkin=2017-11-27&checkout=2017-11-28&adult=1'
inputid= ''
id_update = ''
proxyip   = '62.210.106.225:3681'
fetchrates(url ,inputid, id_update, proxyip)'''
