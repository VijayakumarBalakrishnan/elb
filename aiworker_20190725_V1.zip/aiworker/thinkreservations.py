# -*- coding: utf-8 -*-
import re,requests
import datetime
import json
import boto,gc,sys

import aws_insert

def fetchrates(url,inputid,id_update,proxyip):
    array      = []
    sr         = requests.session()
    proxies    = {"https": "http://{}".format(proxyip)}
    intime     = re.sub(r'\s','T',str(datetime.datetime.now()))
    Domainname = 'langhouse.com'
    Websitecode= '318'
    region     = ''
    statuscode = ''
    Mealtype   = ''
    israteperstay = ''
    try:
        conn   = boto.connect_s3(aws_access_key_id= 'AKIAIXEGZVXCWE2FV3SQ',aws_secret_access_key = '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') 
        bucket = conn.get_bucket("rmapi")
        StartDate = datetime.date.today()
        EndDate   = datetime.date.today() + datetime.timedelta(days=29)
        CheckIn_Check_OT_re = re.search(r'start_date=(.*?)&end_date=(.*?)&',url)
        if CheckIn_Check_OT_re:
            Checkin  = CheckIn_Check_OT_re.group(1)
            Checkout = CheckIn_Check_OT_re.group(2)
            #Checkin_URL = datetime.datetime.strptime(str(CheckIn_Check_OT_re.group(1)),'%Y-%m-%d').strftime('%m/%d/%Y')
            #CheckOT_URL = datetime.datetime.strptime(str(CheckIn_Check_OT_re.group(2)),'%Y-%m-%d').strftime('%m/%d/%Y')
        else:
            Checkin  = ''
            Checkout = ''
            #Checkin_URL = ''
            #CheckOT_URL = ''
        #print Checkin,Checkout
        #print url
        RateDate = Checkin
        delta    = datetime.datetime.strptime(Checkout, "%Y-%m-%d") - datetime.datetime.strptime(Checkin, "%Y-%m-%d")
        LOS      = delta.days
        RoomType = ''
        Guests   = re.search(r'number_of_adults=(\d+)&', url).group(1)
        #print Guests,LOS
        Ratetype = ''
        RateDescription = ''
        Taxtype  = ''
        Curr     = ''
        MaxOccupancy = None
        isPromotionalRate  = 'N'
        Closed   = 'Y'
        NetRate  = 0
        Taxstatus= -1
        TaxAmount= 0
        Discount = 0
        GrossRate= 0
        OnsiteRate = 0
        Curr     = ''
        Promotion_Name= ''
        isAvailable = ''
        RoomAmenity_Type = ''
        url_insert = url
        RRFR = url 
        head    = {'Host':'api.thinkreservations.com', 'User-Agent':'Mozilla/5.0 (X11; Linux i686; rv:40.0) Gecko/20100101 Firefox/40.0', 'Accept':'application/json', 'Accept-Language':'en-US,en;q=0.5', 'Accept-Encoding':'gzip, deflate', 'Content-Type':'application/json; charset=UTF-8', 'Referer':RRFR, 'Content-Length':'2', 'Origin':'https://secure.thinkreservations.com'}
        main_url = 'https://api.thinkreservations.com/hotels/226/availabilities/v2?start_date='+Checkin+'&end_date='+Checkout+'&number_of_adults='+Guests+'&number_of_children=0'
        payload = []
        ip = re.sub(r"\{'.*?@|'\}|:\d+", "", str(proxies))
        try:
            try:
                r = requests.get('http://freegeoip.net/json/' + ip, timeout=30)
            except Exception, e:
                r = requests.get('http://freegeoip.net/json/' + ip, timeout=30)
            js = r.json()
            region = js['country_name']
        except Exception, e:
            region = ''
        try:
            htm = requests.post(main_url,json=payload,headers=head,proxies = proxies,timeout=100)
        except Exception, e:
            value_error = str(re.sub("'", '', str(e)))
            stacktrace = sys.exc_traceback.tb_lineno
            try:
                htm = requests.post(main_url,json=payload,headers=head,proxies = proxies,timeout=120)
            except Exception, e:
                try:
                    htm = requests.post(main_url,json=payload,headers=head,proxies = proxies,timeout=150)
                except Exception, e:
                    value_error = str(re.sub("'", '', str(e)))
                    stacktrace = sys.exc_traceback.tb_lineno
                    keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(Websitecode, datetime.datetime.now(), id_update)
                    key = bucket.new_key(keyvalue)
                    key.set_contents_from_string(str(e) + 'Where Line number' + str(stacktrace) + str(proxies))
                    statuscode = 5
                    Guests = ''
                    array.append(aws_insert.insert(id_update, inputid , Domainname, Websitecode, "", "", "", "", Guests, "", "", "", "", "", url_insert,url_insert,url_insert, "", "", "", "", "", "", StartDate, EndDate , "", "", "", "", "", "", "", "", "", region, statuscode, israteperstay))
                    return json.dumps(array)
            
        if htm.status_code <> 200:
            htm = requests.post(main_url,json=payload,headers=head,proxies = proxies)
        if (htm.status_code == 403 or htm.status_code == 407) or htm.status_code <> 200:
            try:
                if htm.status_code <> 200:
                    htm = requests.post(main_url,json=payload,headers=head)
            except Exception, e:
                Closed    = 'Y'
                value_error = str(re.sub("'", '', str(e)))
                stacktrace = sys.exc_traceback.tb_lineno
                keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(Websitecode, datetime.datetime.now(), id_update)
                key = bucket.new_key(keyvalue)
                key.set_contents_from_string(str(e) + 'Where Line number' + str(stacktrace) + str(proxies))
                statuscode = 5
                Guests = ''
                array.append(aws_insert.insert(id_update, inputid , Domainname, Websitecode, "", "", "", "", Guests, "", "", "", "", "", url_insert,url_insert,url_insert, "", "", "", "", "", "", StartDate, EndDate , "", "", "", "", "", "", "", "", "", region, statuscode, israteperstay))
                return json.dumps(array)
        html = htm.text.encode('ascii','ignore')
        #fo = open('riverside.html','w').write(str(html))
        Rtdate=re.sub(r'-|\-','',str(RateDate))
        keyvalue = "ondemand/{}/{:%Y%m%d}/source{}.json".format(Websitecode,datetime.datetime.now(),str(inputid)+'_'+str(Rtdate)+'_'+id_update)
        key = bucket.new_key(keyvalue)
        key.set_contents_from_string(json.dumps(html))
        if re.search(r'(bookings.*?"numberOfUnits)',html,re.DOTALL):
            for block in re.compile(r'bookings.*?"numberOfUnits',re.DOTALL).findall(html):
                RoomType      = ''
                Ratetype      = ''
                OnsiteRate    = 0
                RoomAmenity_Type = ''
                RateDescription  = ''
                Mealtype         = ''
                Curr             = 'USD'
                Closed           = 'N'
                GrossRate        =  0
                isAvailable      = ''
                MaxOccupancy     = None
                RoomType_re = re.search(r'unit.*?name":"(.*?)"', block)
                if RoomType_re:
                    RoomType = re.sub(r"'","''",RoomType_re.group(1))
                    RoomType = str(RoomType)
                else:
                    RoomType = ''
                Ratetype_re = re.search(r'rateType".*?name":"(.*?)"', block)
                if Ratetype_re:
                    Ratetype_grp = re.sub(r"'","''",Ratetype_re.group(1))
                    Ratetype_c1   = re.sub(r"\s\s+","",Ratetype_grp)
                    Ratetype_c2   = re.sub(r'##'," ",str(Ratetype_c1))
                    Ratetype   = re.sub('([4])', r' \1', Ratetype_c2)
                    Ratetype = str(Ratetype)
                else:
                    Ratetype = ''
                OnsiteRate_re = re.search(r'averagePricePerDay":(.*?),', block)
                if OnsiteRate_re:
                    OnsiteRate_grp = OnsiteRate_re.group(1)
                    OnsiteRate_c1   = re.sub(r"'","''",OnsiteRate_grp)
                    OnsiteRate  = re.sub(r"\s\s+","",OnsiteRate_c1)
                    OnsiteRate   = str(OnsiteRate)
                else:
                    OnsiteRate = 0
                RateDescription_Re = re.search(r'unit.*?description":"(.*?)"', block)
                if RateDescription_Re:
                    description_grp = RateDescription_Re.group(1)
                    DESCRIPTION1 = re.sub(r'"',"",str(description_grp))
                    DESCRIPTION = re.sub(r'\\r\\n\\r\\n'," ",str(DESCRIPTION1))
                    RateDescription = re.sub(r"'","''",DESCRIPTION)
                else:
                    RateDescription = ''
                Mealtypes          = str(RateDescription)+' '+str(RoomType)+' '+str(Ratetype)+' '+str(RoomAmenity_Type)
                if Mealtypes !=None:
                    Mealtype_str = str(Mealtypes)
                    if 'breakfast' in Mealtype_str.lower() and 'dinner' in Mealtype_str.lower()  and 'lunch' in Mealtype_str.lower():
                        Meal = 'Breakfast, Lunch and Dinner'
                    elif 'breakfast' in Mealtype_str.lower() and 'dinner' in Mealtype_str.lower():
                        Meal = 'Breakfast and dinner'
                    elif 'breakfast included' in Mealtype_str.lower():
                        Meal = 'Breakfast included'
                    elif 'BREAKFAST' in Mealtype_str:
                        Meal = 'Breakfast'
                    elif 'breakfast' in Mealtype_str.lower() and 'lunch' in Mealtype_str.lower():
                        Meal = 'Breakfast and Lunch'
                    elif 'Lunch' in Mealtype_str and 'Dinner' in Mealtype_str :
                        Meal = "Lunch and Dinner"
                    elif 'breakfast' in Mealtype_str.lower() and 'lunch' in Mealtype_str.lower() and 'dinner' in Mealtype_str.lower():
                        Meal = 'Breakfast, Lunch and dinner'
                    elif 'Break fast' in Mealtype_str:
                        Meal = 'BreakFast' 
                    elif 'breakfast' in Mealtype_str.lower():
                        Meal = 'BreakFast' 
                    elif 'halfboard' in Mealtype_str.lower():
                        Meal = 'Halfboard'
                    elif 'half board' in Mealtype_str.lower():
                        Meal = 'Half board' 
                    elif 'full board' in Mealtype_str.lower():
                        Meal = 'Full Board'
                    elif 'fullboard' in Mealtype_str.lower():
                        Meal = 'FullBoard'
                    elif 'All-Inclusive' in Mealtype_str:
                        Meal = 'All-Inclusive'
                    elif 'All Inclusive' in Mealtype_str:
                        Meal = 'All Inclusive'
                    elif 'All Meals' in Mealtype_str:
                        Meal = 'All Meals'
                    elif 'All Meal' in Mealtype_str:
                        Meal = 'All Meal'
                    else:
                        Meal = ''
                else:
                    Meal = ''   
                Mealtype = Meal
                if OnsiteRate==0:
                    statuscode = 1
                    Closed='Y'
                else:
                    statuscode = ''
                    Closed='N'
                if int(LOS) >1:
                    israteperstay = 'N'
                else:
                    israteperstay ='Y'
                
                #print 'RoomType    :',RoomType
                #print 'RateDescription :',RateDescription
                #print 'MaximumOccupancy :',MaxOccupancy
                #print 'RoomAmenity_Type :',RoomAmenity_Type
                #print 'Ratetype    :',Ratetype
                #print 'OnsiteRate  :',OnsiteRate
                #print 'Curr        :',Curr
                #print 'isAvailable :',isAvailable
                #print 'Mealtype    :',Mealtype
                #print "="*40
                #print (id_update, inputid , Domainname, Websitecode, StartDate, RoomType, LOS, RateDate, Guests, OnsiteRate, NetRate, GrossRate, Curr, RateDescription, url_insert, url_insert, url_insert, RoomAmenity_Type, Mealtype, MaxOccupancy, isPromotionalRate, Closed, 30, StartDate , EndDate, intime, isAvailable, Taxtype, TaxAmount, Taxstatus, None, Ratetype, Discount,Promotion_Name,region,statuscode, israteperstay)
                array.append(aws_insert.insert(id_update, inputid , Domainname, Websitecode, StartDate, RoomType, LOS, RateDate, Guests, OnsiteRate, NetRate, GrossRate, Curr, RateDescription, url_insert, url_insert, url_insert, RoomAmenity_Type, Mealtype, MaxOccupancy, isPromotionalRate, Closed, 30, StartDate , EndDate, intime, isAvailable, Taxtype, TaxAmount, Taxstatus, None, Ratetype, Discount,Promotion_Name,region,statuscode, israteperstay))
        else:
            Closed     = 'Y'
            statuscode = '2'
            #print "else"
            #print (id_update, inputid , Domainname, Websitecode, StartDate, RoomType, LOS, RateDate, Guests, OnsiteRate, NetRate, GrossRate, Curr, RateDescription, url_insert, url_insert, url_insert, RoomAmenity_Type, Mealtype, MaxOccupancy, isPromotionalRate, Closed, 30, StartDate , EndDate, intime, isAvailable, Taxtype, TaxAmount, Taxstatus, None, Ratetype, Discount,Promotion_Name,region,statuscode, israteperstay)
            array.append(aws_insert.insert(id_update, inputid , Domainname, Websitecode, StartDate, RoomType, LOS, RateDate, Guests, OnsiteRate, NetRate, GrossRate, Curr, RateDescription, url_insert, url_insert, url_insert, RoomAmenity_Type, Mealtype, MaxOccupancy, isPromotionalRate, Closed, 30, StartDate , EndDate, intime, isAvailable, Taxtype, TaxAmount, Taxstatus, None, Ratetype, Discount,Promotion_Name,region,statuscode, israteperstay))
        Rtdate = re.sub(r'-|\-', '', str(RateDate))
        keyvalue = "ondemand/{}/{:%Y%m%d}/delivery/{}.json".format(Websitecode,datetime.datetime.now(),str(inputid)+'_'+str(Rtdate)+'_'+id_update)
        key = bucket.new_key(keyvalue)
        key.set_contents_from_string(json.dumps(array))
        return json.dumps(array)
        gc.collect()
    except Exception as e:
       print e
       value_error = str(re.sub(r"'", '"', str(e)))
       stacktrace = sys.exc_traceback.tb_lineno
       Guests = ''
       statuscode = '4'
       region = ''
       array.append(aws_insert.insert(id_update, inputid , Domainname, Websitecode, "", "", "", "", Guests, "", "", "", "", "", url_insert,url_insert,url_insert, "", "", "", "", "", "", StartDate, EndDate , "", "", "", "", "", "", "", "", "", region, statuscode, israteperstay))
       keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(Websitecode,datetime.datetime.now(),id_update)
       key = bucket.new_key(keyvalue)
       key.set_contents_from_string(json.dumps(value_error))
       return json.dumps(array)
   
