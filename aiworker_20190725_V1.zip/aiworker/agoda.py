# -*- coding: utf-8 -*-
import re
import requests
import datetime
from unidecode import unidecode
import json
import sys 
import boto
import gc
import aws_insert

# inputid = 'Expedia1'
# #url = "https://www.agoda.com/novotel-ottawa-hotel/hotel/ottawa-on-ca.html?checkin=2019-05-20&los=2&adults=2&childs=0&rooms=1&checkout=2019-05-22&hotel_id=8072&Currency=USD&"
# url = "https://www.agoda.com/en-in/bunc-hostel/hotel/singapore-sg.html?checkin=2018-11-28&los=1&adults=1&childs=0&rooms=1&checkout=2018-11-29&hotel_id=295157&Currency=SGD&"
# id_update = 'Exped'
# proxyip ='user-34068:214859b73da0e174@45.64.106.31:1212'

def fetchrates(url , inputid, id_update, proxyip):
	array = []
	intime = re.sub(r'\s', 'T', str(datetime.datetime.now()))
	functionname = 'Agoda'
	Websitecode = 5
	LastModified = intime
	Websitecode = Websitecode
	RoomType = ''
	LastModified = LastModified
	OnsiteRate = "0"
	NetRate = "0"
	RoomAmenity_Type = ""
	MealInclusion_Type = ""
	MaxOccupancy = ""
	isPromotionalRate = "N"
	isAvailable = ""
	Curr = '' 
	RateDescription = ''
	israteperstay = ''
	Taxtype = ""
	TaxAmount = ""
	region = ''
	RateType = ""
	Promotion_Name = ""
	try:
		conn = boto.connect_s3(aws_access_key_id='AKIAIXEGZVXCWE2FV3SQ', aws_secret_access_key='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') 
		bucket = conn.get_bucket("rmapi")
		StartDate = datetime.date.today()
		EndDate = datetime.date.today() + datetime.timedelta(days=29)
		Websitecode = 5
		Domainname = "Agoda"
		if re.search(r'&Currency=(.*?)&', url):
			currency_chk = re.search(r'&Currency=(.*?)&', url).group(1)
			currency_lists = {'AED':14, 'INR':27, 'PHP':18, 'ARS':41, 'IDR':25, 'PLN':23, 'AUD':9, 'JPY':11, 'QAR':148, 'BHD':37, 'JOD':100, 'RON':135, 'BDT':169, 'KZT':172, 'RUB':152, 'BRL':24, 'KRW':26, 'SAR':155, 'GBP':2, 'KWD':105, 'SGD':5, 'BGN':55, 'LAK':103, 'ZAR':12, 'KHR':150, 'MYR':4, 'LKR':165, 'CAD':13, 'MVR':151, 'SEK':21, 'XPF':62, 'MXN':124, 'CHF':19, 'CNY':15, 'ILS':134, 'TWD':28, 'CZK':22, 'NZD':8, 'THB':6, 'DKK':20, 'NGN':129, 'TRY':176, 'EGP':80, 'NOK':31, 'UAH':95, 'EUR':1, 'OMR':35, 'USD':7, 'FJD':36, 'PKR':142, 'VND':78, 'HKD':3, 'HUF':87}    
		curr_id = currency_lists[currency_chk]
		re.search(r"(checkin.*?rooms=1)&", url).group(1)
		delta = datetime.datetime.strptime(re.search(r"checkout=(.*?)&", url).group(1), "%Y-%m-%d") - datetime.datetime.strptime(re.search(r"checkin=(.*?)&", url).group(1), "%Y-%m-%d")
		LOS = delta.days
		Guests = re.search(r'adults=(.*?)&', url).group(1)
		RateDate = re.search(r'checkin=(.*?)&', url).group(1)
		hotel_id_reg = re.search(r'hotel_id=(\d+)', url)
		if hotel_id_reg:
			hotel_id = hotel_id_reg.group(1)
		else:
			statuscode = 3
			Guests = ''
			israteperstay = ''
			array.append(aws_insert.insert(id_update, inputid , functionname, Websitecode, "", "", "", "", Guests, "", "", "", "", "", url, url, url, "", "", "", "", "", "", StartDate, EndDate , "", "", "", "", "", "", "", "", "", region, statuscode, israteperstay))
			return json.dumps(array)
		
		#jsonurl = 'https://www.agoda.com/newsite/en-us/pageparams/property?checkin=' + str(re.search(r"checkin=(.*?)&", url).group(1)) + '&los=' + str(LOS) + '&adults=' + str(Guests) + '&rooms=1&cid=-1&tspTypes=4&hotel_id=' + str(hotel_id) + '&all=false&pageTypeId=7&currencyCode='+str(currency_chk)
		jsonurl = 'https://www.agoda.com/api/en-us/pageparams/property?checkin=' + str(re.search(r"checkin=(.*?)&", url).group(1)) + '&los=' + str(LOS) + '&adults=' + str(Guests) + '&rooms=1&cid=-1&tspTypes=4&hotel_id=' + str(hotel_id) + '&all=false&pageTypeId=7&currencyCode='+str(currency_chk)
# 		print jsonurl
		
		proxies = {"https": "http://{}".format(proxyip)}
		url = re.sub(r'&Currency=.*', '', url)
		url = re.sub(r'los=\d+&', 'los='+str(LOS)+'&', url)
		head = {'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/50.0.2661.102 Safari/537.36', 'Referer': 'https://www.agoda.com/'}
		# head = {'User-Agent':'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:12.0) Gecko/20100101 Firefox/31.0'}
		region = ''
		ip = re.sub(r"\{'.*?@|'\}|:\d+", "", str(proxies))
		try:
			try:
				r = requests.get('http://freegeoip.net/json/' + ip, timeout=15)
			except Exception, e:
				r = requests.get('http://freegeoip.net/json/' + ip, timeout=30)
			js = r.json()
			region = js['country_name']
		except Exception, e:
			region = ''
		sess = requests.session()
		Rtdate=re.sub(r'-|\-','',str(RateDate))
		data = sess.get("https://www.agoda.com/api/en-in/Main/SetSelectedCurency?currencyId=" + str(curr_id), proxies=proxies)
# 		print data.status_code
		try:
			hml = sess.get(jsonurl, headers=head, proxies=proxies, timeout=10)
			if hml.json()['roomGridData']['isDataReady'] == False:
				hml = sess.get(jsonurl, headers=head, proxies=proxies, timeout=10)
				if hml.json()['roomGridData']['isDataReady'] == False:
					hml = sess.get(jsonurl, headers=head, proxies=proxies, timeout=10)
					if hml.json()['roomGridData']['isDataReady'] == False:
						keyvalue = "ondemand/{}/{:%Y%m%d}/source/{}.json".format(Websitecode, datetime.datetime.now(), str(inputid) + '_' + str(Rtdate) + '_' + id_update)
						#print keyvalue
						key = bucket.new_key(keyvalue)
						key.set_contents_from_string(hml.json)
						statuscode = 9
						Guests = ''
						israteperstay = ''
						array.append(aws_insert.insert(id_update, inputid , functionname, Websitecode, "", "", "", "", Guests, "", "", "", "", "", url, url, url, "", "", "", "", "", "", StartDate, EndDate , "", "", "", "", "", "", "", "", "", region, statuscode, israteperstay))
						return json.dumps(array)
		except Exception, e:
			value_error = str(re.sub("'", '', str(e)))
			stacktrace = sys.exc_traceback.tb_lineno
			try:
				hml = sess.get(jsonurl, headers=head, proxies=proxies, timeout=20)
			except Exception, e:
				value_error = str(re.sub("'", '', str(e)))
				stacktrace = sys.exc_traceback.tb_lineno
				keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(Websitecode, datetime.datetime.now(), id_update)
				key = bucket.new_key(keyvalue)
				key.set_contents_from_string(str(e) + 'Where Line number' + str(stacktrace) + str(proxies))
				statuscode = 5
				Guests = ''
				israteperstay = ''
				array.append(aws_insert.insert(id_update, inputid , functionname, Websitecode, "", "", "", "", Guests, "", "", "", "", "", url, url, url, "", "", "", "", "", "", StartDate, EndDate , "", "", "", "", "", "", "", "", "", region, statuscode, israteperstay))
				return json.dumps(array)
		if hml.status_code <> 200:
			hml = sess.get(jsonurl, headers=head, proxies=proxies)
		if (hml.status_code == 403 or hml.status_code == 407) or hml.status_code <> 200:
			try:
				# random_proxy=['media:M3diAproxy@172.245.196.60:80','media:M3diAproxy@154.16.61.52:80','media:M3diAproxy@50.2.218.221:80','media:M3diAproxy@23.229.88.85:80','media:M3diAproxy@155.94.168.244:80','media:M3diAproxy@155.94.168.44:80','media:M3diAproxy@23.231.99.91:80']
				# proxyy=random.choice(random_proxy)
				# proxies = {"http": "http://{}".format(proxyy)}
				hml = sess.get(jsonurl, headers=head,proxies=proxies)
			except Exception, e:
				value_error = str(re.sub("'", '', str(e)))
				stacktrace = sys.exc_traceback.tb_lineno
				keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(Websitecode, datetime.datetime.now(), id_update)
				key = bucket.new_key(keyvalue)
				key.set_contents_from_string(str(e) + 'Where Line number' + str(stacktrace) + str(proxies))
				statuscode = 5
				Guests = ''
				israteperstay = ''
				array.append(aws_insert.insert(id_update, inputid , functionname, Websitecode, "", "", "", "", Guests, "", "", "", "", "", url, url, url, "", "", "", "", "", "", StartDate, EndDate , "", "", "", "", "", "", "", "", "", region, statuscode, israteperstay))
				return json.dumps(array)
		html = hml.text
		html = html.encode('ascii', 'ignore')
# 		print hml.status_code
		keyvalue = "ondemand/{}/{:%Y%m%d}/source/{}.json".format(Websitecode, datetime.datetime.now(), str(inputid) + '_' + str(Rtdate) + '_' + id_update)
		#print keyvalue
		key = bucket.new_key(keyvalue)
		key.set_contents_from_string(html)
		jsonvalue = hml.json()
		if jsonvalue.has_key('roomGridData'):
			if jsonvalue['roomGridData'].has_key('masterRooms'):
				if  jsonvalue['roomGridData']['masterRooms']:
					for block in jsonvalue['roomGridData']['masterRooms']:
						RoomType =  re.sub("'", "''", str(unidecode(block['name']).encode('ascii')))
						RoomType = re.sub(r"&.*?;", "", RoomType)
						RoomAmenity_Type1 = ''
						if block['amenities']:
							for amt in block['amenities']:
								sec_room = ''
								RoomAmenity_Type1 += unidecode(amt['title']).decode('utf-8')+': '
								if block['facilities']:
									for amtes in amt['facilities']:
										if 'true' in str(amtes).lower():
											sec_room += unidecode(amtes['title']).decode('utf-8')+','
								RoomAmenity_Type1 += sec_room+';'
							RoomAmenity_Type1 = re.sub('&amp;','&',RoomAmenity_Type1)
							RoomAmenity_Type1 = re.sub(',;','; ',RoomAmenity_Type1)
							RoomAmenity_Type3 = re.sub('\s+',' ',RoomAmenity_Type1)
							RoomAmenity_Type = re.sub("'","''",RoomAmenity_Type3)
							ratedescription_1 = ''
							ratedescription_2 = ''
							if block['features']:
								for ratedescrip in block['features']:
									ratedescription_1 += unidecode(ratedescrip['title']).decode('utf-8')+', '
								ratedescription_1 = re.sub(r'^,|,$','',ratedescription_1.strip())
								if block.has_key('bedConfigurationSummary'):
									if block['bedConfigurationSummary'].has_key('title'):
										ratedescription_2 = block['bedConfigurationSummary']['title']
							RateDescription = ratedescription_1+', '+ ratedescription_2  
							RateDescription = re.sub(r'^,|,$','',RateDescription.strip())
							if block['rooms']:
								cblock = block['rooms']
		#                     else:
		#                         cblock = block['groupRoom']
								for block_sec in cblock:
									RateType_1 = ''
									RateType_2 = ''
									if RateDescription == '':
										RateDescription = ''
										if block_sec['features']:
											for descrption in block_sec['features']:
												if 'title' in descrption:
													RateDescription += unidecode(descrption['title']).decode('utf-8')+', '
											RateDescription = re.sub(r'^,|,$','',RateDescription.strip())
									OnsiteRate = re.sub(",", "", str(block_sec['pricePopupViewModel']['formattedChargePriceAmount']).strip())
									if block_sec['pricePopupViewModel'].has_key('formattedAgodaPriceSellEx'):
										NetRate = re.sub(",", "", str(block_sec['pricePopupViewModel']['formattedAgodaPriceSellEx']).strip())
									elif block_sec['pricePopupViewModel'].has_key('formattedPropertyCrossoutRatePrice'):
										NetRate = re.sub(",", "", str(block_sec['pricePopupViewModel']['formattedPropertyCrossoutRatePrice']).strip())
									elif block_sec['pricePopupViewModel'].has_key('formattedAgodaPrice'):
										NetRate = re.sub(",", "", str(block_sec['pricePopupViewModel']['formattedAgodaPrice']).strip())
									else:
										NetRate = 0
										
									if float(OnsiteRate) <> float(NetRate):
										isPromotionalRate = 'Y'
										if float(OnsiteRate) > float(NetRate):
											isPromotionalRate = 'N'
											NetRate = 0
									else:
										NetRate = 0
										
									Curr = re.sub("'", "''", str(block_sec['currency']))
									MaxOccupancy = block_sec['occupancy']
									if 'cancellation' in str(block_sec):
										if 'title' in str(block_sec['cancellation']):
											RateType_1 = re.sub("'", "''", str(unidecode(block_sec['cancellation']['title']).decode('utf-8')))
									if 'payAtHotel' in str(block_sec):
										if 'title' in str(block_sec['payAtHotel']):
											RateType_2 = re.sub("'", "''", str(unidecode(block_sec['payAtHotel']['title']).decode('utf-8')))
									RateType = RateType_1+', '+RateType_2
									RateType = re.sub(r',$|^,','',re.sub("'", "''", RateType).strip())
									RateType = re.sub('Conditional cancellation','Cancellation Conditional',RateType)
									##print '\nRateType',RateType
									if 'benefits' in str(block_sec):
										if 'title' in str(block_sec['benefits']):
											MealInclusion_Type = re.sub("'", "''", str(unidecode(block_sec['features'][0]['title']).decode('utf-8')))
											if '{' in MealInclusion_Type:
												MealInclusion_Type = re.sub(r"\{\d+\}","{"+str(MaxOccupancy)+"}",str(MealInclusion_Type))
										else:
											MealInclusion_Type = ''
									#MealInclusion_Type = re.sub("'", "''", str(benefits[0]['title'])).strip()
									##print '\nMealInclusion_Type',MealInclusion_Type
									if block_sec.has_key('promotion'):
										block_sec_promotion = block_sec['promotion']
										#print "block_sec_promotion", block_sec_promotion
										#if 'promotion' in str(block_sec):
										if block_sec_promotion.has_key('description'):
											#if ['promotion'] in str(block_sec['promotion']):
											Promotion_Name = re.sub("'", "''", str(unidecode(block_sec['promotion']['description']).decode('utf-8')))
											isPromotionalRate = 'Y'
									#print '\nPromotion_Name:',Promotion_Name
									if block_sec.has_key('availability'):
										isAvailable = re.sub("'", "''", str(block_sec['availability']))
									if 'taxesAndSurcharges' in str(block_sec):
										if 'title' in str(block_sec['taxesAndSurcharges']):
											Taxtype = re.sub("'", "''", str(unidecode(block_sec['taxesAndSurcharges']['title']).decode('utf-8')))
									##print '\nTaxtype:',Taxtype
									if 'pricePopupViewModel' in str(block_sec):
										if 'taxesAndFeesAmount' in str(block_sec['pricePopupViewModel']):
											Taxincluded = re.sub("'", "''", str(block_sec['pricePopupViewModel']['taxesAndFeesAmount']))
									Taxincluded = int(float(Taxincluded))
									if Taxtype:
										if int(Taxincluded) == 0:
											includedtype_comment = '2'
										else:
											includedtype_comment = '1'
									else:
										includedtype_comment = '-1'
									Tax_status = includedtype_comment
									if OnsiteRate == 0 or str(OnsiteRate) == '0':
										Closed_up = 'Y'
										statuscode = '1'
										
									else:
										Closed_up = 'N'
										statuscode = '' 
										if int(LOS) > 1:
											israteperstay = 'N' 
										else:
											israteperstay = 'Y'  
									if (NetRate == 0 or NetRate == '') and (Promotion_Name == 0 or Promotion_Name == ''):
										isPromotionalRate = 'N'
									print (id_update,inputid ,Domainname,Websitecode,StartDate,RoomType,LOS,RateDate,Guests,OnsiteRate,NetRate,OnsiteRate,Curr,RateDescription,url,url,url,RoomAmenity_Type,MealInclusion_Type,MaxOccupancy,isPromotionalRate,Closed_up,30,StartDate ,EndDate,intime,isAvailable,Taxtype,TaxAmount,Tax_status,None,RateType,NetRate,Promotion_Name,region,statuscode, israteperstay)
									array.append(aws_insert.insert(id_update, inputid , Domainname, Websitecode, StartDate, RoomType, LOS, RateDate, Guests, OnsiteRate, NetRate, OnsiteRate, Curr, RateDescription, url, url, url, RoomAmenity_Type, MealInclusion_Type, MaxOccupancy, isPromotionalRate, Closed_up, 30, StartDate , EndDate, intime, isAvailable, Taxtype, TaxAmount, Tax_status, None, RateType, NetRate, Promotion_Name, region, statuscode, israteperstay))
				
				else:
					statuscode = '2'
					Closed_up = "Y"
					da_time = datetime.datetime.now()
					LastModified = re.sub(r'\s', 'T', str(da_time))
					Tax_status = ''
					israteperstay = ''
					# insert(HotelCode,Websitecode,ReportDate,RoomType,LOS,RateDate,Guests,OnsiteRate,NetRate,GrossRate,Curr,RateDescription,HotelId,urlRate,urlInclusions,urlAmenities,RoomAmenity_Type,MealInclusion_Type,MaxOccupancy,isPromotionalRate,Closed,NumberOfDays,StartDate,EndDate,LastModified,isAvailable,Taxtype,TaxAmount,HotelBlock,RateType,Discount,Promotion_Name)
					array.append(aws_insert.insert(id_update, inputid , Domainname, Websitecode, StartDate, RoomType, LOS, RateDate, Guests, OnsiteRate, NetRate, OnsiteRate, Curr, RateDescription, url, url, url, RoomAmenity_Type, MealInclusion_Type, MaxOccupancy, isPromotionalRate, Closed_up, 30, StartDate , EndDate, intime, isAvailable, Taxtype, TaxAmount, Tax_status, None, RateType, NetRate, Promotion_Name, region, statuscode, israteperstay))                    
			else:
				statuscode = '2'
				Closed_up = "Y"
				da_time = datetime.datetime.now()
				LastModified = re.sub(r'\s', 'T', str(da_time))
				Tax_status = ''
				israteperstay = ''
				# insert(HotelCode,Websitecode,ReportDate,RoomType,LOS,RateDate,Guests,OnsiteRate,NetRate,GrossRate,Curr,RateDescription,HotelId,urlRate,urlInclusions,urlAmenities,RoomAmenity_Type,MealInclusion_Type,MaxOccupancy,isPromotionalRate,Closed,NumberOfDays,StartDate,EndDate,LastModified,isAvailable,Taxtype,TaxAmount,HotelBlock,RateType,Discount,Promotion_Name)
				array.append(aws_insert.insert(id_update, inputid , Domainname, Websitecode, StartDate, RoomType, LOS, RateDate, Guests, OnsiteRate, NetRate, OnsiteRate, Curr, RateDescription, url, url, url, RoomAmenity_Type, MealInclusion_Type, MaxOccupancy, isPromotionalRate, Closed_up, 30, StartDate , EndDate, intime, isAvailable, Taxtype, TaxAmount, Tax_status, None, RateType, NetRate, Promotion_Name, region, statuscode, israteperstay))
		else:
			statuscode = '2'
			Closed_up = "Y"
			da_time = datetime.datetime.now()
			LastModified = re.sub(r'\s', 'T', str(da_time))
			Tax_status = ''
			israteperstay = ''
			# insert(HotelCode,Websitecode,ReportDate,RoomType,LOS,RateDate,Guests,OnsiteRate,NetRate,GrossRate,Curr,RateDescription,HotelId,urlRate,urlInclusions,urlAmenities,RoomAmenity_Type,MealInclusion_Type,MaxOccupancy,isPromotionalRate,Closed,NumberOfDays,StartDate,EndDate,LastModified,isAvailable,Taxtype,TaxAmount,HotelBlock,RateType,Discount,Promotion_Name)
			array.append(aws_insert.insert(id_update, inputid , Domainname, Websitecode, StartDate, RoomType, LOS, RateDate, Guests, OnsiteRate, NetRate, OnsiteRate, Curr, RateDescription, url, url, url, RoomAmenity_Type, MealInclusion_Type, MaxOccupancy, isPromotionalRate, Closed_up, 30, StartDate , EndDate, intime, isAvailable, Taxtype, TaxAmount, Tax_status, None, RateType, NetRate, Promotion_Name, region, statuscode, israteperstay))
			# #print ("UPDATE
		try:
			if jsonvalue.has_key('soldOutRooms'):
				for sldblock in jsonvalue['soldOutRooms']:
					if sldblock.has_key('masterRoomName'):
						RoomType =  re.sub("'", "''", str(unidecode(sldblock['masterRoomName']).encode('ascii')))
						RoomType = re.sub(r"&.*?;", "", RoomType)
# 						 print 'RoomType main:', RoomType
# 					 if sldblock.has_key('exclusivePrice'):
# 						 OnsiteRate = sldblock['exclusivePrice']
# 						 OnsiteRate = round(OnsiteRate)
# 						 print 'OnsiteRate main:', OnsiteRate
# 	 					print 'Sold out'
						statuscode = '1'
						Closed_up = "Y"
						da_time = datetime.datetime.now()
						LastModified = re.sub(r'\s', 'T', str(da_time))
						Tax_status = ''
						israteperstay = ''
						array.append(aws_insert.insert(id_update, inputid , Domainname, Websitecode, StartDate, RoomType, LOS, RateDate, Guests, OnsiteRate, NetRate, OnsiteRate, Curr, RateDescription, url, url, url, RoomAmenity_Type, MealInclusion_Type, MaxOccupancy, isPromotionalRate, Closed_up, 30, StartDate , EndDate, intime, isAvailable, Taxtype, TaxAmount, Tax_status, None, RateType, NetRate, Promotion_Name, region, statuscode, israteperstay))
		except Exception as e:
			print 'Error: Soldout Room Exp',e,sys.exc_traceback.tb_lineno
		# print "completed"
		Rtdate = re.sub(r'-|\-', '', str(RateDate))
		keyvalue = "ondemand/{}/{:%Y%m%d}/delivery/{}.json".format(Websitecode, datetime.datetime.now(), str(inputid) + '_' + str(Rtdate) + '_' + id_update)
		key = bucket.new_key(keyvalue)
		key.set_contents_from_string(json.dumps(array))
		return json.dumps(array)
		gc.collect()
	except Exception as e:
		print e
		value_error = str(re.sub(r"'", '"', str(e)))
		stacktrace = sys.exc_traceback.tb_lineno
		Guests = ''
		region = ''
		Websitecode = '5'
		israteperstay = ''
		insert_value_error = str(value_error) + 'Where line number ' + str(stacktrace) + str(proxyip)
		print insert_value_error
		# print "Websitecode =", Websitecode
		statuscode = '4'
		keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(Websitecode, datetime.datetime.now(), id_update)
		key = bucket.new_key(keyvalue)
		key.set_contents_from_string(insert_value_error)
		# array.append(aws_insert.insert(id_update,inputid ,Domainname,Websitecode,StartDate,'',LOS,RateDate,Guests,OnsiteRate,Netrate,OnsiteRate,Curr,RateDescription,url,url,url,RoomAmenity_Type,MealInclusion_Type,MaxOccupancy,isPromotionalRate,Closed_up,30,StartDate ,EndDate,intime,isAvailable,None,None,None,RateType,Netrate,promotion,region,statuscode))
		array.append(aws_insert.insert(id_update, inputid , functionname, Websitecode, "", "", "", "", Guests, "", "", "", "", "", url, url, url, "", "", "", "", "", "", StartDate, EndDate , "", "", "", "", "", "", "", "", "", region, statuscode, israteperstay))
		return json.dumps(array)

# fetchrates(url , inputid, id_update, proxyip)
