# -*- coding: utf-8 -*-
import re
import requests
import datetime
import json
import sys 
import boto
import gc

import traceback
import aws_insert

'''
url="https://www.blastnessbooking.com/reservations/risultato.html?tot_camere=1&tot_adulti=1&tot_bambini=0&gg=20&mm=7&aa=2017&ggf=&mmf=&aaf=&notti_1=1&id_stile=11656&lingua_int=eng&id_albergo=9911&dc=459686&converti_valuta=&codice_cli=&codice_convenzione=&nome_codice_personale=&cognome_codice_personale=&codice_personale=&countryCode=IN&gps_latitude=&gps_longitude=&adulti1=1&bambini1=0#checkin=2017-06-01&checkout=2017-06-02#"
inputid= 12345
id_update="lokesh-test"
proxyip="media:M3diAproxy@172.93.193.142:80"
'''

def fetchrates(url ,inputid, id_update, proxyip):
	array = []
	intime=re.sub(r'\s','T',str(datetime.datetime.now()))
	functionname='blastnessbooking'
	Websitecode = '316'
	israteperstay = ''
	try:
		conn = boto.connect_s3(aws_access_key_id= 'AKIAIXEGZVXCWE2FV3SQ',aws_secret_access_key = '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') 
		bucket = conn.get_bucket("rmapi")
		StartDate = datetime.date.today()
		EndDate  = datetime.date.today() + datetime.timedelta(days=29)
		RateDate_reg = re.search(r'checkin=(.*?)&', url)
		if RateDate_reg:
			RateDate = RateDate_reg.group(1)
		adults = re.search(r'adulti=(\d+)&tot',url)
		if adults:
			adults1 = re.search(r'adulti=(\d+)&tot',url).group(1)
		proxies = {"https": "http://{}".format(proxyip)}
		chekin=re.search(r'#checkin=.*?&checkout=.*?#',url)
		if chekin:
			cin=re.search(r'#checkin=(.*?)&checkout=(.*?)#',url).group(1)
			cout=re.search(r'#checkin=(.*?)&checkout=(.*?)#',url).group(2)
			cin_d=datetime.datetime.strptime(cin, "%Y-%m-%d").strftime("%d")
			cin_m=datetime.datetime.strptime(cin, "%Y-%m-%d").strftime("%m")
			cin_y=datetime.datetime.strptime(cin, "%Y-%m-%d").strftime("%Y")
		length=datetime.datetime.strptime(cout, "%Y-%m-%d") - datetime.datetime.strptime(cin, "%Y-%m-%d")
		los=length.days
		url = re.sub(r'adulti=.*?&tot_bambini=0&gg=\d+&mm=\d+&aa=\d+&ggf=&mmf=&aaf=&notti_1=\d+&id_','adulti='+adults+'&tot_bambini=0&gg='+cin_d+'&mm='+cin_m+'&aa='+cin_y+'&ggf=&mmf=&aaf=&notti_1='+str(los)+'&id_',str(url))
		#print "URL == ",url
		Domainname=functionname
		RoomType=""
		LOS		=los
		RateDate=""
		Guests=adults1
		OnsiteRate="0"
		NetRate="0"
		GrossRate="0"
		Curr=""
		RateDescription=""
		RoomAmenity_Type=""
		MealInclusion_Type=""
		MaxOccupancy=""
		isPromotionalRate="N"
		Closed="Y"
		isAvailable=""
		Taxtype=""
		TaxAmount="0"
		Tax_status=""
		Ratetype=""
		Discount="0"
		Promotion_Name=""
		RateDate = ""
		region=''
		ip=re.sub(r"\{'.*?@|'\}|:\d+","",str(proxies))
		try:
			try:
				r = requests.get('http://freegeoip.net/json/'+ip,timeout=30)
			except Exception,e:
				r = requests.get('http://freegeoip.net/json/'+ip,timeout=30)
			js = r.json()
			region=js['country_name']
		except Exception,e:
			region=''
		proxies = {"http": "http://{}".format(proxyip)}
		head = {'User-Agent':'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:12.0) Gecko/20100101 Firefox/48.0'}
		try:
			hml = requests.get(url, headers=head, proxies=proxies, verify = False,timeout=30)
		except Exception as e: 
			print e,"Re-run"
			try:
				hml = requests.get(url, headers=head, proxies=proxies, verify = False,timeout=30)
			except Exception as e: 
				print e,"Re-run"
				value_error=str(re.sub(r"'",'"',str(e)))
				stacktrace=sys.exc_traceback.tb_lineno
				insert_value_error=str(value_error)+'Where line number '+str(stacktrace)+str(proxyip)
				print insert_value_error
				keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(Websitecode,datetime.datetime.now(),id_update)
				key = bucket.new_key(keyvalue)
				key.set_contents_from_string(str(e))
				statuscode=5
				Guests='1'
				array.append(aws_insert.insert(id_update, inputid ,Domainname,Websitecode,insert_value_error,"", "", "", Guests, "", "", "", "", "",url, url, url, "", "", "", "", "", "",StartDate, EndDate , "", "", "", "", "", "",  "", "", "",region,statuscode, israteperstay))
				return json.dumps(array)
		if (hml.status_code<> 200):
			hml = requests.get(url, headers=head, proxies=proxies, verify = False)
		if (hml.status_code == 403 or hml.status_code == 407 or hml.status_code <> 200):
			try:
				hml = requests.get(url, headers=head,verify = False)
			except Exception as e:
				print e,"Re-run"
				value_error=str(re.sub(r"'",'"',str(e)))
				stacktrace=sys.exc_traceback.tb_lineno
				insert_value_error=str(value_error)+'Where line number '+str(stacktrace)+str(proxyip)
				print insert_value_error
				keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(Websitecode,datetime.datetime.now(),id_update)
				key = bucket.new_key(keyvalue)
				key.set_contents_from_string(str(e))
				statuscode=5
				Guests='1'
				array.append(aws_insert.insert(id_update, inputid ,Domainname,Websitecode, "","", "", "", Guests, "", "", "", "", "",url, url, url, "", "", "", "", "", "",StartDate, EndDate , "", "", "", "", "", "",  "", "", "",region,statuscode))
				return json.dumps(array)
		#print "hml.status_code ==:",hml.status_code
		html = hml.text
		html = html.encode('ascii', 'ignore')
		Rtdate=re.sub(r'-|\-','',str(RateDate))
		keyvalue = "ondemand/{}/{:%Y%m%d}/source/{}.txt".format(Websitecode,datetime.datetime.now(),str(inputid)+'_'+str(Rtdate)+'_'+id_update)
		key = bucket.new_key(keyvalue)
		key.set_contents_from_string(html)
		
		reg_blo = re.compile('<div class="blocco_camera room-box"(.*?)</div><!--FINE BLOCCO CAMERA><!-->',re.DOTALL)
		Reg_bl = re.compile(r'<div.*?id="rate-block-\d+-\d+"(.*?)<!--FINE CONTAINER TARIFFA><!-->',re.DOTALL)
		reg_blo1_ = re.search(r'<div class="blocco_camera room-box"(.*?)</div><!--FINE BLOCCO CAMERA><!-->',html,re.DOTALL)
		if reg_blo1_:
			for block in reg_blo.findall(html):
				for block1 in Reg_bl.findall(block):
					RoomType=""
					OnsiteRate="0"
					NetRate="0"
					Curr=""
					RateDescription=""
					RoomAmenity_Type=""
					MealInclusion_Type=""
					MaxOccupancy=""
					isPromotionalRate="N"
					Closed="N"
					isAvailable=""
					Taxtype=""
					TaxAmount="0"
					Ratetype=""
					Discount="0"
					Promotion_Name=""
					pri = re.search(r'<h3 class="titoletto">\s*(.*?)\s*</h3>',block)
					if pri:
						RoomType1 = pri.group(1)
						RoomType2 = re.sub('\n|<.*?>','',RoomType1)
						RoomType = re.sub('\s+',' ',RoomType2)
						##print "\nRoomType:",RoomType
					NetRate_re = re.search(r'id="rate-price-discounted.*?>(.*?) ', block1)
					if NetRate_re:
						NetRate = NetRate_re.group(1)
						isPromotionalRate = 'Y'
					else:
						NetRate = 0
						isPromotionalRate = 'N'
					spe = re.search(r'data-pricesloaded="no" data-rate="\d+".*?>\s*(\d.*?)\s*[A-Z|a-z]',block1,re.DOTALL)
					if spe:
						sp1 = spe.group(1)
						OnsiteRate = re.sub('<.*?>|\n|\$|\s|,','',sp1)
						israteperstay = 'Y'
						##print "\nOnsiteRate:",OnsiteRate
						cur = re.search(r'data-pricesloaded="no" data-rate="\d+".*?>\s*\d.*?\s*([A-Z|a-z].*?)\s*<',block1)
						if cur:
							Curr = cur.group(1)
							##print '\nCurr:',Curr
					des = re.search(r'<div class="cancellation text-box">.*?<div class="text">(.*?)\s*</div>',block1,re.DOTALL)
					if des:
						RateType1 = des.group(1)
						Ratetype3 = re.sub('<.*?>','',RateType1)
						Ratetype2 = re.sub('\s+',' ',Ratetype3)
						Ratetype_cost = re.sub('^.*?>','',Ratetype2)
						Ratetype = re.sub('rates|rate|Rate|Rates','Cost',Ratetype_cost)
						##print "\nRatetype:",Ratetype
					prom_reg = re.search(r'<div class="titoletto tariffa_tit"\s*>.*?<span style.*?>(.*?)</span>\s*</span>',block1,re.DOTALL)
					if prom_reg:
						prom_name = prom_reg.group(1)
						prom_name_clean = re.sub('<.*?>','',prom_name)
						prom_name_space = re.sub('\s+',' ',prom_name_clean)
						prom_name_cost = re.sub('^.*?>','',prom_name_space)
						Promotion_Name = re.sub('rates|rate|Rate|Rates','Cost',prom_name_cost)
						##print "Promotion_Name:",Promotion_Name
						if Promotion_Name:
							isPromotionalRate = 'Y'
					meal_reg = re.search(r'<div class="titoletto tariffa_tit"\s*>.*?</span>\s*</span>.*?<p>(.*?)</p>',block1,re.DOTALL)
					if meal_reg:
						Meal_name = meal_reg.group(1)
						Meal_name_clean = re.sub('<.*?>','',Meal_name)
						Meal_name_space = re.sub('\s+',' ',Meal_name_clean)
						Meal_name_cost = re.sub('^.*?>','',Meal_name_space)
						MealInclusion_Type = re.sub('rates|rate|Rate|Rates','Cost',Meal_name_cost)
						##print "MealInclusion_Type:",MealInclusion_Type
					des2 = re.search(r'<h3 class="titoletto">.*?</h3>\s*<.*?>\s*(.*?)\s*</p>\s*<div>',block,re.DOTALL)
					if des2:
						d2 = des2.group(1)
						Description1 = re.sub('<.*?>|\n|[d|D]etails','',d2)
						RateDescription = re.sub('\s+',' ',Description1)
						##print "\nRateDescription:",RateDescription
					Ameints_re = re.search(r'oom\s*amenities\s*<.*?>\s*<.*?>\s*(.*?)\s*</div>\s*</div>', block,re.DOTALL)
					if Ameints_re:
						Amentes = Ameints_re.group(1)
						amentes_space = re.sub(r'</span>',', ', Amentes)
						RoomAmenity_Type1 = re.sub('<.*?>|&amp;|\t+|\n','',amentes_space).strip()
						RoomAmenity_Type3 = re.sub('\s+',' ',RoomAmenity_Type1)
						RoomAmenity_Type = re.sub("'","''",RoomAmenity_Type3)
						##print "\nRoomAmenity_Type:",RoomAmenity_Type
					GrossRate = OnsiteRate
					statuscode=''
					##print (id_update,inputid ,Domainname,WebsiteCode,StartDate,RoomType,LOS,RateDate,Guests,OnsiteRate,NetRate,GrossRate,Curr,RateDescription,url,url,url,RoomAmenity_Type,MealInclusion_Type,MaxOccupancy,isPromotionalRate,Closed,30,StartDate,EndDate,intime,isAvailable,Taxtype,TaxAmount,Tax_status,None,Ratetype,Discount,Promotion_Name,region,statuscode)
					##print "\n-------------------------^^^^^^^^^^^^^^^^^^^^^^^^^---------------------------\n"
					#insert	(HotelCode,WebsiteCode,ReportDate,RoomType,LOS,RateDate,Guests,OnsiteRate,NetRate,GrossRate,Curr,RateDescription,HotelId,urlRate,RoomAmenity_Type,MealInclusion_Type,MaxOccupancy,isPromotionalRate,Closed,NumberOfDays,StartDate,EndDate,LastModified,isAvailable,Taxtype,TaxAmount,HotelBlock,Ratetype,Discount,Promotion_Name)
					array.append(aws_insert.insert(id_update,inputid ,Domainname,Websitecode,StartDate,RoomType,LOS,RateDate,Guests,OnsiteRate,NetRate,GrossRate,Curr,RateDescription,url,url,url,RoomAmenity_Type,MealInclusion_Type,MaxOccupancy,isPromotionalRate,Closed,30,StartDate,EndDate,intime,isAvailable,Taxtype,TaxAmount,Tax_status,None,Ratetype,Discount,Promotion_Name,region,statuscode, israteperstay))
			
		else:
			statuscode='2'
			#insert(HotelCode,WebsiteCode,ReportDate,RoomType,LOS,RateDate,Guests,OnsiteRate,NetRate,GrossRate,Curr,RateDescription,HotelId,urlRate,urlInclusions,urlAmenities,RoomAmenity_Type,MealInclusion_Type,MaxOccupancy,isPromotionalRate,Closed,NumberOfDays,StartDate,EndDate,LastModified,isAvailable,Taxtype,TaxAmount,HotelBlock,Ratetype,Discount,Promotion_Name)
			array.append(aws_insert.insert(id_update,inputid ,Domainname,Websitecode,StartDate,RoomType,LOS,RateDate,Guests,OnsiteRate,NetRate,GrossRate,Curr,RateDescription,url,url,url,RoomAmenity_Type,MealInclusion_Type,MaxOccupancy,isPromotionalRate,Closed,30,StartDate,EndDate,intime,isAvailable,Taxtype,TaxAmount,Tax_status,None,Ratetype,Discount,Promotion_Name,region,statuscode, israteperstay))
		keyvalue = "ondemand/{}/{:%Y%m%d}/delivery/{}.json".format(Websitecode,datetime.datetime.now(),str(inputid)+'_'+str(Rtdate)+'_'+id_update)
		key = bucket.new_key(keyvalue)
		key.set_contents_from_string(json.dumps(array))
		return json.dumps(array)
	except Exception as e:
		print e
		value_error=str(re.sub(r"'",'"',str(e)))
		stacktrace=sys.exc_traceback.tb_lineno
		Guests =''
		region=''
		WebsiteCode='5'
		insert_value_error=str(value_error)+'Where line number '+str(stacktrace)+str(proxyip)
		print insert_value_error
		statuscode='4'
		keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(WebsiteCode,datetime.datetime.now(),id_update)
		key = bucket.new_key(keyvalue)
		key.set_contents_from_string(insert_value_error)
		#array.append(aws_insert.insert(id_update,inputid ,Domainname,WebsiteCode,StartDate,'',LOS,RateDate,Guests,OnsiteRate,Netrate,OnsiteRate,Curr,RateDescription,url,url,url,RoomAmenity_Type,MealInclusion_Type,MaxOccupancy,isPromotionalRate,Closed_up,30,StartDate ,EndDate,intime,isAvailable,None,None,None,RateType,Netrate,promotion,region,statuscode))
		array.append(aws_insert.insert(id_update, inputid ,functionname,WebsiteCode, "","", "", "", Guests, "", "", "", "", "",url, url, url, "", "", "", "", "", "",StartDate, EndDate , "", "", "", "", "", "", "", "", "",region,statuscode, israteperstay))
		return json.dumps(array)
