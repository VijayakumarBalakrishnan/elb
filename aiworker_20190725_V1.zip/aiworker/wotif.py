# -*- coding: utf-8 -*-
import re
import requests
import datetime
import json
import sys 
import boto
import gc
from unidecode import unidecode
from mtranslate import translate
import aws_insert
import random
# url     = 'https://www.wotif.com/Mexico-City-Hotels-Busue-A-Boutique-Experience-Hotel.h199627.Hotel-Information?chkin=2018-07-11&chkout=2018-07-12&rm1=a1&multiCurrencyCode=MXN#rooms-and-rates'
# inputid = '7777'
# id_update = 'wqwq'
# proxyip = 'user-23300:97c98f461884720d@43.241.44.135:1212'
# queueid = ''

def trans(to_translate):
    try:
        Translated = (translate(to_translate, 'en'))
        return Translated
    except:
        return to_translate 

def fetchrates(url, inputid, id_update, proxyip):
    israteperstay = ''
    RateDate = re.search(r'chkin=(.*?)&', url, re.DOTALL).group(1)
    try:
        ref_hr_url = url
        intime = re.sub(r'\s', 'T', str(datetime.datetime.now()))
        Domainname   = "Wotif"
        functionname = Domainname
        Websitecode  = 3659
        region       = ''
        conn   = boto.connect_s3(aws_access_key_id='AKIAIXEGZVXCWE2FV3SQ', aws_secret_access_key='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') 
        bucket = conn.get_bucket("rmapi")
        StartDate = datetime.date.today()
        EndDate = datetime.date.today() + datetime.timedelta(days=29)
        array = []
        def Extraction(jsonvalue, htm, url_db, id_update, inputid, RateDate, totaldays, Currencycode, StartDate, Guests, proxyip, LOS):
            try:
                parsed_htm_re = re.search(r'({"propertyData":.*?}};)', htm, re.DOTALL)
                if parsed_htm_re:
                    parsed_htm = parsed_htm_re.group(1)
                else:
                    parsed_htm = ""   
                listcodes = []
                OnsiteRate = 0
                roomavlb = 0
                Curr = ''
                Maxocp = None
                Room_Desc = ''
                Meal_NotJs = ''
                url_inc = url_db
                Closed_up = 'N'
                LOS = LOS
                israteperstay = ''
                ispromupdate = 'N'
                Roomtype = " "
                Room_Amt_tag = ''
                Ratetype = ''
                Meal = ''
                net_rate = 0
                Room_Amt = ''
                Tax_status = ''
                promotion = ''
                region = ''
                statuscode = ''
                if jsonvalue.has_key('availabilityErrors'):
                    if  jsonvalue['availabilityErrors'][0]['message'] == 'ROOMS_UNAVAILABLE_FOR_SELECTED_DATES' or jsonvalue['availabilityErrors'][0]['message'] == 'EXCEEDED_NUMBER_OF_GUESTS':
                        Closed_up = 'Y'
                        statuscode = '2'
                        # print "Matched"
                        ispromupdate = 'N'
                        LOS = 1
                        OnsiteRate = 0
                        Room_Desc = ''
                        roomavlb = 0
                        Maxocp = None
                        array.append(aws_insert.insert(id_update, inputid , Domainname, Websitecode, StartDate, Roomtype, LOS, RateDate, Guests, OnsiteRate, net_rate, OnsiteRate, Currencycode, Room_Desc, url_inc, url_inc, url_inc, Room_Amt, Meal, Maxocp, ispromupdate, Closed_up, 30, StartDate , EndDate, intime, roomavlb, None, None, Tax_status, None, Ratetype, net_rate, promotion, region, statuscode, israteperstay))
                        return json.dumps(array)
                if 'offers' in jsonvalue:
                    Closed_up = 'N'
                    ispromupdate = 'N'
                    promotion = ''
                    for roomvalue in jsonvalue['offers']:
                        if 'exceedsMaxAdults' in roomvalue:
                            if roomvalue['exceedsMaxAdults']:
                                continue
                        Tax_and_Fees = 0
                        OnsiteRate_c = 0
                        Rmtypcode = roomvalue['roomTypeCode']
                        Rmtypcode = re.sub(r'\.', '\.', re.sub(r'\|', '\|', str(Rmtypcode)))
                        Roomtype_reg_form = 'roomTypeCode":"' + Rmtypcode + '".*?"name":"(.*?)",'
                        Roomtype_reg = re.search(Roomtype_reg_form, parsed_htm, re.IGNORECASE)
                        if Roomtype_reg:
                            Roomtype_clean = Roomtype_reg.group(1)            
                            Roomtype = re.sub("'", "''", str(Roomtype_clean))
                            if Roomtype == '' or Roomtype == None:
                                if 'roomName' in roomvalue:
                                    Roomtype_clean = roomvalue['roomName']
                                    Roomtype = re.sub("'", "''", str(Roomtype_clean))
                                    Roomtype = trans(Roomtype)
                                else:
                                    Roomtype = ''
                        else:
                            if 'roomName' in roomvalue:
                                Roomtype_clean = roomvalue['roomName']
                                Roomtype = re.sub("'", "''", str(Roomtype_clean))
                                Roomtype = trans(Roomtype)
                            else:
                                Roomtype = ''
                        if 'valueAdd' in roomvalue:
                            if 'englishText' in roomvalue['valueAdd']:
                                promo_namchek = roomvalue['valueAdd']['englishText']
                                if '% off' in promo_namchek.lower():
                                    promotion = promo_namchek
                                    ispromupdate = 'Y'
                                else:
                                    ispromupdate = 'N'
                                    promotion = '' 
                            else:
                                promotion = ''    
                                ispromupdate = 'N'                    
                        else:
                            ispromupdate = 'N'
                            promotion = ''
                            
                        ratePlanCode = roomvalue['ratePlanCode']
                        checklist = str(Rmtypcode) + ' ' + str(Roomtype) + ' ' + str(ratePlanCode)
                        if checklist in listcodes:
                            continue
                        else:
                            listcodes.append(checklist)
                        if roomvalue['price'] != None:
                            onsite_rate_clean = roomvalue['price']['displayPrice']
                            if onsite_rate_clean != None:
                                onsite_rate_encode = onsite_rate_clean.encode('ascii', 'ignore')
                                onsite_rate_Str = str (onsite_rate_encode)
                                OnsiteRate = re.sub(r'[A-Z|a-z]', '', re.sub(r'(\D)', '', re.sub(r"\\u20b9|\$|,|[A-Za-z]+\.|Rs\.|Rs", r"", onsite_rate_Str)))
                            else:
                                OnsiteRate = 0
                            net_reg = roomvalue['price']['crossOutPrice']
                            if net_reg != None:
                                net_encode = net_reg.encode('ascii', 'ignore')
                                net_clean = str(net_encode)
                                net_rate = re.sub(r'[A-Z|a-z]', '', re.sub(r'(\D)', '', re.sub(r"\\u20b9|\$|,|[A-Za-z]+\.|Rs\.|Rs", r"", net_clean)))
                                ispromupdate = 'Y'
                            else:
                                net_rate = 0
                                ispromupdate = 'N'
                        else:
                            net_rate = 0
                            ispromupdate = 'N'
                            OnsiteRate = 0
                        
                        if roomvalue['totalPriceWithTaxesAndFees']!=None:
                            Tax_and_Fees = re.sub(r'0$','',str(roomvalue['totalPriceWithTaxesAndFees']['amount']))
                            Taxcheck = re.sub(r'0$','',str(roomvalue["price"]['unformattedTotalPrice']))
                        if roomvalue["price"] != None:
                            Curr = roomvalue["price"]['priceObject']["currencyCode"]
                            if Curr != None:
                                Currencycode = Curr
                        if Currencycode == '':
                            if roomvalue['feePenalty'] != None:
                                Curr = roomvalue["feePenalty"]["currencyCode"]
                                if Curr != None:
                                    Currencycode = Curr
                            else:
                                Currencycode = ''
                        isavlble = roomvalue['numberOfRoomsLeft']
                        if isavlble != None:
                            roomavlb = isavlble
                        else:
                            roomavlb = ''
                        Maxoccp = re.search(r'"roomTypeCode":"' + Rmtypcode + '".*?maxGuests[\'|\"]:(\d+)', parsed_htm)
                        if Maxoccp:
                            Maxoccp = Maxoccp.group(1)
                            Maxocp = re.sub("'", "''", str(Maxoccp))
                            if Maxocp == '0' or Maxocp == '' or Maxocp == None:
                                Maxoccp = re.search(r'"roomTypeCode":"' + Rmtypcode + '".*?total[\'|\"]:(\d+)', parsed_htm)
                                if Maxoccp:
                                    Maxoccp = Maxoccp.group(1)
                                    Maxocp = re.sub("'", "''", str(Maxoccp))
                        else:
                            Maxoccp = re.search(r'"roomTypeCode":"' + Rmtypcode + '".*?total[\'|\"]:(\d+)', parsed_htm)
                            if Maxoccp:
                                Maxoccp = Maxoccp.group(1)
                                Maxocp = re.sub("'", "''", str(Maxoccp))
                            else:
                                Maxoccp = roomvalue['maxGuests']
                                if Maxoccp != None:
                                    Maxocp = Maxoccp
                                else:
                                    Maxocp = None
                        if Maxoccp == None or Maxoccp == '0' or Maxoccp == 0:
                            Maxocp = None
                        Room_AMt_reg = '"roomTypeCode":"' + Rmtypcode + '".*?<b>(.*?)\]'
                        # ##print Room_AMt_reg
                        Room_Else = re.search(Room_AMt_reg, parsed_htm)
                        if Room_Else:
                            Room_Amt1 = re.sub(r"'", "''", str(Room_Else.group(1)))
                            Room_Amt_coma = re.sub("<b>", ", ", str(Room_Amt1))
                            Room_Amt_tag = re.sub("<.*?>|'", "", str(Room_Amt_coma))
                            Room_Amt = Room_Amt_tag
                        else:
                            Room_Amt = ''
                            
                        Room_Dec_reg = r'roomTypeCode":"' + Rmtypcode + '".*?name":".*?"description":\[(.*?)\]'
                        # ##print Room_Dec_reg
                        Room_E_Desc = re.search(Room_Dec_reg, parsed_htm)
                        if Room_E_Desc:
                            if Room_E_Desc.group(1) != None:
                                Room_Decs_group = re.sub(r"'", "''", str(Room_E_Desc.group(1).encode('ascii', 'ignore')))
                                Room_Desc_coma = re.sub("<b>" , ", ", str(Room_Decs_group))
                                Room_Desc_tag = re.sub("\s+|</strong>", " ", str(Room_Desc_coma))
                                Room_Desc = re.sub("<.*?>|'|^.*?\[", "", Room_Desc_tag.replace('"', ''))
                        else:
                            Room_Desc = Roomtype           
                        if re.search(r'"roomTypeCode":"' + str(Rmtypcode) + '".*?"361":"(.*?)"', parsed_htm):
                            Meal_NotJs = re.sub(r'(?sim)Surcharge', 'Cost', str(re.search(r'"roomTypeCode":"' + str(Rmtypcode) + '".*?"361":"(.*?)"', parsed_htm).group(1)))
                        else:
                            Meal_NotJs = '' 
                        Mealtype = roomvalue['amenities']
                        Meal = str(Mealtype) + ' ' + str(Room_Desc) + ' ' + str(Meal_NotJs)
                        if "refundable" in roomvalue:
                            Ratetype = 'Free Cancellation'
                        else:
                            Ratetype = 'Non-Refundable'

                        OnsiteRate_c = OnsiteRate
                        if Currencycode == 'IDR':
                            OnsiteRate_c = re.sub(r"\.", "", str(OnsiteRate_c))
                            Tax_and_Fees = re.sub(r"\.", "", str(Tax_and_Fees))
                        print Tax_and_Fees, Taxcheck
                        if OnsiteRate == 0:
                            Closed_up = 'Y'
                            statuscode = '1'
                        else:
                            if float(Tax_and_Fees) == float(Taxcheck):
                                Tax_status = '1'
                            else:
                                Tax_status = '2'
                            Closed_up = 'N'
                        if LOS > 1 and Currencycode in ('AUD', 'CHF', 'DKK', 'EUR', 'GBP', 'NOK', 'NZD', 'SEK') or LOS == 1:
                            israteperstay = 'Y'
                        else:
                            israteperstay = 'N'
                        if net_rate <> 0:
                            ispromupdate = 'Y'
                        else:
                            ispromupdate = 'N'
                        if Roomtype == '':
                            Roomtype_reg_form = 'roomTypeCode":"' + Rmtypcode + '".*?name":"(.*?)",'
                            Roomtype_reg = re.search(Roomtype_reg_form, parsed_htm)
                            if Roomtype_reg:
                                Roomtype_clean = Roomtype_reg.group(1)            
                                Roomtype = re.sub("'", "''", str(Roomtype_clean))
                                if Roomtype == '' or Roomtype == None:
                                    if 'roomName' in roomvalue:
                                        Roomtype_clean = roomvalue['roomName']
                                        Roomtype = re.sub("'", "''", str(Roomtype_clean))
                                        Roomtype = trans(Roomtype)
                                    else:
                                        Roomtype = ''
                            else:
                                if 'roomName' in roomvalue:
                                    Roomtype_clean = roomvalue['roomName']
                                    Roomtype = re.sub("'", "''", str(Roomtype_clean))
                                    Roomtype = trans(Roomtype)
                                else:
                                    Roomtype = ''
                        if (net_rate == 0 or net_rate == '0') and (promotion == 0 or promotion == ''):
                            ispromupdate = 'N'
                        if 'exceedsMaxGuests'  in roomvalue or 'exceedsMaxAdults' in roomvalue:
                            statuscode = 1
                            OnsiteRate = 0
                            net_rate   = 0
                        array.append(aws_insert.insert(id_update, inputid , Domainname, Websitecode, StartDate, Roomtype, LOS, RateDate, Guests, OnsiteRate, net_rate, OnsiteRate, Currencycode, Room_Desc, url_inc, url_inc, url_inc, Room_Amt, Meal, Maxocp, ispromupdate, Closed_up, 30, StartDate , EndDate, intime, roomavlb, None, None, Tax_status, None, Ratetype, net_rate, promotion, region, statuscode, israteperstay))
                else:
                    print "else"
                    Closed_up = 'Y'
                    statuscode = '2'
                    ispromupdate = 'N'
                    LOS = 1
                    OnsiteRate = 0
                    Room_Desc = ''
                    roomavlb = 0
                    Maxocp = None
                    array.append(aws_insert.insert(id_update, inputid , Domainname, Websitecode, StartDate, Roomtype, LOS, RateDate, Guests, OnsiteRate, net_rate, OnsiteRate, Currencycode, Room_Desc, url_inc, url_inc, url_inc, Room_Amt, Meal, Maxocp, ispromupdate, Closed_up, 30, StartDate , EndDate, intime, roomavlb, None, None, Tax_status, None, Ratetype, net_rate, promotion, region, statuscode, israteperstay))
            except Exception, e:
                print e
                value_error = str(re.sub(r"'", '"', str(e)))
                stacktrace = sys.exc_traceback.tb_lineno
                insert_value_error = str(value_error) + 'Where line number ' + str(stacktrace) + str(proxyip)
                print insert_value_error
                statuscode = '4'
                keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(Websitecode, datetime.datetime.now(), id_update)
                key = bucket.new_key(keyvalue)
                key.set_contents_from_string(insert_value_error)
                Guests = ''
                if re.search(r'=[a|A](\d+)[&|#]', str(url)):
                    Guests = re.search(r'=[a|A](\d+)[&|#]', str(url)).group(1)
                elif re.search(r'[a|A]dults=(\d+)&', str(url)):
                    Guests = re.search(r'[a|A]dults=(\d+)&', str(url)).group(1)
                elif re.search(r'[a|A]dult=(\d+)&', str(url)):
                    Guests = re.search(r'[a|A]dult=(\d+)&', str(url)).group(1)
                else:
                    Guests = re.search(r'=[a|A](\d+)&', str(url)).group(1)
                array.append(aws_insert.insert(id_update, inputid , functionname, Websitecode, "", "", "", "", Guests, "", "", "", "", "", url, url, url, "", "", "", "", "", "", StartDate, EndDate , "", "", "", "", "", "", "", "", "", region, statuscode, israteperstay))
                return json.dumps(array)

        try:
            ref_hr_url = url
            Guests     = ''
            if re.search(r'=[a|A](\d+)[&|#]', str(ref_hr_url)):
                Guests = re.search(r'=[a|A](\d+)[&|#]', str(ref_hr_url)).group(1)
            elif re.search(r'[a|A]dults=(\d+)&', str(url)):
                Guests = re.search(r'[a|A]dults=(\d+)&', str(ref_hr_url)).group(1)
            elif re.search(r'[a|A]dult=(\d+)&', str(url)):
                Guests = re.search(r'[a|A]dult=(\d+)&', str(ref_hr_url)).group(1)
            else:
                Guests = re.search(r'=[a|A](\d+)&', str(ref_hr_url)).group(1)
            if re.search(r'chkin=(.*?)&', ref_hr_url, re.DOTALL):
                chekn = re.search(r'chkin=(.*?)&', ref_hr_url, re.DOTALL).group(1)
            if re.search(r'chkout=(.*?)&', ref_hr_url, re.DOTALL):
                chekt = re.search(r'chkout=(.*?)&', ref_hr_url, re.DOTALL).group(1)
            delta = datetime.datetime.strptime(chekt, "%Y-%m-%d") - datetime.datetime.strptime(chekn, "%Y-%m-%d")
            LOS  = delta.days                
            RateDate = chekn    
            urlinsert1 = datetime.datetime.strptime(chekn, str('%Y-%m-%d')).strftime('%d/%m/%Y')
            urlinsert2 = datetime.datetime.strptime(chekt, str('%Y-%m-%d')).strftime('%d/%m/%Y')
            url_inse   = re.sub(r'chkin=.*?&chkout=.*?&', 'chkin=' + urlinsert1 + '&chkout=' + urlinsert2 + '&', ref_hr_url)
            # #print "FORMING_URL    :", url
            Currenc = re.search(r'multiCurrencyCode=(.*?)#', url_inse).group(1)
            # #print "Load Url", url_db
            
            
            
            proxies  = {"https": "http://{}".format(proxyip)}
            load_url = url_inse
            print load_url
            url_db = url_inse
            host   = re.search(r'(www.*?)/', url_inse).group(1)
            print host
            inpl = ['user-37082:a7d2c0d3ace90f48@45.64.105.154:1212','user-37082:a7d2c0d3ace90f48@103.250.184.172:1212','user-37082:a7d2c0d3ace90f48@103.12.211.82:1212','user-37082:a7d2c0d3ace90f48@45.64.106.37:1212','user-37082:a7d2c0d3ace90f48@45.64.106.5:1212','user-37082:a7d2c0d3ace90f48@45.64.106.27:1212','user-37082:a7d2c0d3ace90f48@103.250.184.229:1212','user-37082:a7d2c0d3ace90f48@45.64.106.62:1212','user-37082:a7d2c0d3ace90f48@45.64.106.41:1212','user-37082:a7d2c0d3ace90f48@103.250.184.252:1212']
            head     = {'Host' :host, 'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/50.0.2661.102 Safari/537.36', 'Accept' : 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8', 'Accept-Encoding' : 'gzip, deflate, br', 'Accept-Language' : 'en-US,en;q=0.5'}
            try:
                hml  = requests.get(load_url, headers=head,proxies=proxies,allow_redirects=True, timeout=15)
                if hml.status_code ==429:
                    prox = random.choice(inpl)
                    proxies      = {"https": "http://{}".format(prox)}
                    hml  = requests.get(load_url, headers=head,proxies=proxies,allow_redirects=True, timeout=15)
            except Exception, e:
                try:
                    prox = random.choice(inpl)
                    proxies      = {"https": "http://{}".format(prox)}
                    hml      = requests.get(load_url, headers=head,proxies=proxies,allow_redirects=True, timeout=20)
                    if hml.status_code ==429:
                        hml  = requests.get(load_url, headers=head,proxies=proxies,allow_redirects=True, timeout=15)
                except Exception, e:
                    value_error = str(re.sub(r"'", '', str(e)))
                    stacktrace = sys.exc_traceback.tb_lineno
                    keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(Websitecode, datetime.datetime.now(), id_update)
                    key = bucket.new_key(keyvalue)
                    key.set_contents_from_string(str(e))
                    statuscode = 5
                    Guests = ''
                    if re.search(r'=[a|A](\d+)[&|#]', str(ref_hr_url)):
                        Guests = re.search(r'=[a|A](\d+)[&|#]', str(ref_hr_url)).group(1)
                    elif re.search(r'[a|A]dults=(\d+)&', str(ref_hr_url)):
                        Guests = re.search(r'[a|A]dults=(\d+)&', str(ref_hr_url)).group(1)
                    elif re.search(r'[a|A]dult=(\d+)&', str(ref_hr_url)):
                        Guests = re.search(r'[a|A]dult=(\d+)&', str(ref_hr_url)).group(1)
                    else:
                        Guests = re.search(r'=[a|A](\d+)&', str(ref_hr_url)).group(1)
                    array.append(aws_insert.insert(id_update, inputid , functionname, Websitecode, "", "", "", "", Guests, "", "", "", "", "", url_db, url_db, url_db, "", "", "", "", "", "", StartDate, EndDate , "", "", "", "", "", "", "", "", "", region, statuscode, israteperstay))
                    return json.dumps(array)
            htm_ec = re.sub("&nbsp;", "", unidecode(hml.text).encode('utf-8'))
            htm    = htm_ec
            jsondata_re = re.search(r"infosite\.offersData\s*=\s*(.*?});", htm)
            if jsondata_re:
                jsondata  = jsondata_re.group(1)     
            else:
                jsondata  = ''
            try:
                s      = re.sub(r'&nbsp;','',str(jsondata))
                Rtdate = re.sub(r'-|\-', '', str(RateDate))
                keyvalue = "ondemand/{}/{:%Y%m%d}/source/{}.html".format(Websitecode, datetime.datetime.now(), str(inputid) + '_' + str(Rtdate) + '_' + id_update)
                key = bucket.new_key(keyvalue)
                key.set_contents_from_string(hml.text)
                keyvalue = "ondemand/{}/{:%Y%m%d}/source/{}.json".format(Websitecode, datetime.datetime.now(), str(inputid) + '_' + str(Rtdate) + '_' + id_update)
                key = bucket.new_key(keyvalue)
                key.set_contents_from_string(s)
                print hml.url
                if re.search(r'https://www.wotif\..*?/Hotel' ,hml.url) or 'Travel-Guide-Hotels' in str(hml.url):
                    statuscode = 3
                    Guests = ''
                    if re.search(r'=[a|A](\d+)[&|#]', str(ref_hr_url)):
                        Guests = re.search(r'=[a|A](\d+)[&|#]', str(ref_hr_url)).group(1)
                    elif re.search(r'[a|A]dults=(\d+)&', str(ref_hr_url)):
                        Guests = re.search(r'[a|A]dults=(\d+)&', str(ref_hr_url)).group(1)
                    elif re.search(r'[a|A]dult=(\d+)&', str(ref_hr_url)):
                        Guests = re.search(r'[a|A]dult=(\d+)&', str(ref_hr_url)).group(1)
                    else:
                        Guests = re.search(r'=[a|A](\d+)&', str(ref_hr_url)).group(1)
                    array.append(aws_insert.insert(id_update, inputid , functionname, Websitecode, "", "", "", "", Guests, "", "", "", "", "", url_db, url_db, url_db, "", "", "", "", "", "", StartDate, EndDate , "", "", "", "", "", "", "", "", "", region, statuscode, israteperstay))
                    return json.dumps(array)
                Json_V = json.loads(s)
                No_of_day = 30
                Extraction(Json_V, htm, url_db, id_update, inputid, RateDate, No_of_day, Currenc, StartDate, Guests, proxyip, LOS)
            except Exception, e:
                print "Error",e
                Json_V = ''
                if hml.status_code==429:
                    statuscode = 9
                else:
                    statuscode = '4'
                value_error = str(re.sub(r"'", '"', str(e)))
                stacktrace = sys.exc_traceback.tb_lineno
                insert_value_error = str(value_error) + 'Where line number ' + str(stacktrace) + str(proxyip)
                print insert_value_error
                keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(Websitecode, datetime.datetime.now(), id_update)
                key = bucket.new_key(keyvalue)
                key.set_contents_from_string(insert_value_error)
                Guests = ''
                if re.search(r'=[a|A](\d+)[&|#]', str(url)):
                    Guests = re.search(r'=[a|A](\d+)[&|#]', str(url)).group(1)
                elif re.search(r'[a|A]dults=(\d+)&', str(url)):
                    Guests = re.search(r'[a|A]dults=(\d+)&', str(url)).group(1)
                elif re.search(r'[a|A]dult=(\d+)&', str(url)):
                    Guests = re.search(r'[a|A]dult=(\d+)&', str(url)).group(1)
                else:
                    Guests = re.search(r'=[a|A](\d+)&', str(url)).group(1)
                array.append(aws_insert.insert(id_update, inputid , functionname, Websitecode, "", "", "", "", Guests, "", "", "", "", "", url_db, url_db, url_db, "", "", "", "", "", "", StartDate, EndDate , "", "", "", "", "", "", "", "", "", region, statuscode, israteperstay))
                return json.dumps(array)
        except Exception, e:
            print e
            value_error = str(re.sub(r"'", '"', str(e)))
            stacktrace = sys.exc_traceback.tb_lineno
            insert_value_error = str(value_error) + 'Where line number ' + str(stacktrace) + str(proxyip)
            statuscode = '4'
            print insert_value_error
            keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(Websitecode, datetime.datetime.now(), id_update)
            key = bucket.new_key(keyvalue)
            key.set_contents_from_string(insert_value_error)
            Guests = ''
            if re.search(r'=[a|A](\d+)[&|#]', str(url)):
                Guests = re.search(r'=[a|A](\d+)[&|#]', str(url)).group(1)
            elif re.search(r'[a|A]dults=(\d+)&', str(url)):
                Guests = re.search(r'[a|A]dults=(\d+)&', str(url)).group(1)
            elif re.search(r'[a|A]dult=(\d+)&', str(url)):
                Guests = re.search(r'[a|A]dult=(\d+)&', str(url)).group(1)
            else:
                Guests = re.search(r'=[a|A](\d+)&', str(url)).group(1)
            array.append(aws_insert.insert(id_update, inputid , functionname, Websitecode, "", "", "", "", Guests, "", "", "", "", "", url_db, url_db, url_db, "", "", "", "", "", "", StartDate, EndDate , "", "", "", "", "", "", "", "", "", region, statuscode, israteperstay))
            return json.dumps(array)
        Rtdate = re.sub(r'-|\-', '', str(RateDate))
        keyvalue = "ondemand/{}/{:%Y%m%d}/delivery/{}.json".format(Websitecode, datetime.datetime.now(), str(inputid) + '_' + str(Rtdate) + '_' + id_update)
        # #print keyvalue
        key = bucket.new_key(keyvalue)
        key.set_contents_from_string(json.dumps(array))
        # #print "!"*30
        #print json.dumps(array)
        return json.dumps(array)
        gc.collect()
    except Exception, e:
        print "error =", e
        value_error = str(re.sub(r"'", '"', str(e)))
        stacktrace = sys.exc_traceback.tb_lineno
        insert_value_error = str(value_error) + 'Where line number ' + str(stacktrace) + str(proxyip)
        statuscode = '4'
        print insert_value_error
        keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(Websitecode, datetime.datetime.now(), id_update)
        key = bucket.new_key(keyvalue)
        key.set_contents_from_string(insert_value_error)
        Guests = ''
        if re.search(r'=[a|A](\d+)[&|#]', str(url)):
            Guests = re.search(r'=[a|A](\d+)[&|#]', str(url)).group(1)
        elif re.search(r'[a|A]dults=(\d+)&', str(url)):
            Guests = re.search(r'[a|A]dults=(\d+)&', str(url)).group(1)
        elif re.search(r'[a|A]dult=(\d+)&', str(url)):
            Guests = re.search(r'[a|A]dult=(\d+)&', str(url)).group(1)
        else:
            Guests = re.search(r'=[a|A](\d+)&', str(url)).group(1)
        array.append(aws_insert.insert(id_update, inputid , functionname, Websitecode, "", "", "", "", Guests, "", "", "", "", "", url_db, url_db, url_db, "", "", "", "", "", "", StartDate, EndDate , "", "", "", "", "", "", "", "", "", region, statuscode, israteperstay))
        return json.dumps(array)
    
#fetchrates(url, inputid, id_update, proxyip)
