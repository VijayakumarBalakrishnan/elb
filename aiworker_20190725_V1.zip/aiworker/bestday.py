# -*- coding: utf-8 -*-
import re
import requests
import datetime
import json
import boto
import gc

import sys
import aws_insert

def fetchrates(url ,inputid, id_update, proxyip):
	try:
		israteperstay = ''
		array = []
		functionname='Bestday'
		Websitecode='271'
		region=''
		conn = boto.connect_s3(aws_access_key_id= 'AKIAIXEGZVXCWE2FV3SQ',aws_secret_access_key = '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') 
		bucket = conn.get_bucket("rmapi")
		StartDate = datetime.date.today()
		EndDate  = datetime.date.today() + datetime.timedelta(days=29)
		delta = datetime.datetime.strptime(re.search(r'&checkout=(.*?)&',url).group(1), "%Y-%m-%d") - datetime.datetime.strptime(re.search(r'#checkin=(.*?)&',url).group(1), "%Y-%m-%d")
		LOS = delta.days
		if re.search(r'currency=(.*?)&', url):
			curr_test = re.search(r'currency=(.*?)&', url).group(1)
		#print curr_test
		Date_replace=re.search(r'#checkin=(\d+)-(\d+)-(\d+)&checkout=(\d+)-(\d+)-(\d+)&',url,re.DOTALL)
		if Date_replace:
			chkin_url='dia_desde='+Date_replace.group(3)+'&mes_desde='+Date_replace.group(2)+'&anio_desde='+Date_replace.group(1)+'&dia_hasta='+Date_replace.group(6)+'&mes_hasta='+Date_replace.group(5)+'&anio_hasta='+Date_replace.group(4)+'&'
			url_1=re.sub(r'dia_desde=.*?&mes_desde=.*?&anio_desde=.*?&dia_hasta=.*?&mes_hasta=.*?&anio_hasta=.*?&',chkin_url,url)
			url=re.sub(r'#checkin=(\d+)-(\d+)-(\d+)&checkout=(\d+)-(\d+)-(\d+)&currency=.*?&','',url_1)
		
		if re.search(r'num_adultos.*?num_adultos=(\d+)&',url):
			Guests=re.search(r'num_adultos.*?num_adultos=(\d+)&',url).group(1)
		else:
			if re.search(r'num_adultos=(\d+)&',url):
				Guests=re.search(r'num_adultos=(\d+)&',url).group(1)
		if curr_test <> 'MXN':
			if 'Rooms' not in url:
				url = re.sub(r'\?','Rooms/?',url)
		if curr_test == 'MXN':
			url1 = re.sub(r"www.bestday.com/",'www.bestday.com.mx/',re.sub('Hotels','Hoteles',url))
			url  = re.sub(r'Rooms','Cuartos',url1)
		#print "Url	:",url
		main_url=url
		#print Guests,LOS
		proxies = {"https": "http://{}".format(proxyip)}
		RateDate = datetime.datetime.strptime(str(re.sub('\D','',re.search('dia_desde(.*?\d\d\d\d)',url).group(1))),'%d%m%Y').strftime('%Y-%m-%d')
		try:
			response = requests.get(main_url,proxies = proxies,timeout=50)
		except Exception,e:
			try:
				response = requests.get(main_url,proxies = proxies,timeout=50)
			except Exception,e:
				region=''
				ip=re.sub(r"\{'.*?@|'\}|:\d+","",str(proxies))
				try:
					try:
						r = requests.get('http://freegeoip.net/json/'+ip,timeout=30)
					except Exception,e:
						r = requests.get('http://freegeoip.net/json/'+ip,timeout=30)
					js = r.json()
					region=js['country_name']
				except Exception,e:
					region=''
				keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(Websitecode,datetime.datetime.now(),id_update)
				key = bucket.new_key(keyvalue)
				key.set_contents_from_string(str(e))
				statuscode=5
				Guests='1'
				array.append(aws_insert.insert(id_update, inputid ,functionname,Websitecode, "","", "", "", Guests, "", "", "", "", "",url, url, url, "", "", "", "", "", "",StartDate, EndDate , "", "", "", "", "", "", "", "", "",region,statuscode, israteperstay))
				return json.dumps(array)
		if (response.status_code <> 200):
			response = requests.get(main_url,proxies=proxies)
		if (response.status_code == 403 or response.status_code == 407):
			try:
				#random_proxy=['media:M3diAproxy@155.94.165.12:80','media:M3diAproxy@107.175.67.126:80','media:M3diAproxy@155.94.165.237:80','media:M3diAproxy@165.231.24.13:80','media:M3diAproxy@107.175.67.87:80','media:M3diAproxy@23.231.99.37:80','media:M3diAproxy@23.231.99.91:80']
				#proxyy=random.choice(random_proxy)
				#proxies = {"http": "http://{}".format(proxyy)}
				response = requests.get(main_url,proxies = proxies)
			except ValueError as e:
				response = requests.get(main_url)
		html = response.text
		html1 = html.encode('ascii','ignore')
		Rtdate=re.sub(r'-|\-','',str(RateDate))
		keyvalue = "ondemand/{}/{:%Y%m%d}/source/{}.html".format(Websitecode,datetime.datetime.now(),str(inputid)+'_'+str(Rtdate)+'_'+id_update)
		key = bucket.new_key(keyvalue)
		key.set_contents_from_string(html)
		region=''
		ip=re.sub(r"\{'.*?@|'\}|:\d+","",str(proxies))
		try:
			try:
				r = requests.get('http://freegeoip.net/json/'+ip,timeout=30)
			except Exception,e:
				r = requests.get('http://freegeoip.net/json/'+ip,timeout=30)
			js = r.json()
			region=js['country_name']
		except Exception,e:
			region=''
		Domainname=''
		Roomtype=''
		OnsiteRate=''
		NetRate=''
		OnsiteRate=''
		Curr=''
		Tax_status=''
		RateDescription=''
		RoomAmenityType=''
		MealInclusion_Type=''
		MaxOccupancy=''
		isPromotionalRate=''
		Closed_up=''
		StartDate =''
		EndDate=''
		intime=''
		Taxtype=''
		Taxamount=''
		Spaceblock=''
		isAvailable=''
		Ratetype=''
		NetRate=''
		promotion=''
		statuscode=''
		intime = re.sub(r'\s','T',str(datetime.datetime.now()))
		if re.search(re.compile(r'<li class="hotel content-summary(.*?)<!-- roomSection',re.DOTALL), html1):        
			for block in re.compile(r'<li class="hotel content-summary(.*?)<!-- roomSection',re.DOTALL).findall(html1):
				for block1 in re.compile(r'><li class="box-blue(.*?)more-info --></div>',re.DOTALL).findall(block):
					Closed_up="N"
					Ratetype = ''
					Roomtype= ''
					OnsiteRate = 0
					NetRate    = 0
					RateDescription = ''
					MaxOccupancy = ''
					RoomAmenityType = ''
					Curr = ''
					isPromotionalRate='N'
					promotion =''
					if re.search(r'id="show-night-detail".*?>(.*?)<', block1):
						Ratetype = re.sub(r"<.*?>","",re.search(r'id="show-night-detail".*?>(.*?)<', block1).group(1))
					if re.search(r'RoomName" value="(.*?)"', block):
						Roomtype = re.sub(r"'","''",re.search(r'RoomName" value="(.*?)"', block).group(1))
					if re.search(r'priceRoom_\d+">(.*?)</span>', block1):
						OnsiteRate = re.search(r'priceRoom_\d+">(.*?)</span>', block1).group(1)
					if re.search(r'--><span class="gray-span">\s*(.*?)\s*</span>', block1):
						Taxtype = re.sub(r"'","''",re.search(r'--><span class="gray-span">\s*(.*?)\s*</span>', block1).group(1))
					if re.search(r'<li class="item-rate"><a>(.*?)<a/>', block1,re.DOTALL):
						NetRate=re.search(r'<li class="item-rate"><a>(.*?)<a/>', block1,re.DOTALL).group(1)
						NetRate = re.sub(r",|\$|\D",'',str(NetRate)).strip()
						isPromotionalRate='Y'
					else:
						NetRate = 0
						isPromotionalRate='N'
					if re.search(r'"room-type"><p>(.*?)</p>', block,re.DOTALL):
						RateDescription=re.sub('<.*?>','',re.search(r'"room-type"><p>(.*?)</p>', block,re.DOTALL).group(1))
					if re.search(r'Capa.*?</h4>\s*<p>(\d+)\s', block,re.DOTALL):
						MaxOccupancy=re.search(r'Capa.*?</h4>\s*<p>(\d+)\s', block,re.DOTALL).group(1)
					if re.search(r'<li><ul><li>(.*?)</li></ul></li>', block):
						RoomAmenityType = re.sub('^,|,$','',re.sub(',+',',',re.sub('\s*|ExtraCharge\.','',re.sub('<.*?>',',',re.sub('><p>(.*?)<img src=".*?>','>',re.search(r'<li><ul><li>(.*?)</li></ul></li>', block).group(1))))))
					if re.search(r'</strong>\s*<span>(.*?)</span>\s*<span', block1):
# 						Curr = re.search(r'</strong>\s*<span>(.*?)</span>\s*<span', block1).group(1)
						Curr = re.sub(r'\$','',str(re.search(r'</strong>\s*<span>(.*?)</span>\s*<span', block1).group(1)))
					else:
						Curr = re.sub('\d|\.|\s|\,','',Curr)  
					if 'breakfast' in Ratetype.lower():
					    MealInclusion_Type1=Ratetype
					    #print "MealInclusion_Type    :",MealInclusion_Type
					else:
					    if re.search(r'id="MealPlan" value="(.*?)"', block1):
					        MealInclusion_Type1 = re.sub(r"'","''",re.search(r'id="MealPlan" value="(.*?)"', block1).group(1))
					    else:
					        MealInclusion_Type1 = ''
					if re.search(r'</h3><div class="last-chance"><p>\s*(.*?)\s*</p><\!', block1):
					    MealInclusion_Type2 = re.sub(r'<.*?>','',re.sub(r'</p>',', ',re.sub(r"'","''",re.search(r'</h3><div class="last-chance"><p>\s*(.*?)\s*</p><\!', block1).group(1))))
					else:
					    MealInclusion_Type2 =''
					if re.search(r'<div class="tooltip-content"><p>\s*(.*?\d+\%.*?)\s*</p>', block1):
					    promotion = re.sub(r'<.*?>','',re.sub(r'^.*<p>','',re.sub(r"'","''",re.search(r'<div class="tooltip-content"><p>\s*(.*?\d+\%.*?)\s*</p>', block1).group(1))))
					    isPromotionalRate='Y'
					else:
					    if re.search(r'<div class="last-chance"><p>\s*(.*?\d+\%)\s*</p>', block1):
					        promotion = re.sub(r'<.*?>','',re.sub(r'^.*<p>','',re.sub(r"'","''",re.search(r'<div class="last-chance"><p>\s*(.*?\d+\%)\s*</p>', block1).group(1))))
					        isPromotionalRate='Y'
					    else:
					        promotion =''
					MealInclusion = MealInclusion_Type1+' '+MealInclusion_Type2
					Mealtypes          = str(RateDescription)+' '+str(Roomtype)+' '+str(Ratetype)+' '+str(RoomAmenityType)+' '+str(MealInclusion)
					if Mealtypes !=None:
					    Mealtype_str = str(Mealtypes)
					    if 'breakfast' in Mealtype_str.lower() and 'dinner' in Mealtype_str.lower()  and 'lunch' in Mealtype_str.lower():
					        Meal = 'Breakfast, Lunch and Dinner'
					    elif 'breakfast' in Mealtype_str.lower() and 'dinner' in Mealtype_str.lower():
					        Meal = 'Breakfast and dinner'
					    elif 'breakfast included' in Mealtype_str.lower():
					        Meal = 'Breakfast included'
					    elif 'BREAKFAST' in Mealtype_str:
					        Meal = 'Breakfast'
					    elif 'breakfast' in Mealtype_str.lower() and 'lunch' in Mealtype_str.lower():
					        Meal = 'Breakfast and Lunch'
					    elif 'Lunch' in Mealtype_str and 'Dinner' in Mealtype_str :
					        Meal = "Lunch and Dinner"
					    elif 'breakfast' in Mealtype_str.lower() and 'lunch' in Mealtype_str.lower() and 'dinner' in Mealtype_str.lower():
					        Meal = 'Breakfast, Lunch and dinner'
					    elif 'Break fast' in Mealtype_str:
					        Meal = 'BreakFast' 
					    elif 'breakfast' in Mealtype_str.lower():
					        Meal = 'BreakFast' 
					    elif 'halfboard' in Mealtype_str.lower():
					        Meal = 'Halfboard'
					    elif 'half board' in Mealtype_str.lower():
					        Meal = 'Half board' 
					    elif 'full board' in Mealtype_str.lower():
					        Meal = 'Full Board'
					    elif 'fullboard' in Mealtype_str.lower():
					        Meal = 'FullBoard'
					    elif 'All-Inclusive' in Mealtype_str:
					        Meal = 'All-Inclusive'
					    elif 'All Inclusive' in Mealtype_str:
					        Meal = 'All Inclusive'
					    elif 'All Meals' in Mealtype_str:
					        Meal = 'All Meals'
					    elif 'All Meal' in Mealtype_str:
					        Meal = 'All Meal'
					    else:
					        Meal = ''
					else:
					    Meal = ''   
					MealInclusion_Type = Meal
					if OnsiteRate==0:
						statuscode = 1
						Tax_status = ''
						Closed ='Y'
					else:
					    statuscode = ''
					    Closed ='N'
					    Tax_status = 1
					israteperstay = 'Y'
# 					#print "MealInclusion_Type    :",MealInclusion_Type
# 					#print "Ratetype    :",Ratetype
# 					#print "Roomtype    :",Roomtype					
# 					#print "OnsiteRate  :",OnsiteRate
# 					#print "NetRate     :",NetRate
# 					#print "Curr        :",Curr
# 					#print "promotion   :",promotion
# 					#print "RoomAmenityType:",RoomAmenityType
# 					#print "isPromotionalRate:",isPromotionalRate
# 					#print"="*40
					array.append(aws_insert.insert(id_update, inputid , Domainname, Websitecode, StartDate, Roomtype, LOS, RateDate, Guests, OnsiteRate, NetRate, OnsiteRate, Curr, RateDescription, url, url, url, RoomAmenityType, MealInclusion_Type, MaxOccupancy, isPromotionalRate, Closed_up,30, StartDate , EndDate, intime, isAvailable, Taxtype, Taxamount,Tax_status, Spaceblock, Ratetype, NetRate,promotion,region,statuscode, israteperstay))
					#print (id_update, inputid , Domainname, Websitecode, StartDate, Roomtype, LOS, RateDate, Guests, OnsiteRate, NetRate, OnsiteRate, Curr, RateDescription, url, url, url, RoomAmenityType, MealInclusion_Type, MaxOccupancy, isPromotionalRate, Closed_up,30, StartDate , EndDate, intime, isAvailable, Taxtype, Taxamount,Tax_status, Spaceblock, Ratetype, NetRate,promotion,region,statuscode, israteperstay)
		else:
			statuscode ='2'
			Closed_up  ='Y'
			array.append(aws_insert.insert(id_update, inputid , Domainname, Websitecode, StartDate, Roomtype, LOS, RateDate, Guests, OnsiteRate, NetRate, OnsiteRate, Curr, RateDescription, url, url, url, RoomAmenityType, MealInclusion_Type, MaxOccupancy, isPromotionalRate, Closed_up,30, StartDate , EndDate, intime, isAvailable, Taxtype, Taxamount, Tax_status, Spaceblock, Ratetype, NetRate,promotion,region,statuscode, israteperstay))
		key = bucket.new_key("ondemand/{}/{:%Y%m%d}/delivery/{}.json".format(Websitecode,datetime.datetime.now(),str(inputid)+'_'+str(Rtdate)+'_'+id_update))
		key.set_contents_from_string(json.dumps(array))
		gc.collect()
		return json.dumps(array) 
	except Exception as e:
		Guests ='0'
		insert_value_error=str(str(re.sub(r"'",'"',str(e))))+'Where line number '+str(sys.exc_traceback.tb_lineno)+str(proxyip)
		statuscode='4'
		key = bucket.new_key("ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(Websitecode,datetime.datetime.now(),id_update))
		key.set_contents_from_string(insert_value_error)
		array.append(aws_insert.insert(id_update, inputid ,functionname,Websitecode, "","", "", "", Guests, "", "", "", "", "",url, url, url, "", "", "", "", "", "",StartDate, EndDate , "", "", "", "", "", "", "", "", "",region,statuscode, israteperstay))
		print insert_value_error
		return json.dumps(array)  
