# -*- coding: utf-8 -*-
import re
import requests
import datetime
import json
import sys 
import boto
import gc
import urllib
import aws_insert
from unidecode import unidecode

# url = 'https://hotels.travelguru.com/hotel-search/tgdom/details?checkinDate=2018-10-29&checkoutDate=2018-10-30&roomRequests[0].id=1&roomRequests[0].noOfAdults=1&roomRequests[0].noOfChildren=0&source=BOOKING_ENGINE&tenant=TGB2C&city.name=Shimla&type=rate&exclude=rates.hotels.taxPercentage,rates.hotels.ecash,rates.hotels.netRate&hotelId=00003023'
# url = 'https://hotels.travelguru.com/hotel-search/tgdom/details?checkinDate=2019-06-26&checkoutDate=2019-06-27&roomRequests[0].id=1&roomRequests[0].noOfAdults=1&roomRequests[0].noOfChildren=0&source=BOOKING_ENGINE&appType=HOTEL&tenant=TGB2C&hotelID=00009077&pg=1&htlFindMthd=booking%20engine:seo'
# url = 'https://hotels.travelguru.com/hotel-search/tgdom/details?checkinDate=2019-07-10&checkoutDate=2019-07-11&roomRequests[0].id=1&roomRequests[0].noOfAdults=1&roomRequests[0].noOfChildren=0&source=BOOKING_ENGINE&tenant=TGB2C&city.name=Tirunelveli&type=rate&exclude=rates.hotels.taxPercentage,rates.hotels.ecash,rates.hotels.netRate&hotelId=00011536'
 
# inputid = '233'
# id_update = '2345'
# proxyip = '51.159.3.60:1720'

def fetchrates(url ,inputid, id_update, proxyip):
    array = []
    israteperstay = ''
    intime=re.sub(r'\s','T',str(datetime.datetime.now()))
    Domainname='TravelGuru'
    conn = boto.connect_s3(aws_access_key_id= 'AKIAIXEGZVXCWE2FV3SQ',aws_secret_access_key = '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') 
    bucket = conn.get_bucket("rmapi")
    WebSiteCode='6'
    url_insert=''
    try:
        StartDate = datetime.date.today()
        EndDate  = datetime.date.today()+datetime.timedelta(days=29)
        if 'noOfAdults=' in url:
            adults=re.search(r'noOfAdults=(\d+)&',url)
            if adults:
                adult=adults.group(1)
            else:
                adult=1
        else:
            adult=1
        region=''
        WebSiteCode= "6"
        Roomtype=""
        RateDate=''
        Guests=str(adult)
        OnsiteRate= 0
        Netrate= 0
        Curr=""
        RateDescription=""
        RoomAmenity_Type=""
        MealInclusion_Type=""
        MaxOccupancy=""
        isPromotionalRate='N'
        Closed_up="N"
        isAvailable=""
        Ratetype=''
        promotion=""
        amnt = ''
        Tax_status=''
        statuscode=''
        hotel_id_url=''
        RateDate=''
        proxies = {"http": "http://{}".format(proxyip)}
        #url_db = re.sub("checkoutDate", "checkOutDate", url)
        #url_db = re.sub("checkinDate", "checkInDate", url_db)
        #checkinDate=2017-02-22&checkoutDate=2017-02-23&
        changurl=re.search('hotelID=.*?$',url)
        if changurl:
            url=re.sub('hotelID','hotelId',url)
        #print url
        hotel_id_urlnew=''
        if re.search('(checkinDate=.*?&checkoutDate=.*?)&',url):
            check_url_sub1 = re.search('(checkinDate=.*?&checkoutDate=.*?)&',url).group(1)
            check_url_sub=str(check_url_sub1)+'&'
        hotel_id = re.search('(hotelId=.*?)&',url)
        if hotel_id:
            hotel_id_url = hotel_id.group(1)
        else:
            hotel_id = re.search('(hotelId=.*?$)',url)
            if hotel_id:
                hotel_id_url = hotel_id.group(1)
            else:
                hotel_id=re.search('(hotelID=.*?$)',url)
                hotel_id_url = hotel_id.group(1)
        hotel_id_new = re.search('hotelId=(.*?)&',url)
        if hotel_id_new:
            hotel_id_urlnew = hotel_id_new.group(1)
        else:
            hotel_id_new = re.search('hotelId=(.*?$)',url)
            if hotel_id_new:
                hotel_id_urlnew = hotel_id_new.group(1)
            else:
                hotel_id_new =re.search('hotelID=(.*?)$',url)
                hotel_id_urlnew = hotel_id_new.group(1)            
        if re.search(r'checkinDate=(.*?)&',check_url_sub):
            chkin_url=datetime.datetime.strptime(re.search(r'checkinDate=(.*?)&',check_url_sub).group(1),str('%Y-%m-%d')).strftime('%d/%m/%Y')
        if re.search(r'&checkoutDate=(.*?)&',check_url_sub):
            chkout_url=datetime.datetime.strptime(re.search(r'checkoutDate=(.*?)&',check_url_sub).group(1),str('%Y-%m-%d')).strftime('%d/%m/%Y')
        delta = datetime.datetime.strptime(re.search(r'checkoutDate=(.*?)&',check_url_sub).group(1),str('%Y-%m-%d')) - datetime.datetime.strptime(re.search(r'checkinDate=(.*?)&',check_url_sub).group(1),str('%Y-%m-%d'))
        LOS = delta.days 
        checvk_url='checkInDate='+chkin_url+'&checkOutDate='+chkout_url
        dates='checkInDate='+chkin_url+'&checkOutDate='+chkout_url+'&'
        url_insert=re.sub(r'checkin.*?&checkout.*?&',dates,url)
        
        city = re.search(r'city.name=(.*?)&',url).group(1)
#         city = ''
#         print "hotel_id_urlnew =",hotel_id_urlnew,  hotel_id_url,   adult
        json_url = 'https://hotels.travelguru.com/tgapi/hotels/v1/hotels/'+hotel_id_urlnew+'?'+checvk_url+'&city.name='+city+'&'+hotel_id_url+'&tenant=TGB2C&rooms[0].noOfChildren=0&rooms[0].id=1&rooms[0].noOfAdults='+Guests+'&_rn=len'
#         json_url = 'https://hotels.travelguru.com/tgapi/hotels/v1/hotels/TGR-00011536?checkInDate=10/07/2019&checkOutDate=11/07/2019&city.name=Tirunelveli&hotelId=TGR-00011536&tenant=TGB2C&rooms\[0\].noOfChildren=0&rooms\[0\].id=1&rooms\[0\].noOfAdults=1&_rn=len'
#         print "json_url =",json_url
        RateDate=chkin_url
        head = {'Host':'hotels.travelguru.com', 'User-Agent':'Mozilla/5.0 (X11; Linux x86_64; rv:45.0) Gecko/20100101 Firefox/45.0', 'Accept':'application/json, text/plain, */*', 'Accept-Language':'en-US,en;q=0.5', 'Accept-Encoding':'gzip, deflate, br', 'Content-Type':'application/x-www-form-urlencoded;charset=utf-8', 'x-api-key':'RcKU4ktJuNBFV1BknPWT', 'Referer':str(url), 'Connection':'keep-alive'}
        proxies = {"https": "http://{}".format(proxyip)}
        region=''
        ip=re.sub(r"\{'.*?@|'\}|:\d+","",str(proxies))
        try:
            try:
                r = requests.get('http://freegeoip.net/json/'+ip,timeout=30)
            except Exception,e:
                r = requests.get('http://freegeoip.net/json/'+ip,timeout=30)
            js = r.json()
            region=js['country_name']
        except Exception,e:
            region=''
            
#         sn = requests.session()
#         b_res = sn.get(url, headers=head,timeout=50)
            
        try:
            hml = requests.get(json_url, headers=head,timeout=50,proxies=proxies)
#             print 'hml.status :',hml.status_code
#             print hml.text
        except Exception as e:
            value_error=str(re.sub("'",'"',str(e)))
            stacktrace=sys.exc_traceback.tb_lineno
            try:
                '''random_proxy=['media:M3diAproxy@155.94.165.12:80','media:M3diAproxy@107.175.67.126:80','media:M3diAproxy@155.94.165.237:80','media:M3diAproxy@165.231.24.13:80','media:M3diAproxy@107.175.67.87:80','media:M3diAproxy@23.231.99.37:80','media:M3diAproxy@23.231.99.91:80']
                proxyy=random.choice(random_proxy)
                proxies = {"http": "http://{}".format(proxyy)}'''
                hml = requests.get(json_url, headers=head,proxies=proxies)
            except Exception as e:
                value_error=str(re.sub("'",'"',str(e)))
                stacktrace=sys.exc_traceback.tb_lineno
                statuscode=5
                keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(WebSiteCode,datetime.datetime.now(),id_update)
                key = bucket.new_key(keyvalue)
                key.set_contents_from_string(str(e))
                Guests=adult
                array.append(aws_insert.insert(id_update, inputid ,"",WebSiteCode, "", "", "", "", Guests, "", "", "", "", "",url_insert, url_insert, url_insert, "", "", "", "", "", "",StartDate, EndDate , "", "", "", "", "", "", "", "", "",region,statuscode, israteperstay))
                return json.dumps(array)
        if (hml.status_code <> 200):
            hml = requests.get(json_url, headers=head,proxies=proxies)
        if (hml.status_code == 403 or hml.status_code == 407):
            try:
                if hml.status_code <> 200:
                    hml = requests.get(json_url, headers=head)
            except Exception as e:
                value_error=str(re.sub("'",'"',str(e)))
                stacktrace=sys.exc_traceback.tb_lineno
                keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(WebSiteCode,datetime.datetime.now(),id_update)
                key = bucket.new_key(keyvalue)
                key.set_contents_from_string(str(e))
                region=''
                ip=re.sub(r"\{'.*?@|'\}|:\d+","",str(proxies))
                try:
                    try:
                        r = requests.get('http://freegeoip.net/json/'+ip,timeout=30)
                    except Exception,e:
                        r = requests.get('http://freegeoip.net/json/'+ip,timeout=30)
                    js = r.json()
                    region=js['country_name']
                except Exception,e:
                    region=''
                statuscode=5
                Guests=adult
                array.append(aws_insert.insert(id_update, inputid ,"",WebSiteCode, "", "", "", "", Guests, "", "", "", "", "",url_insert, url_insert, url_insert, "", "", "", "", "", "",StartDate, EndDate , "", "", "", "", "", "",  "", "", "",region,statuscode, israteperstay))
                return json.dumps(array)
        try:
            #html = json.loads(hml.text)
            try:
                html = json.loads(unidecode(hml.text).encode('ascii'))
            except:
                html = hml.text
                html = urllib.unquote(html).encode('utf-8')
                html =  urllib.unquote(html).decode('utf-8')
                html = json.loads(html)
        except Exception as e:
            Closed_up = "Y"
            statuscode='4'
            WebSiteCode='6'
            array.append(aws_insert.insert(id_update, inputid ,"",WebSiteCode, "", "", "", "", Guests, "", "", "", "", "",url_insert, url_insert, url_insert, "", "", "", "", "", "",StartDate, EndDate , "", "", "", "", "", "",  "", "", "",region,statuscode, israteperstay))
            return json.dumps(array)
        Rtdate=re.sub(r'-|\-','',re.search(r'checkinDate=(.*?)&',check_url_sub).group(1))
        keyvalue = "ondemand/{}/{:%Y%m%d}/source/{}.json".format(WebSiteCode,datetime.datetime.now(),str(inputid)+'_'+str(Rtdate)+'_'+id_update)
        #hml1=json.dumps(html)
        key = bucket.new_key(keyvalue)
        key.set_contents_from_string(unidecode(hml.text).encode('ascii'))
        if html.has_key('errors'):
            noinfo = html['errors']['text']
            if "Invalid vendorId" in noinfo:
                print "invalid"
                Closed_up = "Y"
                statuscode='3'
                WebSiteCode='6'
                array.append(aws_insert.insert(id_update, inputid ,"",WebSiteCode, "", "", "", "", Guests, "", "", "", "", "",url_insert, url_insert, url_insert, "", "", "", "", "", "",StartDate, EndDate , "", "", "", "", "", "",  "", "", "",region,statuscode, israteperstay))
                return json.dumps(array)
        block_reg1 = html['data']
        if 'rates' in block_reg1:    
            for block in html['data']['rates']:
                Roomtype = ""
                RateDescription=''
                OnsiteRate = 0
                Netrate=0
                NetRate = 0
                Closed_up = 'N'
                RoomAmenityType = ""
                Curr=''
                Maxocp = None
                isPromotionalRate = 'N'
                Spaceblock=''
                promotion=''
                Roomavilable = ''
                Taxtype = ''
                MealInclusion_Type=''
                Taxamount = 0
                Ratetype = ''
                #HotelBlock = re.sub("'", "''", str(block))
                Roomtype =  re.sub("'", "''", str(block['name']))
                if block.has_key('roomDesc'):
                    RateDescription = re.sub("'", "''", str(block['roomDesc']))
                if int(Guests) == 1:                   
                    price_check = block['pricing']['perNightPrice']
                    if 'discountedPrice' in price_check:
                        #print "Inside"
                        OnsiteRate = int(block['pricing']['perNightPrice']['discountedPrice'])
                        NetRate = block['pricing']['perNightPrice']['price']
                        isPromotionalRate = 'Y'
                    else:
                        NetRate = 0
                        OnsiteRate = int(block['pricing']['perNightPrice']['price'])
                else:
                    price_check = block['pricing']
                    tax = int(block['pricing']['tax'])*int(LOS)
                    if 'discount' in price_check:
                        OnsiteRate = int(block['pricing']['discount']['price'])
                        NetRate = block['pricing']['price']
                        NetRate = int(NetRate)-int(tax)
                        isPromotionalRate = 'Y'
                    else:
                        NetRate = 0
                        OnsiteRate = int(block['pricing']['price'])
                    OnsiteRate = int(OnsiteRate)-int(tax)
                if block.has_key('currencyCode'):
                    Curr = re.sub("'", "''", str(block['currencyCode']))
#                     print 'Curr :', Curr
                else:
                    Curr = 'INR'
                if block.has_key('maxAdultOccupancy'):
                    MaxOccupancy = block['maxAdultOccupancy']
                if block.has_key('freeCancellation'):
                    Ratetype = block['freeCancellation']
                    if Ratetype:
                        Ratetype = 'FreeCancellation'
                elif block.has_key('cancellationPolicies'):
                    Ratetype = block['cancellationPolicies']
                    if 'no refund' in str(Ratetype).lower():
                        Ratetype = 'Non Refundable'
                    else:
                        Ratetype = 'Cancellation Conditional'
                else:
                    Ratetype = 'Cancellation Conditional'
                if block.has_key('inclusions'):
                    MealInclusion_Type = re.sub("\[|\]|u'", "", str(block['inclusions']))
                roomtypeid = block['roomTypeId']
                if block.has_key('roomsLeft'):
                    isAvailable = block['roomsLeft']
                promotion1 = ''
                if block.has_key('deals'):
                    deals_block = block['deals']
                    if deals_block.has_key('RATE_RULE'):
                        promotion1 = deals_block['RATE_RULE'][0]
                        isPromotionalRate = 'Y'
                promotion2 = ''
                promotion2_re = re.search(r"(\d+%\s*discount.*?)'", str(MealInclusion_Type), re.IGNORECASE)
                if promotion2_re:
                    promotion2 = promotion2_re.group(1)
                    isPromotionalRate = 'Y'
                elif re.search("(\d+\%\s*off.*?)'", str(MealInclusion_Type), re.IGNORECASE):
                    promotion2 = re.search("(\d+\%\s*off.*?)'", str(MealInclusion_Type), re.IGNORECASE).group(1)
                    isPromotionalRate = 'Y'
                else:
                    None
                promotion  = str(promotion1)+'; '+str(promotion2)
                promotion = re.sub(r'^;', '', promotion.strip()).strip()
                if html['data'].has_key('content'):
                    if html['data']['content']['rooms'].has_key(str(roomtypeid)):
                        Amnit_check = html['data']['content']['rooms'][roomtypeid]
                        if 'amenities' in Amnit_check:
                            for amt in html['data']['content']['rooms'][roomtypeid]['amenities']:
                                amnt +=', '+amt['name']
                            RoomAmenity_Type = re.sub("'", "''", re.sub("^, ", "", amnt))
                if OnsiteRate:
                    Tax_status = '2'
                else:
                    Tax_status ='-1'
                if str(OnsiteRate) == '0' or str(OnsiteRate) == '' or OnsiteRate==0:
                    statuscode=1
                    Closed_up='Y'
                else:
                    statuscode=''
                    Closed_up='N'

                if LOS > 1:
                    israteperstay = 'N'
                else:
                    israteperstay = 'Y'
#                 print 'LOS :', LOS
#                 print 'Onsiterate :', OnsiteRate
#                 print 'Netrate :', Netrate
#                 print 'israteperstay :', israteperstay
                if int(OnsiteRate) == int(Netrate):
                    Netrate = 0
                if (Netrate == 0 or Netrate == '') and (promotion == 0 or promotion == ''):
                        isPromotionalRate = 'N'
                array.append(aws_insert.insert(id_update,inputid ,Domainname,WebSiteCode,StartDate,Roomtype,LOS,RateDate,Guests,OnsiteRate,NetRate,OnsiteRate,Curr,RateDescription,url_insert,url_insert,url_insert,RoomAmenity_Type,MealInclusion_Type,MaxOccupancy,isPromotionalRate,Closed_up,30,StartDate ,EndDate,intime,isAvailable,None,None,Tax_status,None,Ratetype,Netrate,promotion,region,statuscode, israteperstay))
#                 print((id_update,inputid ,Domainname,WebSiteCode,StartDate,Roomtype,LOS,RateDate,Guests,OnsiteRate,Netrate,OnsiteRate,Curr,RateDescription,url_insert,url_insert,url_insert,RoomAmenity_Type,MealInclusion_Type,MaxOccupancy,isPromotionalRate,Closed_up,30,StartDate ,EndDate,intime,isAvailable,None,None,None,Ratetype,Netrate,promotion,statuscode))
        else:
            Closed_up = "Y"
            statuscode='2'
            WebSiteCode='6'
            array.append(aws_insert.insert(id_update,inputid ,Domainname,WebSiteCode,StartDate,Roomtype,LOS,RateDate,Guests,OnsiteRate,Netrate,OnsiteRate,Curr,RateDescription,url_insert,url_insert,url_insert,RoomAmenity_Type,MealInclusion_Type,MaxOccupancy,isPromotionalRate,Closed_up,30,StartDate ,EndDate,intime,isAvailable,None,None,Tax_status,None,Ratetype,Netrate,promotion,region,statuscode, israteperstay))
        keyvalue = "ondemand/{}/{:%Y%m%d}/delivery/{}.json".format(WebSiteCode,datetime.datetime.now(),str(inputid)+'_'+str(Rtdate)+'_'+id_update)
        key = bucket.new_key(keyvalue)
        key.set_contents_from_string(json.dumps(array))
        return json.dumps(array)
        gc.collect()
    except Exception as e:
        #print e
        value_error=str(re.sub(r"'",'"',str(e)))
        stacktrace=sys.exc_traceback.tb_lineno
        insert_value_error=str(value_error)+'Where line number '+str(stacktrace)+str(proxyip)
        print insert_value_error
        statuscode='4'
        keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(WebSiteCode,datetime.datetime.now(),id_update)
        key = bucket.new_key(keyvalue)
        key.set_contents_from_string(insert_value_error)
        Guests=adult
        array.append(aws_insert.insert(id_update, inputid ,"",WebSiteCode, "", "", "", "", Guests, "", "", "", "", "",url_insert, url_insert, url_insert, "", "", "", "", "", "",StartDate, EndDate , "", "", "", "", "", "", "", "", "",region,statuscode, israteperstay))
        return json.dumps(array)

# fetchrates(url , inputid, id_update, proxyip)
