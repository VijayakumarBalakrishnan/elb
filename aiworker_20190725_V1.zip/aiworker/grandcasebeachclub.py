# -*- coding: utf-8 -*-
import re
import requests
import datetime
import json
import boto
import gc
import sys

import aws_insert
def fetchrates(url ,inputid, id_update, proxyip):
    array      = []
    israteperstay=''
    proxies    = {"http": "http://{}".format(proxyip)}
    intime     = re.sub(r'\s','T',str(datetime.datetime.now()))
    Domainname = 'grandcasebeachclub.com'
    Websitecode= '359'
    region     = ''
    statuscode = ''
    Mealtype   = ''
    conn   = boto.connect_s3(aws_access_key_id= 'AKIAIXEGZVXCWE2FV3SQ',aws_secret_access_key = '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') 
    bucket = conn.get_bucket("rmapi")
    StartDate= datetime.date.today()
    EndDate  = datetime.date.today() + datetime.timedelta(days=29)
    try:
        CheckIn_Check_OT_re = re.search(r'#Checkin=(.*?)&Checkout=(.*?)&',url)
        if CheckIn_Check_OT_re:
            Checkin = CheckIn_Check_OT_re.group(1)
            CheckOT = CheckIn_Check_OT_re.group(2)
        else:
            Checkin = ''
            CheckOT = ''
        RateDate = Checkin
        delta    = datetime.datetime.strptime(CheckOT, "%Y-%m-%d") - datetime.datetime.strptime(Checkin, "%Y-%m-%d")
        LOS      = delta.days
        RoomType = ''
        Guests   = re.search(r"adults=(\d+)", url).group(1)
        Ratetype = ''
        RateDescription = ''
        Meal     = ''
        Taxtype  = ''
        Curr     = "USD"
        MaxOccupancy = None
        isPromotionalRate  = 'N'
        Closed   = 'Y'
        NetRate  = 0
        Taxstatus= -1
        TaxAmount= 0
        Discount = 0
        GrossRate= 0
        OnsiteRate = 0
        Promotion_Name= ''
        isAvailable = ''
        RoomAmenity_Type = ''
        inMonth_re = re.search(r'Checkin=(\d+)-(\d+)-(\d+)&Checkout=(\d+)-(\d+)-(\d+)&',url)
        if inMonth_re:
            inYear  = inMonth_re.group(1)            
            inMonth = inMonth_re.group(2)
            inDay   = inMonth_re.group(3)
        else:
            inMonth = ""
            inDay   = ''
            inYear  = '' 
        date_str   = 'checkindate='+str(inMonth)+'/'+str(inDay)+'/'+str(inYear)+'&'
        url        = re.sub(r'nights=.*?&','nights='+str(LOS)+'&',re.sub(r"checkindate.*?&",date_str, url))        
        url        = re.sub(r'#.*?$','',url)
        url_insert = url
        proxyip    = re.sub(r':.*','',str(proxyip))
        headers    = {'User-Agent':'Mozilla/5.0 (X11; Linux i686; rv:45.0) Gecko/20100101 Firefox/45.0'}
        try:
            try:
                r = requests.get('http://freegeoip.net/json/' + proxyip, timeout=30)
            except Exception, e:
                r = requests.get('http://freegeoip.net/json/' + proxyip, timeout=30)
            js = r.json()
            region = js['country_name']
        except Exception, e:
            region = ''
        try:
            hml = requests.get(url,headers=headers,proxies=proxies,timeout=50)
        except Exception, e:
            value_error = str(re.sub("'", '', str(e)))
            stacktrace = sys.exc_traceback.tb_lineno
            try:
                hml = requests.get(url,headers=headers,proxies=proxies,timeout=50)
            except Exception, e:
                value_error = str(re.sub("'", '', str(e)))
                stacktrace = sys.exc_traceback.tb_lineno
                keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(Websitecode, datetime.datetime.now(), id_update)
                key = bucket.new_key(keyvalue)
                key.set_contents_from_string(str(e) + 'Where Line number' + str(stacktrace) + str(proxies))
                statuscode = 5
                Guests = ''
                array.append(aws_insert.insert(id_update, inputid , Domainname, Websitecode, "", "", "", "", Guests, "", "", "", "", "", url, url, url, "", "", "", "", "", "", StartDate, EndDate , "", "", "", "", "", "", "", "", "", region, statuscode,israteperstay))
                return json.dumps(array)
        if hml.status_code <> 200:
            hml = requests.get(url,headers=headers,proxies=proxies,timeout=50)
        if (hml.status_code == 403 or hml.status_code == 407) or hml.status_code <> 200:
            try:
                if hml.status_code <> 200:
                    hml = requests.get(url,headers=headers,timeout=50)
            except Exception, e:
                print e
                value_error = str(re.sub("'", '', str(e)))
                stacktrace = sys.exc_traceback.tb_lineno
                keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(Websitecode, datetime.datetime.now(), id_update)
                key = bucket.new_key(keyvalue)
                key.set_contents_from_string(str(e) + 'Where Line number' + str(stacktrace) + str(proxies))
                statuscode = 5
                Guests = ''
                array.append(aws_insert.insert(id_update, inputid , Domainname, Websitecode, "", "", "", "", Guests, "", "", "", "", "", url, url, url, "", "", "", "", "", "", StartDate, EndDate , "", "", "", "", "", "", "", "", "", region, statuscode,israteperstay))
                return json.dumps(array)            
        json_data=hml.text.encode('utf-8')
        Rtdate=re.sub(r'-|\-','',str(RateDate))
        keyvalue = "ondemand/{}/{:%Y%m%d}/source{}.html".format(Websitecode,datetime.datetime.now(),str(inputid)+'_'+str(Rtdate)+'_'+id_update)
        key = bucket.new_key(keyvalue)
        key.set_contents_from_string(json_data)        
        if re.compile(r'foShell">\s*<h1 class="sIFR-ignore">.*?</ul></section>', re.DOTALL).findall(json_data):
            for RoomBlock in re.compile(r'foShell">\s*<h1 class="sIFR-ignore">.*?</ul></section>', re.DOTALL).findall(json_data):
                for block2 in re.compile(r'<h1 class="sIFR-ignore">.*?</div></div></div>', re.DOTALL).findall(RoomBlock):
                    RoomType_re = re.search(r'class="sIFR-ignore">(.*?)</h1>', block2)
                    if RoomType_re:
                        RoomType = RoomType_re.group(1)
                    else:
                        RoomType = ""
                    RateDescription_re = re.search(r'Overview</h2>\s*<p>\s*(.*?)\s*</', block2)
                    if RateDescription_re:
                        RateDescription = re.sub(r"'","''",re.sub(r'\s\s\s*','',re.sub(r'<.*?>','',str(RateDescription_re.group(1)))))
                    else:
                        RateDescription = ""
                    
                    RateType_re_re = re.search(r'foShell">\s*<h1 class="sIFR-ignore">(.*?)<', RoomBlock)
                    if RateType_re_re:
                        Ratetype = RateType_re_re.group(1)
                    else:
                        Ratetype = ""
                        
                    OnsiteRate_re = re.search(r'"priceFinal">.*?;(.*?)<', block2)
                    if OnsiteRate_re:
                        OnsiteRate = OnsiteRate_re.group(1)
                    else:
                        OnsiteRate = 0
                    Mealtypes          = str(RateDescription)+' '+str(RoomType)+' '+str(Ratetype)
                    if Mealtypes !=None:
                        Mealtype_str = str(Mealtypes)
                        if 'breakfast' in Mealtype_str.lower() and 'dinner' in Mealtype_str.lower()  and 'lunch' in Mealtype_str.lower():
                            Meal = 'Breakfast, Lunch and Dinner'
                        elif 'breakfast' in Mealtype_str.lower() and 'dinner' in Mealtype_str.lower():
                            Meal = 'Breakfast and dinner'
                        elif 'breakfast included' in Mealtype_str.lower():
                            Meal = 'Breakfast included'
                        elif 'BREAKFAST' in Mealtype_str:
                            Meal = 'Breakfast'
                        elif 'breakfast' in Mealtype_str.lower() and 'lunch' in Mealtype_str.lower():
                            Meal = 'Breakfast and Lunch'
                        elif 'Lunch' in Mealtype_str and 'Dinner' in Mealtype_str :
                            Meal = "Lunch and Dinner"
                        elif 'breakfast' in Mealtype_str.lower() and 'lunch' in Mealtype_str.lower() and 'dinner' in Mealtype_str.lower():
                            Meal = 'Breakfast, Lunch and dinner'
                        elif 'Break fast' in Mealtype_str:
                            Meal = 'BreakFast' 
                        elif 'breakfast' in Mealtype_str.lower():
                            Meal = 'BreakFast' 
                        elif 'halfboard' in Mealtype_str.lower():
                            Meal = 'Halfboard'
                        elif 'half board' in Mealtype_str.lower():
                            Meal = 'Half board' 
                        elif 'full board' in Mealtype_str.lower():
                            Meal = 'Full Board'
                        elif 'fullboard' in Mealtype_str.lower():
                            Meal = 'FullBoard'
                        elif 'All-Inclusive' in Mealtype_str:
                            Meal = 'All-Inclusive'
                        elif 'All Inclusive' in Mealtype_str:
                            Meal = 'All Inclusive'
                        elif 'All Meals' in Mealtype_str:
                            Meal = 'All Meals'
                        elif 'All Meal' in Mealtype_str:
                            Meal = 'All Meal'
                        else:
                            Meal = ''
                    else:
                        Meal = ''    
                    if OnsiteRate==0:
                        statuscode = 1
                        Closed='Y'
                    else:
                        statuscode = ''
                        Closed='N'
                    if TaxAmount!=0:
                        Taxstatus = 1            
                    '''#print "RoomType :-",RoomType
                    #print "Ratetype :-",Ratetype
                    #print "RateDescription :-",RateDescription
                    #print "Amount   :-",OnsiteRate
                    #print "Prmotion :-",Promotion_Name
                    #print "isPromotionalRate  :-",isPromotionalRate
                    #print "NetRate  :-",NetRate
                    #print "Currency :-",Curr
                    #print "Discount :-",Discount
                    #print "MealType :-",Meal
                    #print "Closed   :-",Closed
                    #print "Taxstatus:-",Taxstatus
                    #print "status_cd:-",statuscode
                    #print "_"*30'''
                    GrossRate = OnsiteRate
                    Mealtype  = Meal
                    RateDate  = Checkin
                    LOS       = int(LOS)
                    if int(LOS) >1:
                        israteperstay = 'N'
                    else:
                        israteperstay ='Y'
                    array.append(aws_insert.insert(id_update, inputid , Domainname, Websitecode, StartDate, RoomType, LOS, RateDate, Guests, OnsiteRate, NetRate, GrossRate, Curr, RateDescription, url_insert, url_insert, url_insert, RoomAmenity_Type, Mealtype, MaxOccupancy, isPromotionalRate, Closed, 30, StartDate , EndDate, intime, isAvailable, Taxtype, TaxAmount, Taxstatus, None, Ratetype, Discount,Promotion_Name,region,statuscode,israteperstay))
        else:
            Closed     = 'Y'
            statuscode = '2'
            array.append(aws_insert.insert(id_update, inputid , Domainname, Websitecode, StartDate, RoomType, LOS, RateDate, Guests, OnsiteRate, NetRate, GrossRate, Curr, RateDescription, url_insert, url_insert, url_insert, RoomAmenity_Type, Mealtype, MaxOccupancy, isPromotionalRate, Closed, 30, StartDate , EndDate, intime, isAvailable, Taxtype, TaxAmount, Taxstatus, None, Ratetype, Discount,Promotion_Name,region,statuscode,israteperstay))
        Rtdate = re.sub(r'-|\-', '', str(RateDate))
        keyvalue = "ondemand/{}/{:%Y%m%d}/delivery/{}.json".format(Websitecode,datetime.datetime.now(),str(inputid)+'_'+str(Rtdate)+'_'+id_update)
        key = bucket.new_key(keyvalue)
        key.set_contents_from_string(json.dumps(array))
        return json.dumps(array)
        gc.collect()
    except Exception as e:
        print e
        value_error = str(re.sub(r"'", '"', str(e)))
        stacktrace = sys.exc_traceback.tb_lineno
        Guests = ''
        region = ''
        insert_value_error = str(value_error) + 'Where line number ' + str(stacktrace) + str(proxyip)
        statuscode = '4'
        keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(Websitecode, datetime.datetime.now(), id_update)
        key = bucket.new_key(keyvalue)
        key.set_contents_from_string(insert_value_error)
        array.append(aws_insert.insert(id_update, inputid , Domainname, Websitecode, "", "", "", "", Guests, "", "", "", "", "", url, url, url, "", "", "", "", "", "", StartDate, EndDate , "", "", "", "", "", "", "", "", "", region, statuscode,israteperstay))
        return json.dumps(array)
'''url       = 'https://www.secure-res.com/res/vn4/checka.aspx?checkindate=05/26/2017&rooms=1&adults=2&children=0&nights=&culture=1&culturename=en-US&hotelid=523#Checkin=2018-03-26&Checkout=2018-03-29&'
inputid   = 'Test'            
id_update = ''
proxyip   = ''
fetchrates(url ,inputid, id_update, proxyip)
'''
