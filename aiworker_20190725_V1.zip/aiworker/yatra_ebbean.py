# -*- coding: utf-8 -*-
import re
import requests
import datetime
import json
import boto
import gc
import sys
import urllib
import aws_insert
from unidecode import unidecode

# inputid='Gokul'
# id_update='12345'
# proxyip='user-23300:97c98f461884720d@45.64.106.59:1212'
# url='https://hotel.yatra.com/hotel-search/dom/details?checkinDate=2019-07-11&checkoutDate=2019-07-12&roomRequests[0].id=1&roomRequests[0].noOfAdults=1&roomRequests[0].noOfChildren=0&source=BOOKING_ENGINE&pg=1&tenant=B2C&city.name=Shimla&city.code=Shimla&country.name=India&country.code=IND&hotelId=00040181'


def fetchrates(url ,inputid, id_update, proxyip):    
	array = []
	israteperstay = ''
	intime=re.sub(r'\s','T',str(datetime.datetime.now()))
	Domainname='Yatra.com'
	Websitecode='261'
	region=''
	statuscode=''
	conn = boto.connect_s3(aws_access_key_id= 'AKIAIXEGZVXCWE2FV3SQ',aws_secret_access_key = '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') 
	bucket = conn.get_bucket("rmapi")
	StartDate = datetime.date.today()
	EndDate  = datetime.date.today() + datetime.timedelta(days=29)
	#print url
	tax  = 0
	try:
		url_db=url
		url_db = re.sub("hotelID", "hotelId", re.sub("hotelid", "hotelId", re.sub("checkinDate", "checkInDate", re.sub("checkoutDate", "checkOutDate", re.sub("checkindate", "checkinDate", re.sub("checkoutdate", "checkoutDate", url_db))))))
		if re.search('checkInDate=.*?&checkOutDate=.*?&',url_db):
			url_db=re.sub(r'checkInDate=.*?&checkOutDate=.*?&','checkInDate='+str(datetime.datetime.strptime(str(re.search('checkInDate=(.*?)&checkOutDate=(.*?)&',url_db).group(1)),'%Y-%m-%d').strftime('%d/%m/%Y'))+'&checkOutDate='+str(datetime.datetime.strptime(str(re.search('checkInDate=(.*?)&checkOutDate=(.*?)&',url_db).group(2)),'%Y-%m-%d').strftime('%d/%m/%Y'))+'&',url_db)
		if re.search('(checkInDate=.*?&checkOutDate=.*?)&',url_db):
			check_url = re.search('(checkInDate=.*?&checkOutDate=.*?)&',url_db).group(1)
		if 'int' in url:
			if re.search('(hotelId=.*?)&',url_db):
				hotel_id_url = re.sub(r'tgr-|tgr','',re.search('(hotelId=.*?)&',url_db).group(1))
			else:
				if re.search('(hotelId=.*?$)',url_db):
					hotel_id_url = re.sub(r'tgr-|tgr','',re.search('(hotelId=.*?$)',url_db).group(1))
			if re.search('hotelId=(.*?)&',url_db):
				hotel_id_urlnew = re.sub(r'tgr-|tgr','',re.search('hotelId=(.*?)&',url_db).group(1))
			else:
				if re.search('hotelId=(.*?$)',url_db):
					hotel_id_urlnew = re.sub(r'tgr-|tgr','',re.search('hotelId=(.*?$)',url_db).group(1))
		else:
			if re.search('(hotelId=.*?)&',url_db):
				hotel_id_url = re.sub(r'tgr-|tgr','',re.search('(hotelId=.*?)&',url_db).group(1).lower())
			else:
				if re.search('(hotelId=.*?$)',url_db):
					hotel_id_url = re.sub(r'tgr-|tgr','',re.search('(hotelId=.*?$)',url_db).group(1).lower())
			if re.search('hotelId=(.*?)&',url_db):
				hotel_id_urlnew = re.sub(r'tgr-|tgr','',re.search('hotelId=(.*?)&',url_db).group(1).lower())
			else:
				if re.search('hotelId=(.*?$)',url_db):
					hotel_id_urlnew = re.sub(r'tgr-|tgr','',re.search('hotelId=(.*?$)',url_db).group(1).lower())
		Guests=""
		if re.search(r'dults=(.*?)&',url_db):
			Guests = re.search(r'dults=(.*?)&',url_db).group(1)
		RateDate=''
		if re.search(r'checkinDate=(.*?)&', url_db):
			Ratedate = re.search(r'checkinDate=(.*?)&', url_db).group(1)
			if Ratedate:
				RateDate = datetime.datetime.strptime(str(Ratedate),'%d/%m/%Y').strftime('%Y-%m-%d')
		elif re.search(r'checkInDate=(.*?)&', url_db):
			Ratedate = re.search(r'checkInDate=(.*?)&', url_db).group(1)
			if Ratedate:
				RateDate = datetime.datetime.strptime(str(Ratedate),'%d/%m/%Y').strftime('%Y-%m-%d')
		if re.search('checkInDate=(.*?)&',url_db):
			check_in_date = datetime.datetime.strptime(datetime.datetime.strptime(str(re.search('checkInDate=(.*?)&',url_db).group(1)),'%d/%m/%Y').strftime('%Y, %m, %d'),'%Y, %m, %d')
		if re.search('checkInDate=.*?&checkOutDate=(.*?)&',url_db):
			check_out_date = datetime.datetime.strptime(datetime.datetime.strptime(str(re.search('checkInDate=.*?&checkOutDate=(.*?)&',url_db).group(1)),'%d/%m/%Y').strftime('%Y, %m, %d'),'%Y, %m, %d')
		LOS = check_out_date - check_in_date
		LOS = LOS.days    
		#head = {'User-Agent':'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:12.0) Gecko/20100101 Firefox/31.0'}
		proxies={"http": "http://{}".format(proxyip)}
		region=''
		ip=re.sub(r"\{'.*?@|'\}|:\d+","",str(proxies))
		try:
			try:
				r = requests.get('http://freegeoip.net/json/'+ip,timeout=30)
			except Exception,e:
				r = requests.get('http://freegeoip.net/json/'+ip,timeout=30)
			js = r.json()
			region=js['country_name']
		except Exception,e:
			region=''
		city = re.search(r'city.name=(.*?)&',url).group(1)
		city = ''
		if 'int' in url:
			head = {'Host':'hotel.yatra.com', 'User-Agent':'Mozilla/5.0 (X11; Linux x86_64; rv:45.0) Gecko/20100101 Firefox/45.0', 'Accept':'application/json, text/plain, */*', 'Accept-Language':'en-US,en;q=0.5', 'Accept-Encoding':'gzip, deflate, br', 'Content-Type':'application/x-www-form-urlencoded;charset=utf-8', 'x-api-key':'G0O6MHNGv9HU4kIfRIWm', 'Referer':str(url), 'Connection':'keep-alive'}
			json_url = 'https://hotel.yatra.com/tgapi/hotels/v1/hotels/'+hotel_id_urlnew+'?'+check_url+'&city.name='+city+'&'+hotel_id_url+'&tenant=B2C&rooms[0].noOfChildren=0&rooms[0].id=1&rooms[0].noOfAdults='+Guests+'&_rn=jtm'
		else:
			head = {'Host':'hotel.yatra.com', 'User-Agent':'Mozilla/5.0 (X11; Linux x86_64; rv:45.0) Gecko/20100101 Firefox/45.0', 'Accept':'application/json, text/plain, */*', 'Accept-Language':'en-US,en;q=0.5', 'Accept-Encoding':'gzip, deflate, br', 'Content-Type':'application/x-www-form-urlencoded;charset=utf-8', 'x-api-key':'JN9aWyj7hJ1ZrExC7Ozo', 'Referer':str(url), 'Connection':'keep-alive'}
			json_url = 'https://hotel.yatra.com/tgapi/hotels/v1/hotels/'+hotel_id_urlnew+'?'+check_url+'&city.name='+city+'&'+hotel_id_url+'&tenant=B2C&rooms[0].noOfChildren=0&rooms[0].id=1&rooms[0].noOfAdults='+Guests+'&_rn=qtq'
	#         print json_url
		try:
			hml = requests.get(json_url, headers=head, proxies = proxies,timeout=30)
	#             print hml.status_code
		except Exception,e:
			try:
				hml = requests.get(json_url, headers=head, proxies = proxies,timeout=30)
			except Exception,e:
				value_error=str(re.sub("'",'"',str(e)))
				stacktrace=sys.exc_traceback.tb_lineno
				insert_value_error=str(value_error)+'Where line number '+str(stacktrace)+str(proxyip)
				print insert_value_error
				keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(Websitecode,datetime.datetime.now(),id_update)
				key = bucket.new_key(keyvalue)
				key.set_contents_from_string(insert_value_error)
				statuscode=5
				Guests='1'
				array.append(aws_insert.insert(id_update, inputid ,Domainname,Websitecode, "","", "", "", Guests, "", "", "", "", "",url_db, url_db, url_db, "", "", "", "", "", "",StartDate, EndDate , "", "", "", "", "", "",  "", "", "",region,statuscode, israteperstay))
				return json.dumps(array)
		if (hml.status_code<> 200):
			hml = requests.get(json_url, headers=head, proxies = proxies)
		if (hml.status_code == 403 or hml.status_code == 407 or hml.status_code <> 200):
			try:
				hml = requests.get(json_url, headers=head, proxies = proxies)
			except Exception as e:
				print e
				try:
					hml = requests.get(json_url, headers=head)
				except Exception as e:
					value_error=str(re.sub("'",'"',str(e)))
					stacktrace=sys.exc_traceback.tb_lineno
					insert_value_error=str(value_error)+'Where line number '+str(stacktrace)+str(proxyip)
					print insert_value_error
					keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(Websitecode,datetime.datetime.now(),id_update)
					key = bucket.new_key(keyvalue)
					key.set_contents_from_string(insert_value_error)
					statuscode=5
					Guests='1'
					array.append(aws_insert.insert(id_update, inputid ,"",Websitecode, "", "", "", "", Guests, "", "", "", "", "",url_db, url_db, url_db, "", "", "", "", "", "",StartDate, EndDate , "", "", "", "", "", "", "", "", "",region,statuscode, israteperstay))
					return json.dumps(array)
		
		#hml = requests.get(json_url, headers=head, proxies = proxies)
		try:
			html = json.loads(unidecode(hml.text).encode('ascii'))
		except:
			html = hml.text
			html = urllib.unquote(html).encode('utf-8')
			html =  urllib.unquote(html).decode('utf-8')
			html = json.loads(html)
		#open('name.html', 'w').write(unidecode(str(hml.text).encode('ascii')))
		Rtdate=re.sub(r'-|\-','',RateDate)
		keyvalue = "ondemand/{}/{:%Y%m%d}/source/{}.json".format(Websitecode,datetime.datetime.now(),str(inputid)+'_'+str(Rtdate)+'_'+id_update)
		key = bucket.new_key(keyvalue)
		key.set_contents_from_string(str(unidecode(hml.text).encode('ascii')))
		Roomtype = ""
		RateDescription=''
		OnsiteRate = 0
		GrossRate = 0
		NetRate=0
		Closed_up = 'N'
		RoomAmenityType = ""
		Curr=''
		Maxocp = None
		isPromotionalRate = 'N'
		Spaceblock=''
		promotion=''
		Roomavilable = ''
		Taxtype = ''
		MealInclusion_Type=''
		Taxamount = 0
		Ratetype = ''
		Tax_status=''
		amnt=''    
	#         print "yatra.com"
		if 'data' in html:
			block_reg1 = html['data']
			if 'rates' in block_reg1:
				Spaceblock=''
				for block in html['data']['rates']:
					Roomtype = ""
					RateDescription=''
					OnsiteRate = 0
					NetRate=0
					Closed_up = 'N'
					RoomAmenityType = ""
					Curr=''
					Maxocp = None
					isPromotionalRate = 'N'
					Spaceblock=''
					promotion=''
					Roomavilable = ''
					Taxtype = ''
					MealInclusion_Type=''
					Taxamount = 0
					Ratetype = ''
					RoomType =  re.sub("'", "''", str(block['name']))
					Roomtype = re.sub(r"&.*?;", "", RoomType)
					if block.has_key('roomDesc'):
						RateDescription = re.sub("'", "''", str(block['roomDesc']))
					Tax_status=2     
					if 'int' in url:         
						price_check = block['pricing']
						if 'discount' in price_check:
							OnsiteRate = int(block['pricing']['discount']['price'])
							NetRate = block['pricing']['price']
							isPromotionalRate = 'Y'
						else:
							NetRate = 0
							isPromotionalRate = 'N'
							OnsiteRate = int(block['pricing']['price'])
					else:      
						if int(Guests) == 1:                   
							price_check = block['pricing']
							if block['pricing'].has_key('tax'):
								tax = int(block['pricing']['tax'])*int(LOS)
							if 'discount' in price_check:
								OnsiteRate = int(block['pricing']['discount']['price'])
								NetRate = block['pricing']['price']
								NetRate = int(NetRate)-int(tax)
								isPromotionalRate = 'Y'
							else:
								NetRate = 0
								isPromotionalRate = 'N'
								OnsiteRate = int(block['pricing']['price'])
							OnsiteRate = int(OnsiteRate)-int(tax)
						else:
							price_check = block['pricing']
							if block['pricing'].has_key('tax'):
								tax = int(block['pricing']['tax'])*int(LOS)
							if 'discount' in price_check:
								OnsiteRate = int(block['pricing']['discount']['price'])
								NetRate = block['pricing']['price']
								NetRate = int(NetRate)-int(tax)
								isPromotionalRate = 'Y'
							else:
								NetRate = 0
								isPromotionalRate = 'N'
								OnsiteRate = int(block['pricing']['price'])
							OnsiteRate = int(OnsiteRate)-int(tax)
					if NetRate != 0:
						isPromotionalRate = 'Y'
					GrossRate=OnsiteRate
					if block.has_key('currencyCode'):
						Curr = re.sub("'", "''", str(block['currencyCode']))
					else:
						Curr = 'INR'
	#                    Discount = NetRate
					if block.has_key('maxAdultOccupancy'):
						Maxocp = block['maxAdultOccupancy']
					if Maxocp == 0:
						if block.has_key('maxGuestOccupancy'):
							Maxocp = block['maxGuestOccupancy']
					if block.has_key('freeCancellation'):
						Ratetype = block['freeCancellation']
						if Ratetype:
							Ratetype = 'FreeCancellation'
					elif block.has_key('cancellationPolicies'):
						Ratetype = block['cancellationPolicies']
						if 'no refund' in str(Ratetype).lower():
							Ratetype = 'Non Refundable'
						else:
							Ratetype = 'Cancellation Conditional'
					else:
						Ratetype = 'Cancellation Conditional'
					if block.has_key('inclusions'):
						MealInclusion_Type = re.sub("\[|\]|'|u'|Cocktail", "", str(block['inclusions']))
						MealInclusion_Type = re.sub(r"\d+%.*?charge to be paid","",str(MealInclusion_Type))
						MealInclusion_Type = re.sub(r"charges|charge","cost",str(MealInclusion_Type).lower())
					if block.has_key('deals'):
						deals_block = block['deals']
						if deals_block.has_key('VendorMessage'):
							Promotion_Name = deals_block['VendorMessage'][0]
							isPromotionalRate = 'Y'
					roomtypeid = block['roomTypeId']
					if block.has_key('roomsLeft'):
						Roomavilable = block['roomsLeft']
					if html['data'].has_key('content'):
						if html['data']['content'].has_key('rooms'):
							if html['data']['content']['rooms'].has_key(str(roomtypeid)):
								Amnit_check = html['data']['content']['rooms'][roomtypeid]
								if 'amenities' in Amnit_check:
									for amt in html['data']['content']['rooms'][roomtypeid]['amenities']:
										amnt +=', '+amt['name']
									RoomAmenityType = re.sub("'", "''", re.sub("^, ", "", amnt))
					if OnsiteRate==0 or str(OnsiteRate) == '0':
						Closed_up = 'Y'
						statuscode='1'
						Tax_status='-1'
					else:
						Closed_up = 'N'
						statuscode='0'
					israteperstay = 'Y'
					if (NetRate == 0 or NetRate == '') and (promotion == 0 or promotion == ''):
						isPromotionalRate = 'N'
					array.append(aws_insert.insert(id_update, inputid , Domainname, Websitecode, StartDate, Roomtype, LOS, RateDate, Guests, OnsiteRate, NetRate, GrossRate, Curr, RateDescription, url_db, url_db, url_db, RoomAmenityType, MealInclusion_Type, Maxocp, isPromotionalRate, Closed_up, 30, StartDate , EndDate, intime, Roomavilable, Taxtype, Taxamount, Tax_status, Spaceblock, Ratetype, NetRate,promotion,region,statuscode, israteperstay))
# 					print (id_update, inputid , Domainname, Websitecode, StartDate, Roomtype, LOS, RateDate, Guests, OnsiteRate, NetRate, GrossRate, Curr, RateDescription, url_db, url_db, url_db, RoomAmenityType, MealInclusion_Type, Maxocp, isPromotionalRate, Closed_up, 30, StartDate , EndDate, intime, Roomavilable, Taxtype, Taxamount, Tax_status, Spaceblock, Ratetype, NetRate,promotion,region,statuscode)
			else:
	#                 print "else :",url_db
				Closed_up = 'Y'
				statuscode='2'
				array.append(aws_insert.insert(id_update, inputid , Domainname, Websitecode, StartDate, Roomtype, LOS, RateDate, Guests, OnsiteRate, NetRate, GrossRate, Curr, RateDescription, url_db, url_db, url_db, RoomAmenityType, MealInclusion_Type, Maxocp, isPromotionalRate, Closed_up, 30, StartDate , EndDate, intime, Roomavilable, Taxtype, Taxamount, Tax_status, Spaceblock, Ratetype, NetRate,promotion,region,statuscode, israteperstay))
		else:
	#             print "else 2:",url_db
			Closed_up = 'Y'
			statuscode='2'    
			array.append(aws_insert.insert(id_update, inputid , Domainname, Websitecode, StartDate, Roomtype, LOS, RateDate, Guests, OnsiteRate, NetRate, GrossRate, Curr, RateDescription, url_db, url_db, url_db, RoomAmenityType, MealInclusion_Type, Maxocp, isPromotionalRate, Closed_up, 30, StartDate , EndDate, intime, Roomavilable, Taxtype, Taxamount, Tax_status, Spaceblock, Ratetype, NetRate,promotion,region,statuscode, israteperstay))
			#print (id_update, inputid , Domainname, Websitecode, StartDate, Roomtype, LOS, RateDate, Guests, OnsiteRate, NetRate, GrossRate, Curr, RateDescription, url_db, url_db, url_db, RoomAmenityType, MealInclusion_Type, Maxocp, isPromotionalRate, Closed_up, 30, StartDate , EndDate, intime, Roomavilable, Taxtype, Taxamount, Tax_status, Spaceblock, Ratetype, NetRate,promotion,region,statuscode)
		Rtdate=re.sub(r'-|\-','',RateDate)
		keyvalue = "ondemand/{}/{:%Y%m%d}/delivery/{}.json".format(Websitecode,datetime.datetime.now(),str(inputid)+'_'+str(Rtdate)+'_'+id_update)
		key = bucket.new_key(keyvalue)
		key.set_contents_from_string(json.dumps(array))
		gc.collect()
		return json.dumps(array)    
	except Exception as e:
		insert_value_error=str(str(re.sub(r"'",'"',str(e))))+'Where line number '+str(sys.exc_traceback.tb_lineno)+str(proxyip)
		print insert_value_error
		statuscode='4'
		Guests='1'
		keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(Websitecode,datetime.datetime.now(),id_update)
		key = bucket.new_key(keyvalue)
		key.set_contents_from_string(insert_value_error)
		array.append(aws_insert.insert(id_update, inputid ,Domainname,Websitecode, "","", "", "", Guests, "", "", "", "", "",url_db, url_db, url_db, "", "", "", "", "", "",StartDate, EndDate , "", "", "", "", "", "",  "", "", "",region,statuscode, israteperstay))
		return json.dumps(array)


# fetchrates(url ,inputid, id_update, proxyip)
