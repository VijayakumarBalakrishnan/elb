# -*- coding: utf-8 -*-
import re
import requests
import datetime
import operator
import json
import sys 
import boto
import gc
import aws_insert

# url       = 'https://www.priceline.com/stay/search/details/28277104/2019-07-29/2019-07-30/1/?cityName=undefined&currency=INR&1#'
# inputid   = '123'
# id_update = '23'
# proxyip   = 'media:365med!a@185.227.240.112:80'

def fetchrates(url ,inputid, id_update, proxyip):    
    array         = []
    israteperstay = ''
    intime        = re.sub(r'\s','T',str(datetime.datetime.now()))
    functionname  = 'Priceline'
    Websitecode   = 34
    StartDate     = datetime.date.today()
    EndDate       = datetime.date.today() + datetime.timedelta(days=29)
    currency      = ''
    conn    = boto.connect_s3(aws_access_key_id= 'AKIAIXEGZVXCWE2FV3SQ',aws_secret_access_key = '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') 
    bucket  = conn.get_bucket("rmapi")
    global OnsiteRate
    region  = ''
    adults  = re.search(r'&currency=.*?&(\d+)#',url)
    if adults:
        adult = re.search(r'&currency=.*?&(\d+)#',url).group(1)
    else:
        adult = re.search(r'&cy=.*?&(\d+)#',url).group(1)
    Guests  = adult
    proxies = {"http": "http://{}".format(proxyip)}
    ip      = re.sub(r"\{'.*?@|'\}|:\d+","",str(proxies))
    
    print proxies
    try:
        try:
            r = requests.get('http://freegeoip.net/json/'+ip,timeout=30)
        except Exception,e:
            r = requests.get('http://freegeoip.net/json/'+ip,timeout=30)
        js = r.json()
        region=js['country_name']
    except Exception,e:
        region=''
    try:
        curr_re = re.search(r'&currency=(.*?)&',url,re.DOTALL)
        if curr_re:
            currency = curr_re.group(1)
            url      = re.sub(r'&currency=.*?&','',url)
        baseurl  = re.sub(r'-','',url)
        checkin  = ''
        checkout = ''
        Guests   = adult
        delta    = datetime.datetime.strptime(re.search(r"ls/(.*?)/(.*?)/(.*?)/", url).group(3), "%Y-%m-%d") - datetime.datetime.strptime(re.search(r"ls/(.*?)/(.*?)/(.*?)/", url).group(2), "%Y-%m-%d")
        LOS      = delta.days
        Details_ID=''
        if re.search(r"ls/(.*?)/(.*?)/(.*?)/", url):
            Details_ID = re.search(r"ls/(.*?)/(.*?)/(.*?)/", url).group(1)
            checkin = re.search(r"ls/(.*?)/(.*?)/(.*?)/", url).group(2)
            Ratdate = checkin    
            chkin   = datetime.datetime.strptime(checkin,str('%Y-%m-%d')).strftime('%Y%m%d')
            checkout= re.search(r"ls/(.*?)/(.*?)/(.*?)/", url).group(3)
            chkout  = datetime.datetime.strptime(checkout,str('%Y-%m-%d')).strftime('%Y%m%d')
            statuscode = ""    
        else:
            Ratdate = 'wrong'
        baseurl = 'https://www.priceline.com/relax/at/'+str(Details_ID)+'/from/'+str(chkin)+'/to/'+str(chkout)+'/rooms/1/adults/'+str(adult)+'?cityName=undefined1#'
#         print 'baseurl :', baseurl
#         try:
#             head_M  = {'Host':'www.priceline.com','User-Agent':'Mozilla/5.0 (X11; Linux x86_64; rv:44.0) Gecko/20100101 Firefox/44.0','Accept':'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8','Accept-Language':'en-US,en;q=0.5','Accept-Encoding':'gzip, deflate, br','Connection':'keep-alive'}
#             respons = ses.get(url,headers=head_M,proxies=proxies,timeout=20)
#             if respons.status_code!=200:
#                 respons = ses.get(url,headers=respons.headers,proxies=proxies,timeout=20)
#                 if respons.status_code!=200:
#                     proxies = {"http": "http://{}".format(proxyip)}
#                     url     = re.sub(r'https://','http://',url)
#                     respons = ses.get(url,headers=respons.headers,proxies=proxies,timeout=20)
#                     if respons.status_code!=200:
#                         respons = ses.get(url,headers=respons.headers,proxies=proxies,timeout=20)
#         except Exception as e:
#             value_error= str(re.sub(r"'",'',str(e)))  
#             stacktrace = sys.exc_traceback.tb_lineno
#             region=''
#             statuscode=5
#             array.append(aws_insert.insert(id_update, inputid ,functionname,Websitecode, "", "", "", "", Guests, "", "", "", "", "",url, url, url, "", "", "", "", "", "",StartDate, EndDate , "", "", "", "", "", "", "", "", "",region,statuscode, israteperstay))
#             return json.dumps(array)
#         
#         if re.findall(r"currencyCode:\s*'(.*?)'", respons.text):
#             curencie = re.findall(r"currencyCode:\s*'(.*?)'", respons.text)
#         else:
#             curencie = ''
#         curencies = set(curencie)
        curencies = {"USD":"$","AUD":"AU$","BRL":"R$","GBP":"Ã‚Â£","CAD":"C$","CNY":"Ã‚Â¥","DKK":"kr","AED":"AED","EUR":"Ã¢â€šÂ¬","HKD":"HK$","INR":"Ã¢â€šÂ¹","MYR":"RM","MXN":"MX$","NZD":"NZ$","PHP":"Ã¢â€šÂ±","RUB":"Ã¢â€šÂ½","SGD":"S$","TWD":"NT$","THB":"Ã Â¸Â¿"}
        if currency not in curencies:
            statuscode = 8
            array.append(aws_insert.insert(id_update, inputid ,functionname,Websitecode, "", "", "", "", Guests, "", "", "", "", "",url, url, url, "", "", "", "", "", "",StartDate, EndDate , "", "", "", "", "", "", "", "", "",region,statuscode, israteperstay))
            return json.dumps(array)    
        if int(Guests)>1:
            #url = 'https://www.priceline.com/pws/v0/stay/integratedlisting/detail/'+Details_ID+'?adult-occ='+str(Guests)+'&check-in='+chkin+'&check-out='+chkout+'&currency='+currency+'&multi-occ-display=true&multi-occ-options=EXCLUDE_SINGLE_OCCUPANCY_RATES&multi-occupancy-rates=true&numReviews=5&payment-rate-merge=true&rate-display-option=S&response-options=POP_COUNT,REVIEWS,CUSTOM_DESC,RATE_SUMMARY,REFUND_INFO&rooms=1'
            data = '{"query":"query getHotelDetails($hotelID: ID, $allInclusive: Boolean, $checkIn: String, $checkOut: String, $roomsCount: Int, $cguid: ID, $currencyCode: String, $pclnID: ID, $metaID: ID, $rehabRateKey: ID, $preferredRateID: ID, $rID: ID, $rateDisplayOption: String, $rguid: ID, $visitId: String, $refClickID: String, $reviewCount: Float, $paymentRateMerge: Boolean, $multiOccDisplay: Boolean, $multiOccRates: Boolean, $multiOccOptions: String, $appCode: String, $adults: Int, $children: [String], $unlockDeals: Boolean, $authToken: ID, $responseOptions: String, $includePrepaidFeeRates: Boolean, $addErrToResponse: Boolean) {\\n  details(hotelID: $hotelID, checkIn: $checkIn, checkOut: $checkOut, roomsCount: $roomsCount, cguid: $cguid, currencyCode: $currencyCode, pclnID: $pclnID, metaID: $metaID, rehabRateKey: $rehabRateKey, preferredRateID: $preferredRateID, rID: $rID, rateDisplayOption: $rateDisplayOption, rguid: $rguid, visitId: $visitId, refClickID: $refClickID, reviewCount: $reviewCount, paymentRateMerge: $paymentRateMerge, multiOccDisplay: $multiOccDisplay, multiOccRates: $multiOccRates, multiOccOptions: $multiOccOptions, appCode: $appCode, adults: $adults, children: $children, allInclusive: $allInclusive, unlockDeals: $unlockDeals, authToken: $authToken, responseOptions: $responseOptions, includePrepaidFeeRates: $includePrepaidFeeRates, addErrToResponse: $addErrToResponse) {\\n    rguid\\n    errorMessage\\n    hotel {\\n      maxPricedOccupancy\\n      maxOccupancy\\n      merchandisingInfo {\\n        color\\n        badgeText\\n        bannerHeader\\n        bannerText\\n        __typename\\n      }\\n      hotelMerchandisingFlagInfo {\\n        bg\\n        text\\n        __typename\\n      }\\n      reasonsToBook {\\n        color\\n        icon\\n        header\\n        substring\\n        __typename\\n      }\\n      hotelViewCount {\\n        cumulativeViewCount\\n        __typename\\n      }\\n      commonRoomAmenities {\\n        type\\n        name\\n        __typename\\n      }\\n      hotelId\\n      recmdScore\\n      brandID\\n      chainCode\\n      description\\n      starRating\\n      name\\n      totalReviewCount\\n      overallGuestRating\\n      taxId\\n      propertyTypeId\\n      quotes {\\n        text\\n        __typename\\n      }\\n      customDesc {\\n        text\\n        paragraphTitle\\n        __typename\\n      }\\n      policies {\\n        checkInTime\\n        checkOutTime\\n        petDescription\\n        childrenDescription\\n        importantInfo\\n        __typename\\n      }\\n      rooms {\\n        maxOccupancy\\n        maxPricedOccupancy\\n        longDescription\\n        roomDisplayName\\n        roomId\\n        roomFacilities\\n        roomFeatures {\\n          beddingOption\\n          size\\n          highlightedRoomAmenities {\\n            name\\n            __typename\\n          }\\n          __typename\\n        }\\n        images {\\n          mediumUrl\\n          __typename\\n        }\\n        bannerBackgroundColor\\n        bannerText\\n        isUnlockedMemberDeal\\n        displayableRates {\\n          displayPrice\\n          displayCurrency\\n          promos {\\n            displayStrikethroughPrice\\n            __typename\\n          }\\n          originalRates {\\n            rateIdentifier\\n            currencySymbol\\n            roomsLeft\\n            cancellationPolicy {\\n              freeRefundableFlag\\n              cancellationModalLinkText\\n              text\\n              rules {\\n                feeAmt\\n                id\\n                text\\n                __typename\\n              }\\n              __typename\\n            }\\n            rateLevelPolicies {\\n              POLICY_HOTEL_INTERNET\\n              POLICY_HOTEL_PARKING\\n              POLICY_REFUND\\n              POLICY_CANCELLATION\\n              __typename\\n            }\\n            mandatoryPropertyFees {\\n              mandatoryFeeDetails {\\n                amountPerRoomInRequestedCurrency\\n                __typename\\n              }\\n              __typename\\n            }\\n            payWhenYouStayFlag\\n            refundPolicy\\n            programName\\n            merchandisingText\\n            savingsPct\\n            maxOccupancy\\n            pricedOccupancy\\n            gid\\n            __typename\\n          }\\n          __typename\\n        }\\n        strikethroughPrice\\n        disclaimerMessage\\n        cancelPayLaterMessage\\n        mandatoryFeeAmountPerRoomPerNight\\n        __typename\\n      }\\n      transformedRooms {\\n        maxPricedOccupancy\\n        roomDisplayName\\n        roomId\\n        longDescription\\n        roomFacilities\\n        cleanliness {\\n          score\\n          totalReviews\\n          __typename\\n        }\\n        beddingOption\\n        roomThumbnailUrl\\n        roomSize\\n        amenities {\\n          code\\n          __typename\\n        }\\n        imageUrls {\\n          largeUrl\\n          mediumUrl\\n          __typename\\n        }\\n        roomRates {\\n          pricedOccupancy\\n          mergedRate {\\n            isFullyUnlocked\\n            rateIdentifier\\n            price\\n            currencySymbol\\n            roomsLeft\\n            cancellationPolicy\\n            cancellationPolicyLongText\\n            refundPolicy\\n            debugString\\n            paymentOptionsText\\n            feeAmount\\n            isPayLater\\n            __typename\\n          }\\n          isPayLater\\n          rateIdentifier\\n          isBestDeal\\n          price\\n          currencySymbol\\n          roomsLeft\\n          strikeThroughPrice\\n          cancellationPolicy\\n          cancellationPolicyLongText\\n          refundPolicy\\n          savingPct\\n          payLaterMessage\\n          feeAmount\\n          bannerText\\n          programName\\n          rateLevelAmenities {\\n            name\\n            __typename\\n          }\\n          paymentOptionsText\\n          disclaimerMessage\\n          debugString\\n          promos {\\n            title\\n            desc\\n            __typename\\n          }\\n          isFullyUnlocked\\n          __typename\\n        }\\n        __typename\\n      }\\n      guestReviews {\\n        firstName\\n        overallScore\\n        reviewTextGeneral\\n        reviewTextNegative\\n        reviewTextPositive\\n        travelerType\\n        travelerTypeId\\n        creationDate\\n        __typename\\n      }\\n      reviewRatingSummary {\\n        ratings {\\n          description\\n          label\\n          score\\n          summaryCount\\n          summaryValue\\n          __typename\\n        }\\n        travelerType {\\n          count\\n          id\\n          type\\n          __typename\\n        }\\n        __typename\\n      }\\n      signInDealsAvailable\\n      ratings {\\n        category\\n        score\\n        __typename\\n      }\\n      images {\\n        imageHDURL\\n        imageURL\\n        __typename\\n      }\\n      bookings {\\n        firstName\\n        lastNameInitial\\n        bookedPrice\\n        bookedCurrencyCode\\n        justBookedBadge\\n        __typename\\n      }\\n      ratesSummary {\\n        pricedOccupancy\\n        suggestedNumOfRooms\\n        freeCancelableRateAvail\\n        minPrice\\n        minStrikePrice\\n        savingsClaimStrikePrice\\n        savingsClaimDisclaimer\\n        savingsClaimPercentage\\n        minCurrencyCodeSymbol\\n        minCurrencyCode\\n        roomLeft\\n        payWhenYouStayAvailable\\n        pclnId\\n        programName\\n        preferredRateId\\n        rateIdentifier\\n        showRecommendation\\n        suggestedNumOfRooms\\n        __typename\\n      }\\n      hotelFeatures {\\n        features\\n        highlightedAmenities\\n        hotelAmenities {\\n          code\\n          displayable\\n          free\\n          name\\n          type\\n          __typename\\n        }\\n        topAmenities\\n        __typename\\n      }\\n      location {\\n        address {\\n          addressLine1\\n          addressLine2\\n          cityName\\n          provinceCode\\n          countryName\\n          isoCountryCode\\n          __typename\\n        }\\n        cityID\\n        zoneID\\n        latitude\\n        longitude\\n        timeZoneAbbr\\n        neighborhoodName\\n        neighborhoodDescription\\n        __typename\\n      }\\n      __typename\\n    }\\n    los\\n    signInDealRelatedInfo {\\n      promptUserToSignIn\\n      __typename\\n    }\\n    __typename\\n  }\\n}\\n","variables":{"appCode":"DESKTOP","checkIn":"'+str(chkin)+'","checkOut":"'+str(chkout)+'","rID":"DTDIRECT","roomsCount":1,"currencyCode":"'+str(currency)+'","refClickID":"","unlockDeals":true,"includePrepaidFeeRates":true,"addErrToResponse":true,"allInclusive":false,"adults":'+str(Guests)+',"paymentRateMerge":true,"multiOccDisplay":true,"multiOccOptions":"EXCLUDE_SINGLE_OCCUPANCY_RATES","multiOccRates":true,"hotelID":"'+str(Details_ID)+'","responseOptions":"POP_COUNT,REVIEWS,CUSTOM_DESC,RATE_SUMMARY,RATINGS,DETAILED_ROOM,HOTEL_IMAGES,RATE_IMPORTANT_INFO,RATE_CHARGES_DETAIL,PROXIMITY,BOOKINGS,REFUND_INFO"},"operationName":"getHotelDetails"}'
        else:
            data = '{"query":"query getHotelDetails($hotelID: ID, $allInclusive: Boolean, $checkIn: String, $checkOut: String, $roomsCount: Int, $cguid: ID, $currencyCode: String, $pclnID: ID, $metaID: ID, $rehabRateKey: ID, $preferredRateID: ID, $rID: ID, $rateDisplayOption: String, $rguid: ID, $visitId: String, $refClickID: String, $reviewCount: Float, $paymentRateMerge: Boolean, $multiOccDisplay: Boolean, $multiOccRates: Boolean, $multiOccOptions: String, $appCode: String, $adults: Int, $children: [String], $unlockDeals: Boolean, $authToken: ID, $responseOptions: String, $includePrepaidFeeRates: Boolean, $addErrToResponse: Boolean) {\\n  details(hotelID: $hotelID, checkIn: $checkIn, checkOut: $checkOut, roomsCount: $roomsCount, cguid: $cguid, currencyCode: $currencyCode, pclnID: $pclnID, metaID: $metaID, rehabRateKey: $rehabRateKey, preferredRateID: $preferredRateID, rID: $rID, rateDisplayOption: $rateDisplayOption, rguid: $rguid, visitId: $visitId, refClickID: $refClickID, reviewCount: $reviewCount, paymentRateMerge: $paymentRateMerge, multiOccDisplay: $multiOccDisplay, multiOccRates: $multiOccRates, multiOccOptions: $multiOccOptions, appCode: $appCode, adults: $adults, children: $children, allInclusive: $allInclusive, unlockDeals: $unlockDeals, authToken: $authToken, responseOptions: $responseOptions, includePrepaidFeeRates: $includePrepaidFeeRates, addErrToResponse: $addErrToResponse) {\\n    rguid\\n    errorMessage\\n    hotel {\\n      maxPricedOccupancy\\n      maxOccupancy\\n      merchandisingInfo {\\n        color\\n        badgeText\\n        bannerHeader\\n        bannerText\\n        __typename\\n      }\\n      hotelMerchandisingFlagInfo {\\n        bg\\n        text\\n        __typename\\n      }\\n      reasonsToBook {\\n        color\\n        icon\\n        header\\n        substring\\n        __typename\\n      }\\n      hotelViewCount {\\n        cumulativeViewCount\\n        __typename\\n      }\\n      commonRoomAmenities {\\n        type\\n        name\\n        __typename\\n      }\\n      hotelId\\n      recmdScore\\n      brandID\\n      chainCode\\n      description\\n      starRating\\n      name\\n      totalReviewCount\\n      overallGuestRating\\n      taxId\\n      propertyTypeId\\n      quotes {\\n        text\\n        __typename\\n      }\\n      customDesc {\\n        text\\n        paragraphTitle\\n        __typename\\n      }\\n      policies {\\n        checkInTime\\n        checkOutTime\\n        petDescription\\n        childrenDescription\\n        importantInfo\\n        __typename\\n      }\\n      rooms {\\n        maxOccupancy\\n        maxPricedOccupancy\\n        longDescription\\n        roomDisplayName\\n        roomId\\n        roomFacilities\\n        roomFeatures {\\n          beddingOption\\n          size\\n          highlightedRoomAmenities {\\n            name\\n            __typename\\n          }\\n          __typename\\n        }\\n        images {\\n          mediumUrl\\n          __typename\\n        }\\n        bannerBackgroundColor\\n        bannerText\\n        isUnlockedMemberDeal\\n        displayableRates {\\n          displayPrice\\n          displayCurrency\\n          promos {\\n            displayStrikethroughPrice\\n            __typename\\n          }\\n          originalRates {\\n            rateIdentifier\\n            currencySymbol\\n            roomsLeft\\n            cancellationPolicy {\\n              freeRefundableFlag\\n              cancellationModalLinkText\\n              text\\n              rules {\\n                feeAmt\\n                id\\n                text\\n                __typename\\n              }\\n              __typename\\n            }\\n            rateLevelPolicies {\\n              POLICY_HOTEL_INTERNET\\n              POLICY_HOTEL_PARKING\\n              POLICY_REFUND\\n              POLICY_CANCELLATION\\n              __typename\\n            }\\n            mandatoryPropertyFees {\\n              mandatoryFeeDetails {\\n                amountPerRoomInRequestedCurrency\\n                __typename\\n              }\\n              __typename\\n            }\\n            payWhenYouStayFlag\\n            refundPolicy\\n            programName\\n            merchandisingText\\n            savingsPct\\n            maxOccupancy\\n            pricedOccupancy\\n            gid\\n            __typename\\n          }\\n          __typename\\n        }\\n        strikethroughPrice\\n        disclaimerMessage\\n        cancelPayLaterMessage\\n        mandatoryFeeAmountPerRoomPerNight\\n        __typename\\n      }\\n      transformedRooms {\\n        maxPricedOccupancy\\n        roomDisplayName\\n        roomId\\n        longDescription\\n        roomFacilities\\n        cleanliness {\\n          score\\n          totalReviews\\n          __typename\\n        }\\n        beddingOption\\n        roomThumbnailUrl\\n        roomSize\\n        amenities {\\n          code\\n          __typename\\n        }\\n        imageUrls {\\n          largeUrl\\n          mediumUrl\\n          __typename\\n        }\\n        roomRates {\\n          pricedOccupancy\\n          mergedRate {\\n            isFullyUnlocked\\n            rateIdentifier\\n            price\\n            currencySymbol\\n            roomsLeft\\n            cancellationPolicy\\n            cancellationPolicyLongText\\n            refundPolicy\\n            debugString\\n            paymentOptionsText\\n            feeAmount\\n            isPayLater\\n            __typename\\n          }\\n          isPayLater\\n          rateIdentifier\\n          isBestDeal\\n          price\\n          currencySymbol\\n          roomsLeft\\n          strikeThroughPrice\\n          cancellationPolicy\\n          cancellationPolicyLongText\\n          refundPolicy\\n          savingPct\\n          payLaterMessage\\n          feeAmount\\n          bannerText\\n          programName\\n          rateLevelAmenities {\\n            name\\n            __typename\\n          }\\n          paymentOptionsText\\n          disclaimerMessage\\n          debugString\\n          promos {\\n            title\\n            desc\\n            __typename\\n          }\\n          isFullyUnlocked\\n          __typename\\n        }\\n        __typename\\n      }\\n      guestReviews {\\n        firstName\\n        overallScore\\n        reviewTextGeneral\\n        reviewTextNegative\\n        reviewTextPositive\\n        travelerType\\n        travelerTypeId\\n        creationDate\\n        __typename\\n      }\\n      reviewRatingSummary {\\n        ratings {\\n          description\\n          label\\n          score\\n          summaryCount\\n          summaryValue\\n          __typename\\n        }\\n        travelerType {\\n          count\\n          id\\n          type\\n          __typename\\n        }\\n        __typename\\n      }\\n      signInDealsAvailable\\n      ratings {\\n        category\\n        score\\n        __typename\\n      }\\n      images {\\n        imageHDURL\\n        imageURL\\n        __typename\\n      }\\n      bookings {\\n        firstName\\n        lastNameInitial\\n        bookedPrice\\n        bookedCurrencyCode\\n        justBookedBadge\\n        __typename\\n      }\\n      ratesSummary {\\n        pricedOccupancy\\n        suggestedNumOfRooms\\n        freeCancelableRateAvail\\n        minPrice\\n        minStrikePrice\\n        savingsClaimStrikePrice\\n        savingsClaimDisclaimer\\n        savingsClaimPercentage\\n        minCurrencyCodeSymbol\\n        minCurrencyCode\\n        roomLeft\\n        payWhenYouStayAvailable\\n        pclnId\\n        programName\\n        preferredRateId\\n        rateIdentifier\\n        showRecommendation\\n        suggestedNumOfRooms\\n        __typename\\n      }\\n      hotelFeatures {\\n        features\\n        highlightedAmenities\\n        hotelAmenities {\\n          code\\n          displayable\\n          free\\n          name\\n          type\\n          __typename\\n        }\\n        topAmenities\\n        __typename\\n      }\\n      location {\\n        address {\\n          addressLine1\\n          addressLine2\\n          cityName\\n          provinceCode\\n          countryName\\n          isoCountryCode\\n          __typename\\n        }\\n        cityID\\n        zoneID\\n        latitude\\n        longitude\\n        timeZoneAbbr\\n        neighborhoodName\\n        neighborhoodDescription\\n        __typename\\n      }\\n      __typename\\n    }\\n    los\\n    signInDealRelatedInfo {\\n      promptUserToSignIn\\n      __typename\\n    }\\n    __typename\\n  }\\n}\\n","variables":{"appCode":"DESKTOP","checkIn":"'+str(chkin)+'","checkOut":"'+str(chkout)+'","rID":"DTDIRECT","roomsCount":1,"currencyCode":"'+str(currency)+'","refClickID":"","unlockDeals":true,"includePrepaidFeeRates":true,"addErrToResponse":true,"allInclusive":false,"adults":'+str(Guests)+',"paymentRateMerge":true,"multiOccDisplay":true,"multiOccOptions":"","multiOccRates":true,"hotelID":"'+str(Details_ID)+'","responseOptions":"POP_COUNT,REVIEWS,CUSTOM_DESC,RATE_SUMMARY,RATINGS,DETAILED_ROOM,HOTEL_IMAGES,RATE_IMPORTANT_INFO,RATE_CHARGES_DETAIL,PROXIMITY,BOOKINGS,REFUND_INFO"},"operationName":"getHotelDetails"}'
            #url = 'https://www.priceline.com/pws/v0/stay/integratedlisting/detail/'+Details_ID+'?adult-occ='+str(Guests)+'&check-in='+chkin+'&check-out='+chkout+'&currency='+currency+'&multi-occ-display=true&multi-occupancy-rates=true&numReviews=5&payment-rate-merge=true&rate-display-option=S&response-options=POP_COUNT,REVIEWS,CUSTOM_DESC,RATE_SUMMARY,REFUND_INFO&rid=DTDIRECT&rooms=1'
        head_M = {
                    'origin': 'https://www.priceline.com',
                    'accept-encoding': 'gzip, deflate, br',
                    'accept-language': 'en-GB,en-US;q=0.9,en;q=0.8',
                    'user-agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36',
                    'content-type': 'application/json',
                    'accept': '*/*',
                    'referer': 'https://www.priceline.com/relax/at/'+str(Details_ID)+'/from/'+str(chkin)+'/to/'+str(chkout)+'/rooms/1?&cur='+(currency)+'&cug=false',
                    'authority': 'www.priceline.com',
                }
        Domainname = 'PriceLine.com'
        Roomtype=""
        RateDate = Ratdate
        NetRate= 0
        Curr = ''
        GrossRate= 0
        RateDescription=""
        OnsiteRate = 0
        RoomAmenity_Type=""
        Mealtype=""
        MaxOccupancy=""
        isPromotionalRate="N"
        Closed_up="N"
        Roomavilable=""
        Taxtype=""
        Tax_status=''
        Ratetype=""
        Promotion_Name=""
        Taxamount=""
        ##print proxyip
        url = 'https://www.priceline.com/relax/stayql'
        try:
            hml = requests.post(url,headers=head_M,proxies=proxies,data=data,timeout=10)
            if hml.status_code!=200:
                proxies = {"http": "http://{}".format(proxyip)}
                url     = re.sub(r'https://','http://',url)
                hml = requests.post(url,headers=hml.headers,proxies=proxies,data=data,timeout=15)
        except Exception,e:
            value_error= str(re.sub(r"'",'',str(e)))  
            stacktrace = sys.exc_traceback.tb_lineno
            region=''
            statuscode=5
            array.append(aws_insert.insert(id_update, inputid ,functionname,Websitecode, "", "", "", "", Guests, "", "", "", "", "",url, url, url, "", "", "", "", "", "",StartDate, EndDate , "", "", "", "", "", "", "", "", "",region,statuscode, israteperstay))
            return json.dumps(array)
        html = json.loads(hml.text.encode('ascii', 'ignore'))
#         print hml.text
        Rtdate = re.sub(r'-|\-', '', str(RateDate))
        keyvalue = "ondemand/{}/{:%Y%m%d}/source/{}.json".format(Websitecode,datetime.datetime.now(),str(inputid)+'_'+str(Rtdate)+'_'+id_update)
        key = bucket.new_key(keyvalue)
        key.set_contents_from_string(hml.text)
        region=''
        ip=re.sub(r"\{'.*?@|'\}|:\d+","",str(proxies))
        try:
            try:
                r = requests.get('http://freegeoip.net/json/'+ip,timeout=30)
            except Exception,e:
                r = requests.get('http://freegeoip.net/json/'+ip,timeout=30)
            js = r.json()
            region=js['country_name']
        except Exception,e:
            region=''     
        #print json.dumps(html)
        if html['data']['details'].has_key('hotel'):   
            if  html['data']['details']['hotel'].has_key('rooms'): 
                if html['data']['details']['hotel']['rooms']:
                    for var in html['data']['details']['hotel']['rooms']:
                        Closed_up="N"
                        NetRate=0
                        OnsiteRate=0
                        GrossRate=0
                        if 'roomDisplayName' in var:
                            Roomtype   = var['roomDisplayName']
#                             print Roomtype
                        else:
                            Roomtype =''
                        if 'longDescription' in var:
                            RateDescription1 =var['longDescription']
                        else:
                            RateDescription1=''
                        if 'roomSize' in var:
                            RateDescription2 = var['roomSize']
                            RateDescription2 = 'Size:'+str(RateDescription2)
                        else:
                            RateDescription2=''
                        if 'roomFeatures' in var:
                            roomfeture = var['roomFeatures']
                            if 'beddingOption' in roomfeture:
                                RateDescription3 = roomfeture['beddingOption']
                            else:
                                RateDescription3 = ''
                            if roomfeture['highlightedRoomAmenities']:
                                roomfeture1 = roomfeture['highlightedRoomAmenities']
                                list_v = []
                                for ameint in roomfeture1:
                                    highlightedRoomAmenities = ameint['name']
                                    list_v.append(highlightedRoomAmenities)
                                    list_v.append(',')
                                    ameints = list_v
                                ameints_reduce = reduce(operator.add,ameints)                        
                            else:
                                ameints_reduce=''
                        else:
                            RateDescription3=''
                            ameints_reduce=''
                        #RateDescription3=''
                        for ratetype in var['displayableRates']:
                            if 'displayPrice' in ratetype: 
                                OnsiteRate = ratetype['displayPrice']
#                                 print 'OnsiteRate',OnsiteRate
                            else:
                                OnsiteRate= 0
                            GrossRate  = str(OnsiteRate)
                            Curr=ratetype['displayCurrency']
                            if ratetype['promos']:                        
                                for nets in ratetype['promos']:
                                    if 'title' in nets:
                                        Promotion_Name=nets['title']
                                        if Promotion_Name:
                                            isPromotionalRate='Y'
                                        else:
                                            Promotion_Name = ''
                                    else:
                                        Promotion_Name =''
                                    if 'displayStrikethroughPrice' in nets:
                                        NetRate = nets['displayStrikethroughPrice']
                                        if NetRate:
                                            isPromotionalRate='Y'
                                            ###print "NetRate",NetRate
                                        else:
                                            NetRate = 0
                                            isPromotionalRate = 'N'
                                    else:
                                        NetRate = 0
                                        isPromotionalRate = 'N'
                                    ###print nets
                            else:
                                isPromotionalRate = 'N'
                                Promotion_Name = ''
                                NetRate = 0
                            for rates in ratetype['originalRates']:
                                cancelPolicyCategory = rates['cancellationPolicy']
                                Ratetype = cancelPolicyCategory['cancellationModalLinkText']
                                if cancelPolicyCategory['freeRefundableFlag']:
                                    Ratetype = 'Free Cancellation: '+str(Ratetype)
                                if 'roomsLeft' in rates:   
                                    Roomavilable=rates['roomsLeft']
                                else:
                                    Roomavilable='' 
                                    
                                if 'maxOccupancy' in rates:              
                                    MaxOccupancy=rates['maxOccupancy']
                                else:
                                    MaxOccupancy = ''
                                    
                                break;
                            
                            RateDescription = str(RateDescription1)+' '+str(RateDescription2)+' '+RateDescription3
                            if 'roomFacilities' in var:
                                roomFacilities=var['roomFacilities']
                                RoomAmeinties1  = str(roomFacilities)
                                RoomAmeinties2  = re.sub(r"(?i),,", r",", RoomAmeinties1)
                                RoomAmeinties3  = re.sub(r"(?i),", r'","', RoomAmeinties2)
                                RoomAmeinties   = re.sub(r'(?i)^|$|" ', r'"', RoomAmeinties3)
                            else:
                                RoomAmeinties=''
                            RoomAmeinties      = re.sub(r"'","''",str(ameints_reduce)+' '+str(RoomAmeinties))
                            RateDescription    = re.sub(r"'","''",RateDescription)
                            Amenities_separated_re = re.search(r"the room [o|f].*? (.*?)$", RateDescription, re.IGNORECASE)
                            if Amenities_separated_re:
                                Amenities_separated = Amenities_separated_re.group(1)
                                RateDescription     =  re.sub(r"(?i)the room [o|f].*? (.*?)$", r"",  str(RateDescription))
                            else:
                                Amenities_separated = ""
                            #RoomAmenity_Type   = re.sub(r'"\\"|\\"|,$', r"", RoomAmenity_Type)
                            #RoomAmenity_Type   = re.sub(r'^','"',RoomAmenity_Type)
                            ###print RoomAmenity_Type
                            RoomAmenity_Type   = re.sub(r'^"",|,\s+$','',str(Amenities_separated)+' '+str(RoomAmeinties))
                            Mealtype          = re.sub(r"'","''", str(RoomAmenity_Type))
                            Ratetype  = re.sub(r'NON_REFUNDABLE','Non Refundable',Ratetype)
                            Ratetype  = re.sub(r'FLEXIBLE_CANCELLATION','Free Cancellation Available',Ratetype)
                            if OnsiteRate == 0 or str(OnsiteRate) == '0':
                                statuscode=1
                                Closed_up = 'Y'
                                Tax_status ='-1'
                            else:
                                statuscode= ''
                                Closed_up = 'N'
                                Tax_status = '2'
                            if LOS>1:
                                israteperstay = 'N'
                            else:
                                israteperstay = 'Y'
                            if (NetRate == 0 or NetRate == '') and (Promotion_Name == 0 or Promotion_Name == ''):
                                isPromotionalRate = 'N'
                            #print "Roomtype :=",Roomtype
                            #print RateDescription
                            #print "Ratetype :=",RoomAmenity_Type
                            ##print "OnsiteRate",OnsiteRate
                            ##print 'NetRate   :=',NetRate
                            ##print "MaxOccupancy",MaxOccupancy
                            ##print "_"*50
                            if float(OnsiteRate)>=float(NetRate):
                                NetRate = 0
                            array.append(aws_insert.insert(id_update, inputid , Domainname, Websitecode, StartDate, Roomtype, LOS, RateDate, Guests, OnsiteRate, NetRate, GrossRate, Curr, RateDescription, baseurl, baseurl, baseurl, RoomAmenity_Type, Mealtype, MaxOccupancy, isPromotionalRate, Closed_up, 30, StartDate , EndDate, intime, Roomavilable, Taxtype, Taxamount,  Tax_status,None, Ratetype, NetRate,Promotion_Name,region,statuscode, israteperstay))
                else:
                    Closed_up = "Y"
                    statuscode=2
                    israteperstay = ''
                    #HotelBlock = "We''re Sorry. We are unable to find rates for this hotel on these dates"
                    array.append(aws_insert.insert(id_update, inputid , Domainname, Websitecode, StartDate, Roomtype, LOS, RateDate, Guests, OnsiteRate, NetRate, GrossRate, Curr, RateDescription, baseurl, baseurl, baseurl, RoomAmenity_Type, Mealtype, MaxOccupancy, isPromotionalRate, Closed_up, 30, StartDate , EndDate, intime, Roomavilable, Taxtype, Taxamount,  Tax_status,None, Ratetype, NetRate,Promotion_Name,region,statuscode, israteperstay))       
            else:
                Closed_up = "Y"
                statuscode=2
                israteperstay = ''
                #HotelBlock = "We''re Sorry. We are unable to find rates for this hotel on these dates"
                array.append(aws_insert.insert(id_update, inputid , Domainname, Websitecode, StartDate, Roomtype, LOS, RateDate, Guests, OnsiteRate, NetRate, GrossRate, Curr, RateDescription, baseurl, baseurl, baseurl, RoomAmenity_Type, Mealtype, MaxOccupancy, isPromotionalRate, Closed_up, 30, StartDate , EndDate, intime, Roomavilable, Taxtype, Taxamount,  Tax_status,None, Ratetype, NetRate,Promotion_Name,region,statuscode, israteperstay))
        else:
            Closed_up = "Y"
            statuscode=2
            israteperstay = ''
            #HotelBlock = "We''re Sorry. We are unable to find rates for this hotel on these dates"
            array.append(aws_insert.insert(id_update, inputid , Domainname, Websitecode, StartDate, Roomtype, LOS, RateDate, Guests, OnsiteRate, NetRate, GrossRate, Curr, RateDescription, baseurl, baseurl, baseurl, RoomAmenity_Type, Mealtype, MaxOccupancy, isPromotionalRate, Closed_up, 30, StartDate , EndDate, intime, Roomavilable, Taxtype, Taxamount,  Tax_status,None, Ratetype, NetRate,Promotion_Name,region,statuscode, israteperstay))    
        keyvalue = "ondemand/{}/{:%Y%m%d}/delivery/{}.json".format(Websitecode,datetime.datetime.now(),str(inputid)+'_'+str(Rtdate)+'_'+id_update)
        key = bucket.new_key(keyvalue)
        key.set_contents_from_string(json.dumps(array))
        gc.collect()
        return json.dumps(array)
    except Exception,e:
        print e
        value_error=str(re.sub(r"'",'"',str(e)))
        stacktrace=sys.exc_traceback.tb_lineno
        insert_value_error=str(value_error)+'Where line number '+str(stacktrace)+str(proxyip)
        print insert_value_error
        statuscode='4'
        WebSitecode='34'
        keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(WebSitecode,datetime.datetime.now(),id_update)
        key = bucket.new_key(keyvalue)
        key.set_contents_from_string(insert_value_error)
        Guests=adult
        array.append(aws_insert.insert(id_update, inputid ,functionname,WebSitecode, "", "", "", "", Guests, "", "", "", "", "",url, url, url, "", "", "", "", "", "",StartDate, EndDate , "", "", "", "", "", "",  "", "", "",region,statuscode, israteperstay))
        return json.dumps(array)
        
# fetchrates(url ,inputid, id_update, proxyip)
