# -*- coding: utf-8 -*-
import requests,re,json,aws_insert,datetime,random,sys,boto,mtranslate

def Load(urlforLd, headerT, proxi, timeout):
    return requests.get(urlforLd, headers=headerT, timeout=timeout, proxies=proxi, verify=False)

def trans(to_translate):
    try:
        Translated = (mtranslate.translate(to_translate, 'en'))
        return Translated
    except:
        return to_translate 
    
def strctOld(jsonvalue, url_inc, id_update, inputid, RateDate, StartDate, EndDate, Guests, LOS, array, region, intime, proxyip, bucket, html):
    try:
        parsed_htm_re = re.search(r'({"propertyData":.*?}};)', html, re.DOTALL)
        if parsed_htm_re:
            parsed_htm = parsed_htm_re.group(1)
        else:
            parsed_htm = ""   
        listcodes = []
        statuscode= 0
        if jsonvalue.has_key('availabilityErrors'):
            if  jsonvalue['availabilityErrors'][0]['message'] == 'ROOMS_UNAVAILABLE_FOR_SELECTED_DATES' or jsonvalue['availabilityErrors'][0]['message'] == 'EXCEEDED_NUMBER_OF_GUESTS':
                statuscode = '2'
                array.append(aws_insert.insert(id_update, inputid , 'Travelocity', 3660, StartDate, '', LOS, RateDate, Guests, 0, 0, 0, '', '', url_inc, url_inc, url_inc, '', '', None, 'N', 'Y', 30, StartDate , EndDate, intime, 0, None, None, '', None, '', 0, '', '', statuscode, ''))
                return json.dumps(array)
        if 'offers' in jsonvalue:
            Closed_up    = 'N'
            ispromupdate = 'N'
            promotion    = ''
            Currencycode = 'USD'
            for roomvalue in jsonvalue['offers']:
                if 'exceedsMaxAdults' in roomvalue:
                    if roomvalue['exceedsMaxAdults']:
                        continue
                Currencycod  = ''
                Tax_and_Fees = 0
                OnsiteRate_c = 0
                Rmtypcode = roomvalue['roomTypeCode']
                Rmtypcode = re.sub(r'\.', '\.', re.sub(r'\|', '\|', str(Rmtypcode)))
                Roomtype_reg_form = 'roomTypeCode":"' + Rmtypcode + '".*?"name":"(.*?)",'
                Roomtype_reg = re.search(Roomtype_reg_form, parsed_htm, re.IGNORECASE)
                if Roomtype_reg:
                    Roomtype_clean = Roomtype_reg.group(1)            
                    Roomtype = re.sub("'", "''", str(Roomtype_clean))
                    if Roomtype == '' or Roomtype == None:
                        if 'roomName' in roomvalue:
                            Roomtype_clean = roomvalue['roomName']
                            Roomtype = re.sub("'", "''", str(Roomtype_clean))
                            Roomtype = trans(Roomtype)
                        else:
                            Roomtype = ''
                else:
                    if 'roomName' in roomvalue:
                        Roomtype_clean = roomvalue['roomName']
                        Roomtype = re.sub("'", "''", str(Roomtype_clean))
                        Roomtype = trans(Roomtype)
                    else:
                        Roomtype = ''
                if 'valueAdd' in roomvalue:
                    if 'englishText' in roomvalue['valueAdd']:
                        promo_namchek = roomvalue['valueAdd']['englishText']
                        if '% off' in promo_namchek.lower():
                            promotion = promo_namchek
                            ispromupdate = 'Y'
                        else:
                            ispromupdate = 'N'
                            promotion = '' 
                    else:
                        promotion = ''    
                        ispromupdate = 'N'                    
                else:
                    ispromupdate = 'N'
                    promotion = ''
                    
                ratePlanCode = roomvalue['ratePlanCode']
                checklist = str(Rmtypcode) + ' ' + str(Roomtype) + ' ' + str(ratePlanCode)
                if checklist in listcodes:
                    continue
                else:
                    listcodes.append(checklist)
                if roomvalue['price'] != None:
                    onsite_rate_clean = roomvalue['price']['displayPrice']
                    if onsite_rate_clean != None:
                        onsite_rate_encode = onsite_rate_clean.encode('ascii', 'ignore')
                        onsite_rate_Str = str (onsite_rate_encode)
                        OnsiteRate = re.sub(r'[A-Z|a-z]', '', re.sub(r'(\D)', '', re.sub(r"\\u20b9|\$|,|[A-Za-z]+\.|Rs\.|Rs", r"", onsite_rate_Str)))
                    else:
                        OnsiteRate = 0
                    net_reg = roomvalue['price']['crossOutPrice']
                    if net_reg != None:
                        net_encode = net_reg.encode('ascii', 'ignore')
                        net_clean = str(net_encode)
                        net_rate = re.sub(r'[A-Z|a-z]', '', re.sub(r'(\D)', '', re.sub(r"\\u20b9|\$|,|[A-Za-z]+\.|Rs\.|Rs", r"", net_clean)))
                        ispromupdate = 'Y'
                    else:
                        net_rate = 0
                        if ispromupdate!='Y':
                            ispromupdate = 'N'
                else:
                    if ispromupdate!='Y':
                        ispromupdate = 'N'
                    net_rate     = 0
                    OnsiteRate   = 0
                
                if roomvalue['totalPriceWithTaxesAndFees']!=None:
                    Tax_and_Fees = re.sub(r'0$','',str(roomvalue['totalPriceWithTaxesAndFees']['amount']))
                    Taxcheck     = re.sub(r'0$','',str(roomvalue["price"]['unformattedTotalPrice']))
                else:
                    Tax_and_Fees = 0
                    Taxcheck     = 0
                if roomvalue["price"] != None:
                    Curr = roomvalue["price"]['priceObject']["currencyCode"]
                    if Curr != None:
                        Currencycod  = Curr
                        Currencycode = Curr
                if Currencycod == '':
                    if roomvalue['feePenalty'] != None:
                        Curr = roomvalue["feePenalty"]["currencyCode"]
                        if Curr != None:
                            Currencycode = Curr
                    else:
                        Currencycode = ''
                isavlble = roomvalue['numberOfRoomsLeft']
                if isavlble != None:
                    roomavlb = isavlble
                else:
                    roomavlb = ''
                Maxoccp = re.search(r'"roomTypeCode":"' + Rmtypcode + '".*?maxGuests[\'|\"]:(\d+)', parsed_htm)
                if Maxoccp:
                    Maxoccp = Maxoccp.group(1)
                    Maxocp = re.sub("'", "''", str(Maxoccp))
                    if Maxocp == '0' or Maxocp == '' or Maxocp == None:
                        Maxoccp = re.search(r'"roomTypeCode":"' + Rmtypcode + '".*?total[\'|\"]:(\d+)', parsed_htm)
                        if Maxoccp:
                            Maxoccp = Maxoccp.group(1)
                            Maxocp = re.sub("'", "''", str(Maxoccp))
                else:
                    Maxoccp = re.search(r'"roomTypeCode":"' + Rmtypcode + '".*?total[\'|\"]:(\d+)', parsed_htm)
                    if Maxoccp:
                        Maxoccp = Maxoccp.group(1)
                        Maxocp = re.sub("'", "''", str(Maxoccp))
                    else:
                        Maxoccp = roomvalue['maxGuests']
                        if Maxoccp != None:
                            Maxocp = Maxoccp
                        else:
                            Maxocp = None
                if Maxoccp == None or Maxoccp == '0' or Maxoccp == 0:
                    Maxocp = None
                Room_AMt_reg = '"roomTypeCode":"' + Rmtypcode + '".*?<b>(.*?)\]'
                # ##print Room_AMt_reg
                Room_Else = re.search(Room_AMt_reg, parsed_htm)
                if Room_Else:
                    Room_Amt1 = re.sub(r"'", "''", str(Room_Else.group(1)))
                    Room_Amt_coma = re.sub("<b>", ", ", str(Room_Amt1))
                    Room_Amt_tag = re.sub("<.*?>|'", "", str(Room_Amt_coma))
                    Room_Amt = Room_Amt_tag
                else:
                    Room_Amt = ''
                    
                Room_Dec_reg = r'roomTypeCode":"' + Rmtypcode + '".*?name":".*?"description":\[(.*?)\]'
                # ##print Room_Dec_reg
                Room_E_Desc = re.search(Room_Dec_reg, parsed_htm)
                if Room_E_Desc:
                    if Room_E_Desc.group(1) != None:
                        Room_Decs_group = re.sub(r"'", "''", str(Room_E_Desc.group(1).encode('ascii', 'ignore')))
                        Room_Desc_coma = re.sub("<b>" , ", ", str(Room_Decs_group))
                        Room_Desc_tag = re.sub("\s+|</strong>", " ", str(Room_Desc_coma))
                        Room_Desc = re.sub("<.*?>|'|^.*?\[", "", Room_Desc_tag.replace('"', ''))
                else:
                    Room_Desc = Roomtype           
                if re.search(r'"roomTypeCode":"' + str(Rmtypcode) + '".*?"361":"(.*?)"', parsed_htm):
                    Meal_NotJs = re.sub(r'(?sim)Surcharge', 'Cost', str(re.search(r'"roomTypeCode":"' + str(Rmtypcode) + '".*?"361":"(.*?)"', parsed_htm).group(1)))
                else:
                    Meal_NotJs = '' 
                Mealtype = roomvalue['amenities']
                Meal     = str(Mealtype) + ' ' + str(Room_Desc) + ' ' + str(Meal_NotJs)
                if "refundable" in roomvalue:
                    Ratetype = 'Free Cancellation'
                else:
                    Ratetype = 'Non-Refundable'
                OnsiteRate_c    = OnsiteRate
                if Currencycode == 'IDR':
                    OnsiteRate_c = re.sub(r"\.", "", str(OnsiteRate_c))
                    Tax_and_Fees = re.sub(r"\.", "", str(Tax_and_Fees))
                if OnsiteRate == 0:
                    Closed_up  = 'Y'
                    statuscode = '1'
                    Tax_status = ''
                else:
                    if float(Tax_and_Fees) == float(Taxcheck):
                        Tax_status = '1'
                    else:
                        Tax_status = '2'
                    Closed_up = 'N'
                if LOS > 1 and Currencycode in ('AUD', 'CHF', 'DKK', 'EUR', 'GBP', 'NOK', 'NZD', 'SEK') or LOS == 1:
                    israteperstay = 'Y'
                else:
                    israteperstay = 'N'
                if net_rate <> 0:
                    ispromupdate = 'Y'
                else:
                    ispromupdate = 'N'
                if Roomtype == '':
                    Roomtype_reg_form = 'roomTypeCode":"' + Rmtypcode + '".*?name":"(.*?)",'
                    Roomtype_reg = re.search(Roomtype_reg_form, parsed_htm)
                    if Roomtype_reg:
                        Roomtype_clean = Roomtype_reg.group(1)            
                        Roomtype = re.sub("'", "''", str(Roomtype_clean))
                        if Roomtype == '' or Roomtype == None:
                            if 'roomName' in roomvalue:
                                Roomtype_clean = roomvalue['roomName']
                                Roomtype = re.sub("'", "''", str(Roomtype_clean))
                                Roomtype = trans(Roomtype)
                            else:
                                Roomtype = ''
                    else:
                        if 'roomName' in roomvalue:
                            Roomtype_clean = roomvalue['roomName']
                            Roomtype = re.sub("'", "''", str(Roomtype_clean))
                            Roomtype = trans(Roomtype)
                        else:
                            Roomtype = ''
                if (net_rate == 0 or net_rate == '0') and (promotion == 0 or promotion == ''):
                    ispromupdate = 'N'
                if 'exceedsMaxGuests'  in roomvalue or 'exceedsMaxAdults' in roomvalue:
                    statuscode = 1
                    OnsiteRate = 0
                    net_rate   = 0
                array.append(aws_insert.insert(id_update, inputid , 'Travelocity', '3660', StartDate, Roomtype, LOS, RateDate, Guests, OnsiteRate, net_rate, OnsiteRate, Currencycode, Room_Desc, url_inc, url_inc, url_inc, Room_Amt, Meal, Maxocp, ispromupdate, Closed_up, 30, StartDate , EndDate, intime, roomavlb, None, None, Tax_status, None, Ratetype, net_rate, promotion, region, statuscode, israteperstay))
        else:
            statuscode = '2'
            array.append(aws_insert.insert(id_update, inputid , 'Travelocity', '3660', StartDate, '', LOS, RateDate, Guests, 0, 0, 0, '', '', url_inc, url_inc, url_inc, '', '', None, 'N', 'Y', 30, StartDate , EndDate, intime, 0, None, None, '', None, '', 0, '', '', statuscode, ''))
        inseRD   = re.sub(r'-|\-', '', str(RateDate))
        keyvalue = "ondemand/{}/{:%Y%m%d}/delivery/{}.json".format(3660,datetime.datetime.now(),str(inputid)+'_'+str(inseRD)+'_'+id_update)
        key = bucket.new_key(keyvalue)
        key.set_contents_from_string(json.dumps(array))
        return json.dumps(array)
    except Exception as e:
        insert_value_error = str(str(re.sub(r"'", '"', str(e)))) + 'Where line number ' + str(sys.exc_traceback.tb_lineno) + str(proxyip)
        print (insert_value_error)
        statuscode = '4'
        keyvalue   = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format('3660', datetime.datetime.now(), id_update)
        key        = bucket.new_key(keyvalue)
        key.set_contents_from_string(insert_value_error)
        array.append(aws_insert.insert(id_update, inputid , 'Travelocity', '3660', "", "", "", "", Guests, "", "", "", "", "", url_inc, url_inc, url_inc, "", "", "", "", "", "", StartDate, EndDate , "", "", "", "", "", "", "", "", "", region, statuscode, israteperstay))
        return json.dumps(array)   

def StrctNew(jsonvalue, url_inc, id_update, inputid, RateDate, StartDate, EndDate, Guests, LOS, array, region, intime, proxyip, bucket):
    try:
        if re.search(r'"curc=(.*?)&', json.dumps(jsonvalue)):
            Currencycode = re.search(r'"curc=(.*?)&', json.dumps(jsonvalue)).group(1)
        else:
            Currencycode = 'USD'
        if 'currentHotel' in jsonvalue:
            if 'offers' in jsonvalue['currentHotel']:
                if 'rooms' in jsonvalue['currentHotel']['offers']:
                    if len(jsonvalue['currentHotel']['offers']['rooms'])!=0:
                        ROOM_CHECK = []
                        for roomsL in jsonvalue['currentHotel']['offers']['rooms']:
                            if 'name' in roomsL:
                                Roomtype = roomsL['name']
                            else:
                                Roomtype = ''
                            if 'description' in roomsL:
                                Room_Desc = roomsL['description']
                            else:
                                Room_Desc = ''
                            if 'maxOccupancy' in roomsL:
                                Maxocp = roomsL['maxOccupancy']['people']
                            else:
                                Maxocp = None
                            Room_Amts = []
                            if roomsL['ratePlans']:
                                for ratesP in roomsL['ratePlans']:
                                    promotion    = ''
                                    ispromupdate = ''
                                    if 'amenities' in ratesP:
                                        for Amnt in ratesP['amenities']:
                                            Room_Amts.append(Amnt['description'])
                                    if 'price' in ratesP:
                                        if 'taxAndFees' in ratesP['price']:
                                            taxAndFees = re.sub(r'[A-Z|a-z]', '', re.sub(r'(\D)', '', re.sub(r"\\u20b9|\$|,|[A-Za-z]+\.|Rs\.|Rs", r"", str(ratesP['price']['taxAndFees']))))
                                        else:
                                            taxAndFees = 0
                                        if 'lead' in ratesP['price']:
                                            statuscode = ''
                                            OnsiteRate = re.sub(r'[A-Z|a-z]', '', re.sub(r'(\D)', '', re.sub(r"\\u20b9|\$|,|[A-Za-z]+\.|Rs\.|Rs", r"", str(ratesP['price']['lead']))))
                                            Closed_up  = 'N'
                                        else:
                                            statuscode = '1'
                                            Closed_up  = 'Y'
                                            OnsiteRate = 0
                                        if 'strikeOut' in ratesP['price']:
                                            net_rate     = re.sub(r'[A-Z|a-z]', '', re.sub(r'(\D)', '', re.sub(r"\\u20b9|\$|,|[A-Za-z]+\.|Rs\.|Rs", r"", str(ratesP['price']['strikeOut']))))
                                            ispromupdate = 'Y'
                                        else:
                                            ispromupdate = 'N'
                                            net_rate     = 0
                                    else:
                                        taxAndFees   = 0
                                        statuscode   = '1'
                                        ispromupdate = 'N'
                                        net_rate     = 0
                                        OnsiteRate   = 0
                                        Closed_up    = 'Y'
                                    if 'limitedAvailability' in ratesP:
                                        if re.search(r'(\d+)', str(ratesP['limitedAvailability'])):
                                            roomavlb = re.search(r'(\d+)', str(ratesP['limitedAvailability'])).group(1)
                                        else:
                                            roomavlb = 0
                                    else:
                                        roomavlb = 0
                                    if 'cancellationPolicy' in ratesP:
                                        if ratesP['cancellationPolicy']['freeCancel']:
                                            Ratetype = 'Free Cancellation'
                                        elif ratesP['cancellationPolicy']['nonRefundable']:
                                            Ratetype = 'Non Refundable'
                                        else:
                                            Ratetype = ''
                                    else:
                                        Ratetype = ''
                                    if 'dynamicRateRule' in ratesP:
                                        if 'description' in ratesP['dynamicRateRule']:
                                            promotion = ratesP['dynamicRateRule']['description']
                                            ispromupdate = 'Y'
                                        else:
                                            ispromupdate = 'N'
                                            promotion = ''
                                    
                                    if OnsiteRate == 0:
                                        net_rate   = 0
                                        Closed_up  = 'Y'
                                        statuscode = '1'
                                        Tax_status = ''
                                    else:
                                        if int(taxAndFees) == 0:
                                            Tax_status = '1'
                                        else:
                                            Tax_status = '2'
                                        Closed_up = 'N'
                                    if LOS > 1 and Currencycode in ('AUD', 'CHF', 'DKK', 'EUR', 'GBP', 'NOK', 'NZD', 'SEK') or LOS == 1:
                                        israteperstay = 'Y'
                                    else:
                                        israteperstay = 'N'
                                    if Roomtype:
                                        ROOM_CHECK.append(Roomtype)
                                        Room_Amt  = ", ".join(Room_Amts)
                                        Room_Desc = re.sub(r'<.*?>|&nbsp;','',re.sub(r"</p><p>", r", ",str(Room_Desc)))
                                        array.append(aws_insert.insert(id_update, inputid , 'Travelocity', 3660, StartDate, Roomtype, LOS, RateDate, Guests, OnsiteRate, net_rate, OnsiteRate, Currencycode, Room_Desc, url_inc, url_inc, url_inc, Room_Amt, Room_Amt, Maxocp, ispromupdate, Closed_up, 30, StartDate , EndDate, intime, roomavlb, None, None, Tax_status, None, Ratetype, net_rate, promotion, region, statuscode, israteperstay))
                            else:
                                if Roomtype:
                                    statuscode = '1'
                                    Room_Desc  = re.sub(r'<.*?>|&nbsp;','',re.sub(r"</p><p>", r", ",str(Room_Desc)))
                                    array.append(aws_insert.insert(id_update, inputid , 'Travelocity', 3660, StartDate, Roomtype, LOS, RateDate, Guests, 0, 0, 0, Currencycode, Room_Desc, url_inc, url_inc, url_inc, '', '', Maxocp, 'N', 'Y', 30, StartDate , EndDate, intime, 0, None, None, '', None, '', 0, '', '', statuscode, ''))
                        if len(ROOM_CHECK)!=0:
                            None
                        else:
                            statuscode = '5'
                            array.append(aws_insert.insert(id_update, inputid , 'Travelocity', 3660, StartDate, '', LOS, RateDate, Guests, 0, 0, 0, Currencycode, '', url_inc, url_inc, url_inc, '', '', None, 'N', 'Y', 30, StartDate , EndDate, intime, 0, None, None, '', None, '', 0, '', '', statuscode, ''))
                    else:
                        statuscode = '2'
                        array.append(aws_insert.insert(id_update, inputid , 'Travelocity', 3660, StartDate, '', LOS, RateDate, Guests, 0, 0, 0, Currencycode, '', url_inc, url_inc, url_inc, '', '', None, 'N', 'Y', 30, StartDate , EndDate, intime, 0, None, None, '', None, '', 0, '', '', statuscode, ''))
                else:
                    statuscode = '2'
                    array.append(aws_insert.insert(id_update, inputid , 'Travelocity', 3660, StartDate, '', LOS, RateDate, Guests, 0, 0, 0, Currencycode, '', url_inc, url_inc, url_inc, '', '', None, 'N', 'Y', 30, StartDate , EndDate, intime, 0, None, None, '', None, '', 0, '', '', statuscode, ''))
            else:
                statuscode = '2'
                array.append(aws_insert.insert(id_update, inputid , 'Travelocity', 3660, StartDate, '', LOS, RateDate, Guests, 0, 0, 0, Currencycode, '', url_inc, url_inc, url_inc, '', '', None, 'N', 'Y', 30, StartDate , EndDate, intime, 0, None, None, '', None, '', 0, '', '', statuscode, ''))
        else:
            statuscode = '2'
            array.append(aws_insert.insert(id_update, inputid , 'Travelocity', 3660, StartDate, '', LOS, RateDate, Guests, 0, 0, 0, Currencycode, '', url_inc, url_inc, url_inc, '', '', None, 'N', 'Y', 30, StartDate , EndDate, intime, 0, None, None, '', None, '', 0, '', '', statuscode, ''))
            
        inseRD   = re.sub(r'-|\-', '', str(RateDate))
        keyvalue = "ondemand/{}/{:%Y%m%d}/delivery/{}.json".format(3660,datetime.datetime.now(),str(inputid)+'_'+str(inseRD)+'_'+id_update)
        key = bucket.new_key(keyvalue)
        key.set_contents_from_string(json.dumps(array))
        return json.dumps(array)
    except Exception as e:
        insert_value_error = str(str(re.sub(r"'", '"', str(e)))) + 'Where line number ' + str(sys.exc_traceback.tb_lineno) + str(proxyip)
        print (insert_value_error)
        statuscode = '4'
        keyvalue   = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(3660, datetime.datetime.now(), id_update)
        key        = bucket.new_key(keyvalue)
        key.set_contents_from_string(insert_value_error)
        array.append(aws_insert.insert(id_update, inputid , 'Travelocity', 3660, "", "", "", "", Guests, "", "", "", "", "", url_inc, url_inc, url_inc, "", "", "", "", "", "", StartDate, EndDate , "", "", "", "", "", "", "", "", "", region, statuscode, israteperstay))
        return json.dumps(array)   

def fetchrates(url, inputid, id_update, proxyip):
    inputid    = str(inputid)
    id_update  = str(id_update)
    proxies    = {'https':'http://{}'.format(proxyip)}
    Websitecode= '3660'
    StartDate  = datetime.date.today()
    intime     = re.sub(r'\s', 'T', str(datetime.datetime.now()))
    array      = []
    EndDate    = datetime.date.today() + datetime.timedelta(days=29)
    conn       = boto.connect_s3(aws_access_key_id='AKIAIXEGZVXCWE2FV3SQ', aws_secret_access_key='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') 
    bucket     = conn.get_bucket("rmapi")
    if re.search(r'=[a|A](\d+)[&|#]', str(url)):
        Guests = re.search(r'=[a|A](\d+)[&|#]', str(url)).group(1)
    elif re.search(r'[a|A]dults=(\d+)&', str(url)):
        Guests = re.search(r'[a|A]dults=(\d+)&', str(url)).group(1)
    elif re.search(r'[a|A]dult=(\d+)&', str(url)):
        Guests = re.search(r'[a|A]dult=(\d+)&', str(url)).group(1)
    else:
        Guests = re.search(r'=[a|A](\d+)&', str(url)).group(1)
    if re.search(r'(?s)chkin=(.*?)&', url):
        chekn = re.search(r'(?s)chkin=(.*?)&', url).group(1)
    if re.search(r'chkout=(.*?)&',url):
        chekt = re.search(r'chkout=(.*?)&', url).group(1)
    delta    = datetime.datetime.strptime(chekt, "%Y-%m-%d") - datetime.datetime.strptime(chekn, "%Y-%m-%d")
    LOS      = delta.days                
    RateDate = chekn
    inseRD   = re.sub(r'-|\-', '', str(RateDate))
    Currenc  = re.search(r'multiCurrencyCode=(.*?)#', url).group(1)
    urlrepl1 = datetime.datetime.strptime(chekn, str('%Y-%m-%d')).strftime('%m/%d/%Y')
    urlrepl2 = datetime.datetime.strptime(chekt, str('%Y-%m-%d')).strftime('%m/%d/%Y')
    url_db   = re.sub(r'chkin=.*?&chkout=.*?&', 'chkin=' + urlrepl1 + '&chkout=' + urlrepl2 + '&', url)
    try:
        ULS     = ['Mozilla/5.0 (X11; Fedora; x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chromium/74.0.3729.169 Chrome/74.0.3729.169 Safari/537.36', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Ubuntu Chromium/74.0.3729.108 Chrome/74.0.3729.108 Safari/537.36', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) snap Chromium/74.0.3729.108 Chrome/74.0.3729.108 Safari/537.36', 'Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.36 (KHTML; like Gecko) Ubuntu Chromium/74.0.3729.169 Chrome/74.0.3729.169 Safari/537.36', 'Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.36 (KHTML, like Gecko) snap Chromium/74.0.3729.108 Chrome/74.0.3729.108 Safari/537.36', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Ubuntu Chromium/74.0.3729.169 Chrome/74.0.3729.169 Safari/537.36', 'Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.36 (KHTML, like Gecko) Ubuntu Chromium/74.0.3729.131 Chrome/74.0.3729.131 Safari/537.36', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) snap Chromium/74.0.3729.157 Chrome/74.0.3729.157 Safari/537.36', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) snap Chromium/74.0.3729.131 Chrome/74.0.3729.131 Safari/537.36', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML; like Gecko) snap Chromium/74.0.3729.131 Chrome/74.0.3729.131 Safari/537.36', 'Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.36 (KHTML, like Gecko) Ubuntu Chromium/74.0.3729.61 Chrome/74.0.3729.61 Safari/537.36', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) snap Chromium/74.0.3729.169 Chrome/74.0.3729.169 Safari/537.36', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Ubuntu Chromium/74.0.3729.131 Chrome/74.0.3729.131 Safari/537.36', 'Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.36 (KHTML, like Gecko) Ubuntu Chromium/74.0.3729.169 Chrome/74.0.3729.169 Safari/537.36', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) snap Chromium/73.0.3683.86 Chrome/73.0.3683.86 Safari/537.36', 'Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.36 (KHTML; like Gecko) Ubuntu Chromium/73.0.3683.86 Chrome/73.0.3683.86 Safari/537.36', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Ubuntu Chromium/73.0.3683.86 Chrome/73.0.3683.86 Safari/537.36', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) snap Chromium/73.0.3683.103 Chrome/73.0.3683.103 Safari/537.36', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Ubuntu Chromium/73.0.3683.103 Chrome/73.0.3683.103 Safari/537.36', 'Mozilla/5.0 (X11; Linux armv7l) AppleWebKit/537.36 (KHTML, like Gecko) Ubuntu Chromium/73.0.3683.75 Chrome/73.0.3683.75 Safari/537.36', 'Mozilla/5.0 (X11; Linux aarch64) AppleWebKit/537.36 (KHTML, like Gecko) Ubuntu Chromium/73.0.3683.86 Chrome/73.0.3683.86 Safari/537.36', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML; like Gecko) Ubuntu Chromium/73.0.3683.86 Chrome/73.0.3683.86 Safari/537.36', 'Mozilla/5.0 (X11; Linux armv7l) AppleWebKit/537.36 (KHTML, like Gecko) Ubuntu Chromium/73.0.3683.86 Chrome/73.0.3683.86 Safari/537.36', 'Mozilla/5.0 (X11; Fedora; x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chromium/73.0.3683.86 Chrome/73.0.3683.86 Safari/537.36', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Ubuntu Chromium/73.0.3683.75 Chrome/73.0.3683.75 Safari/537.36', 'Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.36 (KHTML, like Gecko) Ubuntu Chromium/73.0.3683.86 Chrome/73.0.3683.86 Safari/537.36', 'Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.36 (KHTML, like Gecko) snap Chromium/73.0.3683.75 Chrome/73.0.3683.75 Safari/537.36', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) snap Chromium/73.0.3683.75 Chrome/73.0.3683.75 Safari/537.36', 'Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.36 (KHTML; like Gecko) Ubuntu Chromium/73.0.3683.75 Chrome/73.0.3683.75 Safari/537.36', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML; like Gecko) Ubuntu Chromium/73.0.3683.103 Chrome/73.0.3683.103 Safari/537.36', 'Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.36 (KHTML, like Gecko) Ubuntu Chromium/73.0.3683.75 Chrome/73.0.3683.75 Safari/537.36', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.119 Safari/537.36 Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Ubuntu Chromium/72.0.3626.119 Chrome/72.0.3626.119 Safari/537.36', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Ubuntu Chromium/72.0.3626.119 Chrome/72.0.3626.119 Safari/537.36', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Ubuntu Chromium/72.0.3626.121 Chrome/72.0.3626.121 Safari/537.36', 'Mozilla/5.0 (X11; Fedora; x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chromium/72.0.3626.97 Chrome/72.0.3626.97 Safari/537.36', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) snap Chromium/72.0.3626.121 Chrome/72.0.3626.121 Safari/537.36', 'Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.36 (KHTML, like Gecko) Ubuntu Chromium/72.0.3626.121 Chrome/72.0.3626.121 Safari/537.36', 'Mozilla/5.0 (X11; Linux armv7l) AppleWebKit/537.36 (KHTML; like Gecko) Raspbian Chromium/72.0.3626.121 Chrome/72.0.3626.121 Safari/537.36', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Ubuntu Chromium/72.0.3626.97 Chrome/72.0.3626.97 Safari/537.36', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML; like Gecko) Ubuntu Chromium/72.0.3626.119 Chrome/72.0.3626.119 Safari/537.36', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) snap Chromium/72.0.3626.96 Chrome/72.0.3626.96 Safari/537.36', 'Mozilla/5.0 (X11; Linux aarch64) AppleWebKit/537.36 (KHTML, like Gecko) Ubuntu Chromium/72.0.3626.121 Chrome/72.0.3626.121 Safari/537.36', 'Mozilla/5.0 (X11; Linux armv7l) AppleWebKit/537.36 (KHTML, like Gecko) Raspbian Chromium/72.0.3626.121 Chrome/72.0.3626.121 Safari/537.36', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) snap Chromium/72.0.3626.119 Chrome/72.0.3626.119 Safari/537.36']
        UserAg  = random.choice(ULS)
        headerT = {'authority' :re.search(r'(www.*?)/',url_db).group(1), 'User-Agent':str(UserAg),'upgrade-insecure-requests': '1','accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3', 
                   'accept-encoding' : 'gzip, deflate, br', 
                   'accept-language': 'en-GB,en-US;q=0.9,en;q=0.8',}
        respon1 = Load(url_db, headerT, proxies, 15)
        print respon1.status_code
    except:
        try:
            UserAg  = random.choice(ULS)
            headerT = {'Host' :re.search(r'(www.*?)/',url_db).group(1), 'User-Agent':str(UserAg),'Accept' : 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8', 'Accept-Encoding' : 'gzip, deflate, br', 'Accept-Language' : 'en-US,en;q=0.5'}
            respon1 = Load(url_db, headerT, proxies, 25)
        except Exception as e:
            insert_value_error = str(str(re.sub(r"'", '"', str(e)))) + 'Where line number ' + str(sys.exc_traceback.tb_lineno) + str(proxyip)
            statuscode = '5'
            keyvalue   = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(Websitecode, datetime.datetime.now(), id_update)
            key        = bucket.new_key(keyvalue)
            key.set_contents_from_string(insert_value_error)
            array.append(aws_insert.insert(id_update, inputid , 'Travelocity', Websitecode, "", "", "", "", Guests, "", "", "", "", "", url_db, url_db, url_db, "", "", "", "", "", "", StartDate, EndDate , "", "", "", "", "", "", "", "", "", '', statuscode, ''))
            return json.dumps(array)   

    html    = respon1.content.decode('ascii','ignore')
#     <hrml><saving?>
    keyvalue= "ondemand/{}/{:%Y%m%d}/source/{}.html".format(Websitecode, datetime.datetime.now(), str(inputid) + '_' + str(inseRD) + '_' + id_update)
    key     = bucket.new_key(keyvalue)
    key.set_contents_from_string(html)
    if re.search(r'htt.*?//www.travelocity\t..*?/Hotel' ,respon1.url) or 'Travel-Guide-Hotels' in str(respon1.url):
        statuscode = 3
        array.append(aws_insert.insert(id_update, inputid , 'Travelocity', Websitecode, StartDate, '', LOS, RateDate, Guests, 0, 0, 0, '', '', url_db, url_db, url_db, '', '', None, 'N', 'Y', 30, StartDate , EndDate, intime, 0, None, None, '', None, '', 0, '', '', statuscode, ''))
        return json.dumps(array)
    elif re.search(r'(?s)window\.__STATE__\s*=\s*(.*?});</sc', html):
        jsondata = re.search(r'(?s)window\.__STATE__\s*=\s*(.*?});</sc', html).group(1)
        jsonvalue= json.loads(jsondata)
        s        = re.sub(r'&nbsp;','',str(jsondata))
        keyvalue = "ondemand/{}/{:%Y%m%d}/source/{}.json".format(Websitecode, datetime.datetime.now(), str(inputid) + '_' + str(inseRD) + '_' + id_update)
        key = bucket.new_key(keyvalue)
        key.set_contents_from_string(s)
        return StrctNew(jsonvalue, url_db, id_update, inputid, RateDate, StartDate, EndDate, Guests, LOS, array, '', intime, proxyip, bucket)
    elif re.search(r"infosite\.offersData\s*=\s*(.*?});", html):
        jsondata  = re.search(r"infosite\.offersData\s*=\s*(.*?});", html).group(1)     
        jsonvalue = json.loads(jsondata)
        s         = re.sub(r'&nbsp;','',str(jsondata))
        keyvalue  = "ondemand/{}/{:%Y%m%d}/source/{}.json".format(Websitecode, datetime.datetime.now(), str(inputid) + '_' + str(inseRD) + '_' + id_update)
        key = bucket.new_key(keyvalue)
        key.set_contents_from_string(s)
        return strctOld(jsonvalue, url_db, id_update, inputid, RateDate, StartDate, EndDate, Guests, LOS, array, '', intime, proxyip, bucket,html)
    else:
        insert_value_error = "No Such Structure please check" + str(proxyip)
        statuscode = '5'
        keyvalue   = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(Websitecode, datetime.datetime.now(), id_update)
        key        = bucket.new_key(keyvalue)
        key.set_contents_from_string(insert_value_error)
        array.append(aws_insert.insert(id_update, inputid , 'Travelocity', Websitecode, "", "", "", "", Guests, "", "", "", "", "", url_db, url_db, url_db, "", "", "", "", "", "", StartDate, EndDate , "", "", "", "", "", "", "", "", "", '', statuscode, ''))
        return json.dumps(array)   


