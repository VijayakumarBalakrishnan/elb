# -*- coding: utf-8 -*-
import re
import requests
import datetime
import json
import boto
import gc
from mtranslate import translate

import sys
import traceback
import aws_insert

#url='https://secure.ermeshotels.com/bol/dispo.do?caId=232&hoId=1286&lang=1&dataDa=2017-05-15&dataA=2017-05-16&num_ad=1&_ga=2.171354720.1324845556.1495778268-649167725.1495774761'
#inputid='Gokul'
#id_update='12345'
#proxyip='media:M3d!Aproxy@45.40.120.202:80'

def fetchrates(url ,inputid, id_update, proxyip):
	#print url
	israteperstay = ''
	try:
		array = []		
		intime=re.sub(r'\s','T',str(datetime.datetime.now()))
		functionname='Ticket.com'
		Websitecode='315'	
		region=''
		conn = boto.connect_s3(aws_access_key_id= 'AKIAIXEGZVXCWE2FV3SQ',aws_secret_access_key = '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') 
		bucket = conn.get_bucket("rmapi")
		StartDate = datetime.date.today()
		EndDate  = datetime.date.today() + datetime.timedelta(days=29)
		if re.search(r"dataDa=(.*?)&dataA=(.*?)&", url):
			chkin_date = re.search(r"dataDa=(.*?)&dataA=(.*?)&", url).group(1)
			chkout_date=re.search(r"dataDa=(.*?)&dataA=(.*?)&",url).group(2)
		delta=datetime.datetime.strptime(chkout_date, "%Y-%m-%d") - datetime.datetime.strptime(chkin_date, "%Y-%m-%d")
		LOS=delta.days
		RateDate=chkin_date
		Rtdate=re.sub(r'-|\-','',str(RateDate))	
		url=re.sub(r'dataDa=.*?&dataA=.*?&','dataDa='+str(datetime.datetime.strptime(chkin_date,str('%Y-%m-%d')).strftime('%m/%d/%Y'))+'&dataA='+str(datetime.datetime.strptime(chkout_date,str('%Y-%m-%d')).strftime('%m/%d/%Y'))+'&',url)
		proxies = {"http": "http://{}".format(proxyip)}

		try:
			hml = requests.get(url, proxies = proxies,timeout=50)
			region=''
			ip=re.sub(r"\{'.*?@|'\}|:\d+","",str(proxies))
			try:
				try:
					r = requests.get('http://freegeoip.net/json/'+ip,timeout=30)
				except Exception,e:
					r = requests.get('http://freegeoip.net/json/'+ip,timeout=30)
				js = r.json()
				region=js['country_name']
			except Exception,e:
				region=''
		except Exception,e:
			#print "Second_time"
			try:
				hml = requests.get(url, proxies = proxies,timeout=30)
			except Exception,e:
				value_error=str(re.sub("'",'"',str(e)))
				stacktrace=sys.exc_traceback.tb_lineno
				region=''
				ip=re.sub(r"\{'.*?@|'\}|:\d+","",str(proxies))
				try:
					try:
						r = requests.get('http://freegeoip.net/json/'+ip,timeout=30)
					except Exception,e:
						r = requests.get('http://freegeoip.net/json/'+ip,timeout=30)
					js = r.json()
					region=js['country_name']
				except Exception,e:
					region=''
				keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(Websitecode,datetime.datetime.now(),id_update)
				key = bucket.new_key(keyvalue)
				key.set_contents_from_string(str(e))
				statuscode=5
				Guests='1'
				array.append(aws_insert.insert(id_update, inputid ,functionname,Websitecode, "","", "", "", Guests, "", "", "", "", "",url, url, url, "", "", "", "", "", "",StartDate, EndDate , "", "", "", "", "", "",  "", "", "",region,statuscode))
				return json.dumps(array)
		if (hml.status_code <> 200):
			#random_proxy=['media:M3diAproxy@162.212.173.39:80','media:M3diAproxy@104.202.137.137:80','media:M3diAproxy@104.202.144.8:80','media:M3diAproxy@154.16.55.56:80','media:M3diAproxy@154.16.55.55:80','media:M3diAproxy@109.230.220.196:80','media:M3diAproxy@130.185.153.160:80','media:M3diAproxy@158.222.6.173:80','media:M3diAproxy@162.212.172.181:80','media:M3diAproxy@158.222.6.192:80','media:M3diAproxy@104.202.144.57:80','media:M3diAproxy@138.128.228.40:80','media:M3diAproxy@130.185.153.171:80','media:M3diAproxy@107.173.254.208:80','media:M3diAproxy@104.202.144.58:80','media:M3diAproxy@165.231.164.148:80','media:M3diAproxy@138.128.228.17:80']
			#proxyy=random.choice(random_proxy)
			#proxies = {"https": "http://{}".format(proxyy)}
			hml = requests.get(url, proxies = proxies)
		if (hml.status_code == 403 or hml.status_code == 407 or hml.status_code <> 200):
			try:	
				#random_proxy=['media:M3diAproxy@162.212.173.39:80','media:M3diAproxy@104.202.137.137:80','media:M3diAproxy@104.202.144.8:80','media:M3diAproxy@154.16.55.56:80','media:M3diAproxy@154.16.55.55:80','media:M3diAproxy@109.230.220.196:80','media:M3diAproxy@130.185.153.160:80','media:M3diAproxy@158.222.6.173:80','media:M3diAproxy@162.212.172.181:80','media:M3diAproxy@158.222.6.192:80','media:M3diAproxy@104.202.144.57:80','media:M3diAproxy@138.128.228.40:80','media:M3diAproxy@130.185.153.171:80','media:M3diAproxy@107.173.254.208:80','media:M3diAproxy@104.202.144.58:80','media:M3diAproxy@165.231.164.148:80','media:M3diAproxy@138.128.228.17:80']
				#proxyy=random.choice(random_proxy)
				#proxies = {"http": "http://{}".format(proxyy)}
				hml = requests.get(url, proxies = proxies)
			except Exception,e:
				value_error=str(re.sub("'",'"',str(e)))		
				stacktrace=sys.exc_traceback.tb_lineno
				region=''
				ip=re.sub(r"\{'.*?@|'\}|:\d+","",str(proxies))
				try:
					try:
						r = requests.get('http://freegeoip.net/json/'+ip,timeout=30)
					except Exception,e:
						r = requests.get('http://freegeoip.net/json/'+ip,timeout=30)
					js = r.json()
					region=js['country_name']
				except Exception,e:
					region=''
					keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(Websitecode,datetime.datetime.now(),id_update)
					key = bucket.new_key(keyvalue)
					key.set_contents_from_string(str(e))
					statuscode=5
					Guests='1'
					#array.append(aws_insert.insert(id_update, inputid ,functionname,Websitecode, "","", "", "", Guests, "", "", "", "", "",url, url, url, "", "", "", "", "", "",StartDate, EndDate , "", "", "", "", "", "",  "", "", "",region,statuscode))
					#return json.dumps(array)
		try:
			html = hml.text.encode('ascii', 'ignore')
		except:
			html = hml.text.decode('ascii', 'ignore')
		keyvalue = "ondemand/{}/{:%Y%m%d}/source/{}.html".format(Websitecode,datetime.datetime.now(),str(inputid)+'_'+str(Rtdate)+'_'+id_update)
		key = bucket.new_key(keyvalue)
		key.set_contents_from_string(html)
		if re.search(r'num_ad=(\d+)&',url,re.DOTALL):
			Guests=re.search(r'num_ad=(\d)&',url,re.DOTALL).group(1)
		else:
			Guests='1'
		RoomType=''
		OnsiteRate=''
		net_rate=''
		Curr='EUR'
		RateDescription=''
		RoomAmenity_Type=''
		Meal=''
		MaxOccupancy=''
		isPromotionalRate='N'
		isAvailable=''
		Taxtype=''
		Taxamount='0'
		Tax_status=''
		Spaceblock=''
		Ratetype=''
		discount_rate=''
		Promotion_Name=''
		statuscode=''
		if re.compile(r'id="content_room_desc".*?</div>\s*</div>\s*</div>',re.DOTALL).findall(html):
			Closed_up = 'N'
			for blck1 in re.compile(r'id="content_room_desc".*?</div>\s*</div>\s*</div>',re.DOTALL).findall(html):
				for blck2 in re.compile(r'class="rate_name">.*?<a class="sel_rate_button"', re.DOTALL).findall(blck1):
					if re.search(r'"room_name">\s*(.*?)\s*<',blck1,re.DOTALL):
						RoomType  = re.sub(r'[^\x00-\x7F]+'," ", re.sub(r"'","''",re.search(r'"room_name">\s*(.*?)\s*<',blck1,re.DOTALL).group(1)))			
					if re.search(r'id="rate_name".*?>\s*(.*?)\s*<',blck2,re.DOTALL):
						Ratetype1 = re.sub(r"'","''", re.sub(r"\s\s+", r" ",re.search(r'id="rate_name".*?>\s*(.*?)\s*<',blck2,re.DOTALL).group(1)))
					else:
						Ratetype1 = ''
					if re.search(r'class="cancel_detail">\s*(.*?)\s*<',blck2,re.DOTALL):
						Ratetype2 = re.sub(r"'","''", re.sub(r"\s\s+", r" ",re.search(r'class="cancel_detail">\s*(.*?)\s*<',blck2,re.DOTALL).group(1)))
					else:
						Ratetype2 = ''
					Ratetype = str(Ratetype1)+', '+str(Ratetype2)
					if re.search(r'class="desc_or" value="\s*(.*?)ROOM\s*AMENITIES\s*(.*?)\s*<',blck1,re.DOTALL):
						RateDescription = re.sub(r"<.*?>","",str(re.sub(r'<.*?>','',re.sub(r'&gt;','>',re.sub('&lt;','<',re.search(r'class="desc_or" value="\s*(.*?)ROOM\s*AMENITIES\s*(.*?)\s*<',blck1,re.DOTALL).group(1))))))
						RoomAmenity_Type = re.sub(r'^:\s*|$','"',re.sub(r"<.*?>","",re.sub(r"</li><br/>\s*<li><br/>\s*", r'", "',re.sub(r'&gt;','>',re.sub('&lt;','<',re.search(r'class="desc_or" value="\s*(.*?)ROOM\s*AMENITIES\s*(.*?)\s*<',blck1,re.DOTALL).group(2))))))
					if re.search(r'totale_costo.*?>(.*?)<',blck2):
						OnsiteRate = re.sub(r",|'",'',re.search(r'totale_costo.*?>(.*?)<',blck2).group(1))
						israteperstay = 'Y'
					if re.search(r'"few_rooms">\s*(.*?)\s*<',blck1,re.DOTALL):
						isAvailabl = re.search(r'"few_rooms">\s*(.*?)\s*<',blck1,re.DOTALL).group(1)
						if re.search(r'(\d+)',isAvailabl):
							isAvailable = re.search(r'(\d+)',isAvailabl).group(1)
						elif re.search(r'[L|l]ast',isAvailabl):
							isAvailable = 1
						else:
							isAvailable = ''
					if re.search(r'id="rate_name".*?>\s*.*?\s*<.*?<p>\s*(.*?)\s*<',blck2,re.DOTALL):
						Meal         = re.sub(r"\s\s+", r" ",re.search(r'id="rate_name".*?>\s*.*?\s*<.*?<p>\s*(.*?)\s*<',blck2,re.DOTALL).group(1))
					else:
						Meal = ''	
					if OnsiteRate == 0 or str(OnsiteRate)=='0':
						statuscode=1
					array.append(aws_insert.insert(id_update, inputid , functionname, Websitecode, StartDate, RoomType, LOS, RateDate, Guests, OnsiteRate, net_rate, OnsiteRate, Curr, RateDescription, url, url, url, RoomAmenity_Type, Meal, MaxOccupancy, isPromotionalRate, Closed_up,30, StartDate , EndDate, intime, isAvailable, Taxtype, Taxamount, Tax_status, Spaceblock, Ratetype, discount_rate,Promotion_Name,region,statuscode, israteperstay))
					##print (id_update, inputid , functionname, Websitecode, StartDate, RoomType, LOS, RateDate, Guests, OnsiteRate, net_rate, OnsiteRate, Curr, RateDescription, url, url, url, RoomAmenity_Type, Meal, MaxOccupancy, isPromotionalRate, Closed_up,30, StartDate , EndDate, intime, isAvailable, Taxtype, Taxamount, Tax_status, Spaceblock, Ratetype, discount_rate,Promotion_Name,region,statuscode)
					##print "____________________________________________________"
		else:
			Closed_up = 'Y'
			ispromupdate = 'N'
			statuscode = '2'			
			array.append(aws_insert.insert(id_update, inputid , functionname, Websitecode, StartDate, RoomType, LOS, RateDate, Guests, OnsiteRate, net_rate, OnsiteRate, Curr, RateDescription, url, url, url, RoomAmenity_Type, Meal, MaxOccupancy, isPromotionalRate, Closed_up,30, StartDate , EndDate, intime, isAvailable, Taxtype, Taxamount, Tax_status, Spaceblock, Ratetype, discount_rate,Promotion_Name,region,statuscode, israteperstay))
			##print (id_update, inputid , functionname, Websitecode, StartDate, RoomType, LOS, RateDate, Guests, OnsiteRate, net_rate, OnsiteRate, Curr, RateDescription, url, url, url, RoomAmenity_Type, Meal, MaxOccupancy, isPromotionalRate, Closed_up,30, StartDate , EndDate, intime, isAvailable, Taxtype, Taxamount, Tax_status, Spaceblock, Ratetype, discount_rate,Promotion_Name,region,statuscode)			
		keyvalue = "ondemand/{}/{:%Y%m%d}/delivery/{}.json".format(Websitecode,datetime.datetime.now(),str(inputid)+'_'+str(Rtdate)+'_'+id_update)
		key = bucket.new_key(keyvalue)
		key.set_contents_from_string(json.dumps(array))
		gc.collect()
		return json.dumps(array)			
		
	except Exception as e:
		value_error=str(re.sub(r"'",'"',str(e)))
		stacktrace=sys.exc_traceback.tb_lineno
		Guests ='1'
		insert_value_error=str(value_error)+'Where line number '+str(stacktrace)+str(proxyip)
		statuscode='4'
		keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(Websitecode,datetime.datetime.now(),id_update)
		key = bucket.new_key(keyvalue)
		key.set_contents_from_string(insert_value_error)
		array.append(aws_insert.insert(id_update, inputid ,functionname,Websitecode, insert_value_error,"", "", "", Guests, "", "", "", "", "",url, url, url, "", "", "", "", "", "",StartDate, EndDate , "", "", "", "","", "",  "", "", "",region,statuscode, israteperstay))
		return json.dumps(array)		
		
		


