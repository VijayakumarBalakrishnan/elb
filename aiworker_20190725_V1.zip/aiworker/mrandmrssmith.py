# -*- coding: utf-8 -*-
import re
import requests
import datetime
import json
import boto
import gc

import sys
import aws_insert


def fetchrates(url ,inputid, id_update, proxyip):    
    array = []
    israteperstay = ''
    intime=re.sub(r'\s','T',str(datetime.datetime.now()))
    Domainname='mrandmrssmith'
    Websitecode='1690'
    region=''
    statuscode=''
    conn = boto.connect_s3(aws_access_key_id= 'AKIAIXEGZVXCWE2FV3SQ',aws_secret_access_key = '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') 
    bucket = conn.get_bucket("rmapi")
    StartDate = datetime.date.today()
    EndDate  = datetime.date.today() + datetime.timedelta(days=29)
    #print url
    curencies = ['GBP', 'USD', 'EUR', 'AUD', 'CAD', 'NZD', 'DKK', 'SEK', 'AED', 'CHF', 'HKD', 'SGD', 'NOK', 'ZAR']
    currency = re.search(r'&s\[currency\]=(.*?)#', url).group(1)
    try:
        if currency not in curencies:
            statuscode=8
            #print statuscode
            array.append(aws_insert.insert(id_update, inputid ,Domainname,Websitecode, "", "", "", "", 0, "", "", "", "", "",url, url, url, "", "", "", "", "", "",StartDate, EndDate , "", "", "", "", "", "", "", "", "",region,statuscode, israteperstay))
            return json.dumps(array)
        url_db = url
        Guests=None
        RateDate=''
        if re.search(r'\[date_from\]=(.*?)&', url_db):
            RateDate = re.search(r'\[date_from\]=(.*?)&', url_db).group(1)
        if re.search('\[date_from\]=(.*?)&',url_db):
            check_in_date = datetime.datetime.strptime(datetime.datetime.strptime(str(re.search('\[date_from\]=(.*?)&',url_db).group(1)),'%Y-%m-%d').strftime('%Y, %m, %d'),'%Y, %m, %d')
        if re.search('\[date_to\]=(.*?)&',url_db):
            check_out_date = datetime.datetime.strptime(datetime.datetime.strptime(str(re.search('\[date_to\]=(.*?)&',url_db).group(1)),'%Y-%m-%d').strftime('%Y, %m, %d'),'%Y, %m, %d')
        LOS = check_out_date - check_in_date
        LOS = LOS.days    
        head = {'User-Agent':'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:12.0) Gecko/20100101 Firefox/31.0'}
        proxies={"http": "http://{}".format(proxyip)}
        region=''
        ip=re.sub(r"\{'.*?@|'\}|:\d+","",str(proxies))
        try:
            try:
                r = requests.get('http://freegeoip.net/json/'+ip,timeout=30)
            except Exception,e:
                r = requests.get('http://freegeoip.net/json/'+ip,timeout=30)
            js = r.json()
            region=js['country_name']
        except Exception,e:
            region=''
        try:
            hml = requests.get(url_db, headers=head, proxies = proxies,timeout=30)
            #print hml.status_code
        except Exception,e:
            try:
                hml = requests.get(url_db, headers=head, proxies = proxies,timeout=30)
            except Exception,e:
                value_error=str(re.sub("'",'"',str(e)))
                stacktrace=sys.exc_traceback.tb_lineno
                insert_value_error=str(value_error)+'Where line number '+str(stacktrace)+str(proxyip)
                print insert_value_error
                keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(Websitecode,datetime.datetime.now(),id_update)
                key = bucket.new_key(keyvalue)
                key.set_contents_from_string(insert_value_error)
                statuscode=5
                Guests=None
                array.append(aws_insert.insert(id_update, inputid ,Domainname,Websitecode, "","", "", "", Guests, "", "", "", "", "",url_db, url_db, url_db, "", "", "", "", "", "",StartDate, EndDate , "", "", "", "", "", "",  "", "", "",region,statuscode, israteperstay))
                return json.dumps(array)
        if (hml.status_code<> 200):
            hml = requests.get(url_db, headers=head, proxies = proxies)
        if (hml.status_code == 403 or hml.status_code == 407 or hml.status_code <> 200):
            try:
                hml = requests.get(url_db, headers=head, proxies = proxies)
            except Exception as e:
                print e
                try:
                    hml = requests.get(url_db, headers=head)
                except Exception as e:
                    value_error=str(re.sub("'",'"',str(e)))
                    stacktrace=sys.exc_traceback.tb_lineno
                    insert_value_error=str(value_error)+'Where line number '+str(stacktrace)+str(proxyip)
                    print insert_value_error
                    keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(Websitecode,datetime.datetime.now(),id_update)
                    key = bucket.new_key(keyvalue)
                    key.set_contents_from_string(insert_value_error)
                    statuscode=5
                    Guests=None
                    array.append(aws_insert.insert(id_update, inputid ,"",Websitecode, "", "", "", "", Guests, "", "", "", "", "",url_db, url_db, url_db, "", "", "", "", "", "",StartDate, EndDate , "", "", "", "", "", "", "", "", "",region,statuscode, israteperstay))
                    return json.dumps(array)
        
        #hml = requests.get(json_url, headers=head, proxies = proxies)
        html = (hml.text.encode('ascii','ignore'))
        Rtdate=re.sub(r'-|\-','',RateDate)
        keyvalue = "ondemand/{}/{:%Y%m%d}/source/{}.html".format(Websitecode,datetime.datetime.now(),str(inputid)+'_'+str(Rtdate)+'_'+id_update)
        key = bucket.new_key(keyvalue)
        key.set_contents_from_string(str(html))
        Roomtype = ""
        RateDescription=''
        OnsiteRate = 0
        GrossRate = 0
        NetRate=0
        Closed_up = 'N'
        RoomAmenityType = ""
        Curr=''
        Maxocp = None
        isPromotionalRate = 'N'
        Spaceblock=''
        promotion=''
        Roomavilable = ''
        Taxtype = ''
        MealInclusion_Type=''
        Taxamount = 0
        Ratetype = ''
        Tax_status=''
        reg_block = re.search('class="mod-hotelRooms-rates"\s*(.*?\s*>\s*</div></div></article>.*?)</div>\s',html,re.DOTALL)
        if reg_block:
            for block in re.compile(r'class="mod-hotelRooms-rates"\s*(.*?\s*>\s*</div></div></article>.*?)</div>\s',re.DOTALL).findall(html):
                Roomtype=""
                OnsiteRate= 0
                NetRate= 0
                Curr=""
                RateDescription=""
                RoomAmenity_Type=""
                MealInclusion_Type=""
                Maxocp= None
                isPromotionalRate="N"
                Closed_up="N"
                isAvailable=""
                Taxtype=""
                TaxAmount= 0
                Promotion_Name=""
                statuscode = ''
                Ratetype=""
                room_type=re.search('class="roomcard-title-hotelname".*?>\s*(.*?)\s*</h2>',block)
                if room_type:
                    rooms=room_type.group(1)
                    RoomType=re.sub("'","''",rooms)
                    Roomtype=re.sub('\s+',' ',RoomType)
                    ##print "Room_Type        :",RoomType
                Max=re.search('class="count" itemprop="value">\s*(\d+)\s*<',block)
                if Max:
                    MaxOccupancy_1=Max.group(1)
                    Maxocp=re.sub('\s+',' ',MaxOccupancy_1)
                    ##print "Max_Occupancy        :",Maxocp
                descript=re.search('itemprop="description".*?>\s*(.*?)\s*</div>',block,re.DOTALL)
                if descript:
                    RateDescription_1=descript.group(1)
                    RateDescription = re.sub("\$|<.*?>","",RateDescription_1)
                    RateDescription=re.sub('\s+',' ',RateDescription)
                    ##print "Descriptipon        :",RateDescription
                if re.compile(r'<article class="ratecard.*?>\s*(.*?)\s*</article>',re.DOTALL).findall(block):
                    for blocks in re.compile(r'<article class="ratecard.*?>\s*(.*?)\s*</article>',re.DOTALL).findall(block):
                        RateType1 = ''
                        RateType2 = ''
                        Curr = ''
                        OnsiteRate = ''
                        MealInclusion_Type = ''
                        isPromotionalRate = 'N'
                        promotion = ''
                        Ratetyp1=re.search('<h4.*?>\s*(.*?)\s*</h4>',blocks)
                        if Ratetyp1:
                            price_typ1=Ratetyp1.group(1)
                            price_typ1 = re.sub("&amp;","&",price_typ1)
                            price_typ1 = re.sub("'","''",price_typ1)
                            price1 = re.sub("<.*?>|&.*?;","",price_typ1)
                            RateType1 = re.sub("\s+"," ",price_typ1)
                            ##print "Price_Type        :",RateType1
                        promotion2_re = re.search(r"(\d+%\s*off.*?)", str(RateType1), re.IGNORECASE)
                        if promotion2_re:
                            promotion  = RateType1
                            isPromotionalRate     = 'Y'
                        curr_re = re.search('selected="selected">(.*?)</option>',html)
                        if curr_re:
                            Curr= curr_re.group(1)
                            ##print"Currency   :",Curr
                        old_price=re.search('<span class="totalPrice rate">\s*<.*?>\s*.*?(\d.*?)\s*</',blocks)
                        if old_price:
                            price=old_price.group(1)
                            OnsiteRate = re.sub(",","",price)
                            ##print "Room_Price        :",OnsiteRate
                        meals=re.search('<strong>[i|I]nclu.*?\s*</strong>\s*(.*?)\s*<',blocks)
                        if meals:
                            MealInclusion_Type1=meals.group(1)
                            MealInclusion_Type = re.sub("<.*?>","",MealInclusion_Type1)
                            ##print "Meal_type        :",MealInclusion_Type
                        html_tax = ''
                        url_re = re.search('<a href="(/terms.*?)"',blocks)
                        if url_re:
                            url_tax= 'https://www.mrandmrssmith.com'+str(url_re.group(1))
                            ##print"url_tax   :",url_tax
                            try:
                                sample_load = requests.get(url_tax, headers=head, proxies = proxies)
                            except Exception as e:
                                sample_load = requests.get(url_tax, headers=head)
                            html_tax = sample_load.text.encode('ascii','ignore')
                            ##print sample_load.status_code
                        Taxtype_reg=re.search('class="label M-\d+_\d+ L-\d+_\d+ XL-\d+_\d+ XXL-\d+_\d+">Tax.*?<.*?>\s*<.*?>\s*(.*?)\s*</td>',html_tax)
                        if Taxtype_reg:
                            Taxtype=Taxtype_reg.group(1)
                            Taxtype = re.sub("''","'",Taxtype)
                            ##print "Room_Price        :",Taxtype
                        Ratetyp2=re.search('<tr>\s*<td class="label M-\d+_\d+ L-\d+_\d+ XL-\d+_\d+ XXL-\d+_\d+">\s*(Can.*?)\s*</td>',html_tax)
                        if Ratetyp2:
                            price_typ2=Ratetyp2.group(1)
                            price_typ2 = re.sub("&amp;","&",price_typ2)
                            price_typ2 = re.sub("'","''",price_typ2)
                            price2 = re.sub("<.*?>|&.*?;|\:","",price_typ2)
                            RateType2 = re.sub("\s+"," ",price2)
                            ##print "Price_Type        :",RateType2
                        Ratetype = str(RateType1)+', '+str(RateType2)
                        if OnsiteRate==0 or str(OnsiteRate) == '0':
                            Closed_up = 'Y'
                            statuscode='1'
                            Tax_status='-1'
                        else:
                            Closed_up = 'N'
                            statuscode='0'
                        israteperstay = 'Y'
                        Tax_status = 2
                        GrossRate = OnsiteRate
                        array.append(aws_insert.insert(id_update, inputid , Domainname, Websitecode, StartDate, Roomtype, LOS, RateDate, Guests, OnsiteRate, NetRate, GrossRate, Curr, RateDescription, url_db, url_db, url_db, RoomAmenityType, MealInclusion_Type, Maxocp, isPromotionalRate, Closed_up, 30, StartDate , EndDate, intime, Roomavilable, Taxtype, Taxamount, Tax_status, Spaceblock, Ratetype, NetRate,promotion,region,statuscode, israteperstay))
                        ##print (id_update, inputid , Domainname, Websitecode, StartDate, Roomtype, LOS, RateDate, Guests, OnsiteRate, NetRate, GrossRate, Curr, RateDescription, url_db, url_db, url_db, RoomAmenityType, MealInclusion_Type, Maxocp, isPromotionalRate, Closed_up, 30, StartDate , EndDate, intime, Roomavilable, Taxtype, Taxamount, Tax_status, Spaceblock, Ratetype, NetRate,promotion,region,statuscode)
                else:
                    ##print "else :",url_db
                    Closed_up = 'Y'
                    statuscode='1'
                    ##print (id_update, inputid , Domainname, Websitecode, StartDate, Roomtype, LOS, RateDate, Guests, OnsiteRate, NetRate, GrossRate, Curr, RateDescription, url_db, url_db, url_db, RoomAmenityType, MealInclusion_Type, Maxocp, isPromotionalRate, Closed_up, 30, StartDate , EndDate, intime, Roomavilable, Taxtype, Taxamount, Tax_status, Spaceblock, Ratetype, NetRate,promotion,region,statuscode)
                    array.append(aws_insert.insert(id_update, inputid , Domainname, Websitecode, StartDate, Roomtype, LOS, RateDate, Guests, OnsiteRate, NetRate, GrossRate, Curr, RateDescription, url_db, url_db, url_db, RoomAmenityType, MealInclusion_Type, Maxocp, isPromotionalRate, Closed_up, 30, StartDate , EndDate, intime, Roomavilable, Taxtype, Taxamount, Tax_status, Spaceblock, Ratetype, NetRate,promotion,region,statuscode, israteperstay))
        else:
            ##print "else 2:",url_db
            Closed_up = 'Y'
            statuscode='2'    
            array.append(aws_insert.insert(id_update, inputid , Domainname, Websitecode, StartDate, Roomtype, LOS, RateDate, Guests, OnsiteRate, NetRate, GrossRate, Curr, RateDescription, url_db, url_db, url_db, RoomAmenityType, MealInclusion_Type, Maxocp, isPromotionalRate, Closed_up, 30, StartDate , EndDate, intime, Roomavilable, Taxtype, Taxamount, Tax_status, Spaceblock, Ratetype, NetRate,promotion,region,statuscode, israteperstay))
            ##print (id_update, inputid , Domainname, Websitecode, StartDate, Roomtype, LOS, RateDate, Guests, OnsiteRate, NetRate, GrossRate, Curr, RateDescription, url_db, url_db, url_db, RoomAmenityType, MealInclusion_Type, Maxocp, isPromotionalRate, Closed_up, 30, StartDate , EndDate, intime, Roomavilable, Taxtype, Taxamount, Tax_status, Spaceblock, Ratetype, NetRate,promotion,region,statuscode)
        Rtdate=re.sub(r'-|\-','',RateDate)
        keyvalue = "ondemand/{}/{:%Y%m%d}/delivery/{}.json".format(Websitecode,datetime.datetime.now(),str(inputid)+'_'+str(Rtdate)+'_'+id_update)
        key = bucket.new_key(keyvalue)
        key.set_contents_from_string(json.dumps(array))
        gc.collect()
        return json.dumps(array)    
    except Exception as e:
        insert_value_error=str(str(re.sub(r"'",'"',str(e))))+'Where line number '+str(sys.exc_traceback.tb_lineno)+str(proxyip)
        print insert_value_error
        statuscode='4'
        Guests=None
        keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(Websitecode,datetime.datetime.now(),id_update)
        key = bucket.new_key(keyvalue)
        key.set_contents_from_string(insert_value_error)
        array.append(aws_insert.insert(id_update, inputid ,Domainname,Websitecode, "","", "", "", Guests, "", "", "", "", "",url_db, url_db, url_db, "", "", "", "", "", "",StartDate, EndDate , "", "", "", "", "", "",  "", "", "",region,statuscode, israteperstay))
        return json.dumps(array)
