# -*- coding: utf-8 -*-
import re
import requests
import datetime
import json
import boto
import gc

import sys
import aws_insert
#Connection String


'''url = "https://travel.jumia.com/en-gb/kenya/o10955/la-maison-royale-hotel-nairobi?region=&q=La+Maison+Royale+Hotel&checkin=2018-01-01&checkout=2018-01-02&roomCount=1&adults=1&children=0&age1=7&age2=7&age3=7"
inputid = "lokesh"
id_update = "12345"
proxyip = "media:M3diAproxy@196.17.7.6:80"'''

def fetchrates(url , inputid, id_update, proxyip):
    israteperstay = ''
    delta = datetime.datetime.strptime(re.search(r"checkout=(.*?)&", url).group(1), "%Y-%m-%d") - datetime.datetime.strptime(re.search(r"checkin=(.*?)&", url).group(1), "%Y-%m-%d")
    LOS = delta.days
    Websitecode =  260
    try:
        inputid   = inputid
        url       = url
        intime = re.sub(r'\s', 'T', str(datetime.datetime.now()))
        array = []
        functionname = 'TravelJumia'
        region = ''
        conn = boto.connect_s3(aws_access_key_id='AKIAIXEGZVXCWE2FV3SQ', aws_secret_access_key='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') 
        bucket = conn.get_bucket("rmapi")
        Domainname = 'TravelJumia'
        id_update     = id_update
        if re.search(r"&checkin=(.*?)&", url):
            RteDate = re.search(r"&checkin=(.*?)&", url).group(1)
        StartDate = datetime.date.today()
        EndDate = datetime.date.today() + datetime.timedelta(days=29)
        RoomType        =""
        RateDate        = RteDate
        Guests          ="01"
        OnsiteRate      = 0
        NetRate         = 0
        Curr            =""
        RateDescription =""
        url             = re.sub(r"'","''",url)
        RoomAmenity_Type=""
        Meal            =""
        MaxOccupancy    =""
        isPromotionalRate="N"
        Closed          ="Y"
        da_time         = datetime.datetime.now()
        isAvailable     =""
        Taxtype         =""
        TaxAmount       ="0"
        Ratetype        =""
        Promotion_Name  =""
        ##print url
        proxies      = {"http": "http://{}".format(proxyip)}
        try:
            input_result = requests.get(url, proxies = proxies,timeout =50 )
        except Exception as e:
            print e
            try:
                input_result = requests.get(url, proxies = proxies,timeout =50 )
            except Exception as e:
                print e
                value_error = str(re.sub("'", '', str(e)))
                stacktrace = sys.exc_traceback.tb_lineno
                keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(Websitecode, datetime.datetime.now(), id_update)
                key = bucket.new_key(keyvalue)
                key.set_contents_from_string(str(e) + 'Where Line number' + str(stacktrace) + str(proxies))
                statuscode = 5
                Guests = ''
                array.append(aws_insert.insert(id_update, inputid , functionname, Websitecode, "", "", "", "", Guests, "", "", "", "", "", url, url, url, "", "", "", "", "", "", StartDate, EndDate , "", "", "", "", "", "", "", "", "", region, statuscode,israteperstay))
                return json.dumps(array)
        #print input_result.status_code
        html         = re.sub(r"'","''", input_result.text.encode('ascii', 'ignore'))
        
        Rtdate=re.sub(r'-|\-','',str(RateDate))
        keyvalue = "ondemand/{}/{:%Y%m%d}/source/{}.html".format(Websitecode,datetime.datetime.now(),str(inputid)+'_'+str(Rtdate)+'_'+id_update)
        key = bucket.new_key(keyvalue)
        key.set_contents_from_string(html)
        if re.compile(r'<div class="box-shadow room-box">.*?</button></div></div></div></div></div></div></div>',re.DOTALL).findall(html):
            Closed ="N"
            for blck1 in re.compile(r'<div class="box-shadow room-box">.*?</button></div></div></div></div></div></div></div>',re.DOTALL).findall(html):
                for blck2 in re.compile(r'<div class="room-attr-box conditions-container">.*?</div></div></div></div></div>',re.DOTALL).findall(blck1):
                    for blck3 in re.compile(r'<div class="room-attr-box max-occupancy-container">.*?<button type="submit"',re.DOTALL).findall(blck2):
                        room_serch = re.search(r'href="javascript:.*?" data-roomid=".*?>(.*?)\s*</a><div class="room-attribute-icons-box">',blck1)
                        if room_serch:
                            RoomType = re.sub(r"'","''",room_serch.group(1))
                            
                        ratetyp = re.search(r'<div class="conditions-box">.*?<i class="icon-check"></i>(.*?)\s*<div class="rates-row">',blck2,re.DOTALL)
                        if ratetyp:
                            Ratetype = re.sub(r'">|&.*?;','',re.sub(r"'","''",re.sub(r'\s\s+','; ',re.sub(r'(?s)<.*?>|^\s+','',ratetyp.group(1)))))
    
                        ROOM_ID_search = re.search(r'href="javascript:.*?" data-roomid="(.*?)">.*?\s*</a><div class="room-attribute-icons-box">',blck1)
                        if ROOM_ID_search:
                            ROOM_IDs = ROOM_ID_search.group(1)
                        else:
                            ROOM_IDs = ''
                        desc_con = '"id":'+ROOM_IDs+',.*?"description":"(.*?),"rollinBedAvailable"'
                        desc_ser = re.search(desc_con,html)
                        if desc_ser:
                            RateDescription = re.sub(r'"','',re.sub(r'":"',':',re.sub(r'","',',',re.sub(r'^","','',re.sub(r"'","''",desc_ser.group(1))))))
                            
                        amein_con = r'"id":'+ROOM_IDs+',.*?"description":".*?attributes":\[{(.*?)}\]'
                        amein     = re.search(amein_con,html)
                        if amein:
                            RoomAmenity_Type = re.sub(r"'","''",re.sub(r'"icon":".*?","label":|,"value":".*?"|}|{|\\','',amein.group(1)))
                        
                        Maxocpy  = re.search(r'<div class="max-occupancy-box">(.*?)</div></div><div ',blck3)
                        if Maxocpy:
                            MaxOccupancy = len(re.sub(r',$','',re.sub(r'<.*?="(.*?)"></.*?>', r"\1,",Maxocpy.group(1))).split(','))
                            
                        Onrate = re.search(r'price-per-night finalPrice">(\d.*?) [A-z].*?<',blck3)
                        if Onrate:
                            OnsiteRate = re.sub(r",|'",'',Onrate.group(1))
                            Tax_status = 1
                        else:
                            Tax_status = 2
                        NetRates = re.search(r'<p class="base-price hasPromotion">(\d.*?) [A-z].*?<',blck3)
                        if NetRates:
                            NetRate = re.sub(r"'|,","",NetRates.group(1))
                            if NetRate:
                                isPromotionalRate="Y"
                            else:
                                isPromotionalRate="N"
                        else:
                            NetRate = 0
                            isPromotionalRate="N"
                        curr_concn = re.search(r'price-per-night finalPrice">\d.*? ([A-z].*?)<',blck3)
                        if curr_concn:
                            Curr = re.sub(r"'","''",curr_concn.group(1))
                        promoname_cc = re.search(r'<span id="qa-hotel-discount-badge-.*?">(.*?)</span>',blck3)
                        if promoname_cc:
                            Promotion_Name = re.sub(r"'","",promoname_cc.group(1))
                            if Promotion_Name:
                                isPromotionalRate="Y"
                            else:
                                isPromotionalRate="N"
                        isavailabl_cc = re.search(r'class="room-type-available">\s*.*?(\d+).*?\s*<',blck3)
                        if isavailabl_cc:
                            isAvailable = isavailabl_cc.group(1)
                        
                        Mealtypes          = str(RateDescription)+' '+str(RoomAmenity_Type)+' '+str(RoomType)+' '+str(Ratetype)
                        Meal = Mealtypes  
                                
                        if str(OnsiteRate) == '0' or str(OnsiteRate) == '0.0':
                            statuscode = '1'
                            Closed = 'Y'
                            
                        else:
                            statuscode = ''
                            Closed = 'N'
                            if LOS>1:
                                israteperstay = 'N'
                            else:
                                israteperstay = 'Y'
                        ##print (id_update, inputid , Domainname, Websitecode, StartDate, RoomType, LOS, RateDate, Guests, OnsiteRate, NetRate, OnsiteRate, Curr, RateDescription, url, url, url, RoomAmenity_Type, Meal, MaxOccupancy, isPromotionalRate, Closed, 30, StartDate , EndDate, intime, isAvailable, Taxtype, TaxAmount, Tax_status, None, Ratetype, NetRate, Promotion_Name, region, statuscode, israteperstay)    
                        array.append(aws_insert.insert(id_update, inputid , Domainname, Websitecode, StartDate, RoomType, LOS, RateDate, Guests, OnsiteRate, NetRate, OnsiteRate, Curr, RateDescription, url, url, url, RoomAmenity_Type, Meal, MaxOccupancy, isPromotionalRate, Closed, 30, StartDate , EndDate, intime, isAvailable, Taxtype, TaxAmount, Tax_status, None, Ratetype, NetRate, Promotion_Name, region, statuscode, israteperstay))
        else:
            Closed      = "Y"
            Tax_status = 2
            statuscode = '2'
            
            da_time = datetime.datetime.now()
            intime = re.sub(r'\s', 'T', str(da_time))
            array.append(aws_insert.insert(id_update, inputid , Domainname, Websitecode, StartDate, RoomType, LOS, RateDate, Guests, OnsiteRate, NetRate, OnsiteRate, Curr, RateDescription, url, url, url, RoomAmenity_Type, Meal, MaxOccupancy, isPromotionalRate, Closed, 30, StartDate , EndDate, intime, isAvailable, Taxtype, TaxAmount, Tax_status, None, Ratetype, NetRate, Promotion_Name, region, statuscode, israteperstay))
        keyvalue = "ondemand/{}/{:%Y%m%d}/delivery/{}.json".format(Websitecode, datetime.datetime.now(), str(inputid) + '_' + str(Rtdate) + '_' + id_update)
        key = bucket.new_key(keyvalue)
        key.set_contents_from_string(json.dumps(array))
        gc.collect()
        return json.dumps(array)        
    except Exception as e :
        value_error = str(re.sub(r"'", '"', str(e)))
        stacktrace = sys.exc_traceback.tb_lineno
        insert_value_error = str(value_error) + 'Where line number ' + str(stacktrace) + str(proxyip)
        statuscode = '4'
        keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(Websitecode, datetime.datetime.now(), id_update)
        key = bucket.new_key(keyvalue)
        key.set_contents_from_string(insert_value_error)
        array.append(aws_insert.insert(id_update, inputid , functionname, Websitecode, insert_value_error, "", "", "", Guests, "", "", "", "", "", url, url, url, "", "", "", "", "", "", StartDate, EndDate , "", "", "", "", "", "", "", "", "", region, statuscode, israteperstay))
        return json.dumps(array)    



#fetchrates(url , inputid, id_update, proxyip)
