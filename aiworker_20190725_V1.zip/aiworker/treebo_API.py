# -*- coding: utf-8 -*-
import re
import requests
import datetime
import json
import boto,gc,sys
import aws_insert

one_day = datetime.timedelta(days=1)

# url = 'https://www.treebo.com/hotels-in-mumbai/treebo-archana-residency-mulund-35/?checkin=2018-11-10&checkout=2018-11-11&hotel_id=35&roomconfig=1-0&'
# inputid='3657'
# id_update='3657'
#         
# proxyip='media:M3diAproxy@192.40.94.17:80'

def fetchrates(url,inputid,id_update,proxyip):
    ##print "Hai"
    array      = []
    proxies    = {"https": "http://{}".format(proxyip)}
    intime     = re.sub(r'\s','T',str(datetime.datetime.now()))
    Domainname = 'Treebo'
    Websitecode= '3657'
    region     = ''
    statuscode = ''
    Mealtype   = ''
    israteperstay = ''
    url_insert = ''
    Checkin  = ''
    Checkout = ''
    Guests   = ''
    try:
        conn   = boto.connect_s3(aws_access_key_id= 'AKIAIXEGZVXCWE2FV3SQ',aws_secret_access_key = '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') 
        bucket = conn.get_bucket("rmapi")
        StartDate = datetime.date.today()
        EndDate   = datetime.date.today() + datetime.timedelta(days=29)
        
        #ARRdd=07&ARRmm=12&ARRyyyy=2017&
        
        CheckIn_re = re.search(r'\?checkin=(.*?)&',url)
        if CheckIn_re:
            Checkin  = CheckIn_re.group(1)
            ##print Checkin
        Check_OT_re = re.search(r'&checkout=(.*?)&',url)
        if Check_OT_re:
            Checkout = Check_OT_re.group(1)
            ##print CheckIn_YYYY
        
        hotelid_re = re.search(r'&hotel_id=(.*?)&',url)
        if hotelid_re:
            hotelid = hotelid_re.group(1)
        
        adult_re  = re.search(r'&roomconfig=(\d+)-0',url)
        if adult_re:
            Guests = adult_re.group(1)
        
        else:
            Checkin  = ''
            Checkout = ''
            #Checkin_URL = ''
            #CheckOT_URL = ''
#         #print Checkin,Checkout
#         #print url
#         #print hotelid
#         #print adult
        
        RateDate = Checkin
        delta    = datetime.datetime.strptime(Checkout, "%Y-%m-%d") - datetime.datetime.strptime(Checkin, "%Y-%m-%d")
        LOS      = delta.days
        RoomType = ''
        #Guests   = re.search(r'&ADULT1=(\d+)&', url).group(1)
        #print LOS
        Ratetype = ''
        RateDescription = ''
        Taxtype  = ''
        Curr     = ''
        MaxOccupancy = None
        isPromotionalRate  = 'N'
        Closed   = 'Y'
        NetRate  = 0
        Taxstatus= -1
        TaxAmount= 0
        Discount = 0
        GrossRate= 0
        OnsiteRate = 0
        Curr     = ''
        Promotion_Name= ''
        isAvailable = ''
        RoomAmenity_Type = ''
        url_insert = url
        ##print url_insert
        
        head ={'Host':'www.treebo.com','User-Agent':'Mozilla/5.0 (X11; Linux x86_64; rv:45.0) Gecko/20100101 Firefox/45.0','Accept':'*/*','Accept-Language':'en-US,en;q=0.5','Accept-Encoding':'gzip, deflate, br','Authorization':'Bearer null','Content-Type':'application/json','Origin':'https://www.treebo.comConnection: keep-alive'}
        main_url = 'https://www.treebo.com/api/web/v5/pricing/hotels/'+str(hotelid)+'/room-prices/?checkin='+str(Checkin)+'&checkout='+Checkout+'&hotel_id='+str(hotelid)+'&roomconfig='+str(Guests)+'-0&utm_source=direct'
#         #print "main_url :",main_url
        urldetails = 'https://www.treebo.com/api/web/v3/hotels/'+str(hotelid)+'/details/?'
        ip = re.sub(r"\{'.*?@|'\}|:\d+", "", str(proxies))
        try:
            try:
                r = requests.get('http://freegeoip.net/json/' + ip, timeout=30)
            except Exception, e:
                r = requests.get('http://freegeoip.net/json/' + ip, timeout=30)
            js = r.json()
            region = js['country_name']
        except Exception, e:
            region = ''
            
        try:
#             #print ""
            htm = requests.get(main_url,headers=head,proxies = proxies,timeout=10)
            r=requests.get(urldetails, headers=head,proxies = proxies,timeout=10)
        except Exception, e:
            stacktrace = sys.exc_traceback.tb_lineno
            value_error = str(re.sub("'", '', str(e)))+ 'Where Line number' +str(stacktrace) 
            try:
                htm = requests.get(main_url,headers=head,proxies = proxies,timeout=20)
                r=requests.get(urldetails, headers=head,proxies = proxies,timeout=20)
            except Exception, e:
                try:
                    htm = requests.get(main_url,headers=head,proxies = proxies,timeout=30)
                    r=requests.get(urldetails, headers=head,proxies = proxies,timeout=30)
                except Exception, e:
                    stacktrace = sys.exc_traceback.tb_lineno
                    value_error = str(re.sub("'", '', str(e)))+ 'Where Line number' +str(stacktrace)
                    keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(Websitecode, datetime.datetime.now(), id_update)
                    key = bucket.new_key(keyvalue)
                    key.set_contents_from_string(str(e) + 'Where Line number' + str(value_error) + str(proxies))
                    statuscode = 5
                    Guests = ''
                    array.append(aws_insert.insert(id_update, inputid , Domainname, Websitecode, "", "", "", "", Guests, "", "", "", "", "", url_insert,url_insert,url_insert, "", "", "", "", "", "", StartDate, EndDate , "", "", "", "", "", "", "", "", "", region, statuscode, israteperstay))
                    return json.dumps(array)
            
        if htm.status_code <> 200 or r.status_code <> 200:
            htm = requests.get(main_url,headers=head,proxies = proxies)
            r = requests.get(urldetails, headers=head,proxies = proxies)
        if (htm.status_code == 403 or htm.status_code == 407) or htm.status_code <> 200 or r.status_code <> 200:
            try:
                if htm.status_code <> 200 or r.status_code <> 200:
                    htm = requests.get(main_url,headers=head)
                    r = requests.get(urldetails, headers=head)
                    
            except Exception, e:
                Closed    = 'Y'
                stacktrace = sys.exc_traceback.tb_lineno
                value_error = str(re.sub("'", '', str(e)))+ 'Where Line number' +str(stacktrace)
                keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(Websitecode, datetime.datetime.now(), id_update)
                key = bucket.new_key(keyvalue)
                key.set_contents_from_string(str(e) + 'Where Line number' + str(stacktrace) + str(proxies))
                statuscode = 5
                Guests = ''
                array.append(aws_insert.insert(id_update, inputid , Domainname, Websitecode, "", "", "", "", Guests, "", "", "", "", "", url_insert,url_insert,url_insert, "", "", "", "", "", "", StartDate, EndDate , "", "", "", "", "", "", "", "", "", region, statuscode, israteperstay))
                return json.dumps(array)
        jsonview = htm.json()
        jsonvi = r.json()
#         print json.dumps(jsonvi)
        inside_price = re.compile(r'availability.\s*:\s*(.*?)}').findall(str(jsonview))
        keyvalue = "ondemand/{}/{:%Y%m%d}/source/{}.json".format(Websitecode,datetime.datetime.now(),str(inputid)+'_'+str(Checkin)+'_'+id_update)
        key = bucket.new_key(keyvalue)
        key.set_contents_from_string(json.dumps(jsonview)+'-*100'+json.dumps(jsonvi))

        if jsonview.has_key('data'):
            if 'True' in inside_price:
#                 print "in"
                RoomType      = ''
                Ratetype      = ''
                OnsiteRate    = 0
                RoomAmenity_Type = ''
                RateDescription  = ''
                Mealtype         = ''
                Curr             = 'INR'
                Closed           = 'N'
                GrossRate        =  0
                NetRate          = 0
                isAvailable      = ''
                MaxOccupancy     = None
                TaxAmount=''
                Taxstatus=-1
                #print "jsondata    :",json.dumps(jsonview)
                for types in jsonview['data']['total_price'].iteritems(): 
                    typess =  types[0]
                    if jsonview['data']['total_price'][types[0]]['availability']==False:
#                         print "correct"
                        continue
                    for data in jsonview['data']['total_price'][types[0]]['rate_plans']:
                        if data['price']['net_payable_amount']:
                            OnsiteRate = data['price']['net_payable_amount']
                            
                        if data['price']['rack_rate']:
                            NetRate = data['price']['rack_rate']
                            isPromotionalRate = 'Y' 
                        else:
                            isPromotionalRate = 'N'
                            
                        if data['price']['tax']:
                            TaxAmount = data['price']['tax']
                            if int(TaxAmount)==0:
                                Taxstatus = 2
                                Taxtype = 'Exclusive of all taxes'
                            else:
                                Taxtype = "Inclusive of all taxes"
                                Taxstatus = 1
                        else:
                            TaxAmount = 0
                            Taxstatus = 2
                            
                        if data['rate_plan']['description']:
                            Ratetype = data['rate_plan']['description']
    
#                         print "price :",OnsiteRate
#                         print "strikerate :",NetRate
#                         print "tax :",TaxAmount
#                         print "Ratetype :",Ratetype
                        
                        for data in jsonvi['data']['rooms']:
                            RoomType = str(data['type'])
#                             print RoomType
                            Am_ls = []
                            if RoomType == typess:
                                print "rooms"
                                if data['facilities']:
                                    for aminity in data['facilities']:
                                        Am_ls.append(aminity['name'])
                                    RoomAmenity_Type = re.sub(r"'","",re.sub(r"\[|\]|u'",'',str(Am_ls)))
                                    #print RoomAmenity_Type
                                else:
                                    RoomAmenity_Type = ''
                                
                                if data['occupancy']:
                                    MaxOccupancy = str(data['occupancy'])
                                    MaxOccupancy  = re.search(r'(\d+) G',MaxOccupancy).group(1)
                                else:
                                    MaxOccupancy = ''
                                #print MaxOccupancy
                                
                                if data['facilities']:
                                    RateDescription = str(data['size'])+'Sqft, '+str(data['max_adults'])+'Guests '
                                else:
                                    RateDescription = ''
                                
                                if data['max_adults']:
                                    maxadults = data['max_adults']
                                else:
                                    maxadults = ''
                                #print maxadults
                                
                                if jsonvi['data']['description']:
                                    description = jsonvi['data']['description']
                                    description = re.sub(r"'","''",description)#unidecode(description).decode('utf-8'))
                                else:
                                    description = ''
                                #print description
                                
                                Am_lls = []
                                if jsonvi['data']['facilities']:
                                    for meal in jsonvi['data']['facilities']:
                                        Am_lls.append(meal['name'])
                                    meals = re.sub(r"'","",re.sub(r"\[|\]|u'",'',str(Am_lls)))
                                else:
                                    meals = ''
                                
                                if 'free breakfast' in meals.lower():
                                    Mealtype = 'free breakfast'
                                elif 'breakfast' in meals.lower():
                                    Mealtype = 'breakfast'
                                else:
                                    Mealtype = ''
                                    
                                #print Mealtype
                    
                                if OnsiteRate==0:
                                    statuscode = 1
                                    Closed='Y'
                                else:
                                    statuscode = ''
                                    Closed='N'
                                
                                israteperstay ='Y'
                                
                                if int(OnsiteRate)==int(NetRate):
                                    NetRate = 0
                                
#                                 print 'RoomType    :',RoomType
#                                 print 'RateDescription :',RateDescription
#                                 print 'MaximumOccupancy :',MaxOccupancy
#                                 print 'RoomAmenity_Type :',RoomAmenity_Type
#                                 print 'Ratetype    :',Ratetype
                                print 'OnsiteRate  :',OnsiteRate
                                print 'NetRate     :',NetRate
#                                 print 'Curr        :',Curr
#                                 print 'isAvailable :',isAvailable
#                                 print 'Mealtype    :',Mealtype
    #                             #print (id_update, inputid , Domainname, Websitecode, StartDate, RoomType, LOS, RateDate, Guests, OnsiteRate, NetRate, GrossRate, Curr, RateDescription, url_insert, url_insert, url_insert, RoomAmenity_Type, Mealtype, MaxOccupancy, isPromotionalRate, Closed, 30, StartDate , EndDate, intime, isAvailable, Taxtype, TaxAmount, Taxstatus, None, Ratetype, Discount,Promotion_Name,region,statuscode, israteperstay)
                                array.append(aws_insert.insert(id_update, inputid , Domainname, Websitecode, StartDate, RoomType, LOS, RateDate, Guests, OnsiteRate, NetRate, GrossRate, Curr, RateDescription, url_insert, url_insert, url_insert, RoomAmenity_Type, Mealtype, MaxOccupancy, isPromotionalRate, Closed, 30, StartDate , EndDate, intime, isAvailable, Taxtype, TaxAmount, Taxstatus, None, Ratetype, Discount,Promotion_Name,region,statuscode, israteperstay))
            else:
                Closed     = 'Y'
                statuscode = '2'
    #             #print "else"
    #             #print (id_update, inputid , Domainname, Websitecode, StartDate, RoomType, LOS, RateDate, Guests, OnsiteRate, NetRate, GrossRate, Curr, RateDescription, url_insert, url_insert, url_insert, RoomAmenity_Type, Mealtype, MaxOccupancy, isPromotionalRate, Closed, 30, StartDate , EndDate, intime, isAvailable, Taxtype, TaxAmount, Taxstatus, None, Ratetype, Discount,Promotion_Name,region,statuscode, israteperstay)
                array.append(aws_insert.insert(id_update, inputid , Domainname, Websitecode, StartDate, RoomType, LOS, RateDate, Guests, OnsiteRate, NetRate, GrossRate, Curr, RateDescription, url_insert, url_insert, url_insert, RoomAmenity_Type, Mealtype, MaxOccupancy, isPromotionalRate, Closed, 30, StartDate , EndDate, intime, isAvailable, Taxtype, TaxAmount, Taxstatus, None, Ratetype, Discount,Promotion_Name,region,statuscode, israteperstay))
        else:
            Closed     = 'Y'
            statuscode = '2'
#             #print "else"
#             #print (id_update, inputid , Domainname, Websitecode, StartDate, RoomType, LOS, RateDate, Guests, OnsiteRate, NetRate, GrossRate, Curr, RateDescription, url_insert, url_insert, url_insert, RoomAmenity_Type, Mealtype, MaxOccupancy, isPromotionalRate, Closed, 30, StartDate , EndDate, intime, isAvailable, Taxtype, TaxAmount, Taxstatus, None, Ratetype, Discount,Promotion_Name,region,statuscode, israteperstay)
            array.append(aws_insert.insert(id_update, inputid , Domainname, Websitecode, StartDate, RoomType, LOS, RateDate, Guests, OnsiteRate, NetRate, GrossRate, Curr, RateDescription, url_insert, url_insert, url_insert, RoomAmenity_Type, Mealtype, MaxOccupancy, isPromotionalRate, Closed, 30, StartDate , EndDate, intime, isAvailable, Taxtype, TaxAmount, Taxstatus, None, Ratetype, Discount,Promotion_Name,region,statuscode, israteperstay))
        keyvalue = "ondemand/{}/{:%Y%m%d}/delivery/{}.json".format(Websitecode,datetime.datetime.now(),str(inputid)+'_'+str(RateDate)+'_'+id_update)
        key = bucket.new_key(keyvalue)
        key.set_contents_from_string(json.dumps(array))
        return json.dumps(array)
        gc.collect()
        
    except ValueError as e:
#         print "Error    :",e
        stacktrace = sys.exc_traceback.tb_lineno
        value_error = str(re.sub(r"'", '"', str(e)))+" Where Line number"+str(stacktrace)
#         print "stacktrace",value_error
        Guests = ''
        statuscode = '4'
        region = ''
        array.append(aws_insert.insert(id_update, inputid , Domainname, Websitecode, "", "", "", "", Guests, "", "", "", "", "", url_insert,url_insert,url_insert, "", "", "", "", "", "", StartDate, EndDate , "", "", "", "", "", "", "", "", "", region, statuscode, israteperstay))
        keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(Websitecode,datetime.datetime.now(),id_update)
        key = bucket.new_key(keyvalue)
        key.set_contents_from_string(value_error)
        return json.dumps(array)
# fetchrates(url,inputid,id_update,proxyip)
