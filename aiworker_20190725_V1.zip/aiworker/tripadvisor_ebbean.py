# -*- coding: utf-8 -*-
import re
import requests
import datetime
import json
import boto
import sys
import meta_insert
import random

  
# url='https://www.tripadvisor.com.my/Hotel_Review-g1497917-d15556442-Reviews-Traveller_Bunker_Hostel_1-Tanah_Rata_Cameron_Highlands_Pahang.html#chkin=2019-04-19&chkout=2019-04-21&adults=1#'
# inputid = 123
# id_update = 23
# proxyip = 'user-34068:214859b73da0e174@45.64.106.38:1212'

def fetchrates(url ,inputid, id_update, proxyip):
    try:
        array = []
        csv      = []
        Hotelcode=inputid
        websitecode = 284
        sess = requests.session()
        Provider = ''
        RoomName=''
        NetRate=''
        RoomFacilities=''
        OnsiteRate=''
        Pricepernight=''
        Curr=''
        Ratedate=''
        Los=''
        Reportdate=''
        Hotelcode=''
        url_insert=''
        HotelBlock=''
        Ratedate=''
        statuscode=''
        Rank = 0
        Currencies = {'www.tripadvisor.com.tr': 'TRY', 'www.tripadvisor.com.gr': 'EUR', 'www.tripadvisor.pt': 'EUR', 'fr.tripadvisor.ca': 'CAD', 'www.tripadvisor.com.ph': 'PHP', 'www.tripadvisor.ru': 'RUB', 'www.tripadvisor.nl': 'EUR', 'www.tripadvisor.com.pe': 'PEN', 'fr.tripadvisor.be': 'EUR', 'www.tripadvisor.de': 'EUR', 'www.tripadvisor.com.ve': 'VEF', 'www.tripadvisor.dk': 'DKK', 'www.tripadvisor.fr': 'EUR', 'www.tripadvisor.in': 'INR', 'www.tripadvisor.co.nz': 'NZD', 'www.tripadvisor.co.id': 'IDR', 'pl.tripadvisor.com': 'PLN', 'www.tripadvisor.fi': 'EUR', 'cn.tripadvisor.com': 'CNY', 'www.tripadvisor.com': 'USD', 'no.tripadvisor.com': 'NOK', 'www.tripadvisor.com.ar': 'ARS', 'www.tripadvisor.se': 'SEK', 'www.tripadvisor.it': 'EUR', 'www.tripadvisor.sk': 'EUR', 'www.tripadvisor.be': 'EUR', 'fr.tripadvisor.ch': 'CHF', 'www.tripadvisor.com.sg': 'SGD', 'www.tripadvisor.ie': 'EUR', 'www.tripadvisor.com.au': 'AUD', 'www.tripadvisor.com.mx': 'MXN', 'www.tripadvisor.com.my': 'MYR', 'www.tripadvisor.jp': 'JPY', 'www.tripadvisor.co.uk': 'GBP', 'www.tripadvisor.co.hu': 'HUF', 'www.tripadvisor.rs': 'RSD', 'www.tripadvisor.cz': 'CZK', 'it.tripadvisor.ch': 'CHF', 'www.tripadvisor.at': 'EUR', 'www.tripadvisor.ca': 'CAD', 'www.tripadvisor.com.br': 'BRL', 'www.tripadvisor.es': 'EUR', 'www.tripadvisor.ch': 'CHF', 'www.tripadvisor.cl': 'CLP', 'www.tripadvisor.co': 'COP', 'www.tripadvisor.cn': 'CNY'}
        url_db = url
        domainname = re.search(r'https://(.*?)/', url_db).group(1)
        orgin = re.search(r'(https://.*?)/', url_db).group(1)
        #print orgin, domainname
        today_con = datetime.date.today()
        Curr    = Currencies[domainname]
        Cooki   = 'SetCurrency='+str(Curr)
        url_insert=re.sub(r'#chkin=.*?#','',url_db)
        StartDate = datetime.date.today()
        conn    = boto.connect_s3(aws_access_key_id= 'AKIAIXEGZVXCWE2FV3SQ',aws_secret_access_key = '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') 
        bucket  = conn.get_bucket("rmapi")
        Reportdate=datetime.datetime.strptime(str(StartDate),'%Y-%m-%d').strftime('%Y-%m-%d')
        if (re.search('#chkin=.*?&chkout=.*?&adults=.*?#',url_db)):
            checkin=re.sub(r'-','_',str(re.search('#chkin=(.*?)&chkout=(.*?)&',url_db).group(1)))
            checkout=re.sub(r'-','_',str(re.search('#chkin=(.*?)&chkout=(.*?)&',url_db).group(2)))
            guests=re.search('#chkin=(.*?)&chkout=(.*?)&adults=(.*?)#',url_db).group(3)
            chkin_chkout=str(checkin)+'_'+str(checkout)    
            if checkin:
                check_in_date = datetime.datetime.strptime(datetime.datetime.strptime(str(checkin),'%Y_%m_%d').strftime('%Y, %m, %d'),'%Y, %m, %d')
            if checkout:
                check_out_date = datetime.datetime.strptime(datetime.datetime.strptime(str(checkout),'%Y_%m_%d').strftime('%Y, %m, %d'),'%Y, %m, %d')
            LOS = check_out_date - check_in_date
            Los = LOS.days
            Ratedate=re.search('#chkin=(.*?)&chkout=(.*?)&',url_db).group(1)
        proxies = {"https": "http://{}".format(proxyip)}
        inpl = ['user-37082:a7d2c0d3ace90f48@45.64.106.63:1212', 'user-37082:a7d2c0d3ace90f48@45.64.106.30:1212', 'user-37082:a7d2c0d3ace90f48@45.64.106.33:1212', 'user-37082:a7d2c0d3ace90f48@45.64.106.67:1212', 'user-37082:a7d2c0d3ace90f48@45.64.106.46:1212', 'user-37082:a7d2c0d3ace90f48@45.64.106.56:1212', 'user-37082:a7d2c0d3ace90f48@45.64.106.28:1212', 'user-37082:a7d2c0d3ace90f48@45.64.106.55:1212']
        head = {'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64; rv:64.0) Gecko/20100101 Firefox/64.0','Accept': 'text/html, */*','Accept-Language': 'en-US,en;q=0.5' }
        cookies = {'SetCurrency': '%s'%Curr} 
        loadurl = re.sub("#chkin.*", "", url)+"?reqNum=2&servletClass=com.TripResearch.servlet.accommodation.AccommodationDetail&disableLazyLoading=true&staydates="+str(chkin_chkout)+"&rooms=1&adults="+guests+"&child_rm_ages=&metaReferer=Hotel_Review"
#         print loadurl
        try:
            prox = random.choice(inpl)
            proxies      = {"https": "http://{}".format(prox)}
            print proxies
            domainload = sess.get('https://www.tripadvisor.com/', headers = head, proxies = proxies, timeout = 3)
            domain = domainload.url
#                 print domain
            loadurl = re.sub("https://.*?/", domain, loadurl)
#             print loadurl
            gt = sess.get(loadurl, headers = head, proxies = proxies,cookies = cookies, timeout = 5)
#             open('/home/media/Desktop/false.html','w').write(gt.text.encode('utf-8'))
#             print gt.status_code
            if  '<div class="chevronCta ui_button original loading"><span class="ui_loader small">'  in gt.text:
                gt = sess.get(loadurl, headers=head, cookies= cookies, proxies = proxies)
#                 open('/home/media/Desktop/false1.html','w').write(gt.text.encode('utf-8'))
                if  '<div class="chevronCta ui_button original loading"><span class="ui_loader small">'  in gt.text:
                    print "Load error"
                    keyvalue = "metasearch/{}/{:%Y%m%d}/Error/{}.txt".format(websitecode,datetime.datetime.now(),str(inputid)+'_'+str(id_update))
                    key = bucket.new_key(keyvalue)
                    key.set_contents_from_string("Site does not been return the rate for the ratedate")
                    statuscode=5
                    array.append(meta_insert.insert(Provider,Rank,"","",None,None,None,"",Ratedate,Los,Reportdate,Hotelcode,websitecode,url_db,"",Ratedate,statuscode))
                    return json.dumps(array)
        except Exception,e:
            print e
            try:
                domainload = sess.get('https://www.tripadvisor.com/', headers = head, proxies = proxies, verify = False, timeout = 3)
                domain = domainload.url
#                 print domain
                loadurl = re.sub("https://.*?/", domain, loadurl)
                
                gt = sess.get(loadurl, headers = head, proxies = proxies,cookies = cookies, timeout = 5)
                if  '<div class="chevronCta ui_button original loading"><span class="ui_loader small">'  in gt.text:
                    gt = sess.get(loadurl, headers=head, cookies= cookies, proxies = proxies)
                    if  '<div class="chevronCta ui_button original loading"><span class="ui_loader small">'  in gt.text:
                        keyvalue = "metasearch/{}/{:%Y%m%d}/Error/{}.txt".format(websitecode,datetime.datetime.now(),str(inputid)+'_'+str(id_update))
                        key = bucket.new_key(keyvalue)
                        key.set_contents_from_string("Site does not been return the rate for the ratedate")
                        statuscode=5
                        array.append(meta_insert.insert(Provider,Rank,"","",None,None,None,"",Ratedate,Los,Reportdate,Hotelcode,websitecode,url_db,"",Ratedate,statuscode))
                        return json.dumps(array) 
            except Exception,e:
                print e
                value_error=str(re.sub("'",'"',str(e)))
                stacktrace=sys.exc_traceback.tb_lineno
                keyvalue = "metasearch/{}/{:%Y%m%d}/Error/{}.txt".format(websitecode,datetime.datetime.now(),str(inputid)+'_'+str(id_update))
                key = bucket.new_key(keyvalue)
                key.set_contents_from_string(str(e))
                statuscode=5
                array.append(meta_insert.insert(Provider,Rank,"","",None,None,None,"",Ratedate,Los,Reportdate,Hotelcode,websitecode,url_db,"",Ratedate,statuscode))
                return json.dumps(array)
        proxies = {"https": "http://{}".format(proxyip)}
        keyvalue = "metasearch/{}/{:%Y%m%d}/source/{}.txt".format(websitecode,datetime.datetime.now(),str(inputid)+'_'+str(id_update))
        key = bucket.new_key(keyvalue)
        key.set_contents_from_string(gt.text.encode('utf-8'))
        if "No availability for your dates from these sites" in gt.text or '<div class="noAvailabilityMessage">Sold out for these dates from our partners' in gt.text:
            print "No Data"
            statuscode=2
            array.append(meta_insert.insert(Provider,Rank,"","",None,None,None,"",Ratedate,Los,Reportdate,Hotelcode,websitecode,url_db,"",Ratedate,statuscode))
            return json.dumps(array)
        if re.compile(r'<div class="mobile_textlink.*?</div></div>').findall(gt.text) or re.compile(r'<div class="hotels-hotel-offer.*?data-provider=.*?</div></div>').findall(gt.text):
            check_today = checkin
            check_today = datetime.datetime.strptime(str(check_today),'%Y_%m_%d').strftime('%Y-%m-%d')
            check_today = datetime.datetime.strptime(str(check_today), '%Y-%m-%d')
            today = datetime.datetime.strptime(str(today_con), '%Y-%m-%d')
#             print 'today:',today
#             print 'check_today:',check_today
            
            if check_today < today:
                print 'Date Lessthan'
                statuscode=2
                array.append(meta_insert.insert(Provider,Rank,"","",None,None,None,"",Ratedate,Los,Reportdate,Hotelcode,websitecode,url_db,"",Ratedate,statuscode))
                return json.dumps(array)
            
            html2 = gt.text.encode('utf-8')
            i = 1
            Rank_dict = {}
            deuplist = []
            for block in re.compile(r'<div class="mobile_textlink.*?</div></div>|<div class="hotels-hotel-offer.*?data-provider=.*?</div></div>').findall(html2):
                HotelBlock = re.sub(r"'","''",block)
                RoomName = 'Lowest Available Rate'
                OnsiteRate = 0
                statuscode = 0
                NetRate = 0
                RoomFacilities = ''
                Providername_re = re.search(r'provider">.*?</.*?>(.*?)</', block)
                if Providername_re:
                    Provider = Providername_re.group(1)
                    Provider = re.sub(r"'","''",re.sub(r"<.*?>","",str(Provider)))
                    if str(Provider).strip() == '':
                        Providername_re = re.search(r'provider">(.*?)</', block)
                        if Providername_re:
                            Provider = Providername_re.group(1)
                            Provider = re.sub(r"'","''",re.sub(r"<.*?>","",str(Provider)))
                else:
                    Providername_re = re.search(r'provider">(.*?)</', block)
                    if Providername_re:
                        Provider = Providername_re.group(1)
                    else:
                        Providername_re = re.search(r'data-provider="(.*?)"', block)
                        if Providername_re:
                            Provider = Providername_re.group(1)
                Provider = re.sub(r"'","''",re.sub(r"<.*?>","",str(Provider)))
                if str(Provider).strip() == '':
                    Providername_re = re.search(r'data-provider="(.*?)"', block)
                    if Providername_re:
                        Provider = Providername_re.group(1)
                Provider = re.sub(r"'","''",re.sub(r"<.*?>","",str(Provider)))
                if Provider not in Rank_dict:
                    Rank_dict[Provider] = i
                    i = i+1
                Rank = Rank_dict[Provider]
                if Provider not in deuplist:
                    deuplist.append(Provider)
                else:
                    continue
                Onsiterate_re = re.search(r'perNight="(\d.*?)"', block, re.IGNORECASE)
                if Onsiterate_re:
                    OnsiteRate = re.sub(r',|\*|\$|$','',Onsiterate_re.group(1))
                else:
                    Onsiterate_re = re.search(r'textlink_price"><span>.*?(\d.*?)<', block)
                    if Onsiterate_re:
                        OnsiteRate = re.sub(r',|\*|\$|$','',Onsiterate_re.group(1))
                Stickrate_re = re.search(r'autoResize"><span>\W+(.*?)<', block)
                if Stickrate_re:
                    NetRate = re.sub(r',|\*|\$|$','',Stickrate_re.group(1))
                else:
                    Stickrate_re = re.search(r'strikethrough_price .*?price autoResize.*?">\s*.*?(\d.*?)<', block)
                    if Stickrate_re:
                        NetRate = re.sub(r',|\*|\$|$','',Stickrate_re.group(1))
                OnsiteRate = str(OnsiteRate).decode('ascii','ignore')
                NetRate    = str(NetRate).decode('ascii','ignore')
                if int(OnsiteRate) ==  int(NetRate)    :
                    NetRate = 0
                curr_re = re.search(r'[\'|\"]entryCurrency[\'|\"]:[\'|\"](.*?)[\'|\"]', html2)
                if curr_re:
                    Curr = re.sub(r',|\*','',curr_re.group(1))
                RoomFacilities=re.sub(r',',' - ',RoomFacilities)
                RoomName=re.sub(r',',' - ',RoomName)
                HotelBlock=''
                NetRate=int(NetRate)
                OnsiteRate=int(OnsiteRate)
                if OnsiteRate == 0 or OnsiteRate == '0':
                    statuscode = 1
                Pricepernight = 0
#                 print (Provider,Rank,RoomName,RoomFacilities,OnsiteRate,NetRate,Pricepernight,Curr,Ratedate,Los,Reportdate,Hotelcode,websitecode,url_insert,HotelBlock,Ratedate,statuscode)
                array.append(meta_insert.insert(Provider,Rank,RoomName,RoomFacilities,OnsiteRate,NetRate,Pricepernight,Curr,Ratedate,Los,Reportdate,Hotelcode,websitecode,url_insert,HotelBlock,Ratedate,statuscode))
                valu=str(Provider),str(Rank),str(RoomName),str(RoomFacilities),str(OnsiteRate),str(NetRate),str(Pricepernight),str(Curr),str(Ratedate),str(Los),str(Reportdate),str(Hotelcode),str(websitecode),str(url_db),str(HotelBlock),str(Ratedate),str(statuscode)
                valu=Provider,Rank,RoomName,RoomFacilities,OnsiteRate,NetRate,Pricepernight,Curr,Ratedate,Los,Reportdate,Hotelcode,websitecode,url_insert,HotelBlock,Ratedate,statuscode
                vals=str(valu)
                csv.append(vals) 
        else:
            HotelBlock = ''
            statuscode=2
            valu=Provider,Rank,RoomName,RoomFacilities,OnsiteRate,NetRate,Pricepernight,Curr,Ratedate,Los,Reportdate,Hotelcode,websitecode,url_insert,HotelBlock,Ratedate,statuscode
            vals=str(valu)
            csv.append(vals)
            array.append(meta_insert.insert(Provider,Rank,RoomName,RoomFacilities,OnsiteRate,NetRate,Pricepernight,Curr,Ratedate,Los,Reportdate,Hotelcode,websitecode,url_insert,HotelBlock,Ratedate,statuscode))
        newline="\n".join(csv)
        arrayclean1=re.sub(r'\[|\(|\)|\]','',str(newline))
        arrayclean2=re.sub(r"'",'"',arrayclean1)
        arrayclean=re.sub(r'u"','"',arrayclean2)
        Ratedates=re.sub(r'-','',str(Ratedate))
        date_time=datetime.datetime.now().strftime('%Y%m%d_%I%M')
        keyvalue = "metasearch/metaresults/{}.txt".format(str(date_time)+'_'+str(websitecode)+'_'+str(Hotelcode)+'_'+str(Ratedates))
        key = bucket.new_key(keyvalue)
        key.set_contents_from_string(arrayclean)
        return json.dumps(array)
    except Exception as e:
        print "tripadvisor"
        print e
        insert_value_error=str(str(re.sub(r"'",'"',str(e))))+'Where line number '+str(sys.exc_traceback.tb_lineno)+str(proxyip)
        print insert_value_error
        statuscode=4
        keyvalue = "metasearch/{}/{:%Y%m%d}/Error/{}.txt".format(websitecode,datetime.datetime.now(),str(inputid)+'_'+str(id_update))
        key = bucket.new_key(keyvalue)
        key.set_contents_from_string(insert_value_error)
        array.append(meta_insert.insert(Provider,Rank,"","",OnsiteRate,NetRate,Pricepernight,"",Ratedate,Los,Reportdate,Hotelcode,websitecode,url_insert,"",Ratedate,statuscode))
        return json.dumps(array)
# fetchrates(url ,inputid, id_update, proxyip)
