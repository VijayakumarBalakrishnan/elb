# -*- coding: utf-8 -*-
import re
import requests
import datetime
import json
import gc
import boto
import sys

import aws_insert
ses = requests.Session()
def fetchrates(url ,inputid, id_update, proxyip):
    array      = []
    israteperstay=''
    proxies    = {"http": "http://{}".format(proxyip)}
    intime     = re.sub(r'\s','T',str(datetime.datetime.now()))
    Domainname ='SECURE.REZOVATION.COM'
    Websitecode='319'
    region     =''
    statuscode =''
    Mealtype   =''
    conn   = boto.connect_s3(aws_access_key_id= 'AKIAIXEGZVXCWE2FV3SQ',aws_secret_access_key = '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') 
    bucket = conn.get_bucket("rmapi")
    StartDate= datetime.date.today()
    EndDate  = datetime.date.today() + datetime.timedelta(days=29)
    try:
        CheckIn_Check_OT_re = re.search(r'#Checkin=(.*?)&Checkout=(.*?)&guests=(\d+)&',url)
        if CheckIn_Check_OT_re:
            Checkin = CheckIn_Check_OT_re.group(1)
            CheckOT = CheckIn_Check_OT_re.group(2)
            Guests  = CheckIn_Check_OT_re.group(3)
        else:
            Checkin = ''
            CheckOT = ''
            Guests  = ''
        RateDate = Checkin
        delta    = datetime.datetime.strptime(str(CheckOT), "%Y-%m-%d") - datetime.datetime.strptime(Checkin, "%Y-%m-%d")
        LOS      = delta.days
        RoomType = ''
        Ratetype = ''
        RateDescription = ''
        Meal     = ''
        Taxtype  = ''
        Curr     = 'USD'
        MaxOccupancy  = None
        isPromotionalRate  = 'N'
        Closed   = 'Y'
        NetRate  = 0
        Taxstatus= -1
        TaxAmount= 0
        Discount = 0
        GrossRate= 0
        OnsiteRate = 0
        Promotion_Name= ''
        isAvailable = ''
        RoomAmenity_Type = ''
        Checkin_1 = datetime.datetime.strptime(str(Checkin),'%Y-%m-%d').strftime('%m/%d/%y')
        CheckOT_1 = datetime.datetime.strptime(str(CheckOT),'%Y-%m-%d').strftime('%m/%d/%y')
        url       = re.sub(r'#.*','',str(url))
        url_insert=url
        proxyip   = re.sub(r':.*','',str(proxyip))
        try:
            try:
                r = requests.get('http://freegeoip.net/json/' + proxyip, timeout=30)
            except Exception, e:
                r = requests.get('http://freegeoip.net/json/' + proxyip, timeout=30)
            js = r.json()
            region = js['country_name']
        except Exception, e:
            region = ''
        try:
            head2    = {"Host":"secure.rezovation.com","User-Agent":"Mozilla/5.0 (X11; Linux i686; rv:45.0) Gecko/20100101 Firefox/45.0","Accept":"text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8","Accept-Language":"en-US,en;q=0.5","Accept-Encoding":"gzip, deflate, br","Referer":url,"Connection":"keep-alive"}
            respons2 = ses.get(url,headers=head2,proxies=proxies,timeout=50)
            url_3_re = re.search(r'"(/Reservations/CheckAvailability.*?)"', respons2.text.encode('utf-8'))
            if url_3_re:
                url3 = "https://secure.rezovation.com"+str(url_3_re.group(1))
            else:
                url3 = ""
            respons3 = ses.get(url3,headers=head2,proxies=proxies,timeout=50)
            VIEWSTATE_re = re.search(r'__VIEWSTATE"\s*value="(.*?)"', respons3.text.encode('utf-8'))
            if VIEWSTATE_re:
                VIEWSTATE = VIEWSTATE_re.group(1)
            else:
                VIEWSTATE = ""
            PaidHidden_re = re.search(r'txtPaidHidden"\s*value="(.*?)"', respons3.text.encode('utf-8'))
            if PaidHidden_re:
                PaidHidden = PaidHidden_re.group(1)
            else:
                PaidHidden = ""
            VIEWSTATEGENERATOR_re = re.search(r'VIEWSTATEGENERATOR"\s*value="(.*?)"', respons3.text.encode('utf-8'))
            if VIEWSTATEGENERATOR_re:
                VIEWSTATEGENERATOR = VIEWSTATEGENERATOR_re.group(1)
            else:
                VIEWSTATEGENERATOR = ""
            payload   = {'__EVENTTARGET':'','__EVENTARGUMENT':'','__VIEWSTATE':str(VIEWSTATE),'ctl00_Main_availability_ctl00__checkInDate_date':str(Checkin_1),'ctl00_Main_availability_ctl00__checkOutDate_date':str(CheckOT_1),'ctl00$Main$availability$ctl00$_rooms':'1','ctl00$Main$availability$ctl00$_guests':str(Guests),'ctl00$Main$availability$ctl00$_submit.x':'61','ctl00$Main$availability$ctl00$_submit.y':'3','ctl00$txtPaidHidden':str(PaidHidden),'__VIEWSTATEGENERATOR':str(VIEWSTATEGENERATOR)}
            head4     = {'Host':'secure.rezovation.com','User-Agent':'Mozilla/5.0 (X11; Linux i686; rv:45.0) Gecko/20100101 Firefox/45.0','Accept':'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8','Accept-Language':'en-US,en;q=0.5','Accept-Encoding':'gzip, deflate, br','Referer':str(url3),'Connection':'keep-alive'}
            hml       = ses.post(url3,data=payload,headers=head4,proxies=proxies,timeout=50)
        except Exception, e:
            value_error = str(re.sub("'", '', str(e)))
            stacktrace = sys.exc_traceback.tb_lineno
            try:
                head2    = {"Host":"secure.rezovation.com","User-Agent":"Mozilla/5.0 (X11; Linux i686; rv:45.0) Gecko/20100101 Firefox/45.0","Accept":"text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8","Accept-Language":"en-US,en;q=0.5","Accept-Encoding":"gzip, deflate, br","Referer":url,"Connection":"keep-alive"}
                respons2 = ses.get(url,headers=head2,proxies=proxies,timeout=50)
                url_3_re = re.search(r'"(/Reservations/CheckAvailability.*?)"', respons2.text.encode('utf-8'))
                if url_3_re:
                    url3 = "https://secure.rezovation.com"+str(url_3_re.group(1))
                else:
                    url3 = ""
                respons3 = ses.get(url3,headers=head2,proxies=proxies,timeout=50)
                VIEWSTATE_re = re.search(r'__VIEWSTATE"\s*value="(.*?)"', respons3.text.encode('utf-8'))
                if VIEWSTATE_re:
                    VIEWSTATE = VIEWSTATE_re.group(1)
                else:
                    VIEWSTATE = ""
                PaidHidden_re = re.search(r'txtPaidHidden"\s*value="(.*?)"', respons3.text.encode('utf-8'))
                if PaidHidden_re:
                    PaidHidden = PaidHidden_re.group(1)
                else:
                    PaidHidden = ""
                VIEWSTATEGENERATOR_re = re.search(r'VIEWSTATEGENERATOR"\s*value="(.*?)"', respons3.text.encode('utf-8'))
                if VIEWSTATEGENERATOR_re:
                    VIEWSTATEGENERATOR = VIEWSTATEGENERATOR_re.group(1)
                else:
                    VIEWSTATEGENERATOR = ""
                payload   = {'__EVENTTARGET':'','__EVENTARGUMENT':'','__VIEWSTATE':str(VIEWSTATE),'ctl00_Main_availability_ctl00__checkInDate_date':str(Checkin_1),'ctl00_Main_availability_ctl00__checkOutDate_date':str(CheckOT_1),'ctl00$Main$availability$ctl00$_rooms':'1','ctl00$Main$availability$ctl00$_guests':str(Guests),'ctl00$Main$availability$ctl00$_submit.x':'61','ctl00$Main$availability$ctl00$_submit.y':'3','ctl00$txtPaidHidden':str(PaidHidden),'__VIEWSTATEGENERATOR':str(VIEWSTATEGENERATOR)}
                head4     = {'Host':'secure.rezovation.com','User-Agent':'Mozilla/5.0 (X11; Linux i686; rv:45.0) Gecko/20100101 Firefox/45.0','Accept':'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8','Accept-Language':'en-US,en;q=0.5','Accept-Encoding':'gzip, deflate, br','Referer':str(url3),'Connection':'keep-alive'}
                hml       = ses.post(url3,data=payload,headers=head4,proxies=proxies,timeout=50)
            except Exception, e:
                value_error = str(re.sub("'", '', str(e)))
                stacktrace = sys.exc_traceback.tb_lineno
                keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(Websitecode, datetime.datetime.now(), id_update)
                key = bucket.new_key(keyvalue)
                key.set_contents_from_string(str(e) + 'Where Line number' + str(stacktrace) + str(proxies))
                statuscode = 5
                Guests = ''
                array.append(aws_insert.insert(id_update, inputid , Domainname, Websitecode, "", "", "", "", Guests, "", "", "", "", "", url, url, url, "", "", "", "", "", "", StartDate, EndDate , "", "", "", "", "", "", "", "", "", region, statuscode,israteperstay))
                return json.dumps(array)
        if hml.status_code <> 200:
            head2    = {"Host":"secure.rezovation.com","User-Agent":"Mozilla/5.0 (X11; Linux i686; rv:45.0) Gecko/20100101 Firefox/45.0","Accept":"text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8","Accept-Language":"en-US,en;q=0.5","Accept-Encoding":"gzip, deflate, br","Referer":url,"Connection":"keep-alive"}
            respons2 = ses.get(url,headers=head2,proxies=proxies,timeout=50)
            url_3_re = re.search(r'"(/Reservations/CheckAvailability.*?)"', respons2.text.encode('utf-8'))
            if url_3_re:
                url3 = "https://secure.rezovation.com"+str(url_3_re.group(1))
            else:
                url3 = ""
            respons3 = ses.get(url3,headers=head2,proxies=proxies,timeout=50)
            VIEWSTATE_re = re.search(r'__VIEWSTATE"\s*value="(.*?)"', respons3.text.encode('utf-8'))
            if VIEWSTATE_re:
                VIEWSTATE = VIEWSTATE_re.group(1)
            else:
                VIEWSTATE = ""
            PaidHidden_re = re.search(r'txtPaidHidden"\s*value="(.*?)"', respons3.text.encode('utf-8'))
            if PaidHidden_re:
                PaidHidden = PaidHidden_re.group(1)
            else:
                PaidHidden = ""
            VIEWSTATEGENERATOR_re = re.search(r'VIEWSTATEGENERATOR"\s*value="(.*?)"', respons3.text.encode('utf-8'))
            if VIEWSTATEGENERATOR_re:
                VIEWSTATEGENERATOR = VIEWSTATEGENERATOR_re.group(1)
            else:
                VIEWSTATEGENERATOR = ""
            payload   = {'__EVENTTARGET':'','__EVENTARGUMENT':'','__VIEWSTATE':str(VIEWSTATE),'ctl00_Main_availability_ctl00__checkInDate_date':str(Checkin_1),'ctl00_Main_availability_ctl00__checkOutDate_date':str(CheckOT_1),'ctl00$Main$availability$ctl00$_rooms':'1','ctl00$Main$availability$ctl00$_guests':str(Guests),'ctl00$Main$availability$ctl00$_submit.x':'61','ctl00$Main$availability$ctl00$_submit.y':'3','ctl00$txtPaidHidden':str(PaidHidden),'__VIEWSTATEGENERATOR':str(VIEWSTATEGENERATOR)}
            head4     = {'Host':'secure.rezovation.com','User-Agent':'Mozilla/5.0 (X11; Linux i686; rv:45.0) Gecko/20100101 Firefox/45.0','Accept':'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8','Accept-Language':'en-US,en;q=0.5','Accept-Encoding':'gzip, deflate, br','Referer':str(url3),'Connection':'keep-alive'}
            hml       = ses.post(url3,data=payload,headers=head4,proxies=proxies,timeout=50)
        if (hml.status_code == 403 or hml.status_code == 407) or hml.status_code <> 200:
            try:
                if hml.status_code <> 200:
                    head2    = {"Host":"secure.rezovation.com","User-Agent":"Mozilla/5.0 (X11; Linux i686; rv:45.0) Gecko/20100101 Firefox/45.0","Accept":"text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8","Accept-Language":"en-US,en;q=0.5","Accept-Encoding":"gzip, deflate, br","Referer":url,"Connection":"keep-alive"}
                    respons2 = ses.get(url,headers=head2,timeout=50)
                    url_3_re = re.search(r'"(/Reservations/CheckAvailability.*?)"', respons2.text.encode('utf-8'))
                    if url_3_re:
                        url3 = "https://secure.rezovation.com"+str(url_3_re.group(1))
                    else:
                        url3 = ""
                    respons3 = ses.get(url3,headers=head2,timeout=50)
                    VIEWSTATE_re = re.search(r'__VIEWSTATE"\s*value="(.*?)"', respons3.text.encode('utf-8'))
                    if VIEWSTATE_re:
                        VIEWSTATE = VIEWSTATE_re.group(1)
                    else:
                        VIEWSTATE = ""
                    PaidHidden_re = re.search(r'txtPaidHidden"\s*value="(.*?)"', respons3.text.encode('utf-8'))
                    if PaidHidden_re:
                        PaidHidden = PaidHidden_re.group(1)
                    else:
                        PaidHidden = ""
                    VIEWSTATEGENERATOR_re = re.search(r'VIEWSTATEGENERATOR"\s*value="(.*?)"', respons3.text.encode('utf-8'))
                    if VIEWSTATEGENERATOR_re:
                        VIEWSTATEGENERATOR = VIEWSTATEGENERATOR_re.group(1)
                    else:
                        VIEWSTATEGENERATOR = ""
                    payload   = {'__EVENTTARGET':'','__EVENTARGUMENT':'','__VIEWSTATE':str(VIEWSTATE),'ctl00_Main_availability_ctl00__checkInDate_date':str(Checkin_1),'ctl00_Main_availability_ctl00__checkOutDate_date':str(CheckOT_1),'ctl00$Main$availability$ctl00$_rooms':'1','ctl00$Main$availability$ctl00$_guests':str(Guests),'ctl00$Main$availability$ctl00$_submit.x':'61','ctl00$Main$availability$ctl00$_submit.y':'3','ctl00$txtPaidHidden':str(PaidHidden),'__VIEWSTATEGENERATOR':str(VIEWSTATEGENERATOR)}
                    head4     = {'Host':'secure.rezovation.com','User-Agent':'Mozilla/5.0 (X11; Linux i686; rv:45.0) Gecko/20100101 Firefox/45.0','Accept':'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8','Accept-Language':'en-US,en;q=0.5','Accept-Encoding':'gzip, deflate, br','Referer':str(url3),'Connection':'keep-alive'}
                    hml       = ses.post(url3,data=payload,headers=head4,timeout=50)                    
            except Exception, e:
                print e
                value_error = str(re.sub("'", '', str(e)))
                stacktrace = sys.exc_traceback.tb_lineno
                keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(Websitecode, datetime.datetime.now(), id_update)
                key = bucket.new_key(keyvalue)
                key.set_contents_from_string(str(e) + 'Where Line number' + str(stacktrace) + str(proxies))
                statuscode = 5
                Guests = ''
                array.append(aws_insert.insert(id_update, inputid , Domainname, Websitecode, "", "", "", "", Guests, "", "", "", "", "", url, url, url, "", "", "", "", "", "", StartDate, EndDate , "", "", "", "", "", "", "", "", "", region, statuscode,israteperstay))
                return json.dumps(array)
        Data_Htm  = re.sub('amp;','',hml.text.encode('utf-8'))#).decode('utf-8'))
        json_data = Data_Htm
        Rtdate=re.sub(r'-|\-','',str(RateDate))
        keyvalue = "ondemand/{}/{:%Y%m%d}/source{}.html".format(Websitecode,datetime.datetime.now(),str(inputid)+'_'+str(Checkin)+'_'+id_update)
        key = bucket.new_key(keyvalue)
        key.set_contents_from_string(hml.text.encode('utf-8'))
        if re.compile(r'<span>\s*<table border="0" ce.*?</table>\s*<div style', re.DOTALL).findall(json_data):
            for content in re.compile(r'<span>\s*<table border="0" ce.*?</table>\s*<div style', re.DOTALL).findall(json_data):
                for block in re.compile(r'class="tdRCTitleLeft".*?ctl\d+_Main_ctl\d+_ctl\d+__roomButton', re.DOTALL).findall(content):
                    RoomType_re = re.search(r'style="background-image:url.*?"><b>(.*?)</', block)
                    if RoomType_re:
                        RoomType = RoomType_re.group(1)
                    else:
                        RoomType = ""
                    OnsiteRate_re = re.search(r'<span style="font-weight:normal">\$(.*?) ', block)
                    if OnsiteRate_re:
                        OnsiteRate = OnsiteRate_re.group(1)
                    else:
                        OnsiteRate = ""   
                    Ratetype_re = re.search(r'<span style="font-weight:normal">(.*?)<', block)
                    if Ratetype_re:
                        Ratetype = Ratetype_re.group(1)
                    else:
                        Ratetype = ""
                    RateDescription_re = re.search(r'tdRCAviableText" valign="top">\s*(.*?)\s*<', block)
                    if RateDescription_re:
                        RateDescription = RateDescription_re.group(1)
                    else:
                        RateDescription = "" 
                    MaxOccupancy_re = re.search(r"capacity (\d+);", block, re.IGNORECASE)
                    if MaxOccupancy_re:
                        MaxOccupancy = MaxOccupancy_re.group(1)
                    else:
                        MaxOccupancy = None
                    Mealtypes = str(RateDescription)+' '+str(RoomType)+' '+str(Ratetype)
                    if Mealtypes !=None:
                        Mealtype_str = str(Mealtypes)
                        if 'breakfast' in Mealtype_str.lower() and 'dinner' in Mealtype_str.lower()  and 'lunch' in Mealtype_str.lower():
                            Meal = 'Breakfast, Lunch and Dinner'
                        elif 'breakfast' in Mealtype_str.lower() and 'dinner' in Mealtype_str.lower():
                            Meal = 'Breakfast and dinner'
                        elif 'breakfast included' in Mealtype_str.lower():
                            Meal = 'Breakfast included'
                        elif 'BREAKFAST' in Mealtype_str:
                            Meal = 'Breakfast'
                        elif 'breakfast' in Mealtype_str.lower() and 'lunch' in Mealtype_str.lower():
                            Meal = 'Breakfast and Lunch'
                        elif 'Lunch' in Mealtype_str and 'Dinner' in Mealtype_str :
                            Meal = "Lunch and Dinner"
                        elif 'breakfast' in Mealtype_str.lower() and 'lunch' in Mealtype_str.lower() and 'dinner' in Mealtype_str.lower():
                            Meal = 'Breakfast, Lunch and dinner'
                        elif 'Break fast' in Mealtype_str:
                            Meal = 'BreakFast' 
                        elif 'breakfast' in Mealtype_str.lower():
                            Meal = 'BreakFast' 
                        elif 'halfboard' in Mealtype_str.lower():
                            Meal = 'Halfboard'
                        elif 'half board' in Mealtype_str.lower():
                            Meal = 'Half board' 
                        elif 'full board' in Mealtype_str.lower():
                            Meal = 'Full Board'
                        elif 'fullboard' in Mealtype_str.lower():
                            Meal = 'FullBoard'
                        elif 'All-Inclusive' in Mealtype_str:
                            Meal = 'All-Inclusive'
                        elif 'All Inclusive' in Mealtype_str:
                            Meal = 'All Inclusive'
                        elif 'All Meals' in Mealtype_str:
                            Meal = 'All Meals'
                        elif 'All Meal' in Mealtype_str:
                            Meal = 'All Meal'
                        else:
                            Meal = ''
                    else:
                        Meal = ''                                               
                    Taxstatus = 2
                    GrossRate = OnsiteRate
                    Mealtype  = Meal
                    RateDate  = Checkin
                    LOS = int(LOS)
                    if int(LOS) >1:
                        israteperstay = 'N'
                    else:
                        israteperstay ='Y'
                    if OnsiteRate==0:
                        statuscode = 1
                        Closed='Y'
                    else:
                        statuscode = ''
                        Closed='N'
                    #print "RoomType :-",RoomType
                    #print "Ratetype :-",Ratetype
                    #print "RateDescription :-",RateDescription
                    #print "Amount   :-",OnsiteRate
                    #print "Prmotion :-",Promotion_Name
                    #print "MaxOccupancy:",MaxOccupancy
                    #print "isPromotionalRate  :-",isPromotionalRate
                    #print "NetRate  :-",NetRate
                    #print "Currency :-",Curr
                    #print "Discount :-",Discount
                    #print "MealType :-",Meal
                    #print "Closed   :-",Closed
                    #print "Taxstatus:-",Taxstatus
                    #print "status_cd:-",statuscode                                
                    #print "israteperstay :",israteperstay
                    #print "_"*30
                    array.append(aws_insert.insert(id_update, inputid , Domainname, Websitecode, StartDate, RoomType, LOS, RateDate, Guests, OnsiteRate, NetRate, GrossRate, Curr, RateDescription, url_insert, url_insert, url_insert, RoomAmenity_Type, Mealtype, MaxOccupancy, isPromotionalRate, Closed, 30, StartDate , EndDate, intime, isAvailable, Taxtype, TaxAmount, Taxstatus, None, Ratetype, Discount,Promotion_Name,region,statuscode,israteperstay))
        else:
            Closed     = 'Y'
            statuscode ='2'
            array.append(aws_insert.insert(id_update, inputid , Domainname, Websitecode, StartDate, RoomType, LOS, RateDate, Guests, OnsiteRate, NetRate, GrossRate, Curr, RateDescription, url_insert, url_insert, url_insert, RoomAmenity_Type, Mealtype, MaxOccupancy, isPromotionalRate, Closed, 30, StartDate , EndDate, intime, isAvailable, Taxtype, TaxAmount, Taxstatus, None, Ratetype, Discount,Promotion_Name,region,statuscode,israteperstay))
        Rtdate = re.sub(r'-|\-', '', str(RateDate))
        keyvalue = "ondemand/{}/{:%Y%m%d}/delivery/{}.json".format(Websitecode,datetime.datetime.now(),str(inputid)+'_'+str(Rtdate)+'_'+id_update)
        key = bucket.new_key(keyvalue)
        key.set_contents_from_string(json.dumps(array))
        return json.dumps(array)
        gc.collect()
    except Exception as e:
        print e
        value_error = str(re.sub(r"'", '"', str(e)))
        stacktrace = sys.exc_traceback.tb_lineno
        Guests = ''
        region = ''
        insert_value_error = str(value_error) + 'Where line number ' + str(stacktrace) + str(proxyip)
        statuscode = '4'
        keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(Websitecode, datetime.datetime.now(), id_update)
        key = bucket.new_key(keyvalue)
        key.set_contents_from_string(insert_value_error)
        array.append(aws_insert.insert(id_update, inputid , Domainname, Websitecode, "", "", "", "", Guests, "", "", "", "", "", url, url, url, "", "", "", "", "", "", StartDate, EndDate , "", "", "", "", "", "", "", "", "", region, statuscode,israteperstay))
        return json.dumps(array) 
               
'''url  = "https://secure.rezovation.com/Reservations/CheckAvailability.aspx?_0CYZFGPAY5DQP9#Checkin=2017-11-06&Checkout=2017-11-08&guests=1&"                
inputid   = 'Test'            
id_update = ''
proxyip   = ''
fetchrates(url ,inputid, id_update, proxyip) '''    
