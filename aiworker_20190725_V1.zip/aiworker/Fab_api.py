# -*- coding: utf-8 -*-
import re
import requests
import datetime
import json
import boto,gc,sys
from django.http import HttpResponse
import aws_insert
from unidecode import unidecode
import datetime

one_day = datetime.timedelta(days=1)

'''url='https://www.fabhotels.com/hotels-in-gurgaon/fabhotel-grd-dlf-square.html?checkIn=2018-06-18&checkOut=2018-06-20&guests=1'

inputid='3656'
id_update='3656'

proxyip='media:365med!a@23.229.30.100:80'''


def fetchrates(url,inputid,id_update,proxyip):
    ##print "Hai"
    array      = []
    sr         = requests.session()
    proxies    = {"https": "http://{}".format(proxyip)}
    intime     = re.sub(r'\s','T',str(datetime.datetime.now()))
    Domainname = 'Fabhotels.com'
    Websitecode= '3656'
    region     = ''
    statuscode = ''
    Mealtype   = ''
    israteperstay = ''
    url_insert = ''
    Checkin  = ''
    Checkout = ''
    
    try:
        conn   = boto.connect_s3(aws_access_key_id= 'AKIAIXEGZVXCWE2FV3SQ',aws_secret_access_key = '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') 
        bucket = conn.get_bucket("rmapi")
        StartDate = datetime.date.today()
        EndDate   = datetime.date.today() + datetime.timedelta(days=29)
        #ARRdd=07&ARRmm=12&ARRyyyy=2017&
        CheckIn_re = re.search(r'\?checkIn=(.*?)&',url)
        if CheckIn_re:
            Checkin  = CheckIn_re.group(1)
            ##print Checkin
        Check_OT_re = re.search(r'&checkOut=(.*?)&',url)
        if Check_OT_re:
            Checkout = Check_OT_re.group(1)
            ##print CheckIn_YYYY
            
        Hotelname_re = re.search(r'fabhotels.com/(.*?)html',url)
        if Hotelname_re:
            Hotelname = Hotelname_re.group(1)
            
        Guests_re = re.search(r'&guests=(.*\d+)',url)
        if Guests_re:
            Guests = Guests_re.group(1)
            #print Guests
            
        else:
            Checkin  = ''
            Checkout = ''
            #Checkin_URL = ''
            #CheckOT_URL = ''
        #print Checkin,Checkout
        ##print url
        #print Hotelname
        #Checkin_URL = datetime.datetime.strptime(str(Checkin),'%Y-%m-%d').strftime('%d/%m/%Y')
        RateDate = Checkin
        delta    = datetime.datetime.strptime(Checkout, "%Y-%m-%d") - datetime.datetime.strptime(Checkin, "%Y-%m-%d")
        LOS      = delta.days
        RoomType = ''
        #Guests   = re.search(r'&ADULT1=(\d+)&', url).group(1)
        #print LOS
        Ratetype = ''
        RateDescription = ''
        Taxtype  = ''
        Curr     = ''
        MaxOccupancy = None
        isPromotionalRate  = 'N'
        Closed   = 'Y'
        NetRate  = 0
        Taxstatus= -1
        TaxAmount= 0
        Discount = 0
        GrossRate= 0
        OnsiteRate = 0
        Curr     = ''
        Promotion_Name= ''
        isAvailable = ''
        RoomAmenity_Type = ''
        #Guests=''
        url_insert = url
        ##print url_insert
        main_url='https://www.fabhotels.com/'+str(Hotelname)+'html?checkIn='+str(Checkin)+'&checkOut='+str(Checkout)+'&guests='+str(Guests)
        #urldec = urllib.unquote(url).decode()
        head = {'User-Agent':'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:12.0) Gecko/20100101 Firefox/48.0'}
        #htm= requests.get(main_url,headers = head)
        ip = re.sub(r"\{'.*?@|'\}|:\d+", "", str(proxies))
        try:
            try:
                r = requests.get('http://freegeoip.net/json/' + ip, timeout=30)
            except Exception, e:
                r = requests.get('http://freegeoip.net/json/' + ip, timeout=30)
            js = r.json()
            region = js['country_name']
        except Exception, e:
            region = ''
        try:
            #print ""
            htm = requests.get(main_url,headers=head,proxies = proxies,timeout=100)
        except Exception, e:
            value_error = str(re.sub("'", '', str(e)))
            stacktrace = sys.exc_traceback.tb_lineno
            try:
                htm = requests.get(main_url,headers=head,proxies = proxies,timeout=120)
            except Exception, e:
                try:
                    htm = requests.get(main_url,headers=head,proxies = proxies,timeout=150)
                except Exception, e:
                    value_error = str(re.sub("'", '', str(e)))
                    stacktrace = sys.exc_traceback.tb_lineno
                    keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(Websitecode, datetime.datetime.now(), id_update)
                    key = bucket.new_key(keyvalue)
                    key.set_contents_from_string(str(e) + 'Where Line number' + str(stacktrace) + str(proxies))
                    statuscode = 5
                    Guests = ''
                    array.append(aws_insert.insert(id_update, inputid , Domainname, Websitecode, "", "", "", "", Guests, "", "", "", "", "", url_insert,url_insert,url_insert, "", "", "", "", "", "", StartDate, EndDate , "", "", "", "", "", "", "", "", "", region, statuscode, israteperstay))
                    return json.dumps(array)
            
        if htm.status_code <> 200:
            htm = requests.get(main_url,headers=head,proxies = proxies)
        if (htm.status_code == 403 or htm.status_code == 407) or htm.status_code <> 200:
            try:
                if htm.status_code <> 200:
                    htm = requests.get(main_url,headers=head)
                    
            except Exception, e:
                Closed    = 'Y'
                value_error = str(re.sub("'", '', str(e)))
                stacktrace = sys.exc_traceback.tb_lineno
                keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(Websitecode, datetime.datetime.now(), id_update)
                key = bucket.new_key(keyvalue)
                key.set_contents_from_string(str(e) + 'Where Line number' + str(stacktrace) + str(proxies))
                statuscode = 5
                Guests = ''
                array.append(aws_insert.insert(id_update, inputid , Domainname, Websitecode, "", "", "", "", Guests, "", "", "", "", "", url_insert,url_insert,url_insert, "", "", "", "", "", "", StartDate, EndDate , "", "", "", "", "", "", "", "", "", region, statuscode, israteperstay))
                return json.dumps(array)
        html = unidecode(htm.text).encode('ascii')
        #fo = open('riverside.html','w').write(str(html))
        keyvalue = "ondemand/{}/{:%Y%m%d}/source/{}.json".format(Websitecode,datetime.datetime.now(),str(inputid)+'_'+str(Checkin)+'_'+id_update)
        key = bucket.new_key(keyvalue)
        key.set_contents_from_string(json.dumps(html))
        ##print htm.status_code
        json_re=re.search('class="room_type_price_json".*?({.*?}})\'',html,re.DOTALL)
        if json_re:
            jsondata=json_re.group(1)
            json_data=json.loads(jsondata)
        else:
            json_data = ''
        ##print json_data
        
        if json_data:
            RoomType      = ''
            Ratetype      = ''
            OnsiteRate    = 0
            RoomAmenity_Type = ''
            RateDescription  = ''
            Mealtype         = ''
            Curr             = 'INR'
            Closed           = 'N'
            GrossRate        =  0
            NetRate          = 0
            isAvailable      = ''
            MaxOccupancy     = None
            taxtype=''
            Taxstatus=-1
            
            for block in json_data['roomTypeMeta'].iteritems():
                Available=''
                if json_data['roomTypeMeta'][block[0]]['roomTypeName']:
                    RoomType = json_data['roomTypeMeta'][block[0]]['roomTypeName']
                    #print RoomType
                    
                if json_data['roomTypeMeta'][block[0]]['sumPriceDetails']['1']:       
                    OnsiteRate=json_data['roomTypeMeta'][block[0]]['sumPriceDetails']['1']
                    #print OnsiteRate
                    
                if json_data['roomTypeMeta'][block[0]]['sumRackPriceDetails']['1']:       
                    NetRate=json_data['roomTypeMeta'][block[0]]['sumRackPriceDetails']['1']
                    #print NetRate
                    
                if json_data['roomTypeMeta'][block[0]]['roomCountText']:
                    isAvailable=json_data['roomTypeMeta'][block[0]]['roomCountText']
                    #print isAvailable
                    
                if json_data['roomTypeMeta'][block[0]]['maxOccupancy']:
                    MaxOccupancy=json_data['roomTypeMeta'][block[0]]['maxOccupancy']
                    #print MaxOccupancy
                    
                if NetRate==0:
                    isPromotionalRate='N'
                else:
                    isPromotionalRate='Y'
                
                Mealtype='Breakfast Included'
                
                if isAvailable=='Sold Out':
                    OnsiteRate=0
                    Mealtype=''
                    #print OnsiteRate
                    
                
                if OnsiteRate==0:
                    statuscode = 1
                    Closed='Y'
                else:
                    statuscode = ''
                    Closed='N'
                
                israteperstay ='Y'
                #print (id_update, inputid , Domainname, Websitecode, StartDate, RoomType, LOS, RateDate, Guests, OnsiteRate, NetRate, GrossRate, Curr, RateDescription, url_insert, url_insert, url_insert, RoomAmenity_Type, Mealtype, MaxOccupancy, isPromotionalRate, Closed, 30, StartDate , EndDate, intime, isAvailable, Taxtype, TaxAmount, Taxstatus, None, Ratetype, Discount,Promotion_Name,region,statuscode, israteperstay)
                array.append(aws_insert.insert(id_update, inputid , Domainname, Websitecode, StartDate, RoomType, LOS, RateDate, Guests, OnsiteRate, NetRate, GrossRate, Curr, RateDescription, url_insert, url_insert, url_insert, RoomAmenity_Type, Mealtype, MaxOccupancy, isPromotionalRate, Closed, 30, StartDate , EndDate, intime, isAvailable, Taxtype, TaxAmount, Taxstatus, None, Ratetype, Discount,Promotion_Name,region,statuscode, israteperstay))
        else:
            Closed     = 'Y'
            statuscode = '2'
            #print "else"
            #print (id_update, inputid , Domainname, Websitecode, StartDate, RoomType, LOS, RateDate, Guests, OnsiteRate, NetRate, GrossRate, Curr, RateDescription, url_insert, url_insert, url_insert, RoomAmenity_Type, Mealtype, MaxOccupancy, isPromotionalRate, Closed, 30, StartDate , EndDate, intime, isAvailable, Taxtype, TaxAmount, Taxstatus, None, Ratetype, Discount,Promotion_Name,region,statuscode, israteperstay)
            array.append(aws_insert.insert(id_update, inputid , Domainname, Websitecode, StartDate, RoomType, LOS, RateDate, Guests, OnsiteRate, NetRate, GrossRate, Curr, RateDescription, url_insert, url_insert, url_insert, RoomAmenity_Type, Mealtype, MaxOccupancy, isPromotionalRate, Closed, 30, StartDate , EndDate, intime, isAvailable, Taxtype, TaxAmount, Taxstatus, None, Ratetype, Discount,Promotion_Name,region,statuscode, israteperstay))
        keyvalue = "ondemand/{}/{:%Y%m%d}/delivery/{}.json".format(Websitecode,datetime.datetime.now(),str(inputid)+'_'+str(RateDate)+'_'+id_update)
        key = bucket.new_key(keyvalue)
        key.set_contents_from_string(json.dumps(array))
        return json.dumps(array)
        gc.collect()
    
    except Exception as e:
       ##print e
       value_error = str(re.sub(r"'", '"', str(e)))
       stacktrace = sys.exc_traceback.tb_lineno
       ##print stacktrace
       Guests = ''
       statuscode = '4'
       region = ''
       array.append(aws_insert.insert(id_update, inputid , Domainname, Websitecode, "", "", "", "", Guests, "", "", "", "", "", url_insert,url_insert,url_insert, "", "", "", "", "", "", StartDate, EndDate , "", "", "", "", "", "", "", "", "", region, statuscode, israteperstay))
       keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.json".format(Websitecode,datetime.datetime.now(), id_update)
       key = bucket.new_key(keyvalue)
       key.set_contents_from_string(str(e) + 'Where Line number' + str(stacktrace) + str(proxies))
       return json.dumps(array)
