# -*- coding: utf-8 -*-
import re
import requests
import datetime
import json
import sys 
import boto
import gc

import traceback
import aws_insert

'''id_update=''
inputid=''
url='https://travel.rakuten.com/hotel/Japan-Hokkaido-Esashi-Utanobori_Green_Park_Hotel/67327/?adults=1&checkin=2018-02-15&checkout=2018-02-16&limit=20&offset=0&rooms=1&currency=USD'
proxyip='media:M3diAproxy@192.3.147.133:80'
'''
def fetchrates(url, inputid, id_update, proxyip):
	array = []
	israteperstay = ''
	try:
		#print url
		conn = boto.connect_s3(aws_access_key_id= 'AKIAIXEGZVXCWE2FV3SQ',aws_secret_access_key = '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') 
		bucket = conn.get_bucket("rmapi")
		intime = re.sub(r'\s','T',str(datetime.datetime.now()))
		functionname = 'Travel_rakuten'
		WebSitecode='322'
		Guests=''
		Guests=re.search(r'adults=(\d+)&',url).group(1)
		
		chk_in_out=re.search(r'&checkin=(.*?)&checkout=(.*?)&',url)
		if chk_in_out:
			chk_in=chk_in_out.group(1)
			chk_out=chk_in_out.group(2)
		RateDate=chk_in
		#print RateDate
		Rtdate=re.sub(r'-|\-','',RateDate)
		delta=datetime.datetime.strptime(chk_out, "%Y-%m-%d") - datetime.datetime.strptime(chk_in, "%Y-%m-%d")
		LOS=delta.days
		region=''
		StartDate = datetime.date.today()
		EndDate  = datetime.date.today()+datetime.timedelta(days=29)	
		proxies = {"http": "http://{}".format(proxyip)}
		ip=re.sub(r"\{'.*?@|'\}|:\d+","",str(proxies))
		try:
			try:
				r = requests.get('http://freegeoip.net/json/'+ip,timeout=30)
			except Exception,e:
				r = requests.get('http://freegeoip.net/json/'+ip,timeout=30)
			js = r.json()
			region=js['country_name']
		except Exception,e:
			region=''	
		head = {'Host':'travel.rakuten.com', 'Connection':'keep-alive', 'Cache-Control':'max-age=0', 'Accept':'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8', 'User-Agent':'Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.36 (KHTML, like Gecko) Ubuntu Chromium/37.0.2062.120 Chrome/37.0.2062.120 Safari/537.36', 'Accept-Encoding':'gzip,deflate', 'Accept-Language':'en-US,en;q=0.8'}	
		try:
			htm     = requests.get(url,headers=head,proxies=proxies,timeout=50)
		except Exception,e:
			try:
				htm     = requests.get(url,headers=head,proxies=proxies,timeout=30)
			except Exception,e:
				value_error=str(re.sub(r"'",'',str(e)))
				stacktrace=sys.exc_traceback.tb_lineno
				keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(WebSitecode,datetime.datetime.now(),id_update)
				key = bucket.new_key(keyvalue)
				key.set_contents_from_string(str(e))
				statuscode=5
				Guests='1'
				array.append(aws_insert.insert(id_update, inputid ,functionname,WebSitecode, "", "", "", "", Guests, "", "", "", "", "",url, url, url, "", "", "", "", "", "",StartDate, EndDate , "", "", "", "", "", "", "", "", "",region,statuscode, israteperstay))
				return json.dumps(array)			
		if htm.status_code <> 200:
			htm     = requests.get(url,headers=head,proxies=proxies)
		if htm.status_code == 403 or htm.status_code == 407:
			htm     = requests.get(url,headers=head)
		html    = htm.text.encode('ascii','ignore')
		keyvalue = "ondemand/{}/{:%Y%m%d}/source/{}.html".format(WebSitecode,datetime.datetime.now(),str(inputid)+'_'+str(Rtdate)+'_'+id_update)
		key = bucket.new_key(keyvalue)
		key.set_contents_from_string(html)
		net_rate=''
		MaxOccupancy=''
		ispromupdate='N'
		promotion=''
		TaxAmount=''
		Curr=''
		statuscode=''
		RoomType=''
		OnsiteRate=''
		Curr=''
		Mealtype=''
		isAvailable=''
		Ratetype=''
		RateDescription=''
		TaxStatus=''
		Taxtype =''
		RoomAmenity_Type=''
		block_reg = re.search(r'data=(.*?);</script',html)
		if block_reg:
			block = json.loads(block_reg.group(1))
			if 'rooms' in block:
				Closed_up = "N"
				data   = block['rooms']
				if data.has_key('items'):
					if len(data['items']) !=0:
						for roomblock in  data['items']:
							if 'name' in roomblock:
								RoomType = roomblock['name']
							else:
								RoomType = ''
							if 'personLimit' in roomblock:
								MaxOccupancy = roomblock['personLimit']
								personLimit  = 'upto ' + str(roomblock['personLimit'])+' people'
							else:
								personLimit  = ''
								MaxOccupancy = ''
				
							if 'smokingLead' in roomblock:
								smokingLead = roomblock['smokingLead']
							else:
								smokingLead = ''
				
							if 'facilityLead' in roomblock:
								facilityLead = roomblock['facilityLead']
							else:
								facilityLead = ''                
							RateDescription = facilityLead+' '+personLimit+' '+smokingLead
							if 'plans' in roomblock:
								for rateblock in roomblock['plans']:
									if 'name' in rateblock:
										Ratetype = rateblock['name']
									else:
										Ratetype = ''
									if 'price' in rateblock:
										OnsiteRate = rateblock['price']
										israteperstay = 'Y'
									else:
										OnsiteRate = 0
									if 'currency' in rateblock:
										Curr = rateblock['currency']
									else:
										Curr = ''
									if 'mealsLead' in rateblock:
										Mealtype = rateblock['mealsLead']
									else:
										Mealtype = ''
									if 'detail' in rateblock:
										RoomAmenity_Type = re.sub(r"<.*?>","",re.sub(r'^", "|<br/><br/>$', r'"',re.sub(r"<br/>- |<br/><br/><br/>- ", r'", "',re.sub(r"\[ .*? \]", r"",re.sub(r'\[ Activities \].*?$','',rateblock['detail'])))))
									else:
										RoomAmenity_Type = ''
									if 'roomLeft' in rateblock:
										isAvailable = rateblock['roomLeft']
									else:
										isAvailable = ''
									if 'taxesAndFeedsLead' in rateblock:
										TaxDetails = rateblock['taxesAndFeedsLead']
									else:
										TaxDetails = ''
									Taxtype = TaxDetails
									if 'not include' in TaxDetails.lower():
										TaxStatus = 2
									elif 'include' in TaxDetails.lower():
										TaxStatus = 1
									else:
										TaxStatus = 2
									if OnsiteRate == 0 or str(OnsiteRate) == '0':
										statuscode=1
									else:
										statuscode=''
									array.append(aws_insert.insert(id_update,inputid ,functionname,WebSitecode,StartDate,RoomType,LOS,RateDate,Guests,OnsiteRate,net_rate,OnsiteRate,Curr,RateDescription,url,url,url,RoomAmenity_Type,Mealtype,MaxOccupancy,ispromupdate,Closed_up,30,StartDate ,EndDate,intime,isAvailable,Taxtype,TaxAmount,TaxStatus,None,Ratetype,net_rate,promotion,region,statuscode, israteperstay))
									##print (id_update,inputid ,functionname,WebSitecode,StartDate,RoomType,LOS,RateDate,Guests,OnsiteRate,net_rate,OnsiteRate,Curr,RateDescription,url,url,url,RoomAmenity_Type,Mealtype,MaxOccupancy,ispromupdate,Closed_up,30,StartDate ,EndDate,intime,isAvailable,Taxtype,TaxAmount,TaxStatus,None,Ratetype,net_rate,promotion,region,statuscode)
									##print "_"*50
					else:			
						Closed_up = "Y"
						statuscode= 2
						array.append(aws_insert.insert(id_update,inputid ,functionname,WebSitecode,StartDate,RoomType,LOS,RateDate,Guests,OnsiteRate,net_rate,OnsiteRate,Curr,RateDescription,url,url,url,RoomAmenity_Type,Mealtype,MaxOccupancy,ispromupdate,Closed_up,30,StartDate ,EndDate,intime,isAvailable,Taxtype,TaxAmount,TaxStatus,None,Ratetype,net_rate,promotion,region,statuscode, israteperstay))
						##print (id_update,inputid ,functionname,WebSitecode,StartDate,RoomType,LOS,RateDate,Guests,OnsiteRate,net_rate,OnsiteRate,Curr,RateDescription,url,url,url,RoomAmenity_Type,Mealtype,MaxOccupancy,ispromupdate,Closed_up,30,StartDate ,EndDate,intime,isAvailable,Taxtype,TaxAmount,TaxStatus,None,Ratetype,net_rate,promotion,region,statuscode)
				else:			
					Closed_up = "Y"
					statuscode= 2
					array.append(aws_insert.insert(id_update,inputid ,functionname,WebSitecode,StartDate,RoomType,LOS,RateDate,Guests,OnsiteRate,net_rate,OnsiteRate,Curr,RateDescription,url,url,url,RoomAmenity_Type,Mealtype,MaxOccupancy,ispromupdate,Closed_up,30,StartDate ,EndDate,intime,isAvailable,Taxtype,TaxAmount,TaxStatus,None,Ratetype,net_rate,promotion,region,statuscode, israteperstay))
					##print (id_update,inputid ,functionname,WebSitecode,StartDate,RoomType,LOS,RateDate,Guests,OnsiteRate,net_rate,OnsiteRate,Curr,RateDescription,url,url,url,RoomAmenity_Type,Mealtype,MaxOccupancy,ispromupdate,Closed_up,30,StartDate ,EndDate,intime,isAvailable,Taxtype,TaxAmount,TaxStatus,None,Ratetype,net_rate,promotion,region,statuscode)
			else:			
				Closed_up = "Y"
				statuscode=2
				array.append(aws_insert.insert(id_update,inputid ,functionname,WebSitecode,StartDate,RoomType,LOS,RateDate,Guests,OnsiteRate,net_rate,OnsiteRate,Curr,RateDescription,url,url,url,RoomAmenity_Type,Mealtype,MaxOccupancy,ispromupdate,Closed_up,30,StartDate ,EndDate,intime,isAvailable,Taxtype,TaxAmount,TaxStatus,None,Ratetype,net_rate,promotion,region,statuscode, israteperstay))
# 				#print (id_update,inputid ,functionname,WebSitecode,StartDate,RoomType,LOS,RateDate,Guests,OnsiteRate,net_rate,OnsiteRate,Curr,RateDescription,url,url,url,RoomAmenity_Type,Mealtype,MaxOccupancy,ispromupdate,Closed_up,30,StartDate ,EndDate,intime,isAvailable,Taxtype,TaxAmount,TaxStatus,None,Ratetype,net_rate,promotion,region,statuscode)

		else:			
			Closed_up = "Y"
			statuscode=2
			array.append(aws_insert.insert(id_update,inputid ,functionname,WebSitecode,StartDate,RoomType,LOS,RateDate,Guests,OnsiteRate,net_rate,OnsiteRate,Curr,RateDescription,url,url,url,RoomAmenity_Type,Mealtype,MaxOccupancy,ispromupdate,Closed_up,30,StartDate ,EndDate,intime,isAvailable,Taxtype,TaxAmount,TaxStatus,None,Ratetype,net_rate,promotion,region,statuscode, israteperstay))
# 			#print (id_update,inputid ,functionname,WebSitecode,StartDate,RoomType,LOS,RateDate,Guests,OnsiteRate,net_rate,OnsiteRate,Curr,RateDescription,url,url,url,RoomAmenity_Type,Mealtype,MaxOccupancy,ispromupdate,Closed_up,30,StartDate ,EndDate,intime,isAvailable,Taxtype,TaxAmount,TaxStatus,None,Ratetype,net_rate,promotion,region,statuscode)
		keyvalue = "ondemand/{}/{:%Y%m%d}/delivery/{}.json".format(WebSitecode,datetime.datetime.now(),str(inputid)+'_'+str(Rtdate)+'_'+id_update)
		key = bucket.new_key(keyvalue)
		key.set_contents_from_string(json.dumps(array))
		return json.dumps(array)
		gc.collect()
	except Exception,e:
		value_error=str(re.sub(r"'",'"',str(e)))
		stacktrace=sys.exc_traceback.tb_lineno
		insert_value_error=str(value_error)+'Where line number '+str(stacktrace)+str(proxyip)
		statuscode='4'
		WebSitecode='322'
		keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(WebSitecode,datetime.datetime.now(),id_update)
		key = bucket.new_key(keyvalue)
		key.set_contents_from_string(insert_value_error)
		Guests='1'
# 		print insert_value_error
		array.append(aws_insert.insert(id_update, inputid ,functionname,WebSitecode, "", "", "", "", Guests, "", "", "", "", "",url, url, url, "", "", "", "", "", "",StartDate, EndDate , "", "", "", "", "", "", "", "", "",region,statuscode, israteperstay))
		return json.dumps(array)


#fetchrates(url, inputid, id_update, proxyip)
