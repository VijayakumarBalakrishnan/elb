# -*- coding: utf-8 -*-
import re
import requests
import datetime
import json
import boto
import gc

import aws_insert
import sys

#url ='https://www.hrs.com/hotelData.do?hotelnumber=168111&activity=offer&availability=true&l=en&customerId=413388037&forwardName=defaultSearch&searchType=default&xdynpar_dyn=&fwd=gbgCt&client=en&currency=EUR&startDateDay=07&startDateMonth=12&startDateYear=2017&endDateDay=09&endDateMonth=12&endDateYear=2017&adults=2&children=0&doubleRooms=1&singleRooms=0#checkin=2017-12-07&checkout=2017-12-09#'

#url ='https://www.hrs.com/hotelData.do?hotelnumber=686850&activity=offer&availability=true&l=en&customerId=413388037&forwardName=defaultSearch&searchType=default&xdynpar_dyn=&fwd=gbgCt&client=en&currency=EUR&startDateDay=07&startDateMonth=10&startDateYear=2017&endDateDay=08&endDateMonth=10&endDateYear=2017&&adults=2&children=0&doubleRooms=1&singleRooms=0#checkin=2018-02-06&checkout=2018-02-07#'
#inputid  ='Testing'
#id_update='12345'
#proxyip  ='user-23300:97c98f461884720d@43.241.44.135:1212'

def fetchrates(url ,inputid, id_update, proxyip):
	#print url
	israteperstay = ''
	array = []
	Websitecode='116'
	intime=re.sub(r'\s','T',str(datetime.datetime.now()))
	functionname='HRS'
	delta = datetime.datetime.strptime(re.search(r"checkout=(.*?)#", url).group(1), "%Y-%m-%d") - datetime.datetime.strptime(re.search(r"checkin=(.*?)&", url).group(1), "%Y-%m-%d")
	LOS = delta.days 
	##print LOS
	try:
		StartDate = datetime.date.today()
		EndDate  = datetime.date.today() + datetime.timedelta(days=29)
		conn = boto.connect_s3(aws_access_key_id= 'AKIAIXEGZVXCWE2FV3SQ',aws_secret_access_key = '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') 
		bucket = conn.get_bucket("rmapi")
		#http://www.hrs.com/hotelData.do?hotelnumber=459348&activity=offer&availability=true&l=en&customerId=413388037&forwardName=defaultSearch&searchType=default&xdynpar_dyn=&fwd=gbgCt&client=en&currency=EUR&startDateDay=21&startDateMonth=10&startDateYear=2016&endDateDay=22&endDateMonth=10&endDateYear=2016&adults=1&children=0&doubleRooms=0&singleRooms=1#priceAnchor#checkin=2016-10-21&checkout=2016-10-22&adults=1&
		chkin=''
		if re.search(r'checkin=(.*?)&checkout=(.*?)#',url):
			chkin = re.search(r'checkin=(.*?)&checkout=(.*?)#',url).group(1)	
			chkout = re.search(r'checkin=(.*?)&checkout=(.*?)#',url).group(2)
			adults = re.search(r'&adults=(.*?)&child',url).group(1)
		url = re.sub('#checkin=.*?&checkout=.*?#','',url)
		cind = datetime.datetime.strptime(str(chkin),'%Y-%m-%d').strftime('%d')
		cinm = datetime.datetime.strptime(str(chkin),'%Y-%m-%d').strftime('%m')
		ciny = datetime.datetime.strptime(str(chkin),'%Y-%m-%d').strftime('%Y')
		coutd = datetime.datetime.strptime(str(chkout),'%Y-%m-%d').strftime('%d')
		coutm = datetime.datetime.strptime(str(chkout),'%Y-%m-%d').strftime('%m')
		couty = datetime.datetime.strptime(str(chkout),'%Y-%m-%d').strftime('%Y')
		
		
		if re.search(r'&doubleRooms=(.*?)&singleRooms=(.*?)',url):
			x=int(adults) % 2
			y=int(adults) / 2
			##print x,y
			
			url=re.sub('&doubleRooms=.*?&singleRooms=.*','&doubleRooms='+str(y)+'&singleRooms='+str(x)+'#',url)
			#print 'url',url	
			
		curr_list = ['EUR', 'USD', 'GBP', 'AED', 'ALL', 'AUD', 'BAM', 'BRL', 'BYR', 'CAD', 'CHF', 'CLP', 'CNY', 'CZK', 'DKK', 'FJD', 'HKD', 'HNL', 'HRK', 'HUF', 'IDR', 'ILS', 'INR', 'ISK', 'JPY', 'KRW', 'LTL', 'LVL', 'MDL', 'MKD', 'MXN', 'MYR', 'NOK', 'NZD', 'PHP', 'PKR', 'PLN', 'RON', 'RUB', 'SEK', 'SGD', 'THB', 'TRY', 'TWD', 'UAH', 'ZAR']
		curr_check = re.search(r"currency=(.*?)&", url).group(1)
		if curr_check not in curr_list:
			statuscode=8
			array.append(aws_insert.insert(id_update, inputid ,functionname,Websitecode, "", "", "", "", adults, "", "", "", "", "",url, url, url, "", "", "", "", "", "",StartDate, EndDate , "", "", "", "", "", "", "", "", "","",statuscode, israteperstay))
			return json.dumps(array)
		RateDate = chkin
		if re.search(r'startDateDay=.*?&startDateMonth=.*?&startDateYear=.*?&endDateDay=.*?&endDateMonth=.*?&endDateYear=.*?&adults=.*?&',url):
			url = re.sub('startDateDay=.*?&startDateMonth=.*?&startDateYear=.*?&endDateDay=.*?&endDateMonth=.*?&endDateYear=.*?&adults=.*?&','startDateDay='+cind+'&startDateMonth='+cinm+'&startDateYear='+ciny+'&endDateDay='+coutd+'&endDateMonth='+coutm+'&endDateYear='+couty+'&'+'adults='+adults+'&',url)
		Domainname='hrs.com'
		functionname = Domainname
		StartDate=''
		Roomtype=''
		Guests=adults
		OnsiteRate=0
		NetRate=0
		GrossRate=0
		currency=''
		RateDescription=''
		RoomAmenity_Type=''
		Mealtype=''
		MaxOccupancy=''
		isPromotionalRate='N'
		Closed_up='N'
		Roomavilable=''
		Taxtype=''
		Taxamount=''
		Tax_status=''
		Ratetype=''
		NetRate=''
		Promotion_Name=''
		statuscode=''
		proxies = {"https": "http://{}".format(proxyip)}
		region=''
		ip=re.sub(r"\{'.*?@|'\}|:\d+","",str(proxies))
		try:
			try:
				r = requests.get('http://freegeoip.net/json/'+ip,timeout=30)
			except Exception,e:
				r = requests.get('http://freegeoip.net/json/'+ip,timeout=30)
			js = r.json()
			region=js['country_name']
		except Exception,e:
			region=''

		head = {'User-Agent':'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:12.0) Gecko/20100101 Firefox/12.0'}
		try:
			hml = requests.get(url, headers=head,proxies=proxies,timeout=50)
			##print hml.status_code
			##print url
		except Exception as e:
			value_error=str(re.sub("'",'',str(e)))
			#value_error=str(es).encode('ascii','ignore')
			stacktrace=sys.exc_traceback.tb_lineno			
			try:
				hml = requests.get(url, headers=head,proxies=proxies,timeout=50)
			except Exception,e:
				value_error=str(e)
				stacktrace=sys.exc_traceback.tb_lineno
				keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(Websitecode,datetime.datetime.now(),id_update)
				#print keyvalue
				key = bucket.new_key(keyvalue)
				key.set_contents_from_string(str(e))
				statuscode=5
				Guests='1'
				array.append(aws_insert.insert(id_update, inputid ,functionname,Websitecode, "", "", "", "", Guests, "", "", "", "", "",url,url,url, "", "", "", "", "", "",StartDate, EndDate , "", "", "", "", "", "",  "", "", "",region,statuscode, israteperstay))
				return json.dumps(array)
		if (hml.status_code <> 200):
			hml = requests.get(url, headers=head,proxies=proxies)

		if (hml.status_code == 403 or hml.status_code == 407):
			try:
				proxyresult = requests.get('http://www.gimmeproxy.com/api/getProxy?protocol=http')
				jproxy = json.loads(proxyresult.content)
				proxies = { "http": jproxy["curl"] }
				hml = requests.get(url, headers=head,proxies=proxies)
				if (hml.status_code != 200):
					hml = requests.get(url, headers=head)
			except Exception,e:
				value_error=str(e)
				stacktrace=sys.exc_traceback.tb_lineno
				keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(Websitecode,datetime.datetime.now(),id_update)
				#print keyvalue
				key = bucket.new_key(keyvalue)
				key.set_contents_from_string(str(e))
				statuscode=5
				Guests='1'
				array.append(aws_insert.insert(id_update, inputid ,functionname,Websitecode, "", "", "", "", Guests, "", "", "", "", "",url,url,url, "", "", "", "", "", "",StartDate, EndDate , "", "", "", "", "", "", "", "", "",region,statuscode, israteperstay))
				return json.dumps(array)
		html = hml.text
		html = html.encode('ascii', 'ignore')
		Rtdate=re.sub(r'-|\-','',str(RateDate))
		keyvalue = "ondemand/{}/{:%Y%m%d}/source/{}.html".format(Websitecode,datetime.datetime.now(),str(inputid)+'_'+str(Rtdate)+'_'+id_update)
		#print keyvalue
		key = bucket.new_key(keyvalue)
		key.set_contents_from_string(html)

		if re.compile(r'(<tr class="jsSet.*?<div class="roomTotalPrice">.*?</td>\s*</tr>)', re.DOTALL).findall(html):
			for mainblock in re.compile(r'(<tr class="jsSet.*?<div class="roomTotalPrice">.*?</td>\s*</tr>)', re.DOTALL).findall(html):
				da_time = datetime.datetime.now()
				intime = re.sub(r'\s','T',str(da_time))
				if re.search(re.compile(r'"textWrap ">\s*<h4>(.*?)</h4'), mainblock):
					Roomtype = re.sub(r"<.*?>", r"", re.search(re.compile(r'"textWrap ">\s*<h4>(.*?)</h4'), mainblock).group(1))
				else:
					if re.search('<td class="ftd" >\s*(.*?)\s*</td>', mainblock):
						Roomtype = re.sub(r"<.*?>|:.*", r"", re.search('<td class="ftd" >\s*(.*?)\s*</td>', mainblock).group(1))
					else:
						Roomtype =''
				##print "Roomtype	:", Roomtype
				if re.search(re.compile(r"Room facilities</h5>(.*?)</div>", re.DOTALL), html):
					RoomAmenityType = re.sub(',$', "", re.sub(" , ", ", ", re.sub(r"\s+", r" ", re.sub ("<.*?>|'|:|eatures a|More", "", re.sub("</li>", ",", re.search(re.compile(r"Room facilities</h5>(.*?)</div>", re.DOTALL), html).group(1))))))
					#RoomAmenityType = re.sub("$,", "", RoomAmenityType_Clean)
				else:
					RoomAmenityType = ''
				##print "RoomAmenityType	:", RoomAmenityType
				if re.search(r'Total room price<br/>.*?</td>\s*<td class="price">\s*(.*?) .*?</td>', mainblock, re.DOTALL):
					Taxtype = re.sub("\|", ", ", re.sub ("<.*?>", "", re.search(r'Total room price<br/>.*?</td>\s*<td class="price">\s*(.*?) .*?</td>', mainblock, re.DOTALL).group(1)))
				else:
					if re.search(re.compile(r"Total room price<br/>\((.*?)\):"), mainblock):
						Taxtype = re.sub("\|", ", ", re.sub ("<.*?>", "", re.search(re.compile(r"Total room price<br/>\((.*?)\):"), mainblock).group(1)))
					else:
						Taxtype = ''
						Tax_status=0
						
				if 'incl. tax' or 'includes tax'	in Taxtype:
					Tax_status=1
					Taxtype = 'Includes tax'
				elif 'excl. tax' or 'excludes tax' in Taxtype:
					Tax_status=2
					Taxtype = 'Excludes tax'
				
				##print "Taxtype	:", Taxtype
				if re.search(re.compile(r'incExcEmphasize">.*?</span>:\s*(.*?)\s*</div>'), mainblock):
					Taxamount = re.sub ("", "", re.search(re.compile(r'incExcEmphasize">.*?</span>:\s*(.*?)\s*</div>'), mainblock).group(1))
				else:
					Taxamount = 0
				'''RoomDescp_reg = re.search(r"Rates</h5>\s*<p>(.*?)</p>", re.DOTALL, mainblock)
				if RoomDescp_reg:
					RoomDescp_group = RoomDescp_reg.group(1)
					#RoomDescp_clean = re.sub ("<div >|<i class.*?>|<span id=.*?>|&.*?;|'", "", RoomDescp_group)
					RoomDescp_clean = re.sub(r"(?si)>\s*(Room|Apartment|House)\s*(Facilities|features)(.*?)</p>|high demand!|Recently booked!", r"", RoomDescp_group)
					RoomDescp_clean_tag = re.sub(r"(?s)<p>.*?</p>|<.*?>|&.*?;|<span class.*|<.*", r"", RoomDescp_clean) 
					RoomDescp_clean1 = re.sub("\s+", " ", RoomDescp_clean_tag)
					RoomDescp = re.sub("'", "''", RoomDescp_clean1.strip())
					RateDescription = re.sub(r"Apartment Facilities.*|Room Facilities.*", r"", RoomDescp)
				else:
					RoomDescp = '''''
				RoomDescp_reg = re.search(re.compile(r"</h4>\s*<p>(.*?)</p>", re.DOTALL), mainblock)
				if RoomDescp_reg:
					RoomDescp_group = RoomDescp_reg.group(1)
					#RoomDescp_clean = re.sub ("<div >|<i class.*?>|<span id=.*?>|&.*?;|'", "", RoomDescp_group)
					RoomDescp_clean = re.sub(r"(?si)>\s*(Room|Apartment|House)\s*(Facilities|features)(.*?)</p>|high demand!|Recently booked!", r"", RoomDescp_group)
					RoomDescp_clean_tag = re.sub(r"(?s)<p>.*?</p>|<.*?>|&.*?;|<span class.*|<.*", r"", RoomDescp_clean) 
					RoomDescp_clean1 = re.sub("\s+", " ", RoomDescp_clean_tag)
					RoomDescp = re.sub("'", "''", RoomDescp_clean1.strip())
					RateDescription = re.sub(r"Apartment Facilities.*|Room Facilities.*", r"", RoomDescp)
				else:
					RateDescription = ''
				if re.search(re.compile(r'shortageInfo">.*?<.*?>.*?(\d+)\s.*?</span>'), mainblock):
					Roomavilable = re.sub ("'", "", re.search(re.compile(r'shortageInfo">.*?<.*?>.*?(\d+)\s.*?</span>'), mainblock).group(1))
				else:
					Roomavilable = ''
				##print "Roomavilable	:", Roomavilable
					##print "Room block comes"
					
					#price=<td class="price">\s*(\d.*?)\s*<
				if re.search(re.compile(r'Total room price<br/>.*?\s*</td>\s*<td class="price">\s*.*?\s*<span>(\d.*?)</span>\s*</td>'), mainblock):
					OnsiteRate = re.sub(r"(\d+)\.(\d+\..*)", r"\1\2", re.sub(",", ".", re.sub("[A-Za-z]|&nbsp;|\$", "", re.search(re.compile(r'Total room price<br/>.*?</td>\s*<td class="price">\s*.*?<span>(.*?)</span>\s*</td>',re.DOTALL),mainblock).group(1))))
					GrossRate = OnsiteRate
					if LOS>1:
						israteperstay = 'Y'
					else:
						israteperstay = 'Y'
				elif re.search(re.compile(r'Total room price<br/>.*?</td>\s*<td class="price">\s*(.*?) .*?</td>',re.DOTALL), mainblock):
					OnsiteRate = re.sub(r"(\d+)\.(\d+\..*)", r"\1\2", re.sub(",", ".", re.sub("[A-Za-z]|&nbsp;|\$", "", re.search(re.compile(r'Total room price<br/>.*?</td>\s*<td class="price">\s*(.*?) .*?</td>',re.DOTALL),mainblock).group(1))))
					GrossRate = OnsiteRate
					if LOS>1:
						israteperstay = 'Y'
					else:
						israteperstay = 'Y'
				else:
					OnsiteRate = 0
					GrossRate = 0
				##print "OnsiteRate	:", OnsiteRate
				if re.search(re.compile(r'<td class="price">\s*\d.*?\s*<span>(.*?)</span>\s*</td>'), mainblock):
					currency = re.sub("\d+|\.|,|\s+", "", re.search(re.compile(r'<td class="price">\s*\d.*?\s*<span>(.*?)</span>\s*</td>'), mainblock).group(1).strip())
				elif re.search(re.compile(r'<td class="price">\s*(\d.*?)\s*<'), mainblock):
					currency = re.sub("\d+|\.|,|\s+", "", re.search(re.compile(r'<td class="price">\s*(\d.*?)\s*<'), mainblock).group(1).strip())
				else:
					currency = ''
				##print "currency	:", currency
				if re.search(re.compile(r'blue-sans-rack-rate".*?(\d.*?)\s*</'), mainblock):
					NetRate = re.sub(r"(\d+)\.(\d+\..*)", r"\1\2", re.sub(",", ".",re.sub("[A-Za-z]|&nbsp;|\$", "", re.search(re.compile(r'blue-sans-rack-rate".*?(\d.*?)\s*</'), mainblock).group(1))))
					ispromupdate = 'Y'
				else:
					NetRate = 0
					ispromupdate = 'N'
				##print "discount_rate	:", discount_rate
				if re.search(re.compile(r'<div class="supplements">\s*(.*?)</div', re.DOTALL), mainblock):
					Mealtype = re.sub(r"<.*?>|'|\s+", r"", re.search(re.compile(r'<div class="supplements">\s*(.*?)</div', re.DOTALL), mainblock).group(1)).strip()
				else:
					Mealtype = ''   
				##print "Mealtype	:", Mealtype
				if re.search(re.compile(r'class="checkListSmall">(.*?)</ul>', re.DOTALL), mainblock):
					Ratetype = re.sub(",$", "", re.sub("'", "''", re.sub(r'\s+', r" ", re.sub(r"<.*?>|&nbsp;", r"", re.sub('</li>', ", ", re.search(re.compile(r'class="checkListSmall">(.*?)</ul>', re.DOTALL), mainblock).group(1)))).strip()))
				else:
					Ratetype = ''
				##print "Ratetype	:", Ratetype
				if re.search(re.compile(r'<span class="discount".*?>(.*?)</', re.DOTALL), mainblock):
					Promotion_Name = re.sub("'", "''", re.sub(r"\s+", r" ", re.sub(r"<.*?>", r"", re.sub('</li>|</span>', ", ", re.search(re.compile(r'<span class="discount".*?>(.*?)</', re.DOTALL), mainblock).group(1)))).strip())
				else:
					Promotion_Name = ''
				##print "Promotion_Name	:", Promotion_Name
				if re.search(re.compile(r'<span class="invisible_spoken">\s*.*?:\s*(.*?)\.'), mainblock):
					MaxOccupancy = re.sub(r"â€¢", r"", re.search(re.compile(r'<span class="invisible_spoken">\s*.*?:\s*(.*?)\.'), mainblock).group(1))
				else:
					MaxOccupancy = ''
				##print "Maxocp	:",MaxOccupancy
				if OnsiteRate == 0 or OnsiteRate == '0':
					statuscode =1
					Taxtype = ''
					Tax_status=0
				array.append(aws_insert.insert(id_update, inputid , Domainname, Websitecode, StartDate, Roomtype, LOS, RateDate, Guests, OnsiteRate, NetRate, GrossRate, currency, RateDescription, url, url, url, RoomAmenityType, Mealtype, MaxOccupancy, ispromupdate, Closed_up, 30, StartDate , EndDate, intime, Roomavilable, Taxtype, Taxamount, Tax_status,  None, Ratetype, NetRate,Promotion_Name,region,statuscode, israteperstay))
				##print (id_update, inputid , Domainname, Websitecode, StartDate, Roomtype, LOS, RateDate, Guests, OnsiteRate, NetRate, GrossRate, currency, RateDescription, url, url, url, RoomAmenity_Type, Mealtype, MaxOccupancy, isPromotionalRate, Closed_up, 30, StartDate , EndDate, intime, Roomavilable, Taxtype, Taxamount,Tax_status, None, Ratetype, NetRate,Promotion_Name,region,statuscode, israteperstay)
		else:
			Closed_up = "Y"
			statuscode=2
			da_time = datetime.datetime.now()
			intime = re.sub(r'\s','T',str(da_time))
			##print (id_update, inputid , Domainname, Websitecode, StartDate, Roomtype, LOS, RateDate, Guests, OnsiteRate, NetRate, GrossRate, currency, RateDescription, url, url, url, RoomAmenity_Type, Mealtype, MaxOccupancy, isPromotionalRate, Closed_up, 30, StartDate , EndDate, intime, Roomavilable, Taxtype, Taxamount,Tax_status, None, Ratetype, NetRate,Promotion_Name,region,statuscode)
			array.append(aws_insert.insert(id_update, inputid , Domainname, Websitecode, StartDate, Roomtype, LOS, RateDate, Guests, OnsiteRate, NetRate, GrossRate, currency, RateDescription, url, url, url, RoomAmenity_Type, Mealtype, MaxOccupancy, isPromotionalRate, Closed_up, 30, StartDate , EndDate, intime, Roomavilable, Taxtype, Taxamount,Tax_status, None, Ratetype, NetRate,Promotion_Name,region,statuscode, israteperstay))
		keyvalue = "ondemand/{}/{:%Y%m%d}/delivery/{}.json".format(Websitecode,datetime.datetime.now(),str(inputid)+'_'+str(Rtdate)+'_'+id_update)
		key = bucket.new_key(keyvalue)
		key.set_contents_from_string(json.dumps(array))
		return json.dumps(array)
		gc.collect()				
	except Exception,e:
		value_error=str(re.sub(r"'",'"',str(e)))
		stacktrace=sys.exc_traceback.tb_lineno
		insert_value_error=str(value_error)+'Where line number '+str(stacktrace)+str(proxyip)
		print insert_value_error
		statuscode='4'
		region=''
		Websitecode='116'
		keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(Websitecode,datetime.datetime.now(),id_update)
		key = bucket.new_key(keyvalue)
		key.set_contents_from_string(insert_value_error)
		Guests='1'
		array.append(aws_insert.insert(id_update, inputid ,functionname,Websitecode, "", "", "", "", Guests, "", "", "", "", "",url, url, url, "", "", "", "", "", "",StartDate, EndDate , "", "", "", "", "", "", "", "", "",region,statuscode, israteperstay))
		return json.dumps(array)
