# -*- coding: utf-8 -*-
import re
import requests
import datetime
import operator
import json
import sys 
import boto
import gc

import aws_insert

def fetchrates(url , inputid, id_update, proxyip):
    array = []
    intime = re.sub(r'\s', 'T', str(datetime.datetime.now()))
    functionname = 'xandari.com'
    Websitecode = 365
    LastModified = intime
    israteperstay = ''
    try:
        conn = boto.connect_s3(aws_access_key_id='AKIAIXEGZVXCWE2FV3SQ', aws_secret_access_key='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') 
        bucket = conn.get_bucket("rmapi")
        sr = requests.Session()
        StartDate = datetime.date.today()
        EndDate = datetime.date.today() + datetime.timedelta(days=29)
        Websitecode = 365
        Domainname = "xandari.com"
        chkins = re.search(r'checkindate=(.*?)&', url).group(1)
        chkouts = re.search(r'checkoutdate=(.*?)&', url).group(1)
        txtadult = re.search(r'adult=(.*?)\#', url).group(1)
        checkins = datetime.datetime.strptime(chkins, str("%Y-%m-%d")).strftime("%Y, %m, %d")
        checkouts = datetime.datetime.strptime(chkouts, str("%Y-%m-%d")).strftime("%Y, %m, %d")
        ccin = datetime.datetime.strptime(checkins, '%Y, %m, %d')
        ccout = datetime.datetime.strptime(checkouts, '%Y, %m, %d')
        LOS = ccout - ccin
        LOS = LOS.days
        checkins_load = datetime.datetime.strptime(chkins, str("%Y-%m-%d")).strftime("%m/%d/%Y")
        checkouts_load = datetime.datetime.strptime(chkouts, str("%Y-%m-%d")).strftime("%m/%d/%Y")
        RateDate = chkins
        head = {'User-Agent':'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:12.0) Gecko/20100101 Firefox/12.0'}
        payload = {'dateinicio':str(checkins_load), 'datefin':str(checkouts_load), 'selNights':str(LOS), 'search_rooms':'1', 'adultos_1':str(txtadult), 'ninos_1':'0', 'child_ages_room_1_child_1':'-9', 'child_ages_room_1_child_2':'-9', 'selChilds':'', 'orbeCode':'HZZML', 'selectednights':'-1', 'package_selected':'-1', 'masrate_selected':'-1', 'room_selected':'-1', 'promocode_selected':'-1'}
        proxies = {"http": "http://{}".format(proxyip)}
        region = ''
        ip = re.sub(r"\{'.*?@|'\}|:\d+", "", str(proxies))
        url_load = 'https://reservations.orbebooking.com/Search/StepSearch'
        try:
            try:
                r = requests.get('http://freegeoip.net/json/' + ip, timeout=30)
            except Exception, e:
                r = requests.get('http://freegeoip.net/json/' + ip, timeout=30)
            js = r.json()
            region = js['country_name']
        except Exception, e:
            region = ''
        try:
            hml = sr.get('https://reservations.orbebooking.com/Search/Init/HZZML', headers=head,proxies = proxies)
            hml = sr.post(url_load, data=payload, headers=head, proxies=proxies, timeout=50)
        except Exception, e:
            value_error = str(re.sub("'", '', str(e)))
            stacktrace = sys.exc_traceback.tb_lineno
            try:
                hml = sr.get('https://reservations.orbebooking.com/Search/Init/HZZML', headers=head,proxies = proxies)
                hml = requests.post(url_load, data=payload, headers=head, proxies=proxies, timeout=50)
            except Exception, e:
                value_error = str(re.sub("'", '', str(e)))
                stacktrace = sys.exc_traceback.tb_lineno
                keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(Websitecode, datetime.datetime.now(), id_update)
                key = bucket.new_key(keyvalue)
                key.set_contents_from_string(str(e) + 'Where Line number' + str(stacktrace) + str(proxies))
                statuscode = 5
                Guests = ''
                array.append(aws_insert.insert(id_update, inputid , functionname, Websitecode, "", "", "", "", Guests, "", "", "", "", "", url, url, url, "", "", "", "", "", "", StartDate, EndDate , "", "", "", "", "", "", "", "", "", region, statuscode, israteperstay))
                return json.dumps(array)
        if hml.status_code <> 200:
            hml = sr.get('https://reservations.orbebooking.com/Search/Init/HZZML', headers=head,proxies = proxies)
            hml = requests.post(url_load, data=payload, headers=head, proxies=proxies)
        if (hml.status_code == 403 or hml.status_code == 407) or hml.status_code <> 200:
            try:
                if hml.status_code <> 200:
                    hml = sr.get('https://reservations.orbebooking.com/Search/Init/HZZML', headers=head)
                    hml = requests.post(url_load, data=payload, headers=head)
            except Exception, e:
                value_error = str(re.sub("'", '', str(e)))
                stacktrace = sys.exc_traceback.tb_lineno
                keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(Websitecode, datetime.datetime.now(), id_update)
                key = bucket.new_key(keyvalue)
                key.set_contents_from_string(str(e) + 'Where Line number' + str(stacktrace) + str(proxies))
                statuscode = 5
                Guests = ''
                array.append(aws_insert.insert(id_update, inputid , functionname, Websitecode, "", "", "", "", Guests, "", "", "", "", "", url, url, url, "", "", "", "", "", "", StartDate, EndDate , "", "", "", "", "", "", "", "", "", region, statuscode, israteperstay))
                return json.dumps(array)
        html = hml.text
        html = html.encode('ascii', 'ignore')
        #fo = open('name.html', 'w')
        #fo.write(str(html))
        Rtdate=re.sub(r'-|\-','',str(RateDate))
        Rtdate=re.sub(r'-|\-','',str(RateDate))
        keyvalue = "ondemand/{}/{:%Y%m%d}/source{}.html".format(Websitecode, datetime.datetime.now(), str(inputid) + '_' + str(Rtdate) + '_' + id_update)
        #print keyvalue
        key = bucket.new_key(keyvalue)
        key.set_contents_from_string(html)  
        Websitecode = Websitecode
        RoomType = ""
        Guests = ""
        Guests_reg = re.search(r'adult=(.*?)\#', url)
        if Guests_reg:
            Guests = Guests_reg.group(1)
        OnsiteRate = 0
        NetRate = 0
        Curr = ""
        RateDescription = ""
        RoomAmenity_Type = ""
        MealInclusion_Type = ""
        MaxOccupancy = None
        isPromotionalRate = "N"
        Closed_up = "Y"
        LastModified = LastModified
        isAvailable = ""
        Taxtype = ""
        TaxAmount = 0
        RateType = ""
        Promotion_Name = ""
        Tax_status = ''
        url = 'https://reservations.orbebooking.com/Search/Init/HZZML'
        reg_block = re.search('(<div class="col_full content_room">\s*.*?)\s*</div>\s*</div>\s*<div class="clearfix"></div>\s*</div>',html,re.DOTALL)
        if reg_block:
            for block in re.compile(r'(<div class="col_full content_room">\s*.*?)\s*</div>\s*</div>\s*<div class="clearfix"></div>\s*</div>',re.DOTALL).findall(html):
                RoomType=""
                OnsiteRate= 0
                NetRate= 0
                Curr=""
                RateDescription=""
                RoomAmenity_Type=""
                MealInclusion_Type=""
                MaxOccupancy= None
                isPromotionalRate="N"
                Closed_up="N"
                isAvailable=""
                Taxtype=""
                TaxAmount= 0
                RateType=""
                Promotion_Name=""
                statuscode = ''
                room_type=re.search('<div class="col_full content_room">\s*(.*?)\s*</h1>',block)
                if room_type:
                    rooms=room_type.group(1)
                    RoomType=re.sub('Room Type|\'|<.*?>','',rooms).strip()
                    RoomType=re.sub('\s+',' ',RoomType)
                    #print "Room_Type        :",RoomType
                Avaible=re.search('[O|o]nly\s*(\d+)\s*room',block)
                if Avaible:
                    isAvailable_1=Avaible.group(1)
                    isAvailable_2=re.sub('<.*?>','',isAvailable_1)
                    isAvailable=re.sub('\s+',' ',isAvailable_2)
                    #print "isAvailable        :",isAvailable
                Ratetype_reg=re.search("id='descr-.*?>\s*<strong>\s*(.*?)\s*</strong>\s*</p>",block)
                if Ratetype_reg:
                    Ratetype_1=Ratetype_reg.group(1)
                    Ratetype_2=re.sub('<.*?>','',Ratetype_1)
                    RateType=re.sub('\s+',' ',Ratetype_2)
                    #print "RateType        :",RateType
                descript=re.search('class="modal-body">\s*(.*?)\s*<strong>',block,re.DOTALL)
                if descript:
                    RateDescription_1=descript.group(1)
                    RateDescription_1 = re.sub("&amp;","&",RateDescription_1)
                    RateDescription_2 = re.sub("\$|<.*?>|&.*?;|Close</button>","",RateDescription_1)
                    RateDescription_3 = re.sub("'","''",RateDescription_2)
                    RateDescription = re.sub("\s+"," ",RateDescription_3)
                    #print "Descriptipon        :",RateDescription
                mealinclusion_reg=re.search('rate includes:.*?</p>\s*<[u|p].*?>\s*(.*?)\s*</[u|p]',block,re.DOTALL)
                if mealinclusion_reg:
                    mealinclusion_1=mealinclusion_reg.group(1)
                    mealinclusion_1 = re.sub(r'</li>', ', ', mealinclusion_1)
                    mealinclusion_2 = re.sub("\$|<.*?>|amp;","",mealinclusion_1)
                    mealinclusion_3 = re.sub("'","''",mealinclusion_2)
                    MealInclusion_Type = re.sub("\s+"," ",mealinclusion_3)
                    #print "MealInclusion_Type        :",MealInclusion_Type
                Promoname_reg=re.search('<div class="special-row-offer-content">\s*(.*?)\s*</div>',block,re.DOTALL)
                if Promoname_reg:
                    Promoname_1=Promoname_reg.group(1)
                    Promoname_2 = re.sub(r'</li>', ', ', Promoname_1)
                    Promoname_3 = re.sub("\$|<.*?>|amp;","",Promoname_2)
                    Promoname_4 = re.sub("'","''",Promoname_3)
                    Promotion_Name = re.sub("\s+"," ",Promoname_4)
                    #print "Promotion_Name        :",Promotion_Name
                    isPromotionalRate = 'Y'
                curr_re = re.search('style="display:block; margin-top:5px".*?>\s*(.*?)\s*&',block)
                if curr_re:
                    Curr= curr_re.group(1)
                    #print"Currency   :",Curr
                Tax_status = 2
                Ameints_re = re.search('amenities:</strong>\s*(.*?)</ul>\s*', block, re.DOTALL)
                if Ameints_re:
                    Amentes = Ameints_re.group(1)
                    click1 = re.sub(r'</li>', ', ', Amentes)
                    RoomAmenity_Type1 = re.sub('<.*?>|amp;|\t+|\n|&.*?;', '', click1)
                    RoomAmenity_Type3 = re.sub('\s+', ' ', RoomAmenity_Type1)
                    RoomAmenity_Type2 = re.sub("'", "''", RoomAmenity_Type3).strip()
                    RoomAmenity_Type4 = re.sub('^\s|,$', '', RoomAmenity_Type2)
                    RoomAmenity_Type = RoomAmenity_Type4
                old_price=re.search('style="display:block; margin-top:5px".*?>\w+&.*?;\s*(\d.*?)\s*<',block)
                if old_price:
                    price=old_price.group(1)
                    OnsiteRate = re.sub("\$|,","",price)
                    #print "Room_Price        :",OnsiteRate
                Netrate_reg=re.search('style="display:block; text-decoration: line-through !important;".*?>\w+&.*?;\s*(\d.*?)\s*<',block)
                if Netrate_reg:
                    Netrate_1=Netrate_reg.group(1)
                    NetRate = re.sub("\$|,","",Netrate_1)
                    #print "Netrate        :",NetRate
                    isPromotionalRate = 'Y'
                else:
                    NetRate=0
                    isPromotionalRate = 'N'
                if OnsiteRate <> 0:
                    statuscode = ''
                else:
                    statuscode = 1
                LOS = int(LOS)
                if int(LOS) >1:
                    israteperstay = 'N'
                else:
                    israteperstay ='Y'
                array.append(aws_insert.insert(id_update, inputid , Domainname, Websitecode, StartDate, RoomType, LOS, RateDate, Guests, OnsiteRate, NetRate, OnsiteRate, Curr, RateDescription, url, url, url, RoomAmenity_Type, MealInclusion_Type, MaxOccupancy, isPromotionalRate, Closed_up, 30, StartDate , EndDate, intime, isAvailable, Taxtype, TaxAmount, Tax_status, None, RateType, NetRate, Promotion_Name, region, statuscode, israteperstay))
        else:
            statuscode = '2'
            #print "statuscode    :", statuscode
            Closed_up = "Y"
            da_time = datetime.datetime.now()
            LastModified = re.sub(r'\s', 'T', str(da_time))
            Tax_status = ''
            # insert(HotelCode,Websitecode,ReportDate,RoomType,LOS,RateDate,Guests,OnsiteRate,NetRate,GrossRate,Curr,RateDescription,HotelId,urlRate,urlInclusions,urlAmenities,RoomAmenity_Type,MealInclusion_Type,MaxOccupancy,isPromotionalRate,Closed,NumberOfDays,StartDate,EndDate,LastModified,isAvailable,Taxtype,TaxAmount,HotelBlock,RateType,Discount,Promotion_Name)
            array.append(aws_insert.insert(id_update, inputid , Domainname, Websitecode, StartDate, RoomType, LOS, RateDate, Guests, OnsiteRate, NetRate, OnsiteRate, Curr, RateDescription, url, url, url, RoomAmenity_Type, MealInclusion_Type, MaxOccupancy, isPromotionalRate, Closed_up, 30, StartDate , EndDate, intime, isAvailable, Taxtype, TaxAmount, Tax_status, None, RateType, NetRate, Promotion_Name, region, statuscode, israteperstay))
            # #print ("UPDATE
        #print "completed"
        Rtdate = re.sub(r'-|\-', '', str(RateDate))
        Rtdate = re.sub(r'-|\-', '', str(RateDate))
        keyvalue = "ondemand/{}/{:%Y%m%d}/delivery/{}.json".format(Websitecode, datetime.datetime.now(), str(inputid) + '_' + str(Rtdate) + '_' + id_update)
        key = bucket.new_key(keyvalue)
        key.set_contents_from_string(json.dumps(array))
        return json.dumps(array)
        gc.collect()

    except Exception as e:
        print e
        value_error = str(re.sub(r"'", '"', str(e)))
        stacktrace = sys.exc_traceback.tb_lineno
        Guests = ''
        region = ''
        Websitecode = '365'
        insert_value_error = str(value_error) + 'Where line number ' + str(stacktrace) + str(proxyip)
        print insert_value_error
        #print "Websitecode =", Websitecode
        statuscode = '4'
        keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(Websitecode, datetime.datetime.now(), id_update)
        key = bucket.new_key(keyvalue)
        key.set_contents_from_string(insert_value_error)
        # array.append(aws_insert.insert(id_update,inputid ,Domainname,Websitecode,StartDate,'',LOS,RateDate,Guests,OnsiteRate,Netrate,OnsiteRate,Curr,RateDescription,url,url,url,RoomAmenity_Type,MealInclusion_Type,MaxOccupancy,isPromotionalRate,Closed_up,30,StartDate ,EndDate,intime,isAvailable,None,None,None,RateType,Netrate,promotion,region,statuscode, israteperstay))
        array.append(aws_insert.insert(id_update, inputid , functionname, Websitecode, "", "", "", "", Guests, "", "", "", "", "", url, url, url, "", "", "", "", "", "", StartDate, EndDate , "", "", "", "", "", "", "", "", "", region, statuscode, israteperstay))
        return json.dumps(array)
    
'''url= 'https://reservations.orbebooking.com/Search/StepSearch&checkindate=2017-10-29&checkoutdate=2017-10-30&adult=1#'
inputid= ''
id_update = ''
proxyip   = '62.210.106.225:3681'
fetchrates(url ,inputid, id_update, proxyip)'''
