# -*- coding: utf-8 -*-
import re
import requests
import datetime
import json
import boto
import sys 
from boto.s3.key import Key

import traceback
import aws_insert

def fetchrates (url,inputid, id_update,proxyip):
	#print url
	israteperstay = ''
	array = []
	intime=re.sub(r'\s','T',str(datetime.datetime.now()))
	StartDate = datetime.date.today()
	EndDate  = datetime.date.today() + datetime.timedelta(days=29)
	conn = boto.connect_s3(aws_access_key_id= 'AKIAIXEGZVXCWE2FV3SQ',aws_secret_access_key = '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') 
	bucket = conn.get_bucket("rmapi") 
	WebSiteCode = 272
	
	try:
		Ratedate=''
		region=''
		url_db = url
		proxies = {"http": "http://{}".format(proxyip)}
		WebSiteName = 'Thinkhotels'
		RoomType    = ''
		Guests      = 1
		OnsiteRate  = 0
		Netrate     = 0
		GrossRate   = 0
		Curr        = ''
		MaxOccupancy= ''
		isAvailable = ''
		RateDescription= ''
		Isprom      = 'N' 
		Closed_up   = 'Y'
		NumberOfDays= 48
		MealInclusion_Type= ''
		RateType    = ''
		StartDate   = ''
		EndDate     = ''
		Tax_status  = ''
		da_time     = datetime.datetime.now()
		intime      = re.sub(r'\s','T',str(da_time))
		Discount    = 0
		RoomAmenity_Type = ''
		Promotion_Name = ''
		chkin=datetime.datetime.strptime(str(re.search(r"datepickerchechin=(.*?)&", url_db).group(1)),'%Y-%m-%d').strftime('%d/%m/%Y')
		chkout=datetime.datetime.strptime(str(re.search(r"datepickerchechout=(.*?)&", url_db).group(1)),'%Y-%m-%d').strftime('%d/%m/%Y')
		delta = datetime.datetime.strptime(str(re.search(r"datepickerchechout=(.*?)&", url_db).group(1)),'%Y-%m-%d') - datetime.datetime.strptime(str(re.search(r"datepickerchechin=(.*?)&", url_db).group(1)),'%Y-%m-%d')
		LOS = delta.days 
		Ratedate=re.search(r"datepickerchechin=(.*?)&", url_db).group(1)
		if re.search(r'&adult1=(\d+)&',url_db):
			Guests=re.search(r'&adult1=(\d+)&',url_db).group(1)
		url_db=re.sub(r'&datepickerchechin=.*?&datepickerchechout=.*?&adult1=\d+&','&datepickerchechin='+chkin+'&datepickerchechout='+chkout+'&adult1=1&',url_db)
		head        = {'User-Agent':'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:12.0) Gecko/20100101 Firefox/31.0'}
		try:
			hml = requests.get(url_db, headers= head,proxies=proxies,timeout=50)
		except Exception,e:
			value_error=str(re.sub("'",'"',str(e)))
			value_error=str(e).encode('ascii','ignore')
			stacktrace=sys.exc_traceback.tb_lineno
			try:
				hml = requests.get(url_db, headers= head, proxies=proxies)
			except Exception,e:
				value_error=str(re.sub("'",'"',str(e)))
				stacktrace=sys.exc_traceback.tb_lineno
				keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(WebSiteCode,datetime.datetime.now(),id_update)
				key = bucket.new_key(keyvalue)
				key.set_contents_from_string(str(e))
				region=''
				ip=re.sub(r"\{'.*?@|'\}|:\d+","",str(proxies))
				try:
					try:
						r = requests.get('http://freegeoip.net/json/'+ip,timeout=30)
					except Exception,e:
						r = requests.get('http://freegeoip.net/json/'+ip,timeout=30)
					js = r.json()
					region=js['country_name']
				except Exception,e:
					region=''
				statuscode=5
				Guests='1'
				array.append(aws_insert.insert(id_update, inputid ,"",WebSiteCode, "", "", "", "", Guests, "", "", "", "", "","", "", "", "", "", "", "", "", "",StartDate, EndDate , "", "", "", "", "", "", "", "", "",region,statuscode, israteperstay))
				return json.dumps(array)
		if (hml.status_code <> 200): 
			hml = requests.get(url_db, headers= head, proxies=proxies)  
		if (hml.status_code == 403 or hml.status_code == 407):
			try:
				proxyresult = requests.get('http://www.gimmeproxy.com/api/getProxy?protocol=http')
				jproxy = json.loads(proxyresult.content)
				proxies = { "http": jproxy["curl"] }
				hml = requests.get(url_db, headers= head,proxies=proxies)
				if (hml.status_code != 200):
					hml = requests.get(url_db, headers=head)
			except Exception as e:
				value_error=str(re.sub("'",'"',str(e)))
				#print "value_error	:",value_error
				stacktrace=sys.exc_traceback.tb_lineno
				keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(WebSiteCode,datetime.datetime.now(),id_update)
				key = bucket.new_key(keyvalue)
				key.set_contents_from_string(str(e))
				region=''
				ip=re.sub(r"\{'.*?@|'\}|:\d+","",str(proxies))
				try:
					try:
						r = requests.get('http://freegeoip.net/json/'+ip,timeout=30)
					except Exception,e:
						r = requests.get('http://freegeoip.net/json/'+ip,timeout=30)
					js = r.json()
					region=js['country_name']
				except Exception,e:
					region=''
				statuscode=5
				Guests='1'
				array.append(aws_insert.insert(id_update, inputid ,"",WebSiteCode, "", "", "", "", Guests, "", "", "", "", "","", "", "", "", "", "", "", "", "",StartDate, EndDate , "", "", "", "", "", "", "", "", "",region,statuscode, israteperstay))
				return json.dumps(array)			
		html = hml.text.encode('ascii', 'ignore')
		Rtdate=re.sub(r'-|\-','',str(Ratedate))
		keyvalue = "ondemand/{}/{:%Y%m%d}/source/{}.html".format(WebSiteCode,datetime.datetime.now(),str(inputid)+'_'+str(Rtdate)+'_'+id_update)
		key = bucket.new_key(keyvalue)
		key.set_contents_from_string(html)
		region=''
		ip=re.sub(r"\{'.*?@|'\}|:\d+","",str(proxies))
		try:
			try:
				r = requests.get('http://freegeoip.net/json/'+ip,timeout=30)
			except Exception,e:
				r = requests.get('http://freegeoip.net/json/'+ip,timeout=30)
			js = r.json()
			region=js['country_name']
		except Exception,e:
			region=''
		if re.compile(r'<div class="roomtypes_details">.*?</table>\s*</div>',re.DOTALL).findall(str(html)):
			Closed_up   = 'N'
			for roomblock in re.compile(r'<div class="roomtypes_details">.*?</table>\s*</div>',re.DOTALL).findall(str(html)):
				RoomType_re = re.search(r'id="room_descr_\d.*?">(.*?)<', roomblock)
				if RoomType_re:
					RoomType = RoomType_re.group(1)
				else:
					RoomType = ""
				Occupancy_re = re.search(r'<span>Max (.*?) p', roomblock, re.IGNORECASE)
				if Occupancy_re:
					MaxOccupancy = Occupancy_re.group(1)
				else:
					MaxOccupancy = ""
				Description_re = re.search(r'id="room_descr_long_.*?">(.*?)<', roomblock, re.IGNORECASE)
				if Description_re:
					RateDescription = Description_re.group(1)
				else:
					RateDescription = ""
				Ratetype_re = re.search(r'<div id="rate_descr_long_.*?_.*?_.*?_.*?">\s*(.*?)\s*<', roomblock, re.IGNORECASE)
				if Ratetype_re:
					RateType = Ratetype_re.group(1)
				else:
					RateType = ""
				Price_re = re.search(r'class="ud-price"> [A-z].*? (\d.*?)<', roomblock, re.IGNORECASE)
				if Price_re:
					OnsiteRate = re.sub(r'\s+','',re.sub(r",","",Price_re.group(1)))
					israteperstay = 'Y'
					
				else:
					OnsiteRate = 0
				Currency_re = re.search(r'class="ud-price"> ([A-z].*?) \d.*?<', str(roomblock))
				if Currency_re:
					Curr = Currency_re.group(1)
				else:
					Curr = ""
				##print"="*30
				statuscode = ''
				array.append(aws_insert.insert(id_update, inputid, WebSiteName, WebSiteCode, StartDate, RoomType,1, Ratedate, Guests, OnsiteRate, Netrate, GrossRate, Curr, RateDescription,url_db, url_db, url_db, RoomAmenity_Type, MealInclusion_Type,MaxOccupancy, Isprom, Closed_up,NumberOfDays, StartDate, EndDate,  intime, isAvailable,None, None,Tax_status, None, RateType, Discount,Promotion_Name,region, statuscode, israteperstay))

		else:
			Closed_up   = 'Y'
			statuscode = '2'
			array.append(aws_insert.insert(id_update, inputid, WebSiteName, WebSiteCode, StartDate, RoomType,1, Ratedate, Guests, OnsiteRate, Netrate, GrossRate, Curr, RateDescription,url_db, url_db, url_db, RoomAmenity_Type, MealInclusion_Type,MaxOccupancy, Isprom, Closed_up,NumberOfDays, StartDate, EndDate,  intime, isAvailable,None, None,Tax_status, None, RateType, Discount,Promotion_Name,region, statuscode, israteperstay))
	
		keyvalue = "ondemand/{}/{:%Y%m%d}/delivery/{}.json".format(WebSiteCode,datetime.datetime.now(),str(inputid)+'_'+str(Rtdate)+'_'+id_update)
		key = bucket.new_key(keyvalue)
		key.set_contents_from_string(json.dumps(array))
		return json.dumps(array)
	except Exception as e:
		value_error=str(re.sub(r"'",'"',str(e)))
		stacktrace=sys.exc_traceback.tb_lineno
		insert_value_error=str(value_error)+'Where line number '+str(stacktrace)+' - '+str(proxyip)
		statuscode='4'
		keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(WebSiteCode,datetime.datetime.now(),id_update)
		key = bucket.new_key(keyvalue)
		key.set_contents_from_string(insert_value_error)
		Guests='1'
		array.append(aws_insert.insert(id_update, inputid ,"",WebSiteCode, "", "", "", "", Guests, "", "", "", "", "",url_db, url_db, url_db, "", "", "", "", "", "",StartDate, EndDate , "", "", "", "", "", "", "", "", "",region,statuscode, israteperstay))
		return json.dumps(array)


