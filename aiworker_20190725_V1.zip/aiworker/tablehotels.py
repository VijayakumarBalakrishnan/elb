# -*- coding: utf-8 -*-
import re
import requests
import datetime
import json
import sys 
import boto
import gc

import aws_insert

def fetchrates(url ,inputid, id_update, proxyip):
    array      = []
    israteperstay=''
    proxies    = {"https": "http://{}".format(proxyip)}
    intime     = re.sub(r'\s','T',str(datetime.datetime.now()))
    Domainname ='tablethotels'
    Websitecode='1277'
    region     =''
    statuscode =''
    Mealtype   = ''
    conn       = boto.connect_s3(aws_access_key_id= 'AKIAIXEGZVXCWE2FV3SQ',aws_secret_access_key = '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') 
    bucket     = conn.get_bucket("rmapi")
    StartDate  = datetime.date.today()
    EndDate    = datetime.date.today() + datetime.timedelta(days=29)
    try:
        CheckIn_Check_OT_re = re.search(r'arrDate=(.*?)&depDate=(.*?)&',url)
        if CheckIn_Check_OT_re:
            Checkin = CheckIn_Check_OT_re.group(1)
            CheckOT = CheckIn_Check_OT_re.group(2)
        else:
            Checkin = ''
            CheckOT = ''
        RateDate = Checkin
        delta    = datetime.datetime.strptime(str(CheckOT), "%Y-%m-%d") - datetime.datetime.strptime(Checkin, "%Y-%m-%d")
        LOS      = delta.days
        RoomType = ''
        Guests   = re.search(r'&nA=(\d+)', url).group(1)
        Ratetype = ''
        Meal     = ''
        Taxtype  = ''
        Curr     = re.search(r'#Currency=(.*?)&',url).group(1)
        Closed   = 'Y'
        NetRate  = 0
        Taxstatus= 0
        TaxAmount= 0
        Discount = 0
        GrossRate= 0
        OnsiteRate = 0
        isAvailable= ''
        MaxOccupancy     = None
        Promotion_Name   = ''
        RateDescription  = ''
        RoomAmenity_Type = ''
        isPromotionalRate= 'N'
        currency_pref = 'currency_pref='+Curr
        url_insert = url
        url        = re.sub(r'#.*','',str('https://www.tablethotels.com/_api/rooms?'+re.search(r"\?(.*?)$",url_insert).group(1)))
        #print url
        proxyip    = re.sub(r':.*','',str(proxyip))
        headers    = {'User-Agent':'Mozilla/5.0 (X11; Linux i686; rv:45.0) Gecko/20100101 Firefox/45.0','Cookie':str(currency_pref)}
        try:
            try:
                r = requests.get('http://freegeoip.net/json/' + proxyip, timeout=30)
            except Exception, e:
                r = requests.get('http://freegeoip.net/json/' + proxyip, timeout=30)
            js = r.json()
            region = js['country_name']
        except Exception, e:
            region = ''
        try:
            hml = requests.get(url,headers=headers,proxies=proxies)
        except Exception, e:
            print e
            value_error = str(re.sub("'", '', str(e)))
            stacktrace = sys.exc_traceback.tb_lineno
            try:
                hml = requests.get(url,headers=headers,proxies=proxies,timeout=120)
            except Exception, e:
                try:
                    hml = requests.get(url,headers=headers,proxies=proxies,timeout=150)
                except Exception, e:
                    value_error = str(re.sub("'", '', str(e)))
                    stacktrace = sys.exc_traceback.tb_lineno
                    keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(Websitecode, datetime.datetime.now(), id_update)
                    key = bucket.new_key(keyvalue)
                    key.set_contents_from_string(str(e) + 'Where Line number' + str(stacktrace) + str(proxies))
                    statuscode = 5
                    array.append(aws_insert.insert(id_update, inputid , Domainname, Websitecode, "", "", "", "", Guests, "", "", "", "", "", url, url, url, "", "", "", "", "", "", StartDate, EndDate , "", "", "", "", "", "", "", "", "", region, statuscode,israteperstay))
                    return json.dumps(array)
        if hml.status_code <> 200:
            hml = requests.get(url,headers=headers,proxies=proxies,timeout=50)
        if (hml.status_code == 403 or hml.status_code == 407) or hml.status_code <> 200:
            try:
                if hml.status_code <> 200:
                    hml = requests.get(url,headers=headers,timeout=100)
            except Exception, e:
                print e
                value_error = str(re.sub("'", '', str(e)))
                stacktrace = sys.exc_traceback.tb_lineno
                keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(Websitecode, datetime.datetime.now(), id_update)
                key = bucket.new_key(keyvalue)
                key.set_contents_from_string(str(e) + 'Where Line number' + str(stacktrace) + str(proxies))
                statuscode = 5
                array.append(aws_insert.insert(id_update, inputid , Domainname, Websitecode, "", "", "", "", Guests, "", "", "", "", "", url, url, url, "", "", "", "", "", "", StartDate, EndDate , "", "", "", "", "", "", "", "", "", region, statuscode,israteperstay))
                return json.dumps(array) 
        keyvalue = "ondemand/{}/{:%Y%m%d}/source/{}.json".format(Websitecode,datetime.datetime.now(),str(inputid)+'_'+str(Checkin)+'_'+id_update)
        key = bucket.new_key(keyvalue)
        key.set_contents_from_string(hml.text.encode('utf-8'))
        json_data = hml.json()
        if 'available_rooms' in json_data:
            Curr = json_data['property']['site_currency_code']
            for Room_block in json_data['available_rooms']: 
                if 'available_room_count' in Room_block:
                    isAvailable = Room_block['available_room_count']
                else:
                    isAvailable = ''
                if 'room_title' in Room_block:
                    RoomType = re.sub(r'amp;|nbsp;|<.*?>','',str(Room_block['room_title'].encode('utf-8')))
                else:
                    RoomType = ''
                if 'room_amenity_list' in Room_block:
                    Amenities1= Room_block['room_amenity_list']
                    RoomAmenity_Type = re.sub(r'amp;|nbsp;|<.*?>','',str(', '.join(list(Amenities1)).encode('utf-8')))
                else:
                    RoomAmenity_Type = ''
                if 'bedding_paragraph' in Room_block:
                    RateDescription = re.sub(r'amp;|nbsp;|<.*?>','',str(Room_block['bedding_paragraph'].encode('utf-8')))
                else:
                    RateDescription = ''
                if 'max_occupancy_adult' in Room_block:
                    MaxOccupancy = Room_block['max_occupancy_adult']
                else:
                    MaxOccupancy = None
                if 'first_rate' in Room_block:
                    Rateblock = Room_block['first_rate']
                    if 'avg_night' in  Rateblock:
                        OnsiteRate = re.sub(r",|\\u20b9|₹",'',str(Rateblock['avg_night'].encode('utf-8')))
                    else:
                        OnsiteRate = 0
                    if 'rate_label' in  Rateblock:
                        Ratetype = re.sub(r'amp;|nbsp;|<.*?>','',str(Rateblock['rate_label'].encode('utf-8')))
                    else:
                        Ratetype = 0     
                    if 'display_subtotal_key' in Rateblock:
                        tax_type_key = Rateblock['display_subtotal_key']
                        if 'exclusive' in tax_type_key.lower() or 'excluded' in tax_type_key.lower():
                            Taxstatus = 2
                        elif 'inclusive' in tax_type_key.lower() or 'included' in tax_type_key.lower():
                            Taxstatus = 1
                        else:
                            Taxstatus = 0
                    else:
                        Taxstatus = 0
                    Meal = Rateblock['rate_type_policy']['meal_plan']
                    if OnsiteRate==0:
                        statuscode = 1
                        Closed='Y'
                    else:
                        statuscode = ''
                        Closed='N'
                    GrossRate = OnsiteRate
                    Mealtype  = Meal
                    
                else:
                    Ratetype = ''
                    OnsiteRate = 0
                #print RoomType
                #print Ratetype
                #print Curr
                #print 
                #print RoomAmenity_Type
                #print Taxstatus
                #print OnsiteRate
                #print RateDescription
                #print MaxOccupancy
                #print Meal
                #print"_"*100
                if OnsiteRate==0:
                    statuscode = 1
                    Closed='Y'
                else:
                    statuscode = ''
                    Closed='N'
                if LOS >1:
                    israteperstay = 'N'
                else:
                    israteperstay = 'Y'
                GrossRate = OnsiteRate
                Mealtype  = Meal
                array.append(aws_insert.insert(id_update, inputid , Domainname, Websitecode, StartDate, RoomType, LOS, RateDate, Guests, OnsiteRate, NetRate, GrossRate, Curr, RateDescription, url_insert, url_insert, url_insert, RoomAmenity_Type, Mealtype, MaxOccupancy, isPromotionalRate, Closed, 30, StartDate , EndDate, intime, isAvailable, Taxtype, TaxAmount, Taxstatus, None, Ratetype, Discount,Promotion_Name,region,statuscode,israteperstay))
                if Room_block['rates']:
                    for Rateblock in Room_block['rates']:
                        if 'avg_night' in  Rateblock:
                            OnsiteRate = re.sub(r",|\\u20b9|₹",'',str(Rateblock['avg_night'].encode('utf-8')))
                        else:
                            OnsiteRate = 0
                        if 'rate_label' in  Rateblock:
                            Ratetype = re.sub(r'amp;|nbsp;|<.*?>','',str(Rateblock['rate_label'].encode('utf-8')))
                        else:
                            Ratetype = 0     
                        if 'display_subtotal_key' in Rateblock:
                            tax_type_key = Rateblock['display_subtotal_key']
                            if 'exclusive' in tax_type_key.lower() or 'excluded' in tax_type_key.lower():
                                Taxstatus = 2
                            elif 'inclusive' in tax_type_key.lower() or 'included' in tax_type_key.lower():
                                Taxstatus = 1
                            else:
                                Taxstatus = 0
                        else:
                            Taxstatus = 0
                        if OnsiteRate==0:
                            statuscode = 1
                            Closed='Y'
                        else:
                            statuscode = ''
                            Closed='N'
                        GrossRate = OnsiteRate
                        Meal = Rateblock['rate_type_policy']['meal_plan']
                        #print "From Rates--------"
                        #print RoomType
                        #print Ratetype
                        #print Curr
                        #print 
                        #print RoomAmenity_Type
                        #print Taxstatus
                        #print "OnsiteRate", OnsiteRate
                        #print RateDescription
                        #print MaxOccupancy
                        #print Meal
                        #print"_"*100
                        
                        if OnsiteRate==0:
                            statuscode = 1
                            Closed='Y'
                        else:
                            statuscode = ''
                            Closed='N'
                        if LOS >1:
                            israteperstay = 'N'
                        else:
                            israteperstay = 'Y'
                        GrossRate = OnsiteRate
                        Mealtype  = Meal
                        array.append(aws_insert.insert(id_update, inputid , Domainname, Websitecode, StartDate, RoomType, LOS, RateDate, Guests, OnsiteRate, NetRate, GrossRate, Curr, RateDescription, url_insert, url_insert, url_insert, RoomAmenity_Type, Mealtype, MaxOccupancy, isPromotionalRate, Closed, 30, StartDate , EndDate, intime, isAvailable, Taxtype, TaxAmount, Taxstatus, None, Ratetype, Discount,Promotion_Name,region,statuscode,israteperstay)) 
                
        else:
            Closed     = 'Y'
            statuscode ='2'
            array.append(aws_insert.insert(id_update, inputid , Domainname, Websitecode, StartDate, RoomType, LOS, RateDate, Guests, OnsiteRate, NetRate, GrossRate, Curr, RateDescription, url_insert, url_insert, url_insert, RoomAmenity_Type, Mealtype, MaxOccupancy, isPromotionalRate, Closed, 30, StartDate , EndDate, intime, isAvailable, Taxtype, TaxAmount, Taxstatus, None, Ratetype, Discount,Promotion_Name,region,statuscode,israteperstay))
        keyvalue = "ondemand/{}/{:%Y%m%d}/delivery/{}.json".format(Websitecode,datetime.datetime.now(),str(inputid)+'_'+str(RateDate)+'_'+id_update)
        key = bucket.new_key(keyvalue)
        key.set_contents_from_string(json.dumps(array))
        return json.dumps(array)
        gc.collect()
    except Exception as e:
        print e
        value_error = str(re.sub(r"'", '"', str(e)))
        stacktrace = sys.exc_traceback.tb_lineno
        region = ''
        insert_value_error = str(value_error) + 'Where line number ' + str(stacktrace) + str(proxyip)
        statuscode = '4'
        keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(Websitecode, datetime.datetime.now(), id_update)
        key = bucket.new_key(keyvalue)
        key.set_contents_from_string(insert_value_error)
        array.append(aws_insert.insert(id_update, inputid , Domainname, Websitecode, "", "", "", "", Guests, "", "", "", "", "", url, url, url, "", "", "", "", "", "", StartDate, EndDate , "", "", "", "", "", "", "", "", "", region, statuscode,israteperstay))
        return json.dumps(array)
