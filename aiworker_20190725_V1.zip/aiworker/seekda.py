# -*- coding: utf-8 -*-
import re
import requests
import datetime
import json
import boto
import gc

import sys
import aws_insert


'''url='https://s.seekda.com/api/search.json?checkinDate=2017-09-11&checkoutDate=2017-09-12&roomOccupancies=1&properties=S000926&includeTaxes=withInformativeTaxesAndFees&channelID=ibe&targetCurrency=USD&offerDetail=ALL'
proxyip='media:M3diAproxy@192.3.147.133:80'
id_update=''
inputid=''
'''

def fetchrates(url ,inputid, id_update, proxyip):
    array = []
    israteperstay = ''
    intime=re.sub(r'\s','T',str(datetime.datetime.now()))
    conn = boto.connect_s3(aws_access_key_id= 'AKIAIXEGZVXCWE2FV3SQ',aws_secret_access_key = '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') 
    bucket = conn.get_bucket("rmapi")
    WebSiteCode='-325'
    RoomType_dict = {42 : 'Rooms', 3 : 'Suites', 16 : 'Studios', 45 : 'Villas', 13 : 'Apartments', 42 : 'Room', 3 : 'Suite', 16 : 'Studio', 45 : 'Villa', 13 : 'Apartment', 39 : 'Cottage'}
    Mealplan_dict = {1 : 'All inclusive', 10 : 'Full board', 11 : 'Breakfast', 12 : 'Half board', 100 : '3/4 board'}
    try:
        StartDate = datetime.date.today()
        EndDate  = datetime.date.today()+datetime.timedelta(days=29)
        checkin=re.search(r'checkinDate=(.*?)&check',url)
        if checkin:
            chkins=checkin.group(1)
        Curr=re.search(r'targetCurrency=(\w+)',url).group(1)
        #print Curr
        guest=re.search(r'Occupancies=(.*?)&',url)
        if guest:
            adult=guest.group(1)
        else:
            adult=1
        WebSiteName='Seekda.com'
        region=''
        Roomtype=""
        LOS="1"
        RateDate=chkins
        Guests=adult
        onsiterate=0
        Netrate="0"
        RateDescription=""
        MealInclusion_Type=""
        isPromotionalRate='N'
        Closed_up="N"
        isAvailable=""
        promotion=""
        Tax_status=0
        Maxocc = 0
        Taxtype=''
        statuscode=''
        Taxamount=''
        RoomAnmt=''
        RateType=''
        

        proxies = {"http": "http://{}".format(proxyip)}
        region=''
        ip=re.sub(r"\{'.*?@|'\}|:\d+","",str(proxies))
        try:
            try:
                r = requests.get('http://freegeoip.net/json/'+ip,timeout=30)
            except Exception,e:
                print e
                r = requests.get('http://freegeoip.net/json/'+ip,timeout=30)
            js = r.json()
            region=js['country_name']
        except Exception,e:
            print e
            region=''
        head = {'User-Agent':'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:12.0) Gecko/20100101 Firefox/48.0'}
        try:
            hml = requests.get(url, headers=head, proxies = proxies,timeout=50)
            data = requests.get('https://config.seekda.com/channelmanager/conf/room-amenities.xml', proxies = proxies).text
            #print hml.status_code
            ##print "haaa"
        except Exception as e:
            print e
            value_error=str(re.sub("'",'"',str(e)))
            stacktrace=sys.exc_traceback.tb_lineno
            try:
                hml = requests.get(url, headers=head, proxies = proxies,timeout=50)
                data = requests.get('https://config.seekda.com/channelmanager/conf/room-amenities.xml', proxies = proxies).text
            except Exception as e:
                print e
                value_error=str(re.sub("'",'"',str(e)))
                stacktrace=sys.exc_traceback.tb_lineno
                statuscode=5
                keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(WebSiteCode,datetime.datetime.now(),id_update)
                key = bucket.new_key(keyvalue)
                key.set_contents_from_string(str(e))
                Guests=adult
                array.append(aws_insert.insert(id_update, inputid ,"",WebSiteCode, "", "", "", "", Guests, "", "", "", "", "",url, url, url, "", "", "", "", "", "",StartDate, EndDate , "", "", "", "", "", "", "", "", "",region,statuscode, israteperstay))
                return json.dumps(array)
        if (hml.status_code <> 200):
            hml = requests.get(url, headers=head, proxies = proxies)
        if (hml.status_code == 403 or hml.status_code == 407):
            try:
                if hml.status_code <> 200:
                    hml = requests.get(url, headers=head)
            except Exception as e:
                print e
                value_error=str(re.sub("'",'"',str(e)))
                stacktrace=sys.exc_traceback.tb_lineno
                keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(WebSiteCode,datetime.datetime.now(),id_update)
                key = bucket.new_key(keyvalue)
                key.set_contents_from_string(str(e))
                statuscode=5
                Guests=adult
                array.append(aws_insert.insert(id_update, inputid ,"",WebSiteCode, "", "", "", "", Guests, "", "", "", "", "",url, url, url, "", "", "", "", "", "",StartDate, EndDate , "", "", "", "", "", "",  "", "", "",region,statuscode))
                return json.dumps(array)
        jsonvalue = hml.json()
        html = json.loads(hml.text)
        Rtdate=re.sub(r'-|\-','',str(RateDate))
        keyvalue = "ondemand/{}/{:%Y%m%d}/source/{}.json".format(WebSiteCode,datetime.datetime.now(),str(inputid)+'_'+str(Rtdate)+'_'+id_update)
        hml1=json.dumps(html)
        key = bucket.new_key(keyvalue)
        key.set_contents_from_string(hml1)
        
        if jsonvalue['result']:
            for roomdata in jsonvalue['result']['properties'][0]['offers']:
                ##print roomdata
                Netrate = 0
                RoomAnmt = ''
                if roomdata.has_key('totalPrice'):
                    onsiterate = float(roomdata['totalPrice']['netAmount'])
                    onsiterate = onsiterate/100
                    israteperstay = 'Y'
                #print onsiterate
                if roomdata['totalPrice'].has_key('taxes'):
                    Taxamount = float(roomdata['totalPrice']['taxes'])
                    Taxamount = Taxamount/100
                    Tax_status = 2
                RoomAnmt_list = []
                if roomdata['roomOffers'][0].has_key('roomAmenities'):
                    RoomAmenit_Code =roomdata['roomOffers'][0]['roomAmenities']
                    for codes in RoomAmenit_Code:
                        ##print codes
                        regex = '<seekda:Item Type="RAT" Code="'+str(codes)+'">\s*<dc:title xml:lang="EN">(.*?)</dc:title>'
                        ##print regex
                        RoomAnmt_reg = re.search(regex, data) 
                        if RoomAnmt_reg:
                            RoomAnmt_grou = RoomAnmt_reg.group(1)
                            RoomAnmt_list.append(RoomAnmt_grou)
                            ##print RoomAnmt_list
                            RoomAnmt = re.sub('u\\"|\\"', "", re.sub("\[|\]|u'|'", "", str(RoomAnmt_list)))
                    ##print RoomAnmt
                    RateType =re.sub("\[|\]|u'|'", "", str(roomdata['roomOffers'][0]['ratePolicyTypes']))
                    ##print RateType
                if roomdata['roomOffers'][0]['roomType']:
                    RoomType_code = roomdata['roomOffers'][0]['roomType']
                    Roomtype = RoomType_dict[int(RoomType_code)]
                    ##print Roomtype
                if roomdata['roomOffers'][0]['mealPlanCode']:
                    Mealplan_code = roomdata['roomOffers'][0]['mealPlanCode']
                    ##print Mealplan_code
                    MealInclusion_Type = Mealplan_dict[int(Mealplan_code)]
                    ##print MealInclusion_Type
                if roomdata['roomOffers'][0]['maxOccupancy']:
                    Maxocc = roomdata['roomOffers'][0]['maxOccupancy']
                ##print Maxocc
                
                if str(onsiterate) =='0' or str(onsiterate) =='0.0':
                    statuscode='1'
                    Closed_up='Y'
                else:
                    statuscode=''
                    Closed_up='N'
                array.append(aws_insert.insert(id_update,inputid ,WebSiteName,WebSiteCode,StartDate,Roomtype,LOS,RateDate,Guests,onsiterate,Netrate,onsiterate,Curr,RateDescription,url,url,url,RoomAnmt,MealInclusion_Type,Maxocc,isPromotionalRate,Closed_up,30,StartDate ,EndDate,intime,isAvailable,Taxtype,Taxamount,Tax_status,None,RateType,Netrate,promotion,region,statuscode, israteperstay))
                ##print (id_update,inputid ,WebSiteName,WebSiteCode,StartDate,Roomtype,LOS,RateDate,Guests,onsiterate,Netrate,onsiterate,Curr,RateDescription,url,url,url,RoomAnmt,MealInclusion_Type,Maxocc,isPromotionalRate,Closed_up,30,StartDate ,EndDate,intime,isAvailable,Taxtype,Taxamount,Tax_status,None,RateType,Netrate,promotion,region,statuscode)
        else:
            Closed_up = "Y"
            statuscode='2'
            WebSiteCode='-325'
            array.append(aws_insert.insert(id_update,inputid ,WebSiteName,WebSiteCode,StartDate,Roomtype,LOS,RateDate,Guests,onsiterate,Netrate,onsiterate,Curr,RateDescription,url,url,url,RoomAnmt,MealInclusion_Type,Maxocc,isPromotionalRate,Closed_up,30,StartDate ,EndDate,intime,isAvailable,Taxtype,Taxamount,Tax_status,None,RateType,Netrate,promotion,region,statuscode, israteperstay))
            ##print (id_update,inputid ,WebSiteName,WebSiteCode,StartDate,Roomtype,LOS,RateDate,Guests,onsiterate,Netrate,onsiterate,Curr,RateDescription,url,url,url,RoomAnmt,MealInclusion_Type,Maxocc,isPromotionalRate,Closed_up,30,StartDate ,EndDate,intime,isAvailable,Taxtype,Taxamount,Tax_status,None,RateType,Netrate,promotion,region,statuscode)
            ##print (id_update, inputid , Domainname, Websitecode, StartDate, Roomtype, LOS, RateDate, Guests, OnsiteRate, net_rate, GrossRate, Currencycode, RoomDescp, url, url, url, RoomAmenityType, Mealtype, Maxocp, ispromupdate, Closed_up, 30, StartDate , EndDate, intime, Roomavilable, Taxtype, Taxamount, Tax_status,'', Ratetype, discount_rate,promotion,region,statuscode)
        Rtdate=re.sub(r'-|\-','',str(RateDate))
        keyvalue = "ondemand/{}/{:%Y%m%d}/delivery/{}.json".format(WebSiteCode,datetime.datetime.now(),str(inputid)+'_'+str(Rtdate)+'_'+id_update)
        key = bucket.new_key(keyvalue)
        key.set_contents_from_string(json.dumps(array))
        return json.dumps(array)
        gc.collect()
    except Exception as e:
        value_error=str(re.sub(r"'",'"',str(e)))
        stacktrace=sys.exc_traceback.tb_lineno
        insert_value_error=str(value_error)+'Where line number '+str(stacktrace)+str(proxyip)
        statuscode='4'
        print insert_value_error
        keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(WebSiteCode,datetime.datetime.now(),id_update)
        key = bucket.new_key(keyvalue)
        key.set_contents_from_string(insert_value_error)
        array.append(aws_insert.insert(id_update, inputid ,"",WebSiteCode, "", "", "", "", Guests, "", "", "", "", "",url, url, url, "", "", "", "", "", "",StartDate, EndDate , "", "", "", "", "", "", "", "", "",region,statuscode, israteperstay))
        return json.dumps(array)
#fetchrates(url ,inputid, id_update, proxyip)

