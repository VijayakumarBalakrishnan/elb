# -*- coding: utf-8 -*-
import re
import requests
import datetime
import json
import sys 
import boto
import gc

import aws_insert

#array =[]

def fetchrates(url,inputid,id_update,proxyip):
	array = []
	israteperstay = ''
	intime=re.sub(r'\s','T',str(datetime.datetime.now()))
	functionname='Americasinn'
	try:
		conn = boto.connect_s3(aws_access_key_id= 'AKIAIXEGZVXCWE2FV3SQ',aws_secret_access_key = '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') 
		bucket = conn.get_bucket("rmapi")
		Chekin = re.search(r"checkin=(.*?)&",url).group(1)	
		RateDate = Chekin
		Chkin = datetime.datetime.strptime(Chekin,str('%Y-%m-%d')).strftime('%m-%d-%Y')
		chkin_re = re.sub('-','%2f',Chkin)
		Chek_in = "checkin="+chkin_re+'&'
		url = re.sub("checkin=(.*?)&",Chek_in,url)
		
		StartDate = datetime.date.today()
		EndDate  = datetime.date.today() + datetime.timedelta(days=29)
		
		WebSiteName="americasinn.net"
		WebsiteCode = '204'
		RoomType = ""
		RateType=''
		Guests = 1
		OnsiteRate = 0
		Closed_up = 'N'
		MealInclusion_Type = " "
		RateDescription = " "
		RoomAmenity_Type = ""
		Netrate=0
		Isprom=''
		isAvailable=''
		MaxOccupancy=''
		promotion = ''
		statuscode = ''
		Curr=''
		Isprom = 'N'   
		proxies = {"http": "http://{}".format(proxyip)}

		try:
			hml = requests.get(url, headers={'User-Agent':'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:12.0) Gecko/20100101 Firefox/12.0'},proxies=proxies,timeout=50)
			##print hml.status_code
		except Exception,e:
			print e
			es=re.sub(r"'",'',e)
			value_error=str(es)
			stacktrace=sys.exc_traceback.tb_lineno
			try:
				hml = requests.get(url, headers={'User-Agent':'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:12.0) Gecko/20100101 Firefox/12.0'},proxies=proxies,timeout=50)
			except Exception,e:
				value_error=str(e)
				stacktrace=sys.exc_traceback.tb_lineno
				keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(WebsiteCode,datetime.datetime.now(),id_update)
				#print keyvalue
				key = bucket.new_key(keyvalue)
				key.set_contents_from_string(str(e))
				statuscode=5
				Guests='1'
				array.append(aws_insert.insert(id_update, inputid ,functionname,WebsiteCode, "", "", "", "", Guests, "", "", "", "", "",url, url, url, "", "", "", "", "", "",StartDate, EndDate , "", "", "", "", "", "", "", "", "", "",statuscode, israteperstay))
				return json.dumps(array) 
		if (hml.status_code <> 200):
			hml = requests.get(url, headers={'User-Agent':'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:12.0) Gecko/20100101 Firefox/12.0'},proxies=proxies)
		
		if (hml.status_code == 403 or hml.status_code == 407):
			try:		
				proxyresult = requests.get('http://www.gimmeproxy.com/api/getProxy?protocol=http')
				jproxy = json.loads(proxyresult.content)
				proxies = { "http": jproxy["curl"] }
				hml = requests.get(url, headers={'User-Agent':'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:12.0) Gecko/20100101 Firefox/12.0'}, proxies = proxies)
				if (hml.status_code <> 200):
					hml = requests.get(url, headers={'User-Agent':'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:12.0) Gecko/20100101 Firefox/12.0'})
			except Exception,e:
				value_error=str(e)
				stacktrace=sys.exc_traceback.tb_lineno
				keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(WebsiteCode,datetime.datetime.now(),id_update)
				#print keyvalue
				key = bucket.new_key(keyvalue)
				key.set_contents_from_string(str(e))
				statuscode=5
				Guests='1'
				array.append(aws_insert.insert(id_update, inputid ,functionname,WebsiteCode, "", "", "", "", Guests, "", "", "", "", "",url, url, url, "", "", "", "", "", "",StartDate, EndDate , "", "", "", "", "", "", "", "", "", "",statuscode, israteperstay))
				return json.dumps(array)    	    

		html = hml.text
		html = html.encode('ascii', 'ignore')
		WebsiteCode = '204'
		Rtdate=re.sub(r'-|\-','',str(RateDate))
		keyvalue = "ondemand/{}/{:%Y%m%d}/source/{}.html".format(WebsiteCode,datetime.datetime.now(),str(inputid)+'_'+str(Rtdate)+'_'+id_update)
		#print keyvalue
		key = bucket.new_key(keyvalue)
		key.set_contents_from_string(html)
		#soup_test=unicode.join(u'\n',map(unicode,soup))
		##print "soup	:",type(soup_test)
		##print html_write
		
		if re.search('<h2 class="roomtypename">\s*<a id="MainContent_MyResultRoom_rptRoomTypeNames.*?>(.*?)<', html):
			for mainblock in re.compile(r'<h2 class="roomtypename">.*?</tbody></table>\s*</div>',re.DOTALL).findall(html):
				for block in re.compile(r'<tr id="MainContent_MyResultRoom_.*?</tr', re.DOTALL).findall(mainblock):
					Room_type   = ''
					Closed_up   = 'N'
					Room_type   = ''
					onsite_rate = 0
					Room_type_re = re.search(r'<h2 class="roomtypename">\s*<a id="MainContent_MyResultRoom_rptRoomTypeNames.*?>(.*?)<', mainblock)
					if  Room_type_re:
						Room_type = Room_type_re.group(1)
						RoomType = re.sub("'", "''", Room_type)
						
					Max_ocp = re.search(r'total_room_available":(.*?)\n', mainblock)
					if Max_ocp:
						isAvailable = Max_ocp.group(1)
						
					Room_desp = re.search(r'<p class="roomdesc">\s*(.*?)\s*<', mainblock)
					if Room_desp:
						RateDescription = re.sub("'", "''", Room_desp.group(1))
						
					Rate_type_re = re.search(r'<td>\s*<a id="MainContent_MyResultRoom_rptRoomTypeNames_rptRates.*?currencycode=.*?">(.*?)<', mainblock) 
					if Rate_type_re:
						RateType = re.sub("'", "''", Rate_type_re.group(1))  
						
					onsite_rate = re.search(r'class="currencyamount">(.*?)<', mainblock)
					if onsite_rate:
						OnsiteRate = onsite_rate.group(1)
						
					if re.search(r'span class="currencycode">([A-z].*?)&', block):
						Curr = re.search(r'span class="currencycode">([A-z].*?)&', block).group(1)
					
					if re.search(r'<ul id="MainContent_MyResultRoom.*?>\s*(.*?)\s*</ul', mainblock):
						Ameints_replace = re.search(r'<ul id="MainContent_MyResultRoom.*?>\s*(.*?)\s*</ul', mainblock).group(1)
						Ameints_replac  = re.sub(r"</li><li>", r'","',Ameints_replace)
						RoomAmenity_Type         = re.sub(r'^<.*?>|<.*?>$',r'"',Ameints_replac)
					da_time = datetime.datetime.now()
					intime = re.sub(r'\s','T',str(da_time))

										
					array.append(aws_insert.insert(id_update, inputid, WebSiteName, WebsiteCode, StartDate, RoomType,1, RateDate, Guests, OnsiteRate, Netrate, OnsiteRate, Curr, RateDescription, url, url, url, RoomAmenity_Type, MealInclusion_Type,MaxOccupancy, Isprom, Closed_up, 48, StartDate, EndDate, intime,isAvailable,None,None,"",None,RateType,Netrate,promotion,"",statuscode, israteperstay))
		else:
			#print "else"
			Closed_up = "Y"
			statuscode=2
			array.append(aws_insert.insert(id_update, inputid, WebSiteName, WebsiteCode, StartDate, RoomType,1, RateDate, Guests, OnsiteRate, Netrate, OnsiteRate, Curr, RateDescription, url, url, url, RoomAmenity_Type, MealInclusion_Type,MaxOccupancy, Isprom, Closed_up, 48, StartDate, EndDate, intime,isAvailable,None,None,"",None,RateType,Netrate,promotion,"",statuscode, israteperstay))
	
		keyvalue = "ondemand/{}/{:%Y%m%d}/delivery/{}.json".format(WebsiteCode,datetime.datetime.now(),str(inputid)+'_'+str(RateDate)+'_'+id_update)
		key = bucket.new_key(keyvalue)
		key.set_contents_from_string(json.dumps(array))
		return json.dumps(array)
		gc.collect()
	except Exception,e:
		value_error=str(re.sub(r"'",'"',str(e)))
		stacktrace=sys.exc_traceback.tb_lineno
		insert_value_error=str(value_error)+'Where line number '+str(stacktrace)+str(proxyip)
		statuscode='4'
		WebsiteCode='204'
		keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(WebsiteCode,datetime.datetime.now(),id_update)
		key = bucket.new_key(keyvalue)
		key.set_contents_from_string(insert_value_error)
		Guests='1'
		array.append(aws_insert.insert(id_update, inputid ,functionname,WebsiteCode, "", "", "", "", Guests, "", "", "", "", "",url, url, url, "", "", "", "", "", "",StartDate, EndDate , "", "", "", "", "", "", "", "", "", "",statuscode, israteperstay))
		return json.dumps(array)
