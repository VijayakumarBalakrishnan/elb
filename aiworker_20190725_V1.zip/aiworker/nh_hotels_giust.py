# -*- coding: utf-8 -*-
import re
import requests
import datetime
import json
import sys 
import boto
import gc

import aws_insert

def fetchrates(url,inputid,id_update,proxyip):
    array      = []
    sr  = requests.session()
    intime     = re.sub(r'\s','T',str(datetime.datetime.now()))
    Domainname ='nh-hotels.GIUST'
    Websitecode='367'
    region     =''
    proxies    = {"https": "http://{}".format(proxyip)}
    statuscode =''
    israteperstay = ''
    try:
        conn   = boto.connect_s3(aws_access_key_id= 'AKIAIXEGZVXCWE2FV3SQ',aws_secret_access_key = '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') 
        bucket = conn.get_bucket("rmapi")
        StartDate = datetime.date.today()
        EndDate   = datetime.date.today() + datetime.timedelta(days=29)
        CheckIn_Check_OT_re = re.search(r'fini=(.*?)&fout=(.*?)&',url)
        if CheckIn_Check_OT_re:
            Checkin  = CheckIn_Check_OT_re.group(1)
            Checkout = CheckIn_Check_OT_re.group(2)
            Checkin_URL = datetime.datetime.strptime(str(CheckIn_Check_OT_re.group(1)),'%Y-%m-%d').strftime('%d/%m/%Y')
            CheckOT_URL = datetime.datetime.strptime(str(CheckIn_Check_OT_re.group(2)),'%Y-%m-%d').strftime('%d/%m/%Y')
        else:
            Checkin  = ''
            Checkout = ''
            Checkin_URL = ''
            CheckOT_URL = ''
        #print Checkin,Checkout
        Checkinout_URL = 'fini='+Checkin_URL+'&fout='+CheckOT_URL+'&'
        url = re.sub(r"fini.*?fout.*?&",Checkinout_URL,url)
        #print url
        RateDate = Checkin
        delta    = datetime.datetime.strptime(Checkout, "%Y-%m-%d") - datetime.datetime.strptime(Checkin, "%Y-%m-%d")
        LOS      = delta.days
        RoomType = ''
        Guests   = re.search(r'nadults1=(\d+)&', url).group(1)
        #print Guests
        Ratetype = ''
        Mealtype = ''
        RateDescription = ''
        Taxtype  = ''
        Curr     = ''
        MaxOccupancy = None
        isPromotionalRate  = 'N'
        Closed   = 'Y'
        NetRate  = 0
        Taxstatus= -1
        TaxAmount= 0
        Discount = 0
        GrossRate= 0
        OnsiteRate = 0
        Curr     = ''
        Promotion_Name= ''
        isAvailable = ''
        RoomAmenity_Type = ''
        url_insert = url
        head = {'User-Agent':'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36'}
        ip = re.sub(r"\{'.*?@|'\}|:\d+", "", str(proxies))
        try:
            try:
                r = requests.get('http://freegeoip.net/json/' + ip, timeout=30)
            except Exception, e:
                r = requests.get('http://freegeoip.net/json/' + ip, timeout=30)
            js = r.json()
            region = js['country_name']
        except Exception, e:
            region = ''
        try:
            htm = requests.get(url,headers = head,proxies = proxies,timeout=100)
            
        except Exception, e:
            value_error = str(re.sub("'", '', str(e)))
            stacktrace = sys.exc_traceback.tb_lineno
            try:
                htm = requests.get(url,headers = head,proxies = proxies,timeout=120)
            except Exception, e:
                try:
                    htm = requests.get(url,headers = head,proxies = proxies,timeout=150)
                except Exception, e:
                    value_error = str(re.sub("'", '', str(e)))
                    stacktrace = sys.exc_traceback.tb_lineno
                    keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(Websitecode, datetime.datetime.now(), id_update)
                    key = bucket.new_key(keyvalue)
                    key.set_contents_from_string(str(e) + 'Where Line number' + str(stacktrace) + str(proxies))
                    statuscode = 5
                    Guests = ''
                    array.append(aws_insert.insert(id_update, inputid , Domainname, Websitecode, "", "", "", "", Guests, "", "", "", "", "", url, url, url, "", "", "", "", "", "", StartDate, EndDate , "", "", "", "", "", "", "", "", "", region, statuscode, israteperstay))
                    return json.dumps(array)
        if htm.status_code <> 200:
            htm = requests.get(url,headers = head,proxies = proxies)
        if (htm.status_code == 403 or htm.status_code == 407) or htm.status_code <> 200:
            try:
                if htm.status_code <> 200:
                    htm = requests.get(url,headers = head)
            except Exception, e:
                Closed    = 'Y'
                value_error = str(re.sub("'", '', str(e)))
                stacktrace = sys.exc_traceback.tb_lineno
                keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(Websitecode, datetime.datetime.now(), id_update)
                key = bucket.new_key(keyvalue)
                key.set_contents_from_string(str(e) + 'Where Line number' + str(stacktrace) + str(proxies))
                statuscode = 5
                Guests = ''
                array.append(aws_insert.insert(id_update, inputid , Domainname, Websitecode, "", "", "", "", Guests, "", "", "", "", "", url, url, url, "", "", "", "", "", "", StartDate, EndDate , "", "", "", "", "", "", "", "", "", region, statuscode, israteperstay))
                return json.dumps(array)
        source = htm.text.encode('ascii','ignore')
        keyvalue = "ondemand/{}/{:%Y%m%d}/source/{}.html".format(Websitecode,datetime.datetime.now(),str(inputid)+'_'+str(Checkin)+'_'+id_update)
        key = bucket.new_key(keyvalue)
        key.set_contents_from_string(json.dumps(source))
            
        if re.search(r'<div class="tab-pane fade.*?</section>\s*</div>',source,re.DOTALL):
            for block_re in re.compile(r'<div class="tab-pane fade.*?</section>\s*</div>',re.DOTALL).findall(source):
                if 'data-track="rewards' not in block_re:
                    for block1 in re.compile(r'<section class="grid-rates.*?</section>', re.DOTALL).findall(block_re):
                        for block in re.compile(r'<p class="name-room">.*?</div>\s*</div>\s*</div>',re.DOTALL).findall(block1):
                            RoomType   = ''
                            Ratetype   = ''
                            GrossRate  = 0
                            OnsiteRate = 0
                            NetRate    = 0
                            MaxOccupancy = None
                            Taxstatus    = -1
                            isPromotionalRate = 'N'
                            RoomAmenity_Type  = ''
                            RateDescription   = ''
                            Roomtype_re = re.search(r'<h2 class="h2 text-color-black">(.*?)<', block1)
                            if Roomtype_re:
                                RomType = Roomtype_re.group(1)
                                RoomType = re.sub(r"'","''",re.sub(r'&.*?;',' ',RomType).strip())
                            else:
                                RoomType = ''
                            '''Ratetype1_re = re.search('class="title-rate">(.*?)<', block1)
                            if Ratetype1_re:
                                Ratetype1 = Ratetype1_re.group(1)
                            else:
                                Ratetype1 = '''''
                            Ratetype2_re = re.search('name-room">.*?</p>(.*?)</div>', block,re.DOTALL)
                            if Ratetype2_re:
                                Ratetype2_grp = re.sub(r"<.*?>","",Ratetype2_re.group(1))
                                Ratetype2     = re.sub(r"\s\s+","",Ratetype2_grp)
                            else:
                                Ratetype2 = ''
                            Ratetype_re = re.search(r'class="name-room">(.*?)<', block)   
                            if Ratetype_re:
                                Ratetype = re.sub(r"'","''",Ratetype_re.group(1))
                            else:
                                Ratetype = ''
                            Ratetype  = Ratetype+" "+Ratetype2
                            price_re = re.search(r'<span class="price">(.*?)</span>', block)
                            if price_re:
                                OnsiteRate = re.sub(r"<.*?>","",(price_re.group(1)))
                                OnsiteRate = re.sub(r"amp;|\(.*?\)|'|\$|,",'',OnsiteRate)
                            else:
                                OnsiteRate = 0
                            GrossRate = OnsiteRate
                            strike_re = re.search(r'class="price-offer">(.*?)</span>', block, re.DOTALL)
                            if strike_re:
                                NetRate  = re.sub(r"\s\s+|<.*?>","",strike_re.group(1)).strip()
                                isPromotionalRate  = 'Y'
                            else:
                                NetRate = 0
                                isPromotionalRate  = 'N'
                            Max_re = re.search(r'margin-b-5 small">Max.*?guests:\s(\d+)', block1)
                            if Max_re:
                                MaxOccupancy = Max_re.group(1)
                            else:
                                MaxOccupancy = None
                                
                            curr_re = re.search(r'js-currency">(.*?)<', block, re.IGNORECASE)
                            if curr_re:
                                Curr = curr_re.group(1)
                                if ("USD" in Curr) or ("usd" in Curr):
                                    Curr = 'USD'
                            else:
                                Curr  = ''
                            if re.compile(r'ist-inline no-padding">\s*(<li.*?)</ul>',re.DOTALL).findall(block1):
                                for amenity1_re in re.compile(r'ist-inline no-padding">\s*(<li.*?)</ul>',re.DOTALL).findall(block1):
                                    Amenity1 = re.findall(r'data-original-title="(.*?)">', amenity1_re)
                                    if Amenity1:
                                        Amenities1 = re.sub(r"'|\[|\]","",str(Amenity1))
                                    else:
                                        Amenities1 = ''
                            else:
                                Amenities1 = ''
                            if re.compile(r'list-inline">.*?</ul>',re.DOTALL).findall(block):
                                for amenity2_re in re.compile(r'list-inline">.*?</ul>',re.DOTALL).findall(block):
                                    Amenity2 = re.findall(r'data-original-title="(.*?)">', amenity2_re)
                                    if Amenity2:
                                        Amenities2 = re.sub(r"'|\[|\]","",str(Amenity2))
                                    else:
                                        Amenities2 = ''
                            else:
                                Amenities2 = ''
                            RoomAmenity_Type1 = Amenities1+", "+Amenities2.strip()
                            RoomAmenity_Type = re.sub(r'^,','',RoomAmenity_Type1).strip()
                            RoomAmenity_Type = re.sub(r"'","''",RoomAmenity_Type)
                            description_re = re.search(r'<p class="no-padding margin.*?>(.*?)</p>', block1, re.DOTALL)
                            if description_re:
                                description_grp    = description_re.group(1)
                                description_clean1 = re.sub(r"</li>|<br>",",",description_grp)
                                description_clean2 = re.sub(r"<.*?>|\s\s+","",description_clean1)
                                RateDescription    = re.sub(r",,",",",re.sub(r"\s\s+","",description_clean2))
                            else:
                                RateDescription = ''
                            RateDescription = re.sub(r"'","''",RateDescription)
                            Mealtypes = str(RateDescription)+' '+str(RoomAmenity_Type)+' '+str(RoomType)+''+str(Ratetype)
                            if Mealtypes !=None:
                                Mealtype_str = str(Mealtypes)
                                if 'breakfast' in Mealtype_str.lower() and 'dinner' in Mealtype_str.lower()  and 'lunch' in Mealtype_str.lower():
                                    Meal = 'Breakfast, Lunch and Dinner'
                                elif 'breakfast' in Mealtype_str.lower() and 'dinner' in Mealtype_str.lower():
                                    Meal = 'Breakfast and dinner'
                                elif 'breakfast included' in Mealtype_str.lower():
                                    Meal = 'Breakfast included'
                                elif 'BREAKFAST' in Mealtype_str:
                                    Meal = 'Breakfast'
                                elif 'breakfast' in Mealtype_str.lower() and 'lunch' in Mealtype_str.lower():
                                    Meal = 'Breakfast and Lunch'
                                elif 'Lunch' in Mealtype_str and 'Dinner' in Mealtype_str :
                                    Meal = "Lunch and Dinner"
                                elif 'breakfast' in Mealtype_str.lower() and 'lunch' in Mealtype_str.lower() and 'dinner' in Mealtype_str.lower():
                                    Meal = 'Breakfast, Lunch and dinner'
                                elif 'Break fast' in Mealtype_str:
                                    Meal = 'BreakFast' 
                                elif 'breakfast' in Mealtype_str.lower():
                                    Meal = 'BreakFast' 
                                elif 'halfboard' in Mealtype_str.lower():
                                    Meal = 'Halfboard'
                                elif 'half board' in Mealtype_str.lower():
                                    Meal = 'Half board' 
                                elif 'full board' in Mealtype_str.lower():
                                    Meal = 'Full Board'
                                elif 'fullboard' in Mealtype_str.lower():
                                    Meal = 'FullBoard'
                                elif 'All-Inclusive' in Mealtype_str:
                                    Meal = 'All-Inclusive'
                                elif 'All Inclusive' in Mealtype_str:
                                    Meal = 'All Inclusive'
                                elif 'All Meals' in Mealtype_str:
                                    Meal = 'All Meals'
                                elif 'All Meal' in Mealtype_str:
                                    Meal = 'All Meal'
                                else:
                                    Meal = ''
                            else:
                                Meal = ''    
                            Mealtype = Meal
                            taxtype_re = re.search(r'city tax tcm.*?>\s*(.*?)\s*</small>', block1)
                            if taxtype_re:
                                Taxtype   = re.sub(r"'","''",taxtype_re.group(1))
                                Taxstatus = 1
                            else:
                                Taxtype = ''
                            if OnsiteRate==0:
                                statuscode = 1
                                Closed='Y'
                            else:
                                statuscode = ''
                                Closed='N'
                            LOS = int(LOS)
                            if int(LOS) >1:
                                israteperstay = 'N'
                            else:
                                israteperstay = 'Y'
                            #print "RoomType         :",RoomType          
                            #print "Ratetype         :",Ratetype          
                            #print "price            :",OnsiteRate  
                            #print "NetRate          :",NetRate           
                            #print "RateDescription  :",RateDescription  
                            #print "Currency         :",Curr
                            #print "RoomAmenity_Type :",RoomAmenity_Type
                            #print "MaxOccupancy     :",MaxOccupancy
                            #print "Taxtype          :",Taxtype
                            #print"$"*40
                            #print (id_update, inputid , Domainname, Websitecode, StartDate, RoomType, LOS, RateDate, Guests, OnsiteRate, NetRate, GrossRate, Curr, RateDescription, url_insert, url_insert, url_insert, RoomAmenity_Type, Mealtype, MaxOccupancy, isPromotionalRate, Closed, 30, StartDate , EndDate, intime, isAvailable, Taxtype, TaxAmount, Taxstatus, None, Ratetype, Discount,Promotion_Name,region,statuscode, israteperstay)
                            array.append(aws_insert.insert(id_update, inputid , Domainname, Websitecode, StartDate, RoomType, LOS, RateDate, Guests, OnsiteRate, NetRate, GrossRate, Curr, RateDescription, url_insert, url_insert, url_insert, RoomAmenity_Type, Mealtype, MaxOccupancy, isPromotionalRate, Closed, 30, StartDate , EndDate, intime, isAvailable, Taxtype, TaxAmount, Taxstatus, None, Ratetype, Discount,Promotion_Name,region,statuscode, israteperstay))
        else:
            Closed     = 'Y'
            statuscode = '2'
            Taxstatus  =  0
            #print (id_update, inputid , Domainname, Websitecode, StartDate, RoomType, LOS, RateDate, Guests, OnsiteRate, NetRate, GrossRate, Curr, RateDescription, url_insert, url_insert, url_insert, RoomAmenity_Type, Mealtype, MaxOccupancy, isPromotionalRate, Closed, 30, StartDate , EndDate, intime, isAvailable, Taxtype, TaxAmount, Taxstatus, None, Ratetype, Discount,Promotion_Name,region,statuscode, israteperstay)
            array.append(aws_insert.insert(id_update, inputid , Domainname, Websitecode, StartDate, RoomType, LOS, RateDate, Guests, OnsiteRate, NetRate, GrossRate, Curr, RateDescription, url_insert, url_insert, url_insert, RoomAmenity_Type, Mealtype, MaxOccupancy, isPromotionalRate, Closed, 30, StartDate , EndDate, intime, isAvailable, Taxtype, TaxAmount, Taxstatus, None, Ratetype, Discount,Promotion_Name,region,statuscode, israteperstay))
        keyvalue = "ondemand/{}/{:%Y%m%d}/delivery/{}.json".format(Websitecode,datetime.datetime.now(),str(inputid)+'_'+str(RateDate)+'_'+id_update)
        key = bucket.new_key(keyvalue)
        key.set_contents_from_string(json.dumps(array))
        return json.dumps(array)
        gc.collect()
    except Exception as e:
        print e
        value_error = str(re.sub(r"'", '"', str(e)))
        stacktrace = sys.exc_traceback.tb_lineno
        Guests = ''
        region = ''
        statuscode = '4'
        array.append(aws_insert.insert(id_update, inputid , Domainname, Websitecode, "", "", "", "", Guests, "", "", "", "", "", url, url, url, "", "", "", "", "", "", StartDate, EndDate , "", "", "", "", "", "", "", "", "", region, statuscode, israteperstay))
        keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.json".format(Websitecode,datetime.datetime.now(),str(inputid)+'_'+str(RateDate)+'_'+id_update)
        key = bucket.new_key(keyvalue)
        key.set_contents_from_string(json.dumps(value_error))
        return json.dumps(array)
