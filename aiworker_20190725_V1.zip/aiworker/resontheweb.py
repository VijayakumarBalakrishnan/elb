# -*- coding: utf-8 -*-
import re,requests
import datetime
import json
import boto,gc,sys

import aws_insert

def fetchrates(url,inputid,id_update,proxyip):
    array      = []
    sr         = requests.session()
    proxies    = {"https": "http://{}".format(proxyip)}
    intime     = re.sub(r'\s','T',str(datetime.datetime.now()))
    Domainname = 'thecadillachotel.com'
    Websitecode= '48'
    region     = ''
    statuscode = ''
    Mealtype   = ''
    israteperstay = ''
    try:
        conn   = boto.connect_s3(aws_access_key_id= 'AKIAIXEGZVXCWE2FV3SQ',aws_secret_access_key = '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') 
        bucket = conn.get_bucket("rmapi")
        StartDate = datetime.date.today()
        EndDate   = datetime.date.today() + datetime.timedelta(days=29)
        CheckIn_Check_OT_re = re.search(r'f201=(.*?)&f202=(.*?)&',url)
        if CheckIn_Check_OT_re:
            Checkin  = CheckIn_Check_OT_re.group(1)
            Checkout = CheckIn_Check_OT_re.group(2)
            Checkin_URL = datetime.datetime.strptime(str(CheckIn_Check_OT_re.group(1)),'%Y-%m-%d').strftime('%Y%m%d')
            CheckOT_URL = datetime.datetime.strptime(str(CheckIn_Check_OT_re.group(2)),'%Y-%m-%d').strftime('%Y%m%d')
        else:
            Checkin  = ''
            Checkout = ''
            Checkin_URL = ''
            CheckOT_URL = ''
        Checkinout_URL = 'f201='+Checkin_URL+'&f202='+CheckOT_URL+'&'
        url = re.sub(r"f201=.*?f202=.*?&",Checkinout_URL,url)
        #print url
        RateDate = Checkin
        delta    = datetime.datetime.strptime(Checkout, "%Y-%m-%d") - datetime.datetime.strptime(Checkin, "%Y-%m-%d")
        LOS      = delta.days
        RoomType = ''
        Guests   = 0
        Guests   = re.search(r'f224=(\d)', url).group(1)
        #print Guests,LOS
        Ratetype = ''
        RateDescription = ''
        Taxtype  = ''
        Curr     = ''
        MaxOccupancy = None
        isPromotionalRate  = 'N'
        Closed   = 'Y'
        NetRate  = 0
        Taxstatus= -1
        TaxAmount= 0
        Discount = 0
        GrossRate= 0
        OnsiteRate = 0
        Curr     = ''
        Promotion_Name= ''
        isAvailable = ''
        RoomAmenity_Type = ''
        url_insert = url
        head1 = {"User-Agent":"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36"}
        ip = re.sub(r"\{'.*?@|'\}|:\d+", "", str(proxies))
        try:
            R_htm  = requests.get(url, headers = head1,proxies = proxies)
        except:
            R_htm  = requests.get(url, headers = head1)
        R_html = R_htm.text.encode('ascii','ignore')
        WindowID = re.search(r'WindowID".*?value="(.*?)"', R_html)
        if WindowID:
            WindowID = WindowID.group(1)
        else:
            WindowID = ''
        datein  = datetime.datetime.strptime(Checkin, "%Y-%m-%d").strftime('%B %d,%Y')
        dateOut = datetime.datetime.strptime(Checkout, "%Y-%m-%d").strftime('%B %d,%Y')
        #print datein,dateOut,WindowID
        HotelCode = re.search(r'HotelCode=(.*?)&',url).group(1)
        night = str(LOS)+" night stay"
        load = {"WindowID":WindowID,"HotelCode":HotelCode,"JSPName":"/templates/CustomHv9.jsp","JSPNumber":"65","f100":"116","f236":"0","f201":datein,"f202":dateOut,"nights":night,"f224":Guests,"f225":"0","f226":"0"}
        head = {"Host":"www.resontheweb.com","Connection":"keep-alive","Content-Length":"214","Cache-Control":"max-age=0","Origin":"https://www.resontheweb.com","Upgrade-Insecure-Requests":"1","User-Agent":"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36","Content-Type":"application/x-www-form-urlencoded","Accept":"text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8","Referer":url,"Accept-Encoding":"gzip, deflate, br","Accept-Language":"en-GB,en-US;q=0.8,en;q=0.6"}
        url_main = 'https://www.resontheweb.com/NavigationServlet'
        #print "URL",url
        try:
            try:
                r = sr.get('http://freegeoip.net/json/' + ip, timeout=30)
            except Exception, e:
                r = sr.get('http://freegeoip.net/json/' + ip, timeout=30)
            js = r.json()
            region = js['country_name']
        except Exception, e:
            region = ''
        try:
            htm = requests.post(url_main,data = load,headers = head,timeout=100)
        except Exception, e:
            value_error = str(re.sub("'", '', str(e)))
            stacktrace = sys.exc_traceback.tb_lineno
            try:
                htm = requests.post(url_main,data = load,headers = head,timeout=120)
            except Exception, e:
                try:
                    htm = requests.post(url_main,data = load,headers = head,timeout=150)
                except Exception, e:
                    value_error = str(re.sub("'", '', str(e)))
                    stacktrace = sys.exc_traceback.tb_lineno
                    keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(Websitecode, datetime.datetime.now(), id_update)
                    key = bucket.new_key(keyvalue)
                    key.set_contents_from_string(str(e) + 'Where Line number' + str(stacktrace) + str(proxies))
                    statuscode = 5
                    Guests = ''
                    array.append(aws_insert.insert(id_update, inputid , Domainname, Websitecode, "", "", "", "", Guests, "", "", "", "", "", url_insert,url_insert,url_insert, "", "", "", "", "", "", StartDate, EndDate , "", "", "", "", "", "", "", "", "", region, statuscode, israteperstay))
                    return json.dumps(array)
            
        if htm.status_code <> 200:
            htm = requests.post(url_main,data = load,headers = head)
        if (htm.status_code == 403 or htm.status_code == 407) or htm.status_code <> 200:
            try:
                if htm.status_code <> 200:
                    htm = requests.post(url_main,data = load,headers = head)
            except Exception, e:
                Closed    = 'Y'
                value_error = str(re.sub("'", '', str(e)))
                stacktrace = sys.exc_traceback.tb_lineno
                '''keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(Websitecode, datetime.datetime.now(), id_update)
                key = bucket.new_key(keyvalue)
                key.set_contents_from_string(str(e) + 'Where Line number' + str(stacktrace) + str(proxies))'''
                statuscode = 5
                Guests = ''
                array.append(aws_insert.insert(id_update, inputid , Domainname, Websitecode, "", "", "", "", Guests, "", "", "", "", "", url_insert,url_insert,url_insert, "", "", "", "", "", "", StartDate, EndDate , "", "", "", "", "", "", "", "", "", region, statuscode, israteperstay))
                return json.dumps(array)
        html = htm.text.encode('ascii','ignore')
        #fo = open('riverside.html','w').write(str(html))
        Rtdate=re.sub(r'-|\-','',str(RateDate))
        keyvalue = "ondemand/{}/{:%Y%m%d}/source{}.html".format(Websitecode,datetime.datetime.now(),str(inputid)+'_'+str(Rtdate)+'_'+id_update)
        key = bucket.new_key(keyvalue)
        key.set_contents_from_string(json.dumps(html))
        if re.search(r'<div class="roomselection".*?</form>', html, re.DOTALL):
            for block1 in re.compile(r'<div class="rate_header.*?price_message">', re.DOTALL).findall(html):
                for block in re.compile(r'<div class="roomselection".*?</form>', re.DOTALL).findall(block1):
                    RoomType      = ''
                    Ratetype      = ''
                    OnsiteRate    = 0
                    RoomAmenity_Type = ''
                    RateDescription  = ''
                    Mealtype         = ''
                    Curr             = ''
                    Closed           = 'N'
                    GrossRate        =  0
                    isAvailable      = ''
                    TaxAmount        =  0
                    Taxstatus        =  2
                    roomtype_re = re.search(r'<div class="roomtypeselection.*?button">(.*?)<', block,re.DOTALL)            
                    if roomtype_re:
                        RomeType1 = re.sub(r"'","''", roomtype_re.group(1))
                        RoomType  = re.sub('\s\s+','',re.sub(r'&.*?;','',RomeType1))
                        
                    desc1_re    = re.search(r'roomdescriptiontext.*?>(.*?)<', block,re.DOTALL)
                    if desc1_re:
                        RateDescription = re.sub(r"&amp","&",re.sub(r"\n\s*","",re.sub(r"'","''",re.sub(r"\s\s+","",desc1_re.group(1)))))
                    else:
                        RateDescription = ''
                    desc2_re  = re.search(r'id="rate_message.*?>(.*?)</div>', block1, re.DOTALL)
                    if desc2_re:
                        RateDescription1 = re.sub(r"\n\s*|<.*?>","",re.sub(r"'","''",re.sub(r"\s\s+","",desc2_re.group(1))))
                    else:
                        RateDescription1 = ''
                    RateDescription = RateDescription+' '+RateDescription1
                    ratetype_re     = re.search(r'rate_class_name">(.*?)<', block,re.DOTALL)
                    if ratetype_re:
                        Ratetype = re.sub(r"<.*?>|\s\s+",'',re.sub(r"'","''",ratetype_re.group(1)))
                        
                    price_re    = re.search(r'lass="price".*?\@(.*?)<', block,re.DOTALL)
                    if price_re:
                        OnsiteRate = re.sub('\$|,|[A-Za-z]','',price_re.group(1)).strip()
                    GrossRate  = OnsiteRate 
                    
                    curr_re =  re.search(r'lass="price".*?\@(.*?)<', block,re.DOTALL)
                    if curr_re:
                        Currency = curr_re.group(1).strip()
                        if "$" in Currency:
                            Curr = 'USD'
                        elif 'USD' in Currency:
                            Curr = 'USD'
                    
                    '''TaxAmount_re = re.search(r'class="BigTxt1".*?>.*?(\d.*?)<', block)
                    if TaxAmount_re:
                        TaxAmount1 = TaxAmount_re.group(1)
                        TaxAmount  = float(TaxAmount1)-float(OnsiteRate)
                        Taxstatus  = 2'''
                    Mealtypes          = str(RateDescription)+' '+str(RoomType)+' '+str(Ratetype)
                    if Mealtypes !=None:
                        Mealtype_str = str(Mealtypes)
                        if 'breakfast' in Mealtype_str.lower() and 'dinner' in Mealtype_str.lower()  and 'lunch' in Mealtype_str.lower():
                            Meal = 'Breakfast, Lunch and Dinner'
                        elif 'breakfast' in Mealtype_str.lower() and 'dinner' in Mealtype_str.lower():
                            Meal = 'Breakfast and dinner'
                        elif 'breakfast included' in Mealtype_str.lower():
                            Meal = 'Breakfast included'
                        elif 'BREAKFAST' in Mealtype_str:
                            Meal = 'Breakfast'
                        elif 'breakfast' in Mealtype_str.lower() and 'lunch' in Mealtype_str.lower():
                            Meal = 'Breakfast and Lunch'
                        elif 'Lunch' in Mealtype_str and 'Dinner' in Mealtype_str :
                            Meal = "Lunch and Dinner"
                        elif 'breakfast' in Mealtype_str.lower() and 'lunch' in Mealtype_str.lower() and 'dinner' in Mealtype_str.lower():
                            Meal = 'Breakfast, Lunch and dinner'
                        elif 'Break fast' in Mealtype_str:
                            Meal = 'BreakFast' 
                        elif 'breakfast' in Mealtype_str.lower():
                            Meal = 'BreakFast' 
                        elif 'halfboard' in Mealtype_str.lower():
                            Meal = 'Halfboard'
                        elif 'half board' in Mealtype_str.lower():
                            Meal = 'Half board' 
                        elif 'full board' in Mealtype_str.lower():
                            Meal = 'Full Board'
                        elif 'fullboard' in Mealtype_str.lower():
                            Meal = 'FullBoard'
                        elif 'All-Inclusive' in Mealtype_str:
                            Meal = 'All-Inclusive'
                        elif 'All Inclusive' in Mealtype_str:
                            Meal = 'All Inclusive'
                        elif 'All Meals' in Mealtype_str:
                            Meal = 'All Meals'
                        elif 'All Meal' in Mealtype_str:
                            Meal = 'All Meal'
                        else:
                            Meal = ''
                    else:
                        Meal = ''   
                    Mealtype = Meal
                    if OnsiteRate==0:
                        statuscode = 1
                        Closed='Y'
                    else:
                        statuscode = ''
                        Closed='N'
                    if int(LOS) >1:
                        israteperstay = 'N'
                    else:
                        israteperstay ='Y'
                    
                    #print "RoomType    :",RoomType
                    #print "Ratetype    :",Ratetype
                    #print "OnsiteRate  :",OnsiteRate
                    #print "RateDescription :",RateDescription
                    #print "Curr        :",Curr
                    #print "Mealtype    :",Mealtype
                    #print "="*40
                    #print (id_update, inputid , Domainname, Websitecode, StartDate, RoomType, LOS, RateDate, Guests, OnsiteRate, NetRate, GrossRate, Curr, RateDescription, url_insert, url_insert, url_insert, RoomAmenity_Type, Mealtype, MaxOccupancy, isPromotionalRate, Closed, 30, StartDate , EndDate, intime, isAvailable, Taxtype, TaxAmount, Taxstatus, None, Ratetype, Discount,Promotion_Name,region,statuscode, israteperstay)
                    array.append(aws_insert.insert(id_update, inputid , Domainname, Websitecode, StartDate, RoomType, LOS, RateDate, Guests, OnsiteRate, NetRate, GrossRate, Curr, RateDescription, url_insert, url_insert, url_insert, RoomAmenity_Type, Mealtype, MaxOccupancy, isPromotionalRate, Closed, 30, StartDate , EndDate, intime, isAvailable, Taxtype, TaxAmount, Taxstatus, None, Ratetype, Discount,Promotion_Name,region,statuscode, israteperstay))
        else:
            Closed     = 'Y'
            statuscode = '2'
            #print "else"
            #print (id_update, inputid , Domainname, Websitecode, StartDate, RoomType, LOS, RateDate, Guests, OnsiteRate, NetRate, GrossRate, Curr, RateDescription, url_insert, url_insert, url_insert, RoomAmenity_Type, Mealtype, MaxOccupancy, isPromotionalRate, Closed, 30, StartDate , EndDate, intime, isAvailable, Taxtype, TaxAmount, Taxstatus, None, Ratetype, Discount,Promotion_Name,region,statuscode, israteperstay)
            array.append(aws_insert.insert(id_update, inputid , Domainname, Websitecode, StartDate, RoomType, LOS, RateDate, Guests, OnsiteRate, NetRate, GrossRate, Curr, RateDescription, url_insert, url_insert, url_insert, RoomAmenity_Type, Mealtype, MaxOccupancy, isPromotionalRate, Closed, 30, StartDate , EndDate, intime, isAvailable, Taxtype, TaxAmount, Taxstatus, None, Ratetype, Discount,Promotion_Name,region,statuscode, israteperstay))
        Rtdate = re.sub(r'-|\-', '', str(RateDate))
        keyvalue = "ondemand/{}/{:%Y%m%d}/delivery/{}.json".format(Websitecode,datetime.datetime.now(),str(inputid)+'_'+str(Rtdate)+'_'+id_update)
        key = bucket.new_key(keyvalue)
        key.set_contents_from_string(json.dumps(array))
        return json.dumps(array)
        gc.collect()
    except Exception as e:
       print e
       value_error = str(re.sub(r"'", '"', str(e)))
       stacktrace = sys.exc_traceback.tb_lineno
       Guests = ''
       statuscode = '4'
       region = ''
       array.append(aws_insert.insert(id_update, inputid , Domainname, Websitecode, "", "", "", "", Guests, "", "", "", "", "", url_insert,url_insert,url_insert, "", "", "", "", "", "", StartDate, EndDate , "", "", "", "", "", "", "", "", "", region, statuscode, israteperstay))
       keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(Websitecode,datetime.datetime.now(),id_update)
       key = bucket.new_key(keyvalue)
       key.set_contents_from_string(json.dumps(value_error))
       return json.dumps(array)
   
