# -*- coding: utf-8 -*-
import re
import requests
import datetime
import json
import boto
import sys
import meta_insert

# url ="https://www.kayak.com/hotels/Le-Blanc-Spa-Resort-Los-Cabos-Adults-Only,San-Jose-del-Cabo,Baja-California-Sur,Mexico-c48189-h886478-details/2019-02-11/2019-02-13/exprates/#rates"
# inputid = 123456
# id_update = 007
# proxyip = 'media:M3diAproxy@209.99.164.25:80'

def fetchrates(url ,inputid, id_update, proxyip):            
	array = []
	csv=[]
	Rank = ''
	if re.search(r'-h(\d+)-', url):
		hotelId = re.search(r'-h(\d+)-', url).group(1)
	if re.search(r'(\d+-\d+-\d+)/(\d+-\d+-\d+)/',url):
		checkInDate  = re.search(r'(\d+-\d+-\d+)/(\d+-\d+-\d+)/',url).group(1)
		checkOutDate = re.search(r'(\d+-\d+-\d+)/(\d+-\d+-\d+)/',url).group(2)
	Ratedate = checkInDate
	cid = datetime.datetime.strptime(checkInDate, '%Y-%m-%d')
	cod = datetime.datetime.strptime(checkOutDate, '%Y-%m-%d')
	Los          = cid - cod 
	Los1          = re.sub('-','',str(Los.days))
	Los             = int(Los1)
	Hotelcode=inputid
	functionname='kayak'
	conn = boto.connect_s3(aws_access_key_id= 'AKIAIXEGZVXCWE2FV3SQ',aws_secret_access_key = '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') 
	bucket = conn.get_bucket("rmapi")
	StartDate = datetime.date.today()
	websitecode=281
	Reportdate=datetime.datetime.strptime(str(StartDate),'%Y-%m-%d').strftime('%Y-%m-%d')
	try:
		proxies = {"http": "http://{}".format(proxyip)}
		#prox = requests.get('https://api.proxicity.io/v2/8a1dc5a4034124724b4332363d8bb79d3bb7915299824488d35bcc39e145ba25/proxy?isAnonymous=true&supportedWebsites=google&protocol=http&httpsSupport=true').json()
		#proxies = {"https":'http://%s' % str(prox['ipPort'])}
		searchid =''
		Post_url = 'https://www.kayak.com/s/horizon/hotels/results/HotelRatesTable'
		payload  = {'searchId':searchid,'hotelId':hotelId,'expanded':'exprates','inline':'false','searchFailed':'false','rowClickThroughEnabled':'false','whiskyOnly':'false','hotelAdsSearch':'false','checkInDate':checkInDate,'checkOutDate':checkOutDate,'rooms':'1','guests':'1','updateMultibook':'true'}
		head     = {'Accept':'*/*','Accept-Encoding':'gzip, deflate, br','Accept-Language':'en-US,en;q=0.5','Connection':'keep-alive','Content-Length':'412','Content-Type':'application/x-www-form-urlencoded; charset=UTF-8','Host':'www.kayak.com','Referer':str(url),'User-Agent':'Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:54.0) Gecko/20100101 Firefox/54.0','X-CSRF':'XuluygN1HEpVH5siTRC_Fzfi2Yud3rXt67kP1Um$aGM-MPkBbuhi9hfhlExgcngPda4N3uYQ49Gk4cVhq9toRSA','X-RequestId':'hotels#details#Hl$fyJ','X-Requested-With':'XMLHttpRequest'}
		try:
			#prox = requests.get('https://api.proxicity.io/v2/8a1dc5a4034124724b4332363d8bb79d3bb7915299824488d35bcc39e145ba25/proxy?isAnonymous=true&supportedWebsites=google&protocol=http&httpsSupport=true').json()
			#proxies = {"https":'http://%s' % str(prox['ipPort'])}
			hml = requests.post(Post_url, data=payload, headers=head, proxies = proxies)
		except Exception,e:
			print e
			try:
				#prox = requests.get('https://api.proxicity.io/v2/8a1dc5a4034124724b4332363d8bb79d3bb7915299824488d35bcc39e145ba25/proxy?isAnonymous=true&supportedWebsites=google&protocol=http&httpsSupport=true').json()
				#proxies = {"https":'http://%s' % str(prox['ipPort'])}
				hml = requests.post(Post_url, data=payload, headers=head, proxies = proxies)
			except Exception,e:
				value_error=str(re.sub("'",'"',str(e)))
				stacktrace=sys.exc_traceback.tb_lineno
				keyvalue = "metasearch/{}/{:%Y%m%d}/Error/{}.txt".format(websitecode,datetime.datetime.now(),str(inputid)+'_'+str(id_update))
				key = bucket.new_key(keyvalue)
				key.set_contents_from_string(str(e))
				statuscode=5
				array.append(meta_insert.insert(functionname,Rank,"","",None,None,None,"",Ratedate,Los,Reportdate,Hotelcode,websitecode,url,"",Ratedate,statuscode))
				return json.dumps(array)
		if (hml.status_code <> 200):
			#prox = requests.get('https://api.proxicity.io/v2/8a1dc5a4034124724b4332363d8bb79d3bb7915299824488d35bcc39e145ba25/proxy?isAnonymous=true&supportedWebsites=google&protocol=http&httpsSupport=true').json()
			#proxies = {"https":'http://%s' % str(prox['ipPort'])}
			hml = requests.post(Post_url, data=payload, headers=head, proxies = proxies)
		if (hml.status_code == 403 or hml.status_code == 407 or hml.status_code <> 200):
			try:
				#prox = requests.get('https://api.proxicity.io/v2/8a1dc5a4034124724b4332363d8bb79d3bb7915299824488d35bcc39e145ba25/proxy?isAnonymous=true&supportedWebsites=google&protocol=http&httpsSupport=true').json()
				#proxies = {"https":'http://%s' % str(prox['ipPort'])}
				hml = requests.post(Post_url, data=payload, headers=head, proxies = proxies)
				if (hml.status_code <> 200):
					#prox = requests.get('https://api.proxicity.io/v2/8a1dc5a4034124724b4332363d8bb79d3bb7915299824488d35bcc39e145ba25/proxy?isAnonymous=true&supportedWebsites=google&protocol=http&httpsSupport=true').json()
					#proxies = {"https":'http://%s' % str(prox['ipPort'])}
					hml = requests.post(Post_url, data=payload, headers=head, proxies = proxies)
			except Exception,e:
				value_error=str(re.sub("'",'"',str(e)))        
				stacktrace=sys.exc_traceback.tb_lineno
				keyvalue = "metasearch/{}/{:%Y%m%d}/Error/{}.txt".format(websitecode,datetime.datetime.now(),str(inputid)+'_'+str(id_update))
				key = bucket.new_key(keyvalue)
				key.set_contents_from_string(str(e))
				statuscode=5
				array.append(meta_insert.insert(functionname,Rank,"","",None,None,None,"",Ratedate,Los,Reportdate,Hotelcode,websitecode,url,"",Ratedate,statuscode))
				return json.dumps(array)
	#         print hml.status_code
		html = hml.text.encode('ascii', 'ignore')
	#         print html
		#fo = open('name.html','w')
		#fo.write(str(html))
		i            = 0
		Provider     = None
		NetRate      = 0
		RoomName     = ''
		Pricepernight= 0
		OnsiteRate   = 0
		Curr         = 'USD'
		RoomFacilities= ''
		RoomName2 = ''
		keyvalue = "metasearch/{}/{:%Y%m%d}/source/{}.html".format(websitecode,datetime.datetime.now(),str(inputid)+'_'+str(id_update))
		key = bucket.new_key(keyvalue)
		key.set_contents_from_string(html)
		if '<p>Please confirm that you are a real KAYAK user.</p>' in html or 'If you are not automatically redirected' in html or 'captchaRedirectUrl' in html:
			statuscode=9
			insert_captured_log = 'Site has been blocked'
			keyvalue = "metasearch/{}/{:%Y%m%d}/Error/{}.txt".format(websitecode,datetime.datetime.now(),str(inputid)+'_'+str(id_update))
			key = bucket.new_key(keyvalue)
			key.set_contents_from_string(insert_captured_log)
			array.append(meta_insert.insert(functionname,RoomName,"",OnsiteRate,NetRate,Pricepernight,"","",Ratedate,"",Reportdate,Hotelcode,websitecode,url,"",Ratedate,statuscode))
			return json.dumps(array)
		if re.compile(r'<tbody.*?</tbody>',re.DOTALL).findall(html):
			i= 1
			Rank_dict = {}
			if "No matches were found. Try changing your stay" in html:
				statuscode=2
				Ratedates=re.sub(r'-','',str(Ratedate))
				date_time=datetime.datetime.now().strftime('%Y%m%d_%I%M')
				array.append(meta_insert.insert(functionname,RoomName,"",OnsiteRate,NetRate,Pricepernight,"","",Ratedate,"",Reportdate,Hotelcode,websitecode,url,"",Ratedate,statuscode))
				keyvalue = "metasearch/metaresults/{}.txt".format(str(date_time)+'_'+str(websitecode)+'_'+str(Hotelcode)+'_'+str(Ratedates))
				key = bucket.new_key(keyvalue)
				key.set_contents_from_string(str(array))
				return json.dumps(array)
			for mainblock in re.compile(r'<tbody\s*id.*?</tbody>',re.DOTALL).findall(html):
				for block in re.compile(r'<td class.*?</tr>',re.DOTALL).findall(mainblock):
					RoomName=''
					if "moreOptionsLabel" not in block:
						if re.search(r"providerLogo.*?>(.*?)<", mainblock):
							Provider = re.sub(r"\-logo","",re.search(r"providerLogo.*?>(.*?)<", mainblock).group(1))
							if "DOT" in Provider:
								Provider = re.sub('PRICELINECORE','PRICELINE',re.sub(r'DOT','.',Provider))
						elif re.search(r'<td class=\\"provider.*?/h/(.*?)\.',  block):
							Provider = re.sub(r"\-logo|<.*?>","",re.search(r'<td class=\\"provider.*?/h/(.*?)\.', block).group(1))
							if "DOT" in Provider:
								Provider = re.sub(r'DOT','.',Provider)
							if "PRICELINECORE" in Provider:
								Provider = re.sub(r'PRICELINECORE','PRICELINE',Provider)
							
						else:
							Provider = None
						##print Provider
						if Provider not in Rank_dict:
							Rank_dict[Provider] = i
							i = i+1
						Rank = Rank_dict[Provider]

						if re.search(r'<span class=\\"description \\">(.*?)<', block, re.DOTALL):
							RoomName1=re.sub(r'\\n.*?/>|<div.*?/>|\\n','',re.search(r'<span class=\\"description \\">(.*?)<', block, re.DOTALL).group(1))
						if re.search(r'roomType\\">\\n([A-Za-z|\d].*?)</td>', mainblock, re.DOTALL):
							RoomName2=re.sub(r'\\n.*?/>|<div.*?/>|\\n','',re.search(r'roomType\\">\\n([A-Za-z|\d].*?)</td>', mainblock, re.DOTALL).group(1))
						else:
							RoomName = "Lowest Available Rate"
                        RoomNames = RoomName2+' - '+RoomName1
#                         print "RoomName =",RoomNames 
                        RoomName=re.sub(r"^-","",re.sub('\d more bed type|<.*?>','',RoomNames).strip()).strip()
#                         print "RoomName =",RoomName 
                        if re.search(r'bookingFeature.*?>(.*?)</', block, re.DOTALL):
							RoomFacilities = re.search(r'bookingFeature.*?"feature.*?>(.*?)</', block, re.DOTALL).group(1)
                        else:
                        	RoomFacilities = ""
                        ##print RoomFacilities
                        if re.search(r'priceText.*?>.*?(\d.*?)\s*<', block):
                        	Pricepernight = re.sub(r'&.*?;|,|\$|$|\\n|[^0-9]','',re.search(r'priceText.*?>(.*?)<', block).group(1))
                        else:
                        	Pricepernight = 0
                        if re.search(r'<td class=\\"price\\">\\n<div class=\\"fader\\">.*?(\d.*?)\s*</', block):
                        	OnsiteRate = re.sub(r',|\$|$|\W|[^0-9]','',re.search(r'<td class=\\"price\\">\\n<div class=\\"fader\\">.*?(\d.*?)\s*</',  block).group(1))
                        else:
                        	OnsiteRate = 0
                        Curr    = 'USD'
                        Ratedate = checkInDate
                        statuscode=''
                        HotelBlock=''
                        Pricepernight=int(Pricepernight)
                        OnsiteRate=int(OnsiteRate.strip())
                        valu=Provider,Rank,RoomName,RoomFacilities,OnsiteRate,NetRate,Pricepernight,Curr,Ratedate,Los,Reportdate,Hotelcode,websitecode,url,HotelBlock,Ratedate,statuscode
                        vals=str(valu)
                        csv.append(vals)
                        #print Provider,Rank,RoomName,RoomFacilities,OnsiteRate,NetRate,Pricepernight,Curr,Ratedate,Los,Reportdate,Hotelcode,websitecode,url,HotelBlock,Ratedate,statuscode
                        array.append(meta_insert.insert(Provider,Rank,RoomName,RoomFacilities,OnsiteRate,NetRate,Pricepernight,Curr,Ratedate,Los,Reportdate,Hotelcode,websitecode,url,HotelBlock,Ratedate,statuscode))
		else:
			statuscode=2
			Rank=i
			
			HotelBlock=''
			valu=Provider,Rank,RoomName,RoomFacilities,OnsiteRate,NetRate,Pricepernight,Curr,Ratedate,Los,Reportdate,Hotelcode,websitecode,url,HotelBlock,Ratedate,statuscode
			vals=str(valu)
			csv.append(vals)
			#print Provider,Rank,RoomName,RoomFacilities,OnsiteRate,NetRate,Pricepernight,Curr,Ratedate,Los,Reportdate,Hotelcode,websitecode,url,HotelBlock,Ratedate,statuscode
			array.append(meta_insert.insert(Provider,Rank,RoomName,RoomFacilities,OnsiteRate,NetRate,Pricepernight,Curr,Ratedate,Los,Reportdate,Hotelcode,websitecode,url,HotelBlock,Ratedate,statuscode))
		newline="\n".join(csv)
		arrayclean1=re.sub(r'\[|\(|\)|\]','',str(newline))
		arrayclean2=re.sub(r"'",'"',arrayclean1)
		arrayclean=re.sub(r'u"','"',arrayclean2)
		Ratedates=re.sub(r'-','',str(Ratedate))
		date_time=datetime.datetime.now().strftime('%Y%m%d_%I%M')    
		keyvalue = "metasearch/metaresults/{}.txt".format(str(date_time)+'_'+str(websitecode)+'_'+str(Hotelcode)+'_'+str(Ratedates))
		#print keyvalue
		key = bucket.new_key(keyvalue)
		key.set_contents_from_string(arrayclean)
		return json.dumps(array)
	except Exception as e:
		value_error=str(re.sub(r"'",'"',str(e)))
		stacktrace=sys.exc_traceback.tb_lineno
		insert_value_error=str(value_error)+'Where line number '+str(stacktrace)+str(proxyip)
		print insert_value_error
		statuscode=4
		keyvalue = "metasearch/{}/{:%Y%m%d}/Error/{}.txt".format(websitecode,datetime.datetime.now(),str(inputid)+'_'+str(id_update))
		key = bucket.new_key(keyvalue)
		key.set_contents_from_string(insert_value_error)
		array.append(meta_insert.insert(functionname,RoomName,"",OnsiteRate,NetRate,Pricepernight,"","",Ratedate,"",Reportdate,Hotelcode,websitecode,url,"",Ratedate,statuscode))
		return json.dumps(array)

# fetchrates(url ,inputid, id_update, proxyip)
