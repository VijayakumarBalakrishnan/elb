# -*- coding: utf-8 -*-
import re
import requests
import datetime
import operator
import json
import sys 
import boto
import gc

import aws_insert


def fetchrates(url , inputid, id_update, proxyip):
    array = []
    intime = re.sub(r'\s', 'T', str(datetime.datetime.now()))
    functionname = 'unicoilodge.com'
    Websitecode = 356
    LastModified = intime
    israteperstay = ''
    try:
        conn = boto.connect_s3(aws_access_key_id='AKIAIXEGZVXCWE2FV3SQ', aws_secret_access_key='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') 
        bucket = conn.get_bucket("rmapi")
        sr = requests.Session()
        StartDate = datetime.date.today()
        EndDate = datetime.date.today() + datetime.timedelta(days=29)
        Websitecode = 356
        Domainname = "unicoilodge.com"
        chkins = re.search(r'checkindate=(.*?)&', url).group(1)
        chkouts = re.search(r'checkoutdate=(.*?)&', url).group(1)
        txtadult = re.search(r'txtAdults=(.*?)&', url).group(1)
        checkins = datetime.datetime.strptime(chkins, str("%Y-%m-%d")).strftime("%Y, %m, %d")
        checkouts = datetime.datetime.strptime(chkouts, str("%Y-%m-%d")).strftime("%Y, %m, %d")
        ccin = datetime.datetime.strptime(checkins, '%Y, %m, %d')
        ccout = datetime.datetime.strptime(checkouts, '%Y, %m, %d')
        LOS = ccout - ccin
        LOS = LOS.days
        checkins_load_day = datetime.datetime.strptime(chkins, str("%Y-%m-%d")).strftime("%d")
        checkins_load_mon = datetime.datetime.strptime(chkins, str("%Y-%m-%d")).strftime("%m")
        checkins_load_year = datetime.datetime.strptime(chkins, str("%Y-%m-%d")).strftime("%Y")
        checkouts_load_day = datetime.datetime.strptime(chkouts, str("%Y-%m-%d")).strftime("%d")
        checkouts_load_mon = datetime.datetime.strptime(chkouts, str("%Y-%m-%d")).strftime("%m")
        checkouts_load_year = datetime.datetime.strptime(chkouts, str("%Y-%m-%d")).strftime("%Y")
        RateDate = chkins
        url = 'https://secure.iqres03111.com/iqreservations/asp/AgentLogin.asp?CheckInMonth='+str(checkins_load_mon)+'&CheckInDay='+str(checkins_load_day)+'&CheckInYear='+str(checkins_load_year)+'&CheckOutMonth='+str(checkouts_load_mon)+'&CheckOutDay='+str(checkouts_load_day)+'&CheckOutYear='+str(checkouts_load_year)+'&txtAdults='+str(txtadult)+'&txtChildren=0&txtNumRooms=1&txtRateSelected=0&txtPromoCode=&action=Check+Availability'
        head = {'User-Agent':'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:12.0) Gecko/20100101 Firefox/12.0'}
        proxies = {"http": "http://{}".format(proxyip)}
        region = ''
        ip = re.sub(r"\{'.*?@|'\}|:\d+", "", str(proxies))
        try:
            try:
                r = requests.get('http://freegeoip.net/json/' + ip, timeout=30)
            except Exception, e:
                r = requests.get('http://freegeoip.net/json/' + ip, timeout=30)
            js = r.json()
            region = js['country_name']
        except Exception, e:
            region = ''
        try:
            hml = sr.get('https://secure.iqres03111.com/iqreservations/asp/IQHome.asp',headers=head, proxies=proxies, timeout=50)
            hml = sr.get('https://secure.iqres03111.com/iqreservations/asp/RoomAvailability.asp',headers=head, proxies=proxies, timeout=50)
            hml = sr.get(url,headers=head, proxies=proxies, timeout=50)
        except Exception, e:
            value_error = str(re.sub("'", '', str(e)))
            stacktrace = sys.exc_traceback.tb_lineno
            try:
                hml = sr.get('https://secure.iqres03111.com/iqreservations/asp/IQHome.asp',headers=head, proxies=proxies, timeout=50)
                hml = sr.get('https://secure.iqres03111.com/iqreservations/asp/RoomAvailability.asp',headers=head, proxies=proxies, timeout=50)
                hml = sr.get(url,headers=head, proxies=proxies, timeout=50)
            except Exception, e:
                value_error = str(re.sub("'", '', str(e)))
                stacktrace = sys.exc_traceback.tb_lineno
                keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(Websitecode, datetime.datetime.now(), id_update)
                key = bucket.new_key(keyvalue)
                key.set_contents_from_string(str(e) + 'Where Line number' + str(stacktrace) + str(proxies))
                statuscode = 5
                Guests = ''
                array.append(aws_insert.insert(id_update, inputid , functionname, Websitecode, "", "", "", "", Guests, "", "", "", "", "", url, url, url, "", "", "", "", "", "", StartDate, EndDate , "", "", "", "", "", "", "", "", "", region, statuscode, israteperstay))
                return json.dumps(array)
        if hml.status_code <> 200:
            hml = sr.get('https://secure.iqres03111.com/iqreservations/asp/IQHome.asp',headers=head, proxies=proxies, timeout=50)
            hml = sr.get('https://secure.iqres03111.com/iqreservations/asp/RoomAvailability.asp',headers=head, proxies=proxies, timeout=50)
            hml = sr.get(url,headers=head, proxies=proxies, timeout=50)
        if (hml.status_code == 403 or hml.status_code == 407) or hml.status_code <> 200:
            try:
                if hml.status_code <> 200:
                    hml = sr.get('https://secure.iqres03111.com/iqreservations/asp/IQHome.asp',headers=head, timeout=50)
                    hml = sr.get('https://secure.iqres03111.com/iqreservations/asp/RoomAvailability.asp',headers=head, timeout=50)
                    hml = sr.get(url,headers=head, timeout=50)
            except Exception, e:
                value_error = str(re.sub("'", '', str(e)))
                stacktrace = sys.exc_traceback.tb_lineno
                keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(Websitecode, datetime.datetime.now(), id_update)
                key = bucket.new_key(keyvalue)
                key.set_contents_from_string(str(e) + 'Where Line number' + str(stacktrace) + str(proxies))
                statuscode = 5
                Guests = ''
                array.append(aws_insert.insert(id_update, inputid , functionname, Websitecode, "", "", "", "", Guests, "", "", "", "", "", url, url, url, "", "", "", "", "", "", StartDate, EndDate , "", "", "", "", "", "", "", "", "", region, statuscode, israteperstay))
                return json.dumps(array)
        html = hml.text
        html = html.encode('ascii', 'ignore')
        Rtdate=re.sub(r'-|\-','',str(RateDate))
        Rtdate=re.sub(r'-|\-','',str(RateDate))
        keyvalue = "ondemand/{}/{:%Y%m%d}/source{}.html".format(Websitecode, datetime.datetime.now(), str(inputid) + '_' + str(Rtdate) + '_' + id_update)
        #print keyvalue
        key = bucket.new_key(keyvalue)
        key.set_contents_from_string(html)      
        Websitecode = Websitecode
        RoomType = ""
        Guests = ""
        Guests_reg = re.search(r'txtAdults=(.*?)&', url)
        if Guests_reg:
            Guests = Guests_reg.group(1)
        OnsiteRate = 0
        NetRate = 0
        Curr = ""
        RateDescription = ""
        RoomAmenity_Type = ""
        MealInclusion_Type = ""
        MaxOccupancy = None
        isPromotionalRate = "N"
        Closed_up = "Y"
        LastModified = LastModified
        isAvailable = ""
        Taxtype = ""
        TaxAmount = 0
        RateType = ""
        Promotion_Name = ""
        Tax_status = ''
        reg_block = re.search('<td nowrap class="h\d+" valign="top" align="center">\s*(.*?align="right".*?)\s*</tr>',html,re.DOTALL)
        if reg_block:
            for block in re.compile(r'<td nowrap class="h\d+" valign="top" align="center">\s*(.*?align="right".*?)\s*</tr>',re.DOTALL).findall(html):
                RoomType=""
                OnsiteRate= 0
                Netrate=0
                Curr=""
                RateDescription=""
                RoomAmenity_Type=""
                MealInclusion_Type=""
                MaxOccupancy= None
                isPromotionalRate="N"
                Closed_up="N"
                isAvailable=""
                Taxtype=""
                TaxAmount= 0
                RateType=""
                Promotion_Name=""
                statuscode = ''
                room_type=re.search('<td width="\d+%" align="Left" valign="top" class="h\d+">\s*(.*?)\s*[<|-]',block)
                if room_type:
                    rooms=room_type.group(1)
                    RoomType=re.sub('Room Type|\'|<.*?>','',rooms).strip()
                    RoomType=re.sub('\s+',' ',RoomType)
                    #print "Room_Type        :",RoomType
                if RoomType == '':
                    room_type=re.search('<td width="\d+%" align="Left" valign="top" class="h\d+">.*?\s*<b>\s*(.*?)\s*</b>',block,re.DOTALL)
                    if room_type:
                        rooms=room_type.group(1)
                        RoomType=re.sub('Room Type|\'|<.*?>','',rooms).strip()
                        RoomType=re.sub('\s+',' ',RoomType)
                        #print "Room_Type        :",RoomType
                Ratetype_reg=re.search('<div class="rate-extended">.*?<th colspan="2" class="h1">\s*(.*?)\s*</th>',html,re.DOTALL)
                if Ratetype_reg:
                    Ratetype_1=Ratetype_reg.group(1)
                    Ratetype_1=re.sub("&.*?;|Rate:","",Ratetype_1)
                    Ratetype_2=re.sub("'","''",Ratetype_1)
                    RateType=re.sub('\s+',' ',Ratetype_2)
                    #print "RateType        :",RateType
                if 'offer' in RateType.lower():
                    Promotion_Name = RateType
                    isPromotionalRate = 'Y'
                descript=re.search('<td width="\d+%" align="Left" valign="top" class="h\d+">\s*(.*?)\s*</td>',block,re.DOTALL)
                if descript:
                    RateDescription_1=descript.group(1).strip()
                    RateDescription_1 = re.sub("<td>[A-z][A-z][A-z]$","",RateDescription_1)
                    RateDescription_2 = re.sub("\$|<.*?>|amp;","",RateDescription_1)
                    RateDescription_3 = re.sub("'","''",RateDescription_2)
                    RateDescription = re.sub("\s+"," ",RateDescription_3)
                    #print "Descriptipon        :",RateDescription
                RateDescription = RateDescription.replace(str(RoomType), '')
                curr_re = re.search('nowrap\s*class="h\d+">\s*(.*?)\s*\d.*?\s*</td>',block)
                if curr_re:
                    Curr= curr_re.group(1)
                    if '$' in Curr:
                        Curr = 'USD'
                    else:
                        Curr = ''
                    #print"Currency   :",Curr
                Tax_status = 2
                old_price=re.search('nowrap\s*class="h\d+">.*?</td>\s*<td.*?>\s*.*?(\d.*?)\s*</td>\s*<td.*?>\s*.*?(\d.*?)\s*</td>\s*<td.*?>\s*.*?(\d.*?)</strong>\s*</td>\s*<td.*?>\s*.*?\d.*?\s*</td>',block)
                if old_price:
                    price=old_price.group(1)
                    OnsiteRate = re.sub("\$|,","",price)
                    #print "Room_Price        :",OnsiteRate
                '''Netrate_reg=re.search('nowrap\s*class="h\d+">.*?</td>\s*<td.*?>\s*.*?(\d.*?)\s*</td>\s*<td.*?>\s*.*?(\d.*?)\s*</td>\s*<td.*?>\s*.*?(\d.*?)</strong>\s*</td>\s*<td.*?>\s*.*?\d.*?\s*</td>',block)
                if Netrate_reg:
                    Netrate_1=Netrate_reg.group(3)
                    Netrate = re.sub("\$|,","",Netrate_1)
                    #print "Netrate        :",Netrate
                    isPromotionalRate = 'Y'''
                TaxAmount_reg=re.search('nowrap\s*class="h\d+">.*?</td>\s*<td.*?>\s*.*?(\d.*?)\s*</td>\s*<td.*?>\s*.*?(\d.*?)\s*</td>\s*<td.*?>\s*.*?(\d.*?)</strong>\s*</td>\s*<td.*?>\s*.*?\d.*?\s*</td>',block)
                if TaxAmount_reg:
                    TaxAmount_1=TaxAmount_reg.group(2)
                    TaxAmount = re.sub("\$|,","",TaxAmount_1)
                    #print "TaxAmount        :",TaxAmount
                if int(float(OnsiteRate)) == int(float(Netrate)):
                    Netrate = ''
                #print 'Netrate:',Netrate
                Mealtype_str = str(RateDescription)
                if 'breakfast' in Mealtype_str.lower() and 'dinner' in Mealtype_str.lower()  and 'lunch' in Mealtype_str.lower():
                    Meal = 'Breakfast, Lunch and Dinner'
                elif 'breakfast' in Mealtype_str.lower() and 'dinner' in Mealtype_str.lower():
                    Meal = 'Breakfast and dinner'
                elif 'breakfast included' in Mealtype_str.lower():
                    Meal = 'Breakfast included'
                elif 'breakfast buffet' in Mealtype_str.lower():
                    Meal = 'Breakfast Buffet' 
                elif 'BREAKFAST' in Mealtype_str:
                    Meal = 'Breakfast'
                elif 'breakfast' in Mealtype_str.lower() and 'lunch' in Mealtype_str.lower():
                    Meal = 'Breakfast and Lunch'
                elif 'Lunch' in Mealtype_str and 'Dinner' in Mealtype_str :
                    Meal = "Lunch and Dinner"
                elif 'breakfast' in Mealtype_str.lower() and 'lunch' in Mealtype_str.lower() and 'dinner' in Mealtype_str.lower():
                    Meal = 'Breakfast, Lunch and dinner'
                elif 'Break fast' in Mealtype_str:
                    Meal = 'BreakFast' 
                elif 'breakfast' in Mealtype_str.lower():
                    Meal = 'BreakFast' 
                elif 'halfboard' in Mealtype_str.lower():
                    Meal = 'Halfboard'
                elif 'half board' in Mealtype_str.lower():
                    Meal = 'Half board' 
                elif 'full board' in Mealtype_str.lower():
                    Meal = 'Full Board'
                elif 'fullboard' in Mealtype_str.lower():
                    Meal = 'FullBoard'
                elif 'All-Inclusive' in Mealtype_str:
                    Meal = 'All-Inclusive'
                elif 'All Inclusive' in Mealtype_str:
                    Meal = 'All Inclusive'
                elif 'All Meals' in Mealtype_str:
                    Meal = 'All Meals'
                elif 'All Meal' in Mealtype_str:
                    Meal = 'All Meal'
                else:
                    Meal = ''
                MealInclusion_Type = Meal
                MealInclusion_Type = re.sub(r"charges|charge","cost",str(MealInclusion_Type).lower())
                #print 'MealInclusion_Type    :' ,MealInclusion_Type
                if OnsiteRate <> 0:
                    statuscode = ''
                else:
                    statuscode = 1
                    if RateDescription == '':
                        if int(len(str(RoomType))) > 100:
                            RateDescription = RoomType
                            RoomType = ''
                israteperstay = 'Y'
                #print 'statuscode:',statuscode
                ##print (id_update, inputid , Domainname, Websitecode, StartDate, RoomType, LOS, RateDate, Guests, OnsiteRate, NetRate, OnsiteRate, Curr, RateDescription, url, url, url, RoomAmenity_Type, MealInclusion_Type, MaxOccupancy, isPromotionalRate, Closed_up, 30, StartDate , EndDate, intime, isAvailable, Taxtype, TaxAmount, Tax_status, None, RateType, NetRate, Promotion_Name, region, statuscode, israteperstay)
                array.append(aws_insert.insert(id_update, inputid , Domainname, Websitecode, StartDate, RoomType, LOS, RateDate, Guests, OnsiteRate, NetRate, OnsiteRate, Curr, RateDescription, url, url, url, RoomAmenity_Type, MealInclusion_Type, MaxOccupancy, isPromotionalRate, Closed_up, 30, StartDate , EndDate, intime, isAvailable, Taxtype, TaxAmount, Tax_status, None, RateType, NetRate, Promotion_Name, region, statuscode, israteperstay))
        else:
            statuscode = '2'
            #print "statuscode    :", statuscode
            Closed_up = "Y"
            da_time = datetime.datetime.now()
            LastModified = re.sub(r'\s', 'T', str(da_time))
            Tax_status = ''
            ##print (id_update, inputid , Domainname, Websitecode, StartDate, RoomType, LOS, RateDate, Guests, OnsiteRate, NetRate, OnsiteRate, Curr, RateDescription, url, url, url, RoomAmenity_Type, MealInclusion_Type, MaxOccupancy, isPromotionalRate, Closed_up, 30, StartDate , EndDate, intime, isAvailable, Taxtype, TaxAmount, Tax_status, None, RateType, NetRate, Promotion_Name, region, statuscode, israteperstay)
            # insert(HotelCode,Websitecode,ReportDate,RoomType,LOS,RateDate,Guests,OnsiteRate,NetRate,GrossRate,Curr,RateDescription,HotelId,urlRate,urlInclusions,urlAmenities,RoomAmenity_Type,MealInclusion_Type,MaxOccupancy,isPromotionalRate,Closed,NumberOfDays,StartDate,EndDate,LastModified,isAvailable,Taxtype,TaxAmount,HotelBlock,RateType,Discount,Promotion_Name)
            array.append(aws_insert.insert(id_update, inputid , Domainname, Websitecode, StartDate, RoomType, LOS, RateDate, Guests, OnsiteRate, NetRate, OnsiteRate, Curr, RateDescription, url, url, url, RoomAmenity_Type, MealInclusion_Type, MaxOccupancy, isPromotionalRate, Closed_up, 30, StartDate , EndDate, intime, isAvailable, Taxtype, TaxAmount, Tax_status, None, RateType, NetRate, Promotion_Name, region, statuscode, israteperstay))
        #print "completed"
        Rtdate = re.sub(r'-|\-', '', str(RateDate))
        Rtdate = re.sub(r'-|\-', '', str(RateDate))
        keyvalue = "ondemand/{}/{:%Y%m%d}/delivery/{}.json".format(Websitecode, datetime.datetime.now(), str(inputid) + '_' + str(Rtdate) + '_' + id_update)
        key = bucket.new_key(keyvalue)
        key.set_contents_from_string(json.dumps(array))
        return json.dumps(array)
        gc.collect()

    except Exception as e:
        print e
        value_error = str(re.sub(r"'", '"', str(e)))
        stacktrace = sys.exc_traceback.tb_lineno
        Guests = ''
        region = ''
        Websitecode = '356'
        insert_value_error = str(value_error) + 'Where line number ' + str(stacktrace) + str(proxyip)
        print insert_value_error
        #print "Websitecode =", Websitecode
        statuscode = '4'
        keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(Websitecode, datetime.datetime.now(), id_update)
        key = bucket.new_key(keyvalue)
        key.set_contents_from_string(insert_value_error)
        ##print (id_update, inputid , Domainname, Websitecode, StartDate, RoomType, LOS, RateDate, Guests, OnsiteRate, NetRate, OnsiteRate, Curr, RateDescription, url, url, url, RoomAmenity_Type, MealInclusion_Type, MaxOccupancy, isPromotionalRate, Closed_up, 30, StartDate , EndDate, intime, isAvailable, Taxtype, TaxAmount, Tax_status, None, RateType, NetRate, Promotion_Name, region, statuscode, israteperstay)
        # array.append(aws_insert.insert(id_update,inputid ,Domainname,Websitecode,StartDate,'',LOS,RateDate,Guests,OnsiteRate,Netrate,OnsiteRate,Curr,RateDescription,url,url,url,RoomAmenity_Type,MealInclusion_Type,MaxOccupancy,isPromotionalRate,Closed_up,30,StartDate ,EndDate,intime,isAvailable,None,None,None,RateType,Netrate,promotion,region,statuscode, israteperstay))
        array.append(aws_insert.insert(id_update, inputid , functionname, Websitecode, "", "", "", "", Guests, "", "", "", "", "", url, url, url, "", "", "", "", "", "", StartDate, EndDate , "", "", "", "", "", "", "", "", "", region, statuscode, israteperstay))
        return json.dumps(array)
        
        
'''url= 'https://secure.iqres03111.com/iqreservations/asp/AgentLogin.asp?checkindate=2017-10-26&checkoutdate=2017-10-27&txtAdults=1&txtChildren=0&txtNumRooms=1&txtRateSelected=0&txtPromoCode=&action=Check+Availability'
inputid= ''
id_update = ''
proxyip   = '62.210.106.225:3681'
fetchrates(url ,inputid, id_update, proxyip)'''
