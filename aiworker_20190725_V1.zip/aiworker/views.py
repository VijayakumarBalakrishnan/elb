from django.views.decorators.csrf import csrf_exempt
from django.views.generic import View
from django.http import HttpResponse
import aitask
import threading
import gc
import json
import os
import sys
import gtask
import aws_insert
#import firebase_admin
#from firebase_admin import credentials
#from firebase_admin import firestore
#os.environ["GOOGLE_APPLICATION_CREDENTIALS"]="serviceAccountKey.json"

#cred = credentials.Certificate("/home/media/Downloads/aidb-568aa-firebase-adminsdk-r5y0v-14cfb47bd2.json")
#firebase_admin.initialize_app(cred)

id_update = ''
hotelcode = ''
WebSiteName = ''
websitecode = ''
ReportDate = ''
roomtype = ''
Los = ''
RateDate = ''
guests = ''
onsiterate = ''
netrate = ''
onsiterate = ''
curr = ''
roomdescription = ''
url = ''
url = ''
url = ''
roomamenity = ''
mealinclusion = ''
maxocp = ''
isprom = ''
closed_up = ''
NumberOfDays = ''
StartDate = ''
EndDate = ''
intime = ''
RoomAvilable = ''
taxtype = ''
taxamount = ''
taxstatus = ''
HotelBlock = ''
ratetype = ''
Discount = ''
promotion = ''
region = ''
statuscode = ''
israteperstay = ''
array=[]
from threading import Thread
class ThreadWithReturnValue(Thread):
	def __init__(self, group=None, target=None, name=None,
				 args=(), kwargs={}, Verbose=None):
		Thread.__init__(self, group, target, name, args, kwargs, Verbose)
		self._return = None
	def run(self):
		if self._Thread__target is not None:
			self._return = self._Thread__target(*self._Thread__args,
												**self._Thread__kwargs)
	def join(self):
		Thread.join(self)
		return self._return

@csrf_exempt
def queue(request):
	if request.method == "POST":

		#t = threading.Thread(target=aitask.sqsruntask, args=(request.body,))
		#t.start()
		try:
			if request.body != "":
				t = threading.Thread(target=aitask.sqsruntask, args=(request.body,))
				t.start()
				t.join()
				#threads = [threading.Thread(target=aitask.sqsruntask, args=(request.body,)) for i in range(10)]
	
				#for thread in threads:
					#thread.start()
				#for thread in threads:
					#thread.join()
	
				#aitask.sqsruntask(request.body)	
			gc.collect()
		except Exception as e:
			print "REQUEST ERROR {emsg}".format(emsg=e)

	return HttpResponse("success", content_type='application/json', status=200)
@csrf_exempt
def index(request):
	try:
		#from firebase import firebase
		res_body = { "message": "Timedout" }
		#firebase = firebase.FirebaseApplication('https://aifirestore.firebaseio.com/', None)
		if request.method == "POST":
			try:
				#res_body = gtask.getrequest(request.body)
				t = ThreadWithReturnValue(target=gtask.getrequest, args=(request.body,))
				t.start()
				t.join()
				res_body = t.join()
				#print "joined data=",t.join()
				print "Thread output in views...."
				f_data =json.loads(request.body)
				doc_data=f_data['websitecode']
				#array.append(res_body)
				#firedata = firebase.post('https://aifirestore.firebaseio.com/granular/'+str(doc_data)+'/', res_body)
			except Exception as e:
				print(e)
				statuscode = 4
				res_body = aws_insert.insert(id_update, hotelcode, WebSiteName, websitecode, ReportDate, roomtype, Los, RateDate, guests, onsiterate, netrate, onsiterate, curr, roomdescription, url, url, url, roomamenity, mealinclusion, maxocp, isprom, closed_up, NumberOfDays, StartDate, EndDate, intime, RoomAvilable, taxtype, taxamount,taxstatus, HotelBlock, ratetype, Discount,promotion,region, statuscode, israteperstay)
				print res_body
				#array.append(res_body)
				#firedata = firebase.post('https://aidb-568aa.firebaseio.com/granular/error/', array)
				return HttpResponse(json.dumps(array), content_type="application/json")	
		#print "returningggggg response to json",res_body	
		return HttpResponse(json.dumps(res_body), content_type="application/json")
	except Exception as e:
		print e
		print "error in exception-views.py"
