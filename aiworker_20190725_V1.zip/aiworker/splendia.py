# -*- coding: utf-8 -*-
import re
import requests
import datetime
import json
import boto
import sys 
from boto.s3.key import Key

import traceback
import aws_insert
from unidecode  import unidecode

#https://www.splendia.com/en/the-malabar-house-cochin.html?rooms=1&adults={guest}&dateStart={chkin}&dateEnd={chkout}&changed_currency={currency}&hotelid=40416
#https://www.splendia.com/en/purity-at-lake-vembanad-alleppey.html?rooms=1&adults=1&dateStart=2018-01-24&dateEnd=2018-01-25&changed_currency=USD&hotelid=40416
#url = 'https://www.splendia.com/en/corinthia-palace-hotel-spa-san-anton.html?rooms=1&adults=1&dateStart=2018-01-25&dateEnd=2018-01-26&changed_currency=USD&hotelid=32013'
#inputid = '2'
#id_update = '5'
#proxyip = 'user-34068:214859b73da0e174@45.64.106.45:1212'

M_curr=['GBP','EUR','USD','DZD','ARS','AUD','BHD','BOB','BRL','BGN','KHR','CAD','XPF','CLP','CNY','COP','CRC','HRK','CZK','DKK','DOP','XCD','EGP','FJD','HKD','HUF','ISK','INR','IDR','JPY','JOD','KES','KWD','LBP','MYR','MUR','MXN','MAD','NAD','TWD','NZD','NGN','NOK','OMR','PKR','PEN','PHP','PLN','QAR','RON','RUB','SAR','RSD','ILS','SGD','ZAR','KRW','LKR','SEK','CHF','THB','TND','TRY','AED','UAH','UYU','VEF','VND']

def fetchrates(url , inputid, id_update, proxyip):
    array = []
    intime=re.sub(r'\s','T',str(datetime.datetime.now()))
    WebSiteCode='270'
    israteperstay = ''
    StartDate = datetime.date.today()
    EndDate  = datetime.date.today() + datetime.timedelta(days=29)
    conn = boto.connect_s3(aws_access_key_id= 'AKIAIXEGZVXCWE2FV3SQ',aws_secret_access_key = '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') 
    bucket = conn.get_bucket("rmapi")
    #print url
    delta = datetime.datetime.strptime(re.search(r"dateEnd=(.*?)&", url).group(1), "%Y-%m-%d") - datetime.datetime.strptime(re.search(r"dateStart=(.*?)&", url).group(1), "%Y-%m-%d")
    LOS = delta.days
    try:
        Ratedate=''
        region=''
        proxies = {"https": "http://{}".format(proxyip)}
        WebSiteCode = "270"
        url_db=url
        head        = {'User-Agent':'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:12.0) Gecko/20100101 Firefox/31.0'}
        Checkin=re.search (r'dateStart=(.*?)&',url_db).group(1)
        #print Checkin
        Checkout=re.search (r'&dateEnd=(.*?)&',url_db).group(1)
        #print Checkout
        
        Hotelid=re.search (r'&hotelid=(.*)',url_db).group(1)
        #print Hotelid
                
        Guests=re.search (r'&adults=(.*?)&',url_db).group(1)
        #print Guests
        
        
        Curr=re.search (r'&changed_currency=(.*?)&',url_db).group(1)
        #print Curr
        
        
        
        
        if Curr not in M_curr:
            statuscode=8
            Guests=0
            array.append(aws_insert.insert(id_update, inputid ,"",WebSiteCode, "", "", "", "", Guests, "", "", "", "", "",url_db, url_db, url_db, "", "", "", "", "", "",StartDate, EndDate , "", "", "", "", "", "", "", "", "",region,statuscode, israteperstay))
            return json.dumps(array)
        
            
        #https://www.splendia.com/en/availability/30813.json?adults=1&dateEnd=2018-01-29&dateStart=2018-01-28&rooms=1&changed_currency=INR
        Json_url = 'https://www.splendia.com/en/availability/'+str(Hotelid)+'.json?adults='+str(Guests)+'&dateEnd='+str(Checkout)+'&dateStart='+str(Checkin)+'&rooms=1&changed_currency='+str(Curr)
        #print Json_url
        Ratedate    = re.search(r"&dateStart=(\d+-\d+-\d+)&", url_db).group(1)
        
        
        try:    
            hml = requests.get(Json_url,headers= head,proxies=proxies,timeout=10)
            #print "Statuscode:",hml.status_code
            ##print hml
        
            
        except Exception,e:
            value_error=str(re.sub("'",'"',str(e)))
            value_error=str(e).encode('ascii','ignore')
            try:
                hml = requests.get(Json_url, headers= head, proxies=proxies)
                
            except Exception,e:
                value_error=str(re.sub("'",'"',str(e)))
                keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(WebSiteCode,datetime.datetime.now(),id_update)
                key = bucket.new_key(keyvalue)
                key.set_contents_from_string(str(e))
                region=''
                ip=re.sub(r"\{'.*?@|'\}|:\d+","",str(proxies))
                try:
                    try:
                        r = requests.get('http://freegeoip.net/json/'+ip,timeout=30)
                    except Exception,e:
                        r = requests.get('http://freegeoip.net/json/'+ip,timeout=30)
                    js = r.json()
                    region=js['country_name']
                except Exception,e:
                    region=''
                statuscode=5
                Guests=0
                array.append(aws_insert.insert(id_update, inputid ,"",WebSiteCode, "", "", "", "", Guests, "", "", "", "", "",url_db, url_db, url_db, "", "", "", "", "", "",StartDate, EndDate , "", "", "", "", "", "", "", "", "",region,statuscode, israteperstay))
                return json.dumps(array)
        if (hml.status_code <> 200): 
            hml = requests.get(Json_url, headers= head, proxies=proxies) 
            
        if (hml.status_code == 403 or hml.status_code == 407):
            try:
                hml = requests.get(Json_url,headers= head,proxies=proxies)
                if (hml.status_code != 200):
                    hml = requests.get(Json_url, headers=head)
            except Exception,e:
                value_error=str(re.sub("'",'"',str(e)))
                value_error=str(e).enode('ascii','ignore')
                keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(WebSiteCode,datetime.datetime.now(),id_update)
                key = bucket.new_key(keyvalue)
                key.set_contents_from_string(str(e))
                region=''
                ip=re.sub(r"\{'.*?@|'\}|:\d+","",str(proxies))
                ##print hml
            
                try:
                    try:
                        r = requests.get('http://freegeoip.net/json/'+ip,timeout=30)
                    except Exception,e:
                        r = requests.get('http://freegeoip.net/json/'+ip,timeout=30)
                    js = r.json()
                    region=js['country_name']
                except Exception,e:
                    region=''
                
                 
                statuscode=5
                Guests=0
                array.append(aws_insert.insert(id_update, inputid ,"",WebSiteCode, "", "", "", "", Guests, "", "", "", "", "",url_db, url_db, url_db, "", "", "", "", "", "",StartDate, EndDate , "", "", "", "", "", "", "", "", "",region,statuscode, israteperstay))
                return json.dumps(array)
        Json_Html= unidecode(hml.text).encode('ascii')
        #(unidecode(json_load.text).encode('ascii'))
        #str(roomvalue).decode("unicode-escape")
        if '"ratesAvailable":false' in Json_Html:
            statuscode=2
            Guests=0
            array.append(aws_insert.insert(id_update, inputid ,"",WebSiteCode, "", "", "", "", Guests, "", "", "", "", "",url_db, url_db, url_db, "", "", "", "", "", "",StartDate, EndDate , "", "", "", "", "", "", "", "", "",region,statuscode, israteperstay))
            return json.dumps(array)
    
            
        ##print Json_Html
        Rtdate=re.sub(r'-|\-','',Ratedate)
        keyvalue = "ondemand/{}/{:%Y%m%d}/source/{}.json".format(WebSiteCode,datetime.datetime.now(),str(inputid)+'_'+str(Rtdate)+'_'+id_update)
        #keyvalue = "{:%Y%m%d}/{}/{}/{}-{}-{}.txt".format(datetime.datetime.now(),WebSiteCode, id_update, inputid, id_update,Ratedate)
        key = bucket.new_key(keyvalue)
        key.set_contents_from_string(str(Json_Html))
        json_data=json.loads(Json_Html)
        
        
            
        ##print json_data
        WebSiteName = 'Splendia'
        WebSiteCode = 270
        ReportDate  = datetime.date.today()
        StartDate   = ReportDate
        RoomType    = ''
        #Guests      = ''
        OnsiteRate  = 0
        Netrate     = 0
        GrossRate   = 0
        Curr        = ''
        MaxOccupancy= ''
        isAvailable = ''
        RateDescription= ''
        Isprom      = 'N' 
        Closed_up   = 'Y'
        NumberOfDays= 30
        RateType    = ''
        StartDate   = ''
        EndDate     = ''
        Tax_status  =''
        da_time     = datetime.datetime.now()
        intime      = re.sub(r'\s','T',str(da_time))
        Discount    = 0
        urlRate     = url_db
        urlInclusions = url_db
        urlAmenities  = url_db
        RoomAmenity_Type = ''
        Promotion_Name = ''
        MealInclusion_Type=''
        statuscode  =''
        Description_size = ''
        RateDescription1 = ''
        bedDouble = ''
        bedTwin_ = 0
        bedDouble_ = 0
        bedSingle = ''
        bedSingle_ = 0
        ##print Json_Htmls
        #fo = open('name.html', 'w')
        #fo.write(str(Json_Html))
        
        if 'rooms' in json_data:
            ##print 'Hai'
            Closed_up   = 'N'
            for block in json_data['rooms']:
                ##print 'Hai'
                if 'name' in block:
                    Roomtype=unidecode(str(block['name'])).encode('ascii')
                    Roomtype=re.sub(r"'","",Roomtype)
                else:
                    Roomtype=''
                ##print Roomtype
                '''if 'minSize' in block:
                    Roomtyp=block['minSize']
                    Roomtyp='Sq.ft' +str(Roomtyp)
                else:
                    Roomtyp=''
                ##print Roomtyp'''
                
                #Roomtype=Roomty+' '+Roomtyp
                    
                ##print Roomtype
                
                '''if 'maxOccupancy' in block:
                    MaxOccupancy=block['maxAdults']
                else:
                    MaxOccupancy=''
                ##print MaxOccupancy'''
                
                if 'bedDouble' in block:
                    bedDouble_=block['bedDouble']
                    if int(bedDouble_) > 0:
                        bedDouble = str(bedDouble_)+' Double bed'
                else:
                    bedDouble_=''
                    
                if 'bedTwin' in block:
                    bedTwin_=block['bedTwin']
                    if int(bedTwin_) > 0:
                        bedDouble = str(bedTwin_)+' Twin or double bed'
                else:
                    bedTwin_=''
                    
                if 'bedSingle' in block:
                    bedSingle_=block['bedSingle']
                    #if int(bedSingle_) <= 0:
                        
                    if int(bedSingle_) > 1:
                        bedSingle = str(bedSingle_)+' bedSingle(s)'
                    else:
                        bedSingle=''
                        
                    if ('1' not in str(bedDouble_)) and ('1' not in str(bedTwin_)):
                        bedDouble = ''
                if 'minSize' in block:
                    minSize=block['minSize']
                else:
                    minSize=''
                    
                if 'description' in block:
                    RateDescription1=block['description']
                    RateDescription1=re.sub(r"'","",RateDescription1)
                else:
                    RateDescription1=''
                ##print RateDescription1
                
                if minSize:
                    RateDescription = str(minSize)+' m2,'+str(bedSingle)+' '+str(bedDouble)+' '+(RateDescription1).strip()
                    RateDescription=re.sub(r'\r\n','',RateDescription)
                elif bedSingle:
                    RateDescription = str(bedSingle)+' '+(str(bedDouble)+' '+str(RateDescription1)).strip()
                    RateDescription=re.sub(r'\r\n','',RateDescription)
                else:
                    RateDescription = str(bedSingle)+' '+str(RateDescription1).strip()
                    RateDescription=re.sub(r'\r\n','',RateDescription)
                 
                ##print RateDescription
                RoomAmenity_Type = []
                if 'criteria' in block:
                    for Amenities1 in block['criteria']:
                        #Amenities=block3['criteria']
                        ##print Amenities 
                        
                        RoomAmenity_Type.append(Amenities1)
                        #RoomAmenity_Type=re.sub(r'\r\n','',RoomAmenity_Type)
                        
                    else:
                        RoomAmenity_Type=''
                    #print ",".join(RoomAmenity_Type)
                
                for block2 in block['ratePlans']:
                    ##print block2
                    if 'totalPrice' in block2:
                        OnsiteRate=block2['totalPrice']
                    else:
                        OnsiteRate=0
                    ##print OnsiteRate
                    if 'adults' in block2:
                        MaxOccupancy=block2['adults']
                    else:
                        MaxOccupancy=0
                    
                    
                    if 'nonRefundable' in block2:
                        Ratetype=block2['nonRefundable']
                        if '0' in str(Ratetype):
                            RateType = 'FREE CANCELLATION'
                        else:
                            RateType = 'NON Refundable'
                        ##print RateType
                    else:
                        RateType=''
                    
                    if 'mealPlan' in block2:
                        MealPlan=block2['mealPlan']
                        if '1' in MealPlan:
                            MealInclusion_Type = 'Breakfast Included'
                        else:
                            MealInclusion_Type = ''
                        ##print MealInclusion_Type
                    else:
                        MealPlan=''
                    if 'totalParentPrice' in block2:
                        Netrate=block2['totalParentPrice']
                        Isprom = 'Y'
                    elif 'parentPrice' in block2:
                        Netrate=block2['parentPrice']
                        Isprom = 'Y'
                    else:
                        Netrate=0
                        Isprom = 'N'
                    ##print Netrate
                    
                    Discount=Netrate
            
            
                    if 'discount' in block2:
                        promo_dis=block2['discount']
                    else:
                        promo_dis=''
                    ##print promo_dis
                    if 'linkedRateType' in block2:
                        if "specialOffer" in block2['linkedRateType']:
                            Promo=block2['linkedRateType']['specialOffer']
                            if Promo:
                                Promotion_Name = 'SPECIAL OFFER '+str(promo_dis)+' OFF'
                                Isprom = 'Y'  
                            else:
                                Promotion_Name = ''
                        else:
                            Promotion_Name = ''
                        
                    ##print Promotion_Name
            
                    if OnsiteRate==0 and str(OnsiteRate=='0'):
                        Closed_up='Y'
                        statuscode ='1'
                    else:
                        Closed_up='N'
                    '''if LOS>1:
                        israteperstay = 'N'
                    else:'''
                    israteperstay = 'Y'
                    Tax_status = '-1'
                    if (Netrate == 0 or Netrate == '') and (Promotion_Name == 0 or Promotion_Name == ''):
                        Isprom = 'N'
                ##print (id_update, inputid, WebSiteName, WebSiteCode, StartDate, RoomType,LOS, Ratedate, Guests, OnsiteRate, Netrate, GrossRate, Curr, RateDescription,urlRate, urlInclusions, urlAmenities, RoomAmenity_Type, MealInclusion_Type,MaxOccupancy, Isprom, Closed_up,NumberOfDays, StartDate, EndDate,  intime, isAvailable,None, None,Tax_status, None, RateType, Discount,Promotion_Name,region, statuscode, israteperstay)
                    array.append(aws_insert.insert(id_update, inputid, WebSiteName, WebSiteCode, StartDate, Roomtype,LOS, Ratedate, Guests, OnsiteRate, Netrate, GrossRate, Curr, RateDescription,urlRate, urlInclusions, urlAmenities, RoomAmenity_Type, MealInclusion_Type,MaxOccupancy, Isprom, Closed_up,NumberOfDays, StartDate, EndDate,  intime, isAvailable,None, None,Tax_status, None, RateType, Discount,Promotion_Name,region, statuscode, israteperstay))
        else:
            Closed_up='Y'
            statuscode  ='2'
            ##print (id_update, inputid, WebSiteName, WebSiteCode, StartDate, RoomType,LOS, Ratedate, Guests, OnsiteRate, Netrate, GrossRate, Curr, RateDescription,urlRate, urlInclusions, urlAmenities, RoomAmenity_Type, MealInclusion_Type,MaxOccupancy, Isprom, Closed_up,NumberOfDays, StartDate, EndDate,  intime, isAvailable,None, None,Tax_status, None, RateType, Discount,Promotion_Name,region, statuscode, israteperstay)
            array.append(aws_insert.insert(id_update, inputid, WebSiteName, WebSiteCode, StartDate, Roomtype,LOS, Ratedate, Guests, OnsiteRate, Netrate, GrossRate, Curr, RateDescription,urlRate, urlInclusions, urlAmenities, RoomAmenity_Type, MealInclusion_Type,MaxOccupancy, Isprom, Closed_up,NumberOfDays, StartDate, EndDate,  intime, isAvailable,None, None,Tax_status, None, RateType, Discount,Promotion_Name,region, statuscode, israteperstay))
        keyvalue = "ondemand/{}/{:%Y%m%d}/delivery/{}.json".format(WebSiteCode,datetime.datetime.now(),str(inputid)+'_'+str(Rtdate)+'_'+id_update)
        key = bucket.new_key(keyvalue)
        key.set_contents_from_string(json.dumps(array))
        return json.dumps(array)
    except Exception as e: 
        value_error=str(re.sub(r"'",'"',str(e)))
        insert_value_error=str(value_error)+'Where line number '+str(sys.exc_traceback.tb_lineno)+' - '+str(proxyip)
        print insert_value_error
        statuscode='4'
        keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(WebSiteCode,datetime.datetime.now(),id_update)
        key = bucket.new_key(keyvalue)
        key.set_contents_from_string(insert_value_error)
        Guests=0
        array.append(aws_insert.insert(id_update, inputid ,"",WebSiteCode, "", "", "", "", Guests, "", "", "", "", "",urlRate, urlInclusions, urlAmenities, "", "", "", "", "", "",StartDate, EndDate , "", "", "", "", "","", "", "", "",region,statuscode, israteperstay))
        return json.dumps(array)

#fetchrates(url , inputid, id_update, proxyip)
