import boto3 
import time 
import botocore 
import traceback 


sqs = boto3.client('sqs', aws_access_key_id='AKIAI3ZTEOXURCYJUOFA',aws_secret_access_key='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',region_name='us-west-2')
logclient = boto3.client('logs', aws_access_key_id='AKIAI3ZTEOXURCYJUOFA',aws_secret_access_key='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',region_name='us-west-2')


queue_url = "https://sqs.us-west-2.amazonaws.com/982499500900/rmresult"
resd = logclient.describe_log_streams(logGroupName="rmapi", logStreamNamePrefix="scheduler")
token = resd["logStreams"][0]['uploadSequenceToken']
res = logclient.put_log_events(logGroupName="rmapi", logStreamName="scheduler", logEvents=[{'timestamp':int(round(time.time() * 1000)),'message':' Test File' }], sequenceToken = token)
print(res)
exit()
_run = True
while _run:
	try:
		print "Waiting for message"
		response = sqs.receive_message(
		    QueueUrl=queue_url,
		    AttributeNames=[
		        'SentTimestamp'
		    ],
		    MaxNumberOfMessages=1,
		    MessageAttributeNames=[
		        'All'
		    ],
		    WaitTimeSeconds=20
		)
		print response
		time.sleep(30)
		if response.has_key("Messages"):
			receipt_handle = response["Messages"][0]["ReceiptHandle"]
			sqs.change_message_visibility(QueueUrl=queue_url,ReceiptHandle=receipt_handle,VisibilityTimeout=0)
			print "Queue Pushed back"
			exit()
	except botocore.errorfactory.ClientError as e: 
		print traceback.format_tb(exc_traceback)
		if e.response["Error"]["Code"] == "AWS.SimpleQueueService.NonExistentQueue":
			print("No Message available")
			pass
	except Exception, e:
		print traceback.format_tb(exc_traceback)
		pass
	except KeyboardInterrupt:
		_run = False
