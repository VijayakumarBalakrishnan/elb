# -*- coding: utf-8 -*-
import re
import requests
import datetime
import json
import sys 
import boto
import gc

import unidecode
import aws_insert

'''url = 'http://english.ctrip.com/hotels/paris-hotel-detail-717281/amarante-beau-manoir-hotel-paris/#ci=2018-01-29&co=2018-01-31&curr=USD&city=192&crn=1'
inputid = '2'
id_update = '5'
proxyip = 'user-34068:214859b73da0e174@45.64.106.45:1212'
'''

def fetchrates(url, inputid, id_update, proxyip):
	array = []
	israteperstay = ''
	try:
		intime = re.sub(r'\s', 'T', str(datetime.datetime.now()))
		functionname = 'Ctrip'
		WebSitecode = '323'
		Guests = 0
		region = ''
		conn = boto.connect_s3(aws_access_key_id='AKIAIXEGZVXCWE2FV3SQ', aws_secret_access_key='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') 
		bucket = conn.get_bucket("rmapi")
		StartDate = datetime.date.today()
		EndDate = datetime.date.today() + datetime.timedelta(days=29)	
		proxies = {"http": "http://{}".format(proxyip)}
		url1 = 'http://english.ctrip.com/hotels/Detail/GetRoomDataJson4HotelsV2'
		HotelID = re.search(r"detail-(\d+)[/|#]", url).group(1)
		checkin = re.search(r"ci=(.*?)&", url).group(1)
		RateDate = checkin
		Rtdate = re.sub(r'-|\-', '', RateDate)
		checkout = re.search(r"co=(.*?)&", url).group(1)
		delta = datetime.datetime.strptime(checkout, "%Y-%m-%d") - datetime.datetime.strptime(checkin, "%Y-%m-%d")
		LOS = delta.days
		curr = re.search(r"curr=(.*?)&", url).group(1)
		currency_list = ['AUD','IDR','PLN','BRL','INR','RUB','CAD','JPY','SGD','CHF','KRW','THB','CNY','MYR','TRY','EUR','NZD','TWD','GBP','PHP','USD','HKD']
		if curr not in currency_list:
			stacktrace = sys.exc_traceback.tb_lineno
			keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(WebSitecode, datetime.datetime.now(), id_update)
			key = bucket.new_key(keyvalue)
			key.set_contents_from_string("Selected Currencies not available in the sources")
			region = ''
			ip = re.sub(r"\{'.*?@|'\}|:\d+", "", str(proxies))
			try:
				try:
					r = requests.get('http://freegeoip.net/json/' + ip, timeout=30)
				except Exception, e:
					r = requests.get('http://freegeoip.net/json/' + ip, timeout=30)
				js = r.json()
				region = js['country_name']
			except Exception, e:
				region = ''
			statuscode = 8
			Guests = 0
			array.append(aws_insert.insert(id_update, inputid , functionname, WebSitecode, "", "", "", "", Guests, "", "", "", "", "", url, url, url, "", "", "", "", "", "", StartDate, EndDate , "", "", "", "", "", "", "", "", "", region, statuscode, israteperstay))
			return json.dumps(array)
		CityID = re.search(r"city=(.*?)&", url).group(1)
		payload = {'HotelID':HotelID, 'checkin':checkin, 'checkout':checkout, 'RoomQuantity':'1', 'CityID':CityID, 'PromotionIds':'', 'allianceid':'', 'sid':'', 'ouid':'', 'curr':curr}
		head = {'User-Agent':'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:12.0) Gecko/20100101 Firefox/48.0'}
		try:
			json_load = requests.post(url1, data=payload, headers=head, proxies=proxies, timeout=50)
		except Exception, e:
			print e
			try:
				json_load = requests.post(url1, data=payload, headers=head, proxies=proxies)
			except Exception, e:
				value_error = str(re.sub(r"'", '', str(e)))
				stacktrace = sys.exc_traceback.tb_lineno
				keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(WebSitecode, datetime.datetime.now(), id_update)
				key = bucket.new_key(keyvalue)
				key.set_contents_from_string(str(e))
				region = ''
				ip = re.sub(r"\{'.*?@|'\}|:\d+", "", str(proxies))
				try:
					try:
						r = requests.get('http://freegeoip.net/json/' + ip, timeout=30)
					except Exception, e:
						r = requests.get('http://freegeoip.net/json/' + ip, timeout=30)
					js = r.json()
					region = js['country_name']
				except Exception, e:
					region = ''
				statuscode = 5
				Guests = 0
				array.append(aws_insert.insert(id_update, inputid , functionname, WebSitecode, "", "", "", "", Guests, "", "", "", "", "", url, url, url, "", "", "", "", "", "", StartDate, EndDate , "", "", "", "", "", "", "", "", "", region, statuscode, israteperstay))
				return json.dumps(array)	
			ip = re.sub(r"\{'.*?@|'\}|:\d+", "", str(proxies))
			try:
				try:
					r = requests.get('http://freegeoip.net/json/' + ip, timeout=30)
				except Exception, e:
					r = requests.get('http://freegeoip.net/json/' + ip, timeout=30)
				js = r.json()
				region = js['country_name']
			except Exception, e:
				region = ''	
		if json_load.status_code <> 200:
			json_load = requests.post(url1, data=payload, headers=head, proxies=proxies)
		json_data = json_load.json()
		
		keyvalue = "ondemand/{}/{:%Y%m%d}/source/{}.json".format(WebSitecode, datetime.datetime.now(), str(inputid) + '_' + str(Rtdate) + '_' + id_update)
		key = bucket.new_key(keyvalue)
		key.set_contents_from_string(str(json_data))
		net_rate = ''
		ispromupdate = 'N'
		roomavlb = ''
		TaxType = ''
		Tax_status = ''
		promotion = ''
		RoomType = ''
		Mealtype = ''
		RateDescription = ''
		Ratetype = ''
		TaxAmount = ''
		OnsiteRate = ''
		MaxOccupancy = ''
		RoomAmenity_Type = ''
		#fo = open('ctrip_name.html', 'w')
		#fo.write(str(json_data))
		##print "json_data :",json_data																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																				
		if 'lstHtlDetailJsonModel' in json_data:
			Closed_up = 'N'
			if json_data['lstHtlDetailJsonModel']:
				roomsIds = []
				for RoomIds in re.compile(r"BaseRoomId':\s*(.*?),").findall(str(json_data)):
					roomsIds.append(RoomIds)
				roomsIds = re.sub(r"'", "", str(roomsIds))
				Link = 'http://english.ctrip.com/hotels/Detail/GetRoomsFacility' 
				head1 = {'Host':'english.ctrip.com', 'Connection':'keep-alive', 'Cache-Control':'max-age=0', 'Origin':'http://english.ctrip.com', 'User-Agent':'Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.36 (KHTML, like Gecko) Ubuntu Chromium/37.0.2062.120 Chrome/37.0.2062.120 Safari/537.36', 'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8', 'Accept':'*/*', 'Referer':url, 'Accept-Encoding':'gzip,deflate', 'Accept-Language':'en-US,en;q=0.8'}
				pay1 = {'hotelId':HotelID, 'roomsIds':roomsIds}
				AMNT_D = requests.post(Link, data=pay1, headers=head1, proxies=proxies).text
				for Data in json_data['lstHtlDetailJsonModel']:
					if 'baseRoomName' in Data:
						RoomType = Data['baseRoomName']
					else:
						RoomType = ''
					if 'roomInfo' in Data:
						Desc = []
						for Desc_l in  Data['roomInfo']['list']:
							if 'itemDetail' in Desc_l:
								itemDetail = Desc_l['itemDetail']
								itemName = Desc_l['itemName']
								itemDetails = itemDetail.encode('ascii', 'ignore')
								itemNames = itemName.encode('ascii', 'ignore')
								Final = str(itemNames) + ':' + str(itemDetails)
								Desc.append(Final)
					if 'BaseRoomId' in Data:
						BaseRoomId = Data['BaseRoomId']
					else:
						BaseRoomId = ''
					
					AMenit_reg = re.search(r'RoomID":' + str(BaseRoomId) + ',"FTypes":(.*?)]}', AMNT_D)
					if AMenit_reg:
						RoomAmenity_Type = re.sub(r'"FName":|"FTypeName":', r"", re.sub(r'\[|\]|{|}|"Facilitys":|"FID":\d+,|,"FValue":\d+}', r"", AMenit_reg.group(1)))
					else:
						RoomAmenity_Type = ''
					if 'roomList' in Data:
						for Rates in Data['roomList']:
							if 'personNums' in Rates:
								MaxOccupancy = Rates['personNums']
							else:
								MaxOccupancy = ''
							if 'saleDetailInfo' in Rates:
								sellPopupWindow = str(Rates['saleDetailInfo']['sellPopupWindow'])
								##print 'sellPopupWindow:',sellPopupWindow
								onsiterate_reg = re.search(r'<tr class="tr-total">.*?<span class="price-num">\s*(.*?)\s*<', str(sellPopupWindow), re.DOTALL)
								if onsiterate_reg:
									OnsiteRate = onsiterate_reg.group(1)
								else:
									OnsiteRate = 0
								##print "OnsiteRate :",OnsiteRate
								israteperstay = 'Y'
								curr = Rates['saleDetailInfo']['currency']
								#TaxAmount = Rates['saleDetailInfo']['roomFee']
								Taxamout_reg = re.search(r'class="fee-item">.*?<span class="c-price">.*?<span>\s*(.*?)\s*<', str(sellPopupWindow), re.DOTALL)
								if Taxamout_reg:
									TaxAmount = Taxamout_reg.group(1)
								else:
									TaxAmount = 0
								##print "TaxAmount :",TaxAmount
							try:
								Ratetype = Rates['sellPoint']['freeCancel']['freeCancelStr']
								Mealtype = Rates['sellPoint']['breakfast']['breakfastStr']
							except Exception, e:
								Ratetype = ''
								Mealtype = ''
								print e
							RateDescription = re.sub(r'&.*?;','',re.sub(r'&sup2', r'²', re.sub(r"'|\[|\]|\\\\r|\\\\n", "", re.sub(r"::", ":", str(Desc)))))
							u = unicode(RateDescription, "utf-8")
							RateDescription = unidecode.unidecode(u)
							if OnsiteRate == 0:
								statuscode = 1
							else:
								statuscode = ""
							if TaxAmount == 0 or str(TaxAmount) == '0':
								Tax_status = '-1'
							else:
								Tax_status = '1'
							##print (id_update,inputid ,functionname,WebSitecode,StartDate,RoomType,LOS,RateDate,Guests,OnsiteRate,net_rate,OnsiteRate,curr,RateDescription,url,url,url,RoomAmenity_Type,Mealtype,MaxOccupancy,ispromupdate,Closed_up,30,StartDate ,EndDate,intime,roomavlb,TaxType,TaxAmount,Tax_status,None,Ratetype,net_rate,promotion,region,statuscode)
							array.append(aws_insert.insert(id_update, inputid , functionname, WebSitecode, StartDate, RoomType, LOS, RateDate, Guests, OnsiteRate, net_rate, OnsiteRate, curr, RateDescription, url, url, url, RoomAmenity_Type, Mealtype, MaxOccupancy, ispromupdate, Closed_up, 30, StartDate , EndDate, intime, roomavlb, TaxType, TaxAmount, Tax_status, None, Ratetype, net_rate, promotion, region, statuscode, israteperstay))
			else:
				Closed_up = "Y"
				statuscode = 2
				array.append(aws_insert.insert(id_update, inputid , functionname, WebSitecode, StartDate, RoomType, LOS, RateDate, Guests, OnsiteRate, net_rate, OnsiteRate, curr, RateDescription, url, url, url, RoomAmenity_Type, Mealtype, MaxOccupancy, ispromupdate, Closed_up, 30, StartDate , EndDate, intime, roomavlb, TaxType, TaxAmount, Tax_status, None, Ratetype, net_rate, promotion, region, statuscode, israteperstay))
				##print (id_update,inputid ,functionname,WebSitecode,StartDate,RoomType,LOS,RateDate,Guests,OnsiteRate,net_rate,OnsiteRate,curr,RateDescription,url,url,url,RoomAmenity_Type,Mealtype,MaxOccupancy,ispromupdate,Closed_up,30,StartDate ,EndDate,intime,roomavlb,TaxType,TaxAmount,Tax_status,None,Ratetype,net_rate,promotion,region,statuscode)
		else:
			Closed_up = "Y"
			statuscode = 2
			array.append(aws_insert.insert(id_update, inputid , functionname, WebSitecode, StartDate, RoomType, LOS, RateDate, Guests, OnsiteRate, net_rate, OnsiteRate, curr, RateDescription, url, url, url, RoomAmenity_Type, Mealtype, MaxOccupancy, ispromupdate, Closed_up, 30, StartDate , EndDate, intime, roomavlb, TaxType, TaxAmount, Tax_status, None, Ratetype, net_rate, promotion, region, statuscode, israteperstay))
			##print (id_update,inputid ,functionname,WebSitecode,StartDate,RoomType,LOS,RateDate,Guests,OnsiteRate,net_rate,OnsiteRate,curr,RateDescription,url,url,url,RoomAmenity_Type,Mealtype,MaxOccupancy,ispromupdate,Closed_up,30,StartDate ,EndDate,intime,roomavlb,TaxType,TaxAmount,Tax_status,None,Ratetype,net_rate,promotion,region,statuscode)
		keyvalue = "ondemand/{}/{:%Y%m%d}/delivery/{}.json".format(WebSitecode, datetime.datetime.now(), str(inputid) + '_' + str(Rtdate) + '_' + id_update)
		key = bucket.new_key(keyvalue)
		key.set_contents_from_string(json.dumps(array))
		return json.dumps(array)
		gc.collect()
	except Exception, e:
		value_error = str(re.sub(r"'", '"', str(e)))
		stacktrace = sys.exc_traceback.tb_lineno
		insert_value_error = str(value_error) + 'Where line number ' + str(stacktrace) + str(proxyip)
		#print 'insert_value_error:',insert_value_error
		statuscode = '4'
		WebSitecode = '323'
		keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(WebSitecode, datetime.datetime.now(), id_update)
		key = bucket.new_key(keyvalue)
		key.set_contents_from_string(insert_value_error)
		Guests = 0
		array.append(aws_insert.insert(id_update, inputid , functionname, WebSitecode, "", "", "", "", Guests, "", "", "", "", "", url, url, url, "", "", "", "", "", "", StartDate, EndDate , "", "", "", "", "", "", "", "", "", region, statuscode, israteperstay))
		return json.dumps(array)


#fetchrates(url , inputid, id_update, proxyip)
