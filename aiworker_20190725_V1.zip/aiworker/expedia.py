import requests,re,json,aws_insert,datetime,random,sys,boto
from mtranslate import translate

def trans(to_translate):
    try:
        Translated = (translate(to_translate, 'en'))
        return Translated
    except:
        return to_translate 
    
def Load(urlforLd, headerT, proxi, timeout):
    return requests.get(urlforLd, headers=headerT, timeout=timeout, proxies=proxi, verify=False)

def StrctNew(jsonvalue, url_inc, id_update, inputid, RateDate, Currencycode, StartDate, EndDate, Guests, LOS, array, region, intime, proxyip, bucket):
    try:
        if 'currentHotel' in jsonvalue:
            if 'offers' in jsonvalue['currentHotel']:
                if 'rooms' in jsonvalue['currentHotel']['offers']:
                    if len(jsonvalue['currentHotel']['offers']['rooms'])!=0:
                        ROOM_CHECK = []
                        for roomsL in jsonvalue['currentHotel']['offers']['rooms']:
                            if 'name' in roomsL:
                                Roomtype = roomsL['name']
                            else:
                                Roomtype = ''
                            if 'description' in roomsL:
                                Room_Desc = roomsL['description']
                            else:
                                Room_Desc = ''
                            if 'maxOccupancy' in roomsL:
                                Maxocp = roomsL['maxOccupancy']['people']
                            else:
                                Maxocp = None
                            Room_Amts = []
                            if roomsL['ratePlans']:
                                for ratesP in roomsL['ratePlans']:
                                    promotion    = ''
                                    ispromupdate = ''
                                    if 'amenities' in ratesP:
                                        for Amnt in ratesP['amenities']:
                                            Room_Amts.append(Amnt['description'])
                                    if 'price' in ratesP:
                                        if 'taxAndFees' in ratesP['price']:
                                            taxAndFees = re.sub(r'[A-Z|a-z]', '', re.sub(r'(\D)', '', re.sub(r"\\u20b9|\$|,|[A-Za-z]+\.|Rs\.|Rs", r"", str(ratesP['price']['taxAndFees']))))
                                        else:
                                            taxAndFees = 0
                                        if 'lead' in ratesP['price']:
                                            statuscode = ''
                                            OnsiteRate = re.sub(r'[A-Z|a-z]', '', re.sub(r'(\D)', '', re.sub(r"\\u20b9|\$|,|[A-Za-z]+\.|Rs\.|Rs", r"", str(ratesP['price']['lead']))))
                                            Closed_up  = 'N'
                                        else:
                                            statuscode = '1'
                                            Closed_up  = 'Y'
                                            OnsiteRate = 0
                                        if 'strikeOut' in ratesP['price']:
                                            net_rate     = re.sub(r'[A-Z|a-z]', '', re.sub(r'(\D)', '', re.sub(r"\\u20b9|\$|,|[A-Za-z]+\.|Rs\.|Rs", r"", str(ratesP['price']['strikeOut']))))
                                            ispromupdate = 'Y'
                                        else:
                                            ispromupdate = 'N'
                                            net_rate     = 0
                                    else:
                                        taxAndFees   = 0
                                        statuscode   = '1'
                                        ispromupdate = 'N'
                                        net_rate     = 0
                                        OnsiteRate   = 0
                                        Closed_up    = 'Y'
                                    if 'limitedAvailability' in ratesP:
                                        if re.search(r'(\d+)', str(ratesP['limitedAvailability'])):
                                            roomavlb = re.search(r'(\d+)', str(ratesP['limitedAvailability'])).group(1)
                                        else:
                                            roomavlb = 0
                                    else:
                                        roomavlb = 0
                                    if 'cancellationPolicy' in ratesP:
                                        if ratesP['cancellationPolicy']['freeCancel']:
                                            Ratetype = 'Free Cancellation'
                                        elif ratesP['cancellationPolicy']['nonRefundable']:
                                            Ratetype = 'Non Refundable'
                                        else:
                                            Ratetype = ''
                                    else:
                                        Ratetype = ''
                                    if 'dynamicRateRule' in ratesP:
                                        if 'description' in ratesP['dynamicRateRule']:
                                            promotion = ratesP['dynamicRateRule']['description']
                                            ispromupdate = 'Y'
                                        else:
                                            ispromupdate = 'N'
                                            promotion = ''
                                    
                                    if OnsiteRate == 0:
                                        net_rate   = 0
                                        Closed_up  = 'Y'
                                        statuscode = '1'
                                        Tax_status = ''
                                    else:
                                        if int(taxAndFees) == 0:
                                            Tax_status = '1'
                                        else:
                                            Tax_status = '2'
                                        Closed_up = 'N'
                                    if LOS > 1 and Currencycode in ('AUD', 'CHF', 'DKK', 'EUR', 'GBP', 'NOK', 'NZD', 'SEK') or LOS == 1:
                                        israteperstay = 'Y'
                                    else:
                                        israteperstay = 'N'
                                    if Roomtype:
                                        ROOM_CHECK.append(Roomtype)
                                        Room_Amt  = ", ".join(Room_Amts)
                                        Room_Desc = re.sub(r'<.*?>|&nbsp;','',re.sub(r"</p><p>", r", ",str(Room_Desc)))
                                        array.append(aws_insert.insert(id_update, inputid , 'Expedia', 1, StartDate, Roomtype, LOS, RateDate, Guests, OnsiteRate, net_rate, OnsiteRate, Currencycode, Room_Desc, url_inc, url_inc, url_inc, Room_Amt, Room_Amt, Maxocp, ispromupdate, Closed_up, 30, StartDate , EndDate, intime, roomavlb, None, None, Tax_status, None, Ratetype, net_rate, promotion, region, statuscode, israteperstay))
                                try:
                                    if 'unavailableRatePlans' in roomsL and roomsL['unavailableRatePlans']:
                                        for uratesP in roomsL['unavailableRatePlans']:
                                            if 'price' in uratesP:
                                                if 'lead' in uratesP['price']:
#                                                     OnsiteRate = str(uratesP['price']['lead'])
#                                                     if 'sold out' in OnsiteRate.lower():
                                                    OnsiteRate = 0
                                                    net_rate   = 0
                                                    Closed_up  = 'Y'
                                                    statuscode = '1'
                                                    Tax_status = ''
                                                    region = ''
                                            Room_Amts = []
                                            if 'amenities' in uratesP:
                                                for Amnt in uratesP['amenities']:
                                                    Room_Amts.append(Amnt['description'])
                                            Room_Amt  = re.sub(r"'","''",str(", ".join(Room_Amts)))
                                            Room_Desc = re.sub(r"'","''",re.sub(r'<.*?>|&nbsp;','',re.sub(r"</p><p>", r", ",str(Room_Desc))))
                                            array.append(aws_insert.insert(id_update, inputid , 'Expedia', 1, StartDate, Roomtype, LOS, RateDate, Guests, 0, 0, 0, '', Room_Desc, url_inc, url_inc, url_inc, Room_Amt, Room_Amt, Maxocp, 'N', 'Y', 30, StartDate , EndDate, intime, 0, None, None, '', None, '', 0, '', '', statuscode, ''))
                                except Exception as e:
                                    print 'Error: Soldout Room Exp'
#                                     None           
                            else:
                                if Roomtype:
                                    statuscode = '1'
                                    Room_Desc  = re.sub(r'<.*?>|&nbsp;','',re.sub(r"</p><p>", r", ",str(Room_Desc)))
                                    array.append(aws_insert.insert(id_update, inputid , 'Expedia', 1, StartDate, Roomtype, LOS, RateDate, Guests, 0, 0, 0, '', Room_Desc, url_inc, url_inc, url_inc, '', '', Maxocp, 'N', 'Y', 30, StartDate , EndDate, intime, 0, None, None, '', None, '', 0, '', '', statuscode, ''))
                        if len(ROOM_CHECK)!=0:
                            return json.dumps(array)
                        else:
                            statuscode = '5'
                            array.append(aws_insert.insert(id_update, inputid , 'Expedia', 1, StartDate, '', LOS, RateDate, Guests, 0, 0, 0, '', '', url_inc, url_inc, url_inc, '', '', None, 'N', 'Y', 30, StartDate , EndDate, intime, 0, None, None, '', None, '', 0, '', '', statuscode, ''))
                            return json.dumps(array)
                    else:
                        statuscode = '2'
                        array.append(aws_insert.insert(id_update, inputid , 'Expedia', 1, StartDate, '', LOS, RateDate, Guests, 0, 0, 0, '', '', url_inc, url_inc, url_inc, '', '', None, 'N', 'Y', 30, StartDate , EndDate, intime, 0, None, None, '', None, '', 0, '', '', statuscode, ''))
                        return json.dumps(array)
                else:
                    statuscode = '2'
                    array.append(aws_insert.insert(id_update, inputid , 'Expedia', 1, StartDate, '', LOS, RateDate, Guests, 0, 0, 0, '', '', url_inc, url_inc, url_inc, '', '', None, 'N', 'Y', 30, StartDate , EndDate, intime, 0, None, None, '', None, '', 0, '', '', statuscode, ''))
                    return json.dumps(array)
            else:
                statuscode = '2'
                array.append(aws_insert.insert(id_update, inputid , 'Expedia', 1, StartDate, '', LOS, RateDate, Guests, 0, 0, 0, '', '', url_inc, url_inc, url_inc, '', '', None, 'N', 'Y', 30, StartDate , EndDate, intime, 0, None, None, '', None, '', 0, '', '', statuscode, ''))
                return json.dumps(array)
        else:
            statuscode = '2'
            array.append(aws_insert.insert(id_update, inputid , 'Expedia', 1, StartDate, '', LOS, RateDate, Guests, 0, 0, 0, '', '', url_inc, url_inc, url_inc, '', '', None, 'N', 'Y', 30, StartDate , EndDate, intime, 0, None, None, '', None, '', 0, '', '', statuscode, ''))
            return json.dumps(array)
    except Exception as e:
        insert_value_error = str(str(re.sub(r"'", '"', str(e)))) + 'Where line number ' + str(sys.exc_traceback.tb_lineno) + str(proxyip)
        print (insert_value_error)
        statuscode = '4'
        keyvalue   = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format('1', datetime.datetime.now(), id_update)
        key        = bucket.new_key(keyvalue)
        key.set_contents_from_string(insert_value_error)
        array.append(aws_insert.insert(id_update, inputid , "Expedia", '1', "", "", "", "", Guests, "", "", "", "", "", url_inc, url_inc, url_inc, "", "", "", "", "", "", StartDate, EndDate , "", "", "", "", "", "", "", "", "", region, statuscode, israteperstay))
    return json.dumps(array)   

def fetchrates(url, inputid, id_update, proxyip):
    inputid    = str(inputid)
    id_update  = str(id_update)
    proxies    = {'https':'http://{}'.format(proxyip)}
    Websitecode= 1
    StartDate  = datetime.date.today()
    intime     = re.sub(r'\s', 'T', str(datetime.datetime.now()))
    array      = []
    EndDate    = datetime.date.today() + datetime.timedelta(days=29)
    conn       = boto.connect_s3(aws_access_key_id='AKIAIXEGZVXCWE2FV3SQ', aws_secret_access_key='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') 
    bucket     = conn.get_bucket("rmapi")
    if re.search(r'=[a|A](\d+)[&|#]', str(url)):
        Guests = re.search(r'=[a|A](\d+)[&|#]', str(url)).group(1)
    elif re.search(r'[a|A]dults=(\d+)&', str(url)):
        Guests = re.search(r'[a|A]dults=(\d+)&', str(url)).group(1)
    elif re.search(r'[a|A]dult=(\d+)&', str(url)):
        Guests = re.search(r'[a|A]dult=(\d+)&', str(url)).group(1)
    else:
        Guests = re.search(r'=[a|A](\d+)&', str(url)).group(1)
    if re.search(r'(?s)chkin=(.*?)&', url):
        chekn = re.search(r'(?s)chkin=(.*?)&', url).group(1)
    if re.search(r'chkout=(.*?)&',url):
        chekt = re.search(r'chkout=(.*?)&', url).group(1)
    delta    = datetime.datetime.strptime(chekt, "%Y-%m-%d") - datetime.datetime.strptime(chekn, "%Y-%m-%d")
    LOS      = delta.days                
    RateDate = chekn
    inseRD   = re.sub(r'-|\-', '', str(RateDate))
    
    urlrepl1 = datetime.datetime.strptime(chekn, str('%Y-%m-%d')).strftime('%d/%m/%Y')
    urlrepl2 = datetime.datetime.strptime(chekt, str('%Y-%m-%d')).strftime('%d/%m/%Y')
    url_inse = re.sub(r'chkin=.*?&chkout=.*?&', 'chkin=' + urlrepl1 + '&chkout=' + urlrepl2 + '&', url)
    #URL_FORMAT#CHANGE
    chkin_re = re.search(r'chkin=(.*?)&', url_inse)
    chkot_re = re.search(r'chkout=(.*?)&', url_inse)
    Currenc  = re.search(r'multiCurrencyCode=(.*?)#', url_inse).group(1)
    if Currenc == 'USD':
        url_db_replace1 = re.sub(r"www.expedia.co.in", r"www.expedia.com", url_inse)        
        dates_chkin = datetime.datetime.strftime(datetime.datetime.strptime(re.search(r'chkin=(.*?)&', url_db_replace1).group(1), "%d/%m/%Y"), "%m/%d/%Y")
        dates_chkot = datetime.datetime.strftime(datetime.datetime.strptime(re.search(r'chkout=(.*?)&', url_db_replace1).group(1), "%d/%m/%Y"), "%m/%d/%Y")
        dates = 'chkin=' + dates_chkin + '&chkout=' + dates_chkot + '&'
        url_db = re.sub(r'chkin=.*?&chkout=.*?&', dates, url_db_replace1)
    elif Currenc == 'THB':
        url_db = re.sub(r"www.expedia.co.in", r"www.expedia.co.th", url_inse)       
    elif Currenc == 'EUR':
        url_db = re.sub(r"www.expedia.co.in", r"www.expedia.ie", url_inse)        
    elif Currenc == 'CHF':
        url_db = re.sub(r"www.expedia.co.in", r"www.expedia.ch", re.sub(r'chkin=.*?&chkout=.*?&', 'chkin=' + re.sub("/", ".", chkin_re.group(1)) + '&chkout=' + re.sub("/", ".", chkot_re.group(1)) + '&', url_inse))
        # #print "url_db", url_db
    elif Currenc == 'IDR':
        url_db = re.sub(r"www.expedia.co.in", r"www.expedia.co.id", url_inse)        
    elif Currenc == 'MYR':
        url_db = re.sub(r"www.expedia.co.in", r"www.expedia.com.my", url_inse)        
    elif Currenc == 'GBP':
        url_db = re.sub(r"www.expedia.co.in", r"www.expedia.co.uk", url_inse) 
    elif Currenc == 'INR':
        url_db = url_inse
    elif Currenc == 'ARS':
        url_db = re.sub(r"www.expedia.co.in", r'www.expedia.com.ar', url_inse)
    elif Currenc == 'AUD':
        url_db = re.sub(r"www.expedia.co.in", r'www.expedia.com.au', url_inse)
    elif Currenc == 'BRL':
        url_db = re.sub(r"www.expedia.co.in", r'www.expedia.com.br', url_inse)     
    elif Currenc == 'CAD':
        url_db = re.sub(r"www.expedia.co.in", r'www.expedia.ca', url_inse)   
    elif Currenc == 'DKK':
        url_db = re.sub(r"www.expedia.co.in", r'www.expedia.dk', re.sub(r'chkin=.*?&chkout=.*?&', 'chkin=' + re.sub("/", ".", chkin_re.group(1)) + '&chkout=' + re.sub("/", ".", chkot_re.group(1)) + '&', url_inse))
    elif Currenc == 'HKD':
        url_db = re.sub(r"www.expedia.co.in", r'www.expedia.com.hk', url_inse)   
        dates_chkin = datetime.datetime.strftime(datetime.datetime.strptime(re.search(r'chkin=(.*?)&', url_db).group(1), "%d/%m/%Y"), "%Y/%m/%d")
        dates_chkot = datetime.datetime.strftime(datetime.datetime.strptime(re.search(r'chkout=(.*?)&', url_db).group(1), "%d/%m/%Y"), "%Y/%m/%d")
        dates = 'chkin=' + dates_chkin + '&chkout=' + dates_chkot + '&'
        url_db = re.sub(r'chkin=.*?&chkout=.*?&', dates, url_db) 
    elif Currenc == 'JPY':
        url_db = re.sub(r"www.expedia.co.in", r'www.expedia.co.jp', url_inse)
        dates_chkin = datetime.datetime.strftime(datetime.datetime.strptime(re.search(r'chkin=(.*?)&', url_db).group(1), "%d/%m/%Y"), "%Y/%m/%d")
        dates_chkot = datetime.datetime.strftime(datetime.datetime.strptime(re.search(r'chkout=(.*?)&', url_db).group(1), "%d/%m/%Y"), "%Y/%m/%d")
        dates = 'chkin=' + dates_chkin + '&chkout=' + dates_chkot + '&'
        url_db = re.sub(r'chkin=.*?&chkout=.*?&', dates, url_db)           
    elif Currenc == 'KPW':
        url_db = re.sub(r"www.expedia.co.in", r'www.expedia.co.kr', url_inse)   
        dates_chkin = datetime.datetime.strftime(datetime.datetime.strptime(re.search(r'chkin=(.*?)&', url_db).group(1), "%d/%m/%Y"), "%Y.%m.%d")
        dates_chkot = datetime.datetime.strftime(datetime.datetime.strptime(re.search(r'chkout=(.*?)&', url_db).group(1), "%d/%m/%Y"), "%Y.%m.%d")
        dates = 'chkin=' + dates_chkin + '&chkout=' + dates_chkot + '&'
        url_db = re.sub(r'chkin=.*?&chkout=.*?&', dates, url_db)         
    elif Currenc == 'MXN':
        url_db = re.sub(r"www.expedia.co.in", r'www.expedia.mx', url_inse)  
    elif Currenc == 'NZD':
        url_db = re.sub(r"www.expedia.co.in", r'www.expedia.co.nz', url_inse)        
    elif Currenc == 'NOK':
        url_db = re.sub(r"www.expedia.co.in", r'www.expedia.no', re.sub(r'chkin=.*?&chkout=.*?&', 'chkin=' + re.sub("/", ".", chkin_re.group(1)) + '&chkout=' + re.sub("/", ".", chkot_re.group(1)) + '&', url_inse))         
    elif Currenc == 'PHP':
        url_db = re.sub(r"www.expedia.co.in", r'www.expedia.com.ph', url_inse)         
        dates_chkin = datetime.datetime.strftime(datetime.datetime.strptime(re.search(r'chkin=(.*?)&', url_db).group(1), "%d/%m/%Y"), "%m/%d/%Y")
        dates_chkot = datetime.datetime.strftime(datetime.datetime.strptime(re.search(r'chkout=(.*?)&', url_db).group(1), "%d/%m/%Y"), "%m/%d/%Y")
        dates = 'chkin=' + dates_chkin + '&chkout=' + dates_chkot + '&'
        url_db = re.sub(r'chkin=.*?&chkout=.*?&', dates, url_db)        
    elif Currenc == 'SGD':
        url_db = re.sub(r"www.expedia.co.in", r'www.expedia.com.sg', url_inse)         
    elif Currenc == 'TWD':
        url_db = re.sub(r"www.expedia.co.in", r'www.expedia.com.tw', url_inse)
        dates_chkin = datetime.datetime.strftime(datetime.datetime.strptime(re.search(r'chkin=(.*?)&', url_db).group(1), "%d/%m/%Y"), "%Y/%m/%d")
        dates_chkot = datetime.datetime.strftime(datetime.datetime.strptime(re.search(r'chkout=(.*?)&', url_db).group(1), "%d/%m/%Y"), "%Y/%m/%d")
        dates = 'chkin=' + dates_chkin + '&chkout=' + dates_chkot + '&'
        url_db = re.sub(r'chkin=.*?&chkout=.*?&', dates, url_db)      
    elif Currenc == 'CNY':
        url_db = re.sub(r"www.expedia.co.in", r'www.expedia.cn', url_inse)    
        dates_chkin = datetime.datetime.strftime(datetime.datetime.strptime(re.search(r'chkin=(.*?)&', url_db).group(1), "%d/%m/%Y"), "%Y/%m/%d")
        dates_chkot = datetime.datetime.strftime(datetime.datetime.strptime(re.search(r'chkout=(.*?)&', url_db).group(1), "%d/%m/%Y"), "%Y/%m/%d")
        dates = 'chkin=' + dates_chkin + '&chkout=' + dates_chkot + '&'
        url_db = re.sub(r'chkin=.*?&chkout=.*?&', dates, url_db)                 
    elif Currenc == 'VND':
        url_db = re.sub(r"www.expedia.co.in", r'www.expedia.com.vn', url_inse)         
    elif Currenc == 'SEK':
        url_db_replace1 = re.sub(r"www.expedia.co.in", r"www.expedia.se", url_inse)        
        dates_chkin = datetime.datetime.strftime(datetime.datetime.strptime(re.search(r'chkin=(.*?)&', url_db_replace1).group(1), "%d/%m/%Y"), "%Y-%m-%d")
        dates_chkot = datetime.datetime.strftime(datetime.datetime.strptime(re.search(r'chkout=(.*?)&', url_db_replace1).group(1), "%d/%m/%Y"), "%Y-%m-%d")
        dates = 'chkin=' + dates_chkin + '&chkout=' + dates_chkot + '&'
        url_db = re.sub(r'chkin=.*?&chkout=.*?&', dates, url_db_replace1)
    else:
        statuscode = '8'
        array.append(aws_insert.insert(id_update, inputid , 'Expedia', Websitecode, StartDate, '', LOS, RateDate, Guests, 0, 0, 0, '', '', url_db, url_db, url_db, '', '', None, 'N', 'Y', 30, StartDate , EndDate, intime, 0, None, None, '', None, '', 0, '', '', statuscode, ''))
        return json.dumps(array)
    try:
        UserAg  = random.choice(['Mozilla/5.0 (Linux; Android 4.4.2; Lenovo B8080-F Build/KVT49L) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/64.0.3282.137 Safari/537.36', 'Mozilla/5.0 (Linux; Android 7.1.1; Moto G Play Build/NPIS26.48-43-2) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.91 Mobile Safari/537.36', 'Mozilla/5.0 (Linux; Android 7.0; TRT-L53 Build/HUAWEITRT-L53) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/69.0.3497.100 Mobile Safari/537.36', 'Mozilla/5.0 (Linux; Android 8.1.0; Moto G (5S) Plus) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.80 Mobile Safari/537.36', 'Mozilla/5.0 (Linux; Android 7.1.1; Moto E (4) Plus Build/NMA26.42-152) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/69.0.3497.100 Mobile Safari/537.36', 'Mozilla/5.0 (Linux; Android 7.0; HUAWEI VNS-L23 Build/HUAWEIVNS-L23) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/69.0.3497.100 Mobile Safari/537.36', 'Mozilla/5.0 (Linux; Android 7.1.1; Moto G Play) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.80 Mobile Safari/537.36', 'Mozilla/5.0 (Linux; Android 7.0; Moto G (5) Plus Build/NPNS25.137-92-14) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/69.0.3497.100 Mobile Safari/537.36', 'Mozilla/5.0 (Linux; Android 7.0; Moto G (5) Plus Build/NPNS25.137-92-14) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.87 Mobile Safari/537.36', 'Mozilla/5.0 (Linux; Android 7.0; Moto G (5) Build/NPPS25.137-93-2-3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.87 Mobile Safari/537.36', 'Mozilla/5.0 (Linux; Android 7.0; Moto C Build/NRD90M.063) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/69.0.3497.100 Mobile Safari/537.36', 'Mozilla/5.0 (Linux; Android 7.1.1; Moto G (5S)) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.80 Mobile Safari/537.36', 'Mozilla/5.0 (Linux; Android 6.0; MotoG3 Build/MPIS24.65-33.1-2-16) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.91 Mobile Safari/537.36', 'Mozilla/5.0 (Linux; Android 8.0.0; moto g(6) play) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.80 Mobile Safari/537.36', 'Mozilla/5.0 (Linux; Android 7.1.1; Moto G (5S) Build/NPPS26.102-49-8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.158 Mobile Safari/537.36', 'Mozilla/5.0 (Linux; Android 7.0; Moto G (5) Plus Build/NPN25.137-92) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.111 Mobile Safari/537.36', 'Mozilla/5.0 (Linux; Android 7.0; Moto G (4) Build/NPJS25.93-14-13) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.111 Mobile Safari/537.36', 'Mozilla/5.0 (Linux; Android 7.0; Moto C) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.80 Mobile Safari/537.36', 'Mozilla/5.0 (Linux; Android 7.1.1; Moto G (5S) Build/NPPS26.102-49-8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.126 Mobile Safari/537.36', 'Mozilla/5.0 (Linux; Android 8.0.0; Moto Z2 Play Build/OPSS27.76-12-25-7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/69.0.3497.100 Mobile Safari/537.36', 'Mozilla/5.0 (Linux; Android 7.1.1; Moto G (5S) Plus Build/NPSS26.116-64-11) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/69.0.3497.100 Mobile Safari/537.36', 'Mozilla/5.0 (Linux; Android 7.1.1; Moto G Play Build/NPIS26.48-43-2) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.87 Mobile Safari/537.36', 'Mozilla/5.0 (Linux; Android 7.0; Moto G (4) Build/NPJS25.93-14-8.1-9) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/69.0.3497.100 Mobile Safari/537.36', 'Mozilla/5.0 (Linux; Android 7.0; Moto G (4) Build/NPJS25.93-14-13) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/64.0.3282.137 Mobile Safari/537.36', 'Mozilla/5.0 (Linux; Android 8.0.0; ANE-LX1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.157 Mobile Safari/537.36', 'Mozilla/5.0 (Linux; Android 6.0; MotoG3 Build/MPIS24.65-33.1-2-16) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.111 Mobile Safari/537.36', 'Mozilla/5.0 (Linux; Android 5.1.1; D6503 Build/23.4.A.1.200) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/46.0.2490.76 Mobile Safari/537.36', 'Mozilla/5.0 (Linux; Android 6.0; DIG-L03 Build/HUAWEIDIG-L03) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/69.0.3497.100 Mobile Safari/537.36', 'Mozilla/5.0 (Linux; U; Android 4.2.2; pl-pl; PMT7077_3G Build/JDQ39) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 Safari/534.30', 'Mozilla/5.0 (Linux; Android 7.1.1; Moto G (5S) Build/NPPS26.102-49-1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/64.0.3282.137 Mobile Safari/537.36', 'Mozilla/5.0 (Linux; Android 8.0.0; moto g(6) play Build/OPP27.91-143) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/69.0.3497.100 Mobile Safari/537.36', 'Mozilla/5.0 (Linux; Android 7.0; Moto C Plus Build/NRD90M.04.026) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/69.0.3497.100 Mobile Safari/537.36', 'Mozilla/5.0 (Linux; Android 7.0; TRT-LX3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.80 Mobile Safari/537.36', 'Mozilla/5.0 (Linux; Android 5.0.1; ALE-L23 Build/HuaweiALE-L23) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/69.0.3497.100 Mobile Safari/537.36', 'Mozilla/5.0 (Linux; Android 8.0.0; WAS-LX3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.80 Mobile Safari/537.36', 'Mozilla/5.0 (Linux; Android 8.1.0; Moto G (5S) Build/OPP28.65-37) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/69.0.3497.100 Mobile Safari/537.36', 'Mozilla/5.0 (Linux; Android 7.0; Moto G (4) Build/NPJS25.93-14-4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.83 Mobile Safari/537.36', 'Mozilla/5.0 (Linux; Android 7.0; Moto G (5) Build/NPP25.137-93) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.111 Mobile Safari/537.36', 'Mozilla/5.0 (Linux; Android 7.0; Moto G (5) Plus Build/NPNS25.137-92-4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.109 Mobile Safari/537.36', 'Mozilla/5.0 (Linux; Android 8.0.0; FLA-LX3 Build/HUAWEIFLA-LX3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/69.0.3497.100 Mobile Safari/537.36', 'Mozilla/5.0 (Linux; Android 7.0; TRT-L53) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.80 Mobile Safari/537.36', 'Mozilla/5.0 (Linux; Android 6.0; HUAWEI VNS-L23 Build/HUAWEIVNS-L23) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/69.0.3497.100 Mobile Safari/537.36', 'Mozilla/5.0 (Linux; Android 7.0; Moto G (5) Build/NPP25.137-93-2) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.158 Mobile Safari/537.36', 'Mozilla/5.0 (Linux; Android 7.0; Moto G (5) Build/NPPS25.137-93-4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.109 Mobile Safari/537.36', 'Mozilla/5.0 (Linux; Android 4.4.2; Lenovo A7600-H Build/KOT49H) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/47.0.2526.83 Safari/537.36', 'Mozilla/5.0 (Linux; Android 6.0.1; MotoG3 Build/MPIS24.107-55-2-17) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/69.0.3497.100 Mobile Safari/537.36'])
        headerT = {'Host' :re.search(r'(www.*?)/',url_db).group(1), 'User-Agent':str(UserAg),'Accept' : 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8', 'Accept-Encoding' : 'gzip, deflate, br', 'Accept-Language' : 'en-US,en;q=0.5'}
        respon1 = Load(url_db, headerT, proxies, 15)
        print respon1.status_code
    except:
        try:
            UserAg  = random.choice(['Mozilla/5.0 (Linux; Android 4.4.2; Lenovo B8080-F Build/KVT49L) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/64.0.3282.137 Safari/537.36', 'Mozilla/5.0 (Linux; Android 7.1.1; Moto G Play Build/NPIS26.48-43-2) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.91 Mobile Safari/537.36', 'Mozilla/5.0 (Linux; Android 7.0; TRT-L53 Build/HUAWEITRT-L53) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/69.0.3497.100 Mobile Safari/537.36', 'Mozilla/5.0 (Linux; Android 8.1.0; Moto G (5S) Plus) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.80 Mobile Safari/537.36', 'Mozilla/5.0 (Linux; Android 7.1.1; Moto E (4) Plus Build/NMA26.42-152) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/69.0.3497.100 Mobile Safari/537.36', 'Mozilla/5.0 (Linux; Android 7.0; HUAWEI VNS-L23 Build/HUAWEIVNS-L23) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/69.0.3497.100 Mobile Safari/537.36', 'Mozilla/5.0 (Linux; Android 7.1.1; Moto G Play) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.80 Mobile Safari/537.36', 'Mozilla/5.0 (Linux; Android 7.0; Moto G (5) Plus Build/NPNS25.137-92-14) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/69.0.3497.100 Mobile Safari/537.36', 'Mozilla/5.0 (Linux; Android 7.0; Moto G (5) Plus Build/NPNS25.137-92-14) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.87 Mobile Safari/537.36', 'Mozilla/5.0 (Linux; Android 7.0; Moto G (5) Build/NPPS25.137-93-2-3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.87 Mobile Safari/537.36', 'Mozilla/5.0 (Linux; Android 7.0; Moto C Build/NRD90M.063) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/69.0.3497.100 Mobile Safari/537.36', 'Mozilla/5.0 (Linux; Android 7.1.1; Moto G (5S)) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.80 Mobile Safari/537.36', 'Mozilla/5.0 (Linux; Android 6.0; MotoG3 Build/MPIS24.65-33.1-2-16) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.91 Mobile Safari/537.36', 'Mozilla/5.0 (Linux; Android 8.0.0; moto g(6) play) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.80 Mobile Safari/537.36', 'Mozilla/5.0 (Linux; Android 7.1.1; Moto G (5S) Build/NPPS26.102-49-8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.158 Mobile Safari/537.36', 'Mozilla/5.0 (Linux; Android 7.0; Moto G (5) Plus Build/NPN25.137-92) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.111 Mobile Safari/537.36', 'Mozilla/5.0 (Linux; Android 7.0; Moto G (4) Build/NPJS25.93-14-13) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.111 Mobile Safari/537.36', 'Mozilla/5.0 (Linux; Android 7.0; Moto C) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.80 Mobile Safari/537.36', 'Mozilla/5.0 (Linux; Android 7.1.1; Moto G (5S) Build/NPPS26.102-49-8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.126 Mobile Safari/537.36', 'Mozilla/5.0 (Linux; Android 8.0.0; Moto Z2 Play Build/OPSS27.76-12-25-7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/69.0.3497.100 Mobile Safari/537.36', 'Mozilla/5.0 (Linux; Android 7.1.1; Moto G (5S) Plus Build/NPSS26.116-64-11) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/69.0.3497.100 Mobile Safari/537.36', 'Mozilla/5.0 (Linux; Android 7.1.1; Moto G Play Build/NPIS26.48-43-2) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.87 Mobile Safari/537.36', 'Mozilla/5.0 (Linux; Android 7.0; Moto G (4) Build/NPJS25.93-14-8.1-9) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/69.0.3497.100 Mobile Safari/537.36', 'Mozilla/5.0 (Linux; Android 7.0; Moto G (4) Build/NPJS25.93-14-13) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/64.0.3282.137 Mobile Safari/537.36', 'Mozilla/5.0 (Linux; Android 8.0.0; ANE-LX1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.157 Mobile Safari/537.36', 'Mozilla/5.0 (Linux; Android 6.0; MotoG3 Build/MPIS24.65-33.1-2-16) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.111 Mobile Safari/537.36', 'Mozilla/5.0 (Linux; Android 5.1.1; D6503 Build/23.4.A.1.200) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/46.0.2490.76 Mobile Safari/537.36', 'Mozilla/5.0 (Linux; Android 6.0; DIG-L03 Build/HUAWEIDIG-L03) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/69.0.3497.100 Mobile Safari/537.36', 'Mozilla/5.0 (Linux; U; Android 4.2.2; pl-pl; PMT7077_3G Build/JDQ39) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 Safari/534.30', 'Mozilla/5.0 (Linux; Android 7.1.1; Moto G (5S) Build/NPPS26.102-49-1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/64.0.3282.137 Mobile Safari/537.36', 'Mozilla/5.0 (Linux; Android 8.0.0; moto g(6) play Build/OPP27.91-143) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/69.0.3497.100 Mobile Safari/537.36', 'Mozilla/5.0 (Linux; Android 7.0; Moto C Plus Build/NRD90M.04.026) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/69.0.3497.100 Mobile Safari/537.36', 'Mozilla/5.0 (Linux; Android 7.0; TRT-LX3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.80 Mobile Safari/537.36', 'Mozilla/5.0 (Linux; Android 5.0.1; ALE-L23 Build/HuaweiALE-L23) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/69.0.3497.100 Mobile Safari/537.36', 'Mozilla/5.0 (Linux; Android 8.0.0; WAS-LX3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.80 Mobile Safari/537.36', 'Mozilla/5.0 (Linux; Android 8.1.0; Moto G (5S) Build/OPP28.65-37) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/69.0.3497.100 Mobile Safari/537.36', 'Mozilla/5.0 (Linux; Android 7.0; Moto G (4) Build/NPJS25.93-14-4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.83 Mobile Safari/537.36', 'Mozilla/5.0 (Linux; Android 7.0; Moto G (5) Build/NPP25.137-93) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.111 Mobile Safari/537.36', 'Mozilla/5.0 (Linux; Android 7.0; Moto G (5) Plus Build/NPNS25.137-92-4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.109 Mobile Safari/537.36', 'Mozilla/5.0 (Linux; Android 8.0.0; FLA-LX3 Build/HUAWEIFLA-LX3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/69.0.3497.100 Mobile Safari/537.36', 'Mozilla/5.0 (Linux; Android 7.0; TRT-L53) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.80 Mobile Safari/537.36', 'Mozilla/5.0 (Linux; Android 6.0; HUAWEI VNS-L23 Build/HUAWEIVNS-L23) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/69.0.3497.100 Mobile Safari/537.36', 'Mozilla/5.0 (Linux; Android 7.0; Moto G (5) Build/NPP25.137-93-2) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.158 Mobile Safari/537.36', 'Mozilla/5.0 (Linux; Android 7.0; Moto G (5) Build/NPPS25.137-93-4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.109 Mobile Safari/537.36', 'Mozilla/5.0 (Linux; Android 4.4.2; Lenovo A7600-H Build/KOT49H) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/47.0.2526.83 Safari/537.36', 'Mozilla/5.0 (Linux; Android 6.0.1; MotoG3 Build/MPIS24.107-55-2-17) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/69.0.3497.100 Mobile Safari/537.36'])
            headerT = {'Host' :re.search(r'(www.*?)/',url_db).group(1), 'User-Agent':str(UserAg),'Accept' : 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8', 'Accept-Encoding' : 'gzip, deflate, br', 'Accept-Language' : 'en-US,en;q=0.5'}
            respon1 = Load(url_db, headerT, proxies, 25)
        except Exception as e:
            print (e)
            insert_value_error = str(str(re.sub(r"'", '"', str(e)))) + 'Where line number ' + str(sys.exc_traceback.tb_lineno) + str(proxyip)
            statuscode = '5'
            keyvalue   = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format('1', datetime.datetime.now(), id_update)
            key        = bucket.new_key(keyvalue)
            key.set_contents_from_string(insert_value_error)
            array.append(aws_insert.insert(id_update, inputid , "Expedia", '1', "", "", "", "", Guests, "", "", "", "", "", url_db, url_db, url_db, "", "", "", "", "", "", StartDate, EndDate , "", "", "", "", "", "", "", "", "", '', statuscode, ''))
            return json.dumps(array)   

    html    = respon1.content.decode('ascii','ignore')
    #<hrml><saving?>
    keyvalue= "ondemand/{}/{:%Y%m%d}/source/{}.html".format(Websitecode, datetime.datetime.now(), str(inputid) + '_' + str(inseRD) + '_' + id_update)
    key     = bucket.new_key(keyvalue)
    key.set_contents_from_string(html)
    
    if re.search(r'htt.*?//www.expedia\t..*?/Hotel' ,respon1.url) or 'Travel-Guide-Hotels' in str(respon1.url):
        statuscode = 3
        array.append(aws_insert.insert(id_update, inputid , 'Expedia', Websitecode, StartDate, '', LOS, RateDate, Guests, 0, 0, 0, '', '', url_db, url_db, url_db, '', '', None, 'N', 'Y', 30, StartDate , EndDate, intime, 0, None, None, '', None, '', 0, '', '', statuscode, ''))
        return json.dumps(array)
    elif re.search(r'(?s)window\.__STATE__\s*=\s*(.*?});</sc', html):
        jsondata = re.search(r'(?s)window\.__STATE__\s*=\s*(.*?});</sc', html).group(1)
        jsonvalue= json.loads(jsondata)
        s        = re.sub(r'&nbsp;','',str(jsondata))
        keyvalue = "ondemand/{}/{:%Y%m%d}/source/{}.json".format(Websitecode, datetime.datetime.now(), str(inputid) + '_' + str(inseRD) + '_' + id_update)
        key = bucket.new_key(keyvalue)
        key.set_contents_from_string(s)
        return StrctNew(jsonvalue, url_db, id_update, inputid, RateDate, Currenc, StartDate, EndDate, Guests, LOS, array, '', intime, proxyip, bucket)
    else:
        insert_value_error = "No Such Structure please check" + str(proxyip)
        statuscode = '5'
        keyvalue   = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format('1', datetime.datetime.now(), id_update)
        key        = bucket.new_key(keyvalue)
        key.set_contents_from_string(insert_value_error)
        array.append(aws_insert.insert(id_update, inputid , "Expedia", '1', "", "", "", "", Guests, "", "", "", "", "", url_db, url_db, url_db, "", "", "", "", "", "", StartDate, EndDate , "", "", "", "", "", "", "", "", "", '', statuscode, ''))
        return json.dumps(array)   
