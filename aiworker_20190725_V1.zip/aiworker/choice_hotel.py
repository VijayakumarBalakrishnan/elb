# -*- coding: utf-8 -*-
import re,requests
import datetime
import json
import boto,gc,sys

import aws_insert

def fetchrates(url,inputid,id_update,proxyip):
    array      = []
    sr         = requests.session()
    proxies    = {"https": "http://{}".format(proxyip)}
    intime     = re.sub(r'\s','T',str(datetime.datetime.now()))
    Domainname = 'MILE NORTH HOTEL'
    Websitecode= '41'
    region     = ''
    statuscode = ''
    Mealtype   = ''
    israteperstay = ''
    try:
        conn   = boto.connect_s3(aws_access_key_id= 'AKIAIXEGZVXCWE2FV3SQ',aws_secret_access_key = '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') 
        bucket = conn.get_bucket("rmapi")
        StartDate = datetime.date.today()
        EndDate   = datetime.date.today() + datetime.timedelta(days=29)
        CheckIn_Check_OT_re = re.search(r'checkInDate=(.*?)&checkOutDate=(.*?)&',url)
        if CheckIn_Check_OT_re:
            Checkin  = CheckIn_Check_OT_re.group(1)
            Checkout = CheckIn_Check_OT_re.group(2)
            #Checkin_URL = datetime.datetime.strptime(str(CheckIn_Check_OT_re.group(1)),'%Y-%m-%d').strftime('%m/%d/%Y')
            #CheckOT_URL = datetime.datetime.strptime(str(CheckIn_Check_OT_re.group(2)),'%Y-%m-%d').strftime('%m/%d/%Y')
        else:
            Checkin  = ''
            Checkout = ''
            #Checkin_URL = ''
            #CheckOT_URL = ''
        #print Checkin,Checkout
        #print url
        RateDate = Checkin
        delta    = datetime.datetime.strptime(Checkout, "%Y-%m-%d") - datetime.datetime.strptime(Checkin, "%Y-%m-%d")
        LOS      = delta.days
        RoomType = ''
        Guests   = re.search(r'adults=(\d)&', url).group(1)
        #print Guests,LOS
        Ratetype = ''
        RateDescription = ''
        Taxtype  = ''
        Curr     = ''
        MaxOccupancy = None
        isPromotionalRate  = 'N'
        Closed   = 'Y'
        NetRate  = 0
        Taxstatus= -1
        TaxAmount= 0
        Discount = 0
        GrossRate= 0
        OnsiteRate = 0
        Curr     = ''
        Promotion_Name= ''
        isAvailable = ''
        RoomAmenity_Type = ''
        url_insert = 'https://www.choicehotels.com/illinois/chicago/cambria-hotels/il521/rates'
        head={'User-Agent':'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv:50.0) Gecko/20100101 Firefox/50.0'}
        ip = re.sub(r"\{'.*?@|'\}|:\d+", "", str(proxies))
        try:
            try:
                r = sr.get('http://freegeoip.net/json/' + ip, timeout=30)
            except Exception, e:
                r = sr.get('http://freegeoip.net/json/' + ip, timeout=30)
            js = r.json()
            region = js['country_name']
        except Exception, e:
            region = ''
        try:
            htm = sr.get(url,headers = head,proxies = proxies,timeout=100)
        except Exception, e:
            value_error = str(re.sub("'", '', str(e)))
            stacktrace = sys.exc_traceback.tb_lineno
            try:
                htm = sr.get(url,headers = head,proxies = proxies , timeout=120)
            except Exception, e:
                try:
                    htm = sr.get(url,headers = head,proxies = proxies , timeout=150)
                except Exception, e:
                    value_error = str(re.sub("'", '', str(e)))
                    stacktrace = sys.exc_traceback.tb_lineno
                    keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(Websitecode, datetime.datetime.now(), id_update)
                    key = bucket.new_key(keyvalue)
                    key.set_contents_from_string(str(e) + 'Where Line number' + str(stacktrace) + str(proxies))
                    statuscode = 5
                    Guests = ''
                    array.append(aws_insert.insert(id_update, inputid , Domainname, Websitecode, "", "", "", "", Guests, "", "", "", "", "", url_insert,url_insert,url_insert, "", "", "", "", "", "", StartDate, EndDate , "", "", "", "", "", "", "", "", "", region, statuscode, israteperstay))
                    return json.dumps(array)
            
        if htm.status_code <> 200:
            htm = sr.get(url,headers = head,proxies = proxies)
        if (htm.status_code == 403 or htm.status_code == 407) or htm.status_code <> 200:
            try:
                if htm.status_code <> 200:
                    htm = sr.get(url,headers = head)
            except Exception, e:
                Closed    = 'Y'
                value_error = str(re.sub("'", '', str(e)))
                stacktrace = sys.exc_traceback.tb_lineno
                keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(Websitecode, datetime.datetime.now(), id_update)
                key = bucket.new_key(keyvalue)
                key.set_contents_from_string(str(e) + 'Where Line number' + str(stacktrace) + str(proxies))
                statuscode = 5
                Guests = ''
                array.append(aws_insert.insert(id_update, inputid , Domainname, Websitecode, "", "", "", "", Guests, "", "", "", "", "", url_insert,url_insert,url_insert, "", "", "", "", "", "", StartDate, EndDate , "", "", "", "", "", "", "", "", "", region, statuscode, israteperstay))
                return json.dumps(array)
        html = htm.text.encode('ascii','ignore')
        json_value = json.loads(html)
        #fo = open('riverside.html','w').write(str(html))
        Rtdate=re.sub(r'-|\-','',str(RateDate))
        keyvalue = "ondemand/{}/{:%Y%m%d}/source{}.json".format(Websitecode,datetime.datetime.now(),str(inputid)+'_'+str(Rtdate)+'_'+id_update)
        key = bucket.new_key(keyvalue)
        key.set_contents_from_string(json.dumps(json_value))
        if 'outputInfo' not in json_value:
            for block in json_value['rooms'].iteritems():
                RoomType      = ''
                Ratetype      = ''
                OnsiteRate    = 0
                RoomAmenity_Type = ''
                RateDescription  = ''
                Mealtype         = ''
                Curr             = ''
                Closed           = 'N'
                GrossRate        =  0
                isAvailable      = ''
                MaxOccupancy     = None
                roomcode        = block[0]
                #print 'roomcode    :',roomcode
                RoomType        = block[1]['bedsDescription']
                RateDescription = block[1]['featuresDescription']
                MaxOccupancy    = block[1]['capacity']
                description = ''
                for Amen_block in block[1]['amenities']:
                    description += ','+Amen_block['description']
                    RoomAmenity_Type = re.sub(r"^,","",re.sub(r"'","''",description)).strip()
                for Rate_block in json_value['stay']['rates'].iteritems():
                    Ratetype= Rate_block[1]['name']
                    if LOS > 2:
                        if 'stay 2 nights' in Ratetype.lower():
                            continue
                    for rateblock in  Rate_block[1]['roomStayCharges']:
                        #print  rateblock
                        if roomcode == rateblock['roomCode']:
                            #print roomcode
                            if rateblock.has_key('avgNightlyBeforeTax'):
                                OnsiteRate = rateblock['avgNightlyBeforeTax']
                                GrossRate  = OnsiteRate
                                Curr = rateblock['currencyCode']
                                isAvailable = rateblock['available']
                                break
                            elif rateblock.has_key('childRates'):
                                if rateblock['childRates'][0].has_key('avgNightlyBeforeTax'):
                                    OnsiteRate = rateblock['childRates'][0]['avgNightlyBeforeTax']
                                    GrossRate  = OnsiteRate
                                    Curr = rateblock['childRates'][0]['currencyCode']
                                    isAvailable = rateblock['childRates'][0]['available']
                                    break
                                else:
                                    OnsiteRate='0'
                                    statuscode='1'
                            else:
                                OnsiteRate='0'
                                statuscode='1'
                    Mealtypes          = str(RateDescription)+' '+str(RoomType)+' '+str(Ratetype)+' '+str(RoomAmenity_Type)
                    if Mealtypes !=None:
                        Mealtype_str = str(Mealtypes)
                        if 'breakfast' in Mealtype_str.lower() and 'dinner' in Mealtype_str.lower()  and 'lunch' in Mealtype_str.lower():
                            Meal = 'Breakfast, Lunch and Dinner'
                        elif 'breakfast' in Mealtype_str.lower() and 'dinner' in Mealtype_str.lower():
                            Meal = 'Breakfast and dinner'
                        elif 'breakfast included' in Mealtype_str.lower():
                            Meal = 'Breakfast included'
                        elif 'BREAKFAST' in Mealtype_str:
                            Meal = 'Breakfast'
                        elif 'breakfast' in Mealtype_str.lower() and 'lunch' in Mealtype_str.lower():
                            Meal = 'Breakfast and Lunch'
                        elif 'Lunch' in Mealtype_str and 'Dinner' in Mealtype_str :
                            Meal = "Lunch and Dinner"
                        elif 'breakfast' in Mealtype_str.lower() and 'lunch' in Mealtype_str.lower() and 'dinner' in Mealtype_str.lower():
                            Meal = 'Breakfast, Lunch and dinner'
                        elif 'Break fast' in Mealtype_str:
                            Meal = 'BreakFast' 
                        elif 'breakfast' in Mealtype_str.lower():
                            Meal = 'BreakFast' 
                        elif 'halfboard' in Mealtype_str.lower():
                            Meal = 'Halfboard'
                        elif 'half board' in Mealtype_str.lower():
                            Meal = 'Half board' 
                        elif 'full board' in Mealtype_str.lower():
                            Meal = 'Full Board'
                        elif 'fullboard' in Mealtype_str.lower():
                            Meal = 'FullBoard'
                        elif 'All-Inclusive' in Mealtype_str:
                            Meal = 'All-Inclusive'
                        elif 'All Inclusive' in Mealtype_str:
                            Meal = 'All Inclusive'
                        elif 'All Meals' in Mealtype_str:
                            Meal = 'All Meals'
                        elif 'All Meal' in Mealtype_str:
                            Meal = 'All Meal'
                        else:
                            Meal = ''
                    else:
                        Meal = ''   
                    Mealtype = Meal
                    if OnsiteRate==0:
                        statuscode = 1
                        Closed='Y'
                    else:
                        statuscode = ''
                        Closed='N'
                    if int(LOS) >1:
                        israteperstay = 'N'
                    else:
                        israteperstay ='Y'
                    Taxstatus = 2
                    if (OnsiteRate == 0) and (Curr == '') and (isAvailable == ''):
                                continue
                    else:
                        #print 'RoomType    :',RoomType
                        #print 'RateDescription :',RateDescription
                        #print 'MaximumOccupancy :',MaxOccupancy
                        #print 'RoomAmenity_Type :',RoomAmenity_Type
                        #print 'Ratetype    :',Ratetype
                        #print 'OnsiteRate  :',OnsiteRate
                        #print 'Curr        :',Curr
                        #print 'isAvailable :',isAvailable
                        #print 'Mealtype    :',Mealtype
                        #print "="*40
                        if OnsiteRate == '0' or OnsiteRate == 0:
                            statuscode = 1 
                        #print (id_update, inputid , Domainname, Websitecode, StartDate, RoomType, LOS, RateDate, Guests, OnsiteRate, NetRate, GrossRate, Curr, RateDescription, url_insert, url_insert, url_insert, RoomAmenity_Type, Mealtype, MaxOccupancy, isPromotionalRate, Closed, 30, StartDate , EndDate, intime, isAvailable, Taxtype, TaxAmount, Taxstatus, None, Ratetype, Discount,Promotion_Name,region,statuscode, israteperstay)
                        array.append(aws_insert.insert(id_update, inputid , Domainname, Websitecode, StartDate, RoomType, LOS, RateDate, Guests, OnsiteRate, NetRate, GrossRate, Curr, RateDescription, url_insert, url_insert, url_insert, RoomAmenity_Type, Mealtype, MaxOccupancy, isPromotionalRate, Closed, 30, StartDate , EndDate, intime, isAvailable, Taxtype, TaxAmount, Taxstatus, None, Ratetype, Discount,Promotion_Name,region,statuscode, israteperstay))
        else:
            Closed     = 'Y'
            statuscode = '2'
            #print "else"
            #print (id_update, inputid , Domainname, Websitecode, StartDate, RoomType, LOS, RateDate, Guests, OnsiteRate, NetRate, GrossRate, Curr, RateDescription, url_insert, url_insert, url_insert, RoomAmenity_Type, Mealtype, MaxOccupancy, isPromotionalRate, Closed, 30, StartDate , EndDate, intime, isAvailable, Taxtype, TaxAmount, Taxstatus, None, Ratetype, Discount,Promotion_Name,region,statuscode, israteperstay)
            array.append(aws_insert.insert(id_update, inputid , Domainname, Websitecode, StartDate, RoomType, LOS, RateDate, Guests, OnsiteRate, NetRate, GrossRate, Curr, RateDescription, url_insert, url_insert, url_insert, RoomAmenity_Type, Mealtype, MaxOccupancy, isPromotionalRate, Closed, 30, StartDate , EndDate, intime, isAvailable, Taxtype, TaxAmount, Taxstatus, None, Ratetype, Discount,Promotion_Name,region,statuscode, israteperstay))
        Rtdate = re.sub(r'-|\-', '', str(RateDate))
        keyvalue = "ondemand/{}/{:%Y%m%d}/delivery/{}.json".format(Websitecode,datetime.datetime.now(),str(inputid)+'_'+str(Rtdate)+'_'+id_update)
        key = bucket.new_key(keyvalue)
        key.set_contents_from_string(json.dumps(array))
        return json.dumps(array)
        gc.collect()
    except Exception as e:
        print e
        value_error = str(re.sub(r"'", '"', str(e)))
        stacktrace = sys.exc_traceback.tb_lineno
        Guests = ''
        statuscode = '4'
        region = ''
        array.append(aws_insert.insert(id_update, inputid , Domainname, Websitecode, "", "", "", "", Guests, "", "", "", "", "", url_insert,url_insert,url_insert, "", "", "", "", "", "", StartDate, EndDate , "", "", "", "", "", "", "", "", "", region, statuscode, israteperstay))
        keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(Websitecode,datetime.datetime.now(),id_update)
        key = bucket.new_key(keyvalue)
        key.set_contents_from_string(json.dumps(value_error))
        return json.dumps(array)
