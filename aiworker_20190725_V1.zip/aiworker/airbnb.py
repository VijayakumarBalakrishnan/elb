# -*- coding: utf-8 -*-
import re
import requests
import datetime
import json
import sys 
import boto
import gc

import aws_insert
import time
import random
from unidecode import unidecode

start = time.time()


#print start

# url       = 'https://www.airbnb.com/rooms/506121?check_in=2018-07-15&guests=1&adults=1&check_out=2018-07-16&currency=USD'
# inputid   = ''
# id_update = ''
# proxyip   = 'media:M3diAproxy@104.223.105.254:80'
# proxyip = 'user-34068:214859b73da0e174@45.64.106.56:1212'


def fetchrates(url , inputid, id_update, proxyip):
    try:
        array = []
        israteperstay = ''
        intime = re.sub(r'\s', 'T', str(datetime.datetime.now()))
        StartDate = datetime.date.today()
        EndDate = datetime.date.today() + datetime.timedelta(days=29)
        conn = boto.connect_s3(aws_access_key_id='AKIAIXEGZVXCWE2FV3SQ', aws_secret_access_key='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') 
        bucket = conn.get_bucket("rmapi")
        region = ''
        ispromupdate = 'N'
        GrossRate = 0
        NetRate = 0
        Roomtype = ''
        Taxtype = ''
        Promotion_Name = ''
        MaxOccupancy = None
        Taxamount = None
        Tax_status = ''
        Websitecode = 3662
        Guests = re.search(r"guests=(\d+)&", url).group(1)
        Domainname = 'Airbnb'
        head = {'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/50.0.2661.102 Safari/537.36', 'Accept' : 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8', 'Accept-Language' : 'en-US,en;q=0.5', 'Accept-Encoding' : 'gzip, deflate, br', 'Connection' : 'keep-alive'}
        #print chkout_strip
        chkin = datetime.datetime.strptime(re.search(r'check_in=(.*?)&', url).group(1), "%Y-%m-%d").strftime("%Y-%m-%d")
        chkout = datetime.datetime.strptime(re.search(r'check_out=(.*?)&', url).group(1), "%Y-%m-%d").strftime("%Y-%m-%d")
        Los = datetime.datetime.strptime(chkout,"%Y-%m-%d") - datetime.datetime.strptime(chkin,"%Y-%m-%d")
        LOS = Los.days
        Closed_up = 'N'
        RateDate = chkin
        proxies = {"https": "http://{}".format(proxyip)}
        try:
            loadurl = requests.get(url, headers = head, proxies = proxies, timeout=10)
        except Exception as e:
            try:
                loadurl = requests.get(url, headers = head, proxies = proxies, timeout=20)
            except:
                try:
                    loadurl = requests.get(url, headers = head, proxies = proxies, timeout=30)
                except:
                    value_error = str(e)
                    stacktrace = value_error+" Where Line number "+str(sys.exc_traceback.tb_lineno)
                    keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(Websitecode, datetime.datetime.now(), id_update)
                    #print keyvalue
                    key = bucket.new_key(keyvalue)
                    key.set_contents_from_string(str(stacktrace))
                    region = ''
                    statuscode = 5
                    array.append(aws_insert.insert(id_update, inputid , Domainname, Websitecode, "", "", "", "", Guests, "", "", "", "", "", url, url, url, "", "", "", "", "", "", StartDate, EndDate , "", "", "", "", "", "", "", "", "", region, statuscode, israteperstay))
                    return json.dumps(array)
        if loadurl.status_code == 503 or loadurl.status_code!=200:
            try:
                loadurl = requests.get(url, headers = head, proxies = proxies, timeout=10)
                if loadurl.status_code == 503 or loadurl.status_code!=200:
                    stacktrace = value_error+" Where Line number "+str(sys.exc_traceback.tb_lineno)
                    keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(Websitecode, datetime.datetime.now(), id_update)
                    #print keyvalue
                    key = bucket.new_key(keyvalue)
                    key.set_contents_from_string(str(stacktrace))
                    region = ''
                    statuscode = 9
                    array.append(aws_insert.insert(id_update, inputid , Domainname, Websitecode, "", "", "", "", Guests, "", "", "", "", "", url, url, url, "", "", "", "", "", "", StartDate, EndDate , "", "", "", "", "", "", "", "", "", region, statuscode, israteperstay))
                    return json.dumps(array)
            except Exception as e:
                value_error = str(e)
                stacktrace = value_error+" Where Line number "+str(sys.exc_traceback.tb_lineno)
                keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(Websitecode, datetime.datetime.now(), id_update)
                #print keyvalue
                key = bucket.new_key(keyvalue)
                key.set_contents_from_string(str(stacktrace))
                region = ''
                statuscode = 5
                array.append(aws_insert.insert(id_update, inputid , Domainname, Websitecode, "", "", "", "", Guests, "", "", "", "", "", url, url, url, "", "", "", "", "", "", StartDate, EndDate , "", "", "", "", "", "", "", "", "", region, statuscode, israteperstay))
                return json.dumps(array)
        load = loadurl.text.encode('utf-8')
        Rtdate=re.sub(r'-|\-','',str(RateDate))
        keyvalue = "ondemand/{}/{:%Y%m%d}/source/{}.html".format(Websitecode, datetime.datetime.now(), str(inputid) + '_' + str(Rtdate) + '_' + id_update)
        #print keyvalue
        key = bucket.new_key(keyvalue)
        key.set_contents_from_string(load)
        ListingID_reg = re.search("/(\d+)", url)
        if ListingID_reg:
            ListingID = ListingID_reg.group(1)
        RequestID_reg = re.search(r"uuid&quot;:&quot;(.*?)&quot;", load)
        if RequestID_reg:
            RequestID = RequestID_reg.group(1)
        Apikey_reg = re.search(r"api&quot;,&quot;key&quot;:&quot;(.*?)&quot;}", load)
        if Apikey_reg:
            Apikey = Apikey_reg.group(1)
        curr = re.search(r'currency=(.*)', url).group(1)
        json_link  = "https://www.airbnb.co.in/api/v2/pricing_quotes?guests=1&listing_id="+ListingID+"&_format=for_detailed_booking_info_on_web_p3_with_message_data&_interaction_type=pageload&_intents=p3_book_it&_parent_request_uuid="+RequestID+"p3_1489059793_r2n4gYrI90mL4C%2FR&show_smart_promotion=0&check_in="+chkin+"&check_out="+chkout+"&number_of_adults=1&number_of_children=0&number_of_infants=0&key="+Apikey+"&currency="+curr+"&locale=en-IN"
        try:
            jsonloading = requests.get(json_link, headers = head, proxies = proxies, timeout=10)
        except Exception as e:
            try:
                jsonloading = requests.get(json_link, headers = head, proxies = proxies, timeout=20)
            except:
                try:
                    jsonloading = requests.get(json_link, headers = head, proxies = proxies, timeout=30)
                except:
                    value_error = str(e)
                    stacktrace = value_error+" Where Line number "+str(sys.exc_traceback.tb_lineno)
                    keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(Websitecode, datetime.datetime.now(), id_update)
                    #print keyvalue
                    key = bucket.new_key(keyvalue)
                    key.set_contents_from_string(str(stacktrace))
                    region = ''
                    statuscode = 5
                    array.append(aws_insert.insert(id_update, inputid , Domainname, Websitecode, "", "", "", "", Guests, "", "", "", "", "", url, url, url, "", "", "", "", "", "", StartDate, EndDate , "", "", "", "", "", "", "", "", "", region, statuscode, israteperstay))
                    return json.dumps(array)
        try:
            jsonvalue = json.loads(unidecode(jsonloading.text).encode('utf-8'))
            if 'You do not have permission to access this resource.' in str(jsonvalue):
                value_error = str(e)
                stacktrace = value_error+" Where Line number "+str(sys.exc_traceback.tb_lineno)
                keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(Websitecode, datetime.datetime.now(), id_update)
                #print keyvalue
                key = bucket.new_key(keyvalue)
                key.set_contents_from_string(str(stacktrace))
                region = ''
                statuscode = 3
                array.append(aws_insert.insert(id_update, inputid , Domainname, Websitecode, "", "", "", "", Guests, "", "", "", "", "", url, url, url, "", "", "", "", "", "", StartDate, EndDate , "", "", "", "", "", "", "", "", "", region, statuscode, israteperstay))
                return json.dumps(array)
            if jsonvalue['pricing_quotes'][0]['base_price_breakdown'][0]['amount']:
                OnsiteRate = jsonvalue['pricing_quotes'][0]['base_price_breakdown'][0]['amount']
                currency = jsonvalue['pricing_quotes'][0]['base_price_breakdown'][0]['currency']
                Rate_policy = jsonvalue['pricing_quotes'][0]['cancellation_policy_label']
            #print Onsiterate
            for priceitems in jsonvalue['pricing_quotes'][0]['price']['price_items']:
                if priceitems['type'] == 'TAXES':
                    if priceitems.has_key('localized_title'):
                        Taxtype = priceitems['localized_title']
                        Taxamount =  priceitems['total']['amount']
                        if int(Taxamount) == 0:
                            Tax_status = 2  
                        else:
                            Tax_status = 1
                    break
                
            if 'moderate' in Rate_policy.lower():
                Ratetype = 'Moderate: Cancel up to 5 days before check in and get a full refund (minus service fees). Cancel within 5 days of your trip and the first night is non-refundable, but 50% of the cost for the remaining nights will be refunded. Service fees are refunded when cancellation happens before check in and within 48 hours of booking.'
            if 'strict' in Rate_policy.lower():
                Ratetype = 'Strict: Cancel within 48 hours of booking and 14 days before check-in to get a full refund. Cancel up to 7 days before check in and get a 50% refund (minus service fees). Cancel within 7 days of your trip and the reservation is non-refundable.'
            if 'flexible' in Rate_policy.lower():
                Ratetype = 'Flexible: Cancel up to 24 hours before check in and get a full refund (minus service fees). Cancel within 24 hours of your trip and the first night is non-refundable. Service fees are refunded when cancellation happens before check in and within 48 hours of booking.'
            if 'Minimum stay' in jsonvalue['pricing_quotes'][0]['localized_unavailability_message']:
                Ratetype  = str(jsonvalue['pricing_quotes'][0]['localized_unavailability_message'])+'; '+Ratetype
            jsonload = json.loads(re.search(r'<script type="application/json" data-hypernova-key=".*?<!--({"bootstrapData".*?)--></script>', load).group(1))
            if jsonload['bootstrapData']['reduxData']['homePDP']['listingInfo']['listing']['room_and_property_type']:
                Roomtype = jsonload['bootstrapData']['reduxData']['homePDP']['listingInfo']['listing']['room_and_property_type']
            if jsonload['bootstrapData']['reduxData']['homePDP']['listingInfo']['listing']['sectioned_description'].has_key('description'):
                RateDescription = unidecode(jsonload['bootstrapData']['reduxData']['homePDP']['listingInfo']['listing']['sectioned_description']['description']).encode('utf-8')
            if jsonload['bootstrapData']['reduxData']['homePDP']['listingInfo']['listing']['guest_label']:
                MaxOccupancy = re.sub("\s*guests|\s*guest", "", jsonload['bootstrapData']['reduxData']['homePDP']['listingInfo']['listing']['guest_label'])
            RateDescription = str(RateDescription)[:3999]
            RoomAmenity_Type = ''
            for amnt in jsonload['bootstrapData']['reduxData']['homePDP']['listingInfo']['listing']['listing_amenities']:
                RoomAmenity_Type += unidecode(amnt['name']).encode('utf-8')+', '
            RoomAmenity_Type = re.sub(r",$", r"", RoomAmenity_Type[:3999])
            if 'breakfast' in RoomAmenity_Type.lower():
                Mealtype = 'Breakfast'
            elif 'lunch' in RoomAmenity_Type.lower():
                Mealtype = 'Lunch'
            elif 'dinner' in RoomAmenity_Type.lower():
                Mealtype = 'Dinner'
            else:
                Mealtype = ''
            statuscode = '0'
            if jsonvalue['pricing_quotes'][0]['localized_unavailability_message'] == 'Those dates are not available' :
                Closed_up = 'Y'
                statuscode = '2'
            if LOS == 1:
                israteperstay = 'Y'    
            else:
                israteperstay = 'N'    
            array.append(aws_insert.insert(id_update, inputid , Domainname, Websitecode, StartDate, Roomtype, LOS, RateDate, Guests, OnsiteRate, NetRate, GrossRate, currency, RateDescription, url, url, url, RoomAmenity_Type, Mealtype, MaxOccupancy, ispromupdate, Closed_up, 30, StartDate , EndDate, intime, None, Taxtype, Taxamount, Tax_status, None, Ratetype, NetRate, Promotion_Name, region, statuscode, israteperstay))
            Rtdate=re.sub(r'-|\-','',str(RateDate))
            keyvalue = "ondemand/{}/{:%Y%m%d}/delivery/{}.json".format(Websitecode, datetime.datetime.now(), str(inputid) + '_' + str(Rtdate) + '_' + id_update)
            key = bucket.new_key(keyvalue)
            key.set_contents_from_string(json.dumps(array))
            return json.dumps(array)
            gc.collect()    
        except Exception, e:
            value_error = str(re.sub(r"'", '"', str(e)))
            stacktrace = sys.exc_traceback.tb_lineno
            insert_value_error = str(value_error) + 'Where line number ' + str(stacktrace) + str(proxyip)
            print insert_value_error
            statuscode = '4'
            Websitecode = '3662'
            keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(Websitecode, datetime.datetime.now(), id_update)
            key = bucket.new_key(keyvalue)
            key.set_contents_from_string(insert_value_error)
            array.append(aws_insert.insert(id_update, inputid , Domainname, Websitecode, "", "", "", "", Guests, "", "", "", "", "", url, url, url, "", "", "", "", "", "", StartDate, EndDate , "", "", "", "", "", "", "", "", "", region, statuscode, israteperstay))
            return json.dumps(array)        
    except Exception, e:
        value_error = str(re.sub(r"'", '"', str(e)))
        stacktrace = sys.exc_traceback.tb_lineno
        insert_value_error = str(value_error) + 'Where line number ' + str(stacktrace) + str(proxyip)
        print insert_value_error
        statuscode = '4'
        Websitecode = '285'
        keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(Websitecode, datetime.datetime.now(), id_update)
        key = bucket.new_key(keyvalue)
        key.set_contents_from_string(insert_value_error)
        array.append(aws_insert.insert(id_update, inputid , Domainname, Websitecode, "", "", "", "", Guests, "", "", "", "", "", url, url, url, "", "", "", "", "", "", StartDate, EndDate , "", "", "", "", "", "", "", "", "", region, statuscode, israteperstay))
        return json.dumps(array)        
# fetchrates(url , inputid, id_update, proxyip)
