# -*- coding: utf-8 -*-
import re
import requests
import datetime
import json
import gc
import boto
import sys
from mtranslate import translate

from unidecode import unidecode
import aws_insert

'''
url = 'https://www.simplebooking.it/ibe/hotelbooking/dosearch?hid=4192&lang=EN&guests=1&in=2017-12-08&out=2017-12-09&coupon='
inputid = ''
id_update = ''
proxyip = 'media:M3diAproxy@108.175.52.100:80'
websitecode = ''
'''

def fetchrates(url ,inputid, id_update,proxyip, websitecode):	
	Websitecode = websitecode
	Domainname  = 'simplebooking'
	#print Websitecode
	#print Domainname	
	array      = []
	israteperstay=''
	proxies    = {"https": "http://{}".format(proxyip)}
	intime     = re.sub(r'\s','T',str(datetime.datetime.now()))
	region     =''
	statuscode =''
	Mealtype   = ''
	conn   = boto.connect_s3(aws_access_key_id= 'AKIAIXEGZVXCWE2FV3SQ',aws_secret_access_key = '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') 
	bucket = conn.get_bucket("rmapi")
	StartDate= datetime.date.today()
	EndDate  = datetime.date.today() + datetime.timedelta(days=29)
	try:
		def trans(to_translate):
			try:
				Translated = (translate(to_translate,'en'))
				return Translated
			except:
				return to_translate 
		CheckIn_Check_OT_re = re.search(r'&in=(.*?)&out=(.*?)&',url)
		if CheckIn_Check_OT_re:
			Checkin = CheckIn_Check_OT_re.group(1)
			CheckOT = CheckIn_Check_OT_re.group(2)
		else:
			Checkin = ''
			CheckOT = ''
		RateDate = Checkin
		delta    = datetime.datetime.strptime(str(CheckOT), "%Y-%m-%d") - datetime.datetime.strptime(Checkin, "%Y-%m-%d")
		LOS      = delta.days
		RoomType = ''
		Guests   = re.search(r'guests=(.*?)&',url).group(1)
		url      = re.sub(r'guests=.*?&','guests='+str(re.sub(',$', '', 'A,'*int(re.search(r'guests=(.*?)&',url).group(1))))+'&',url)
		Ratetype = ''
		RateDescription = ''
		Meal     = ''
		Taxtype  = ''
		Curr     = ''
		MaxOccupancy  = None
		isPromotionalRate  = 'N'
		Closed   = 'Y'
		NetRate  = 0
		Taxstatus= -1
		TaxAmount= 0
		discount = 0
		Discount = 0
		GrossRate= 0
		OnsiteRate = 0
		Promotion_Name= ''
		isAvailable = ''
		RoomAmenity_Type = ''        
		hotel_id = re.search(r'hid=(.*?)&', url).group(1)
		url_insert = 'https://www.simplebooking.it/ibe/hotelbooking/search?lang=en&hid='+str(hotel_id)+'#'
		proxyip = re.sub(r':.*','',str(proxyip))
		headers = {'User-Agent':'Mozilla/5.0 (X11; Linux i686; rv:45.0) Gecko/20100101 Firefox/45.0'}
		try:
			try:
				r = requests.get('http://freegeoip.net/json/' + proxyip, timeout=30)
			except Exception, e:
				r = requests.get('http://freegeoip.net/json/' + proxyip, timeout=30)
			js = r.json()
			region = js['country_name']
		except Exception, e:
			region = ''
		try:
			curr_hml = requests.get(url_insert,headers=headers,proxies=proxies,timeout=100,verify=False).text.encode('ascii','ignore')
		except:
			curr_hml = requests.get(url_insert,headers=headers,timeout=100,verify=False).text.encode('ascii','ignore')
		try:
			hml = requests.get(url,headers=headers,proxies=proxies,timeout=100,verify=False)
		except Exception, e:
			value_error = str(re.sub("'", '', str(e)))
			stacktrace = sys.exc_traceback.tb_lineno
			try:
				hml = requests.get(url,headers=headers,proxies=proxies,timeout=120,verify=False)
			except Exception, e:
				try:
					hml = requests.get(url,headers=headers,proxies=proxies,timeout=150,verify=False)
				except Exception, e:
					value_error = str(re.sub("'", '', str(e)))
					stacktrace = sys.exc_traceback.tb_lineno
					keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(Websitecode, datetime.datetime.now(), id_update)
					key = bucket.new_key(keyvalue)
					key.set_contents_from_string(str(e) + 'Where Line number' + str(stacktrace) + str(proxies))
					statuscode = 5
					Guests = ''
					array.append(aws_insert.insert(id_update, inputid , Domainname, Websitecode, "", "", "", "", Guests, "", "", "", "", "", url, url, url, "", "", "", "", "", "", StartDate, EndDate , "", "", "", "", "", "", "", "", "", region, statuscode,israteperstay))
					return json.dumps(array)
		if hml.status_code <> 200:
			hml = requests.get(url,headers=headers,proxies=proxies,timeout=50)
		if (hml.status_code == 403 or hml.status_code == 407) or hml.status_code <> 200:
			try:
				if hml.status_code <> 200:
					hml = requests.get(url,headers=headers,timeout=50)
			except Exception, e:
				print e
				value_error = str(re.sub("'", '', str(e)))
				stacktrace = sys.exc_traceback.tb_lineno
				keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(Websitecode, datetime.datetime.now(), id_update)
				key = bucket.new_key(keyvalue)
				key.set_contents_from_string(str(e) + 'Where Line number' + str(stacktrace) + str(proxies))
				statuscode = 5
				Guests = ''
				array.append(aws_insert.insert(id_update, inputid , Domainname, Websitecode, "", "", "", "", Guests, "", "", "", "", "", url, url, url, "", "", "", "", "", "", StartDate, EndDate , "", "", "", "", "", "", "", "", "", region, statuscode,israteperstay))
				return json.dumps(array) 
		Data_Htm  = unidecode(re.sub('amp;','',hml.text)).encode('ascii')
		##print re.sub('amp;','',hml.text)
		##print Data_Htm
		if 'Service no longer available' in Data_Htm:
			#print 'status_code 203'
			keyvalue  = "ondemand/{}/{:%Y%m%d}/source/{}.txt".format(Websitecode,datetime.datetime.now(),str(inputid)+'_'+str(Checkin)+'_'+id_update)
			key = bucket.new_key(keyvalue)
			key.set_contents_from_string(hml.text.encode('utf-8'))
			Closed_up = 'Y'
			statuscode = '3'
			Guests = Guests
			array.append(aws_insert.insert(id_update, inputid , Domainname, Websitecode, StartDate, "", LOS, RateDate, Guests, OnsiteRate, NetRate, GrossRate, "", "", url_insert, url_insert, url_insert, "", "", "", isPromotionalRate, Closed, 30, StartDate, EndDate , intime, "", "", "", "", None, "", Discount, "", region, statuscode,israteperstay))
			return json.dumps(array) 
		Data_Htm = re.sub(r'(\s)"([A-Z|a-z])',r"\1'\2",str(Data_Htm))
		Data_Htm = re.sub(r'([A-Z|a-z])"([\s|\.])',r"\1'\2",str(Data_Htm))
		Data_Htm = re.sub(r'(\d)"([\s|\.])',r"\1'\2",str(Data_Htm))
		Data_Htm = re.sub(r'(\s)"(\d)',r"\1'\2",str(Data_Htm))
		htmls     = json.loads(Data_Htm)
		'''#print Data_Htm
		fo = open('3915_2017-11-27_8268108f-4116-4ed3-9b80-adf9c492d7a0.json', 'r')
		Data_Htm = fo.read()
		#print Data_Htm
		htmls     = json.loads(Data_Htm)
		#print htmls'''
		keyvalue  = "ondemand/{}/{:%Y%m%d}/source/{}.json".format(Websitecode,datetime.datetime.now(),str(inputid)+'_'+str(Checkin)+'_'+id_update)
		key = bucket.new_key(keyvalue)
		key.set_contents_from_string(hml.text.encode('utf-8'))
		Cur_reg = re.search(r'"currency": {\s*"id":\s*\d+,\s*"code":\s*"(.*?)",', curr_hml)
		if Cur_reg:
			Curr = Cur_reg.group(1)
		else:
			Curr = ""
		tax_reg = re.search(r'taxesVisualizationType":\s*(\d+),', curr_hml)
		if tax_reg:
			tax_ = tax_reg.group(1)
		else:
			tax_ = ""
		if 'isAlternative' in htmls:
			Condition_check = htmls['isAlternative']
			#print 'Condition_check:',Condition_check
		else:
			Condition_check = ''
		if Condition_check:
			Closed     = 'Y'
			statuscode ='2'
			array.append(aws_insert.insert(id_update, inputid , Domainname, Websitecode, StartDate, RoomType, LOS, RateDate, Guests, OnsiteRate, NetRate, GrossRate, Curr, RateDescription, url_insert, url_insert, url_insert, RoomAmenity_Type, Mealtype, MaxOccupancy, isPromotionalRate, Closed, 30, StartDate , EndDate, intime, isAvailable, Taxtype, TaxAmount, Taxstatus, None, Ratetype, Discount,Promotion_Name,region,statuscode,israteperstay))
		else:
			if 'rooms' in htmls:
				if len(htmls['rooms'])!=0:
					for Rooms in htmls['rooms']:
						if 'roomType' in Rooms:
							RoomType = Rooms['roomType']['locName']
						else:
							RoomType = ''
						if 'locDescription' in Rooms['roomType']:
							RateDescr        = unidecode(Rooms['roomType']['locDescription']).encode('ascii')
							if re.search(r'(^.*?)\s*([F|f]acilitie.*?$)', RateDescr):
								#RateDescription  = re.search(r'(^.*?)\s*([F|f]acilitie.*?$)', RateDescr).group(1)
								RoomAmenity_Type = re.search(r'(^.*?)\s*([F|f]acilitie.*?$)', RateDescr).group(2)
							elif re.search(r'\.\s*(.*?AC.*?\.)', RateDescr):
								RoomAmenity_Type = re.search(r'\.\s*(.*?AC.*?\.)', RateDescr).group(1)
							elif re.search(r'\.\s*(.*?Fan.*?\.)', RateDescr):
								RoomAmenity_Type = re.search(r'\.\s*(.*?Fan.*?\.)', RateDescr).group(1)
							elif re.search(r'\.\s*(.*?Shower.*?\.)', RateDescr):
								RoomAmenity_Type = re.search(r'\.\s*(.*?Shower.*?\.)', RateDescr).group(1)
							elif re.search(r'\.\s*(.*?Hair dryer.*?\.)', RateDescr):
								RoomAmenity_Type = re.search(r'\.\s*(.*?Hair dryer.*?\.)', RateDescr).group(1)
							elif re.search(r'\.\s*(.*?Cable TV.*?\.)', RateDescr):
								RoomAmenity_Type = re.search(r'\.\s*(.*?Cable TV.*?\.)', RateDescr).group(1)
							elif re.search(r'\.\s*(.*?Phone.*?\.)', RateDescr):
								RoomAmenity_Type = re.search(r'\.\s*(.*?Phone.*?\.)', RateDescr).group(1)
							elif re.search(r'\.\s*(.*?Wi-Fi.*?\.)', RateDescr):
								RoomAmenity_Type = re.search(r'\.\s*(.*?Wi-Fi.*?\.)', RateDescr).group(1)
							else:
								RateDescription  = RateDescr
								RoomAmenity_Type = ''
							RateDescription = re.sub(r'\s+',' ',RateDescr.strip())
						else:
							RateDescription  = ''
							RoomAmenity_Type = ''
						if Rooms['offer']:
							if 'locName' in Rooms['offer']:
								Ratetype = Rooms['offer']['locName']
							else:
								Ratetype = ''
						else:
							if 'locName' in Rooms['ratePlan']:
								Ratetype = Rooms['ratePlan']['locName']
							else:
								Ratetype = ''
						'''if 'locDescription' in Rooms['ratePlan']:
							rate_id   = Rooms['ratePlan']['id']
						else:
							rate_id   = ''
						'''    
						if 'name' in Rooms['mealPlanType']:
							Meals = Rooms['mealPlanType']['name']
							if 'B&B' in Meals:
								Meals = 'Bed & Breakfast'
						else:
							Meals = ''
						if 'discountedTotalPrice' in Rooms:
							OnsiteRate  = Rooms['discountedTotalPrice']
						else:
							OnsiteRate  = 0
						if 'totalPrice' in Rooms:
							NetRate  = Rooms['totalPrice'] 
							tax_price = Rooms['totalPriceWithTaxes']
							tax_check = Rooms['taxes']
							if tax_check:
								if (int(float(tax_price)) != int(float(NetRate))) and int(tax_) == 0:
									Taxstatus = 1
								elif int(tax_) == 0:
									Taxstatus = 2
								else:
									if (int(float(tax_price)) == int(float(NetRate))):
										Taxstatus = 1
									else:
										Taxstatus = 2
							else:
								Taxstatus = -1
							isPromotionalRate = 'Y'
						else:
							NetRate  = 0
							isPromotionalRate = 'N'
						if (int(float(OnsiteRate)) == int(float(NetRate))) or (int(float(OnsiteRate)) >= int(float(NetRate))):
							NetRate = 0
							isPromotionalRate = 'N'
						else:
							NetRate = str(round(NetRate, 2))
						OnsiteRate = str(round(OnsiteRate, 2))
						if  'availability' in Rooms:
							isAvailable = Rooms['availability'] 
						else:
							isAvailable = None
						'''if 'signature' in Rooms:
							signature = Rooms['signature']
							'https://www.simplebooking.it/Inclusioni/Popup/info_popup_tariffe_responsive.aspx?IDA='+str(rate_id)+'&IDT=1&IDO=0&IDL='+str(rate_id)+'&OCCCAM='+1+'&NP=1&NC=1&D_A=2017&D_M=11&D_D=18&A_A=2017&A_M=11&A_D=19&LANG=EN&SIG='+str(signature)+'&CUR='+str(Curr)+'&RPIGUID=eae1ff00-4d8d-4260-a844-a9dabda8c1ec&_=1510552012163'
							hotel_id
							rate_id
							netrate   = onsite_rate
							onsite_rate = ''
						else:
							onsite_rate = onsite_rate
							netrate     = 0'''
						try:
							Meals= re.sub(r'[^\x00-\x7F]+'," ",str(Meals))
						except:
							Meals= re.sub(r'[^\x00-\x7F]+'," ",Meals)
						try:
							RateDescription = re.sub(r'[^\x00-\x7F]+'," ",str(RateDescription))
						except:
							RateDescription = re.sub(r'[^\x00-\x7F]+'," ",RateDescription)
						try:
							RoomType        = re.sub(r'[^\x00-\x7F]+'," ",str(RoomType))
						except:
							RoomType        = re.sub(r'[^\x00-\x7F]+'," ",RoomType)
						try:
							Ratetype        = re.sub(r'[^\x00-\x7F]+'," ",str(Ratetype))
						except:
							Ratetype        = re.sub(r'[^\x00-\x7F]+'," ",Ratetype)
						try:
							RoomAmenity_Type        = re.sub(r'[^\x00-\x7F]+'," ",str(RoomAmenity_Type))
						except:
							RoomAmenity_Type        = re.sub(r'[^\x00-\x7F]+'," ",RoomAmenity_Type)
						if 'offer' in Ratetype.lower():
							Promotion_Name = Ratetype 
							isPromotionalRate = 'Y'
						else:
							isPromotionalRate = 'N'
						Mealtypes = str(RateDescription)+' '+str(RoomType)+' '+str(Ratetype)+' '+str(RoomAmenity_Type)+' '+str(Meals)
						if Mealtypes !=None:
							Mealtype_str = str(Mealtypes)
							if 'breakfast' in Mealtype_str.lower() and 'dinner' in Mealtype_str.lower()  and 'lunch' in Mealtype_str.lower():
								Meal = 'Breakfast, Lunch and Dinner'
							elif 'breakfast' in Mealtype_str.lower() and 'dinner' in Mealtype_str.lower():
								Meal = 'Breakfast and dinner'
							elif 'breakfast included' in Mealtype_str.lower():
								Meal = 'Breakfast included'
							elif 'BREAKFAST' in Mealtype_str:
								Meal = 'Breakfast'
							elif 'breakfast' in Mealtype_str.lower() and 'lunch' in Mealtype_str.lower():
								Meal = 'Breakfast and Lunch'
							elif 'Lunch' in Mealtype_str and 'Dinner' in Mealtype_str :
								Meal = "Lunch and Dinner"
							elif 'breakfast' in Mealtype_str.lower() and 'lunch' in Mealtype_str.lower() and 'dinner' in Mealtype_str.lower():
								Meal = 'Breakfast, Lunch and dinner'
							elif 'Break fast' in Mealtype_str:
								Meal = 'BreakFast' 
							elif 'breakfast' in Mealtype_str.lower():
								Meal = 'BreakFast' 
							elif 'halfboard' in Mealtype_str.lower():
								Meal = 'Halfboard'
							elif 'half board' in Mealtype_str.lower():
								Meal = 'Half board' 
							elif 'full board' in Mealtype_str.lower():
								Meal = 'Full Board'
							elif 'fullboard' in Mealtype_str.lower():
								Meal = 'FullBoard'
							elif 'All-Inclusive' in Mealtype_str:
								Meal = 'All-Inclusive'
							elif 'All Inclusive' in Mealtype_str:
								Meal = 'All Inclusive'
							elif 'All Meals' in Mealtype_str:
								Meal = 'All Meals'
							elif 'All Meal' in Mealtype_str:
								Meal = 'All Meal'
							else:
								Meal = ''
						else:
							Meal = '' 
						if OnsiteRate==0:
							Taxstatus = -1
							Closed    = 'Y'
							statuscode= 1
						else:
							Closed    = 'N'
							statuscode= ''
						if 'maxCapacity' in Rooms['roomType']:
							MaxOccupancy = Rooms['roomType']['maxCapacity']
						else:
							MaxOccupancy = None
						RoomType = trans(RoomType)
						Ratetype = trans(Ratetype)
						RateDescription = trans(RateDescription)
						RoomAmenity_Type = trans(RoomAmenity_Type)
						Promotion_Name = trans(Promotion_Name)
						Meal = trans(Meal)
						Taxstatus = -1
						#print "MaxOccupancy:",MaxOccupancy                 
						#print "RoomType :-",RoomType
						#print "Ratetype :-",Ratetype
						#print "RateDescription :-",RateDescription
						#print "RoomAmenity_Type:-",RoomAmenity_Type
						#print "Amount   :-",OnsiteRate
						#print "Prmotion :-",Promotion_Name
						#print "isPromotionalRate  :-",isPromotionalRate
						#print "NetRate  :-",NetRate
						#print "Currency :-",Curr
						#print "isAvailable :-",isAvailable
						#print "MealType :-",Meal
						#print "Closed   :-",Closed
						#print "Taxstatus:-",Taxstatus
						#print "status_cd:-",statuscode
						#print "_"*30
						GrossRate = OnsiteRate
						Mealtype  = Meal
						RateDate  = Checkin
						israteperstay ='Y'
						#print (id_update, inputid , Domainname, Websitecode, StartDate, RoomType, LOS, RateDate, Guests, OnsiteRate, NetRate, GrossRate, Curr, RateDescription, url_insert, url_insert, url_insert, RoomAmenity_Type, Mealtype, MaxOccupancy, isPromotionalRate, Closed, 30, StartDate , EndDate, intime, isAvailable, Taxtype, TaxAmount, Taxstatus, None, Ratetype, Discount,Promotion_Name,region,statuscode,israteperstay)
						array.append(aws_insert.insert(id_update, inputid , Domainname, Websitecode, StartDate, RoomType, LOS, RateDate, Guests, OnsiteRate, NetRate, GrossRate, Curr, RateDescription, url_insert, url_insert, url_insert, RoomAmenity_Type, Mealtype, MaxOccupancy, isPromotionalRate, Closed, 30, StartDate , EndDate, intime, isAvailable, Taxtype, TaxAmount, Taxstatus, None, Ratetype, Discount,Promotion_Name,region,statuscode,israteperstay))
				else:
					Closed     = 'Y'
					statuscode ='2'
					array.append(aws_insert.insert(id_update, inputid , Domainname, Websitecode, StartDate, RoomType, LOS, RateDate, Guests, OnsiteRate, NetRate, GrossRate, Curr, RateDescription, url_insert, url_insert, url_insert, RoomAmenity_Type, Mealtype, MaxOccupancy, isPromotionalRate, Closed, 30, StartDate , EndDate, intime, isAvailable, Taxtype, TaxAmount, Taxstatus, None, Ratetype, Discount,Promotion_Name,region,statuscode,israteperstay))
			else:
				Closed     = 'Y'
				statuscode ='2'
				array.append(aws_insert.insert(id_update, inputid , Domainname, Websitecode, StartDate, RoomType, LOS, RateDate, Guests, OnsiteRate, NetRate, GrossRate, Curr, RateDescription, url_insert, url_insert, url_insert, RoomAmenity_Type, Mealtype, MaxOccupancy, isPromotionalRate, Closed, 30, StartDate , EndDate, intime, isAvailable, Taxtype, TaxAmount, Taxstatus, None, Ratetype, Discount,Promotion_Name,region,statuscode,israteperstay))
		keyvalue = "ondemand/{}/{:%Y%m%d}/delivery/{}.json".format(Websitecode,datetime.datetime.now(),str(inputid)+'_'+str(RateDate)+'_'+id_update)
		key = bucket.new_key(keyvalue)
		key.set_contents_from_string(json.dumps(array))
		return json.dumps(array)
		gc.collect()
	except Exception as e:
		#print "e:", e
		value_error = str(re.sub(r"'", '"', str(e)))
		stacktrace = sys.exc_traceback.tb_lineno
		Guests = ''
		region = ''
		insert_value_error = str(value_error) + 'Where line number ' + str(stacktrace) + str(proxyip)
		statuscode = '4'
		print insert_value_error
		keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(Websitecode, datetime.datetime.now(), id_update)
		key = bucket.new_key(keyvalue)
		key.set_contents_from_string(insert_value_error)
		array.append(aws_insert.insert(id_update, inputid , Domainname, Websitecode, "", "", "", "", Guests, "", "", "", "", "", url, url, url, "", "", "", "", "", "", StartDate, EndDate , "", "", "", "", "", "", "", "", "", region, statuscode,israteperstay))
		return json.dumps(array)


#fetchrates(url ,inputid, id_update,proxyip, websitecode)

