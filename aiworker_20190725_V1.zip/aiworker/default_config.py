AWS_REGION = 'us-west-2'
FLASK_DEBUG = 'true'
