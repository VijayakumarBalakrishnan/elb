# -*- coding: utf-8 -*-
import re
import requests
import datetime
import json
import boto,gc,sys

import aws_insert

def fetchrates(url,inputid,id_update,proxyip):
    array      = []
    sr  = requests.session()
    intime     = re.sub(r'\s','T',str(datetime.datetime.now()))
    Domainname ='warwickwa.com'
    Websitecode='349'
    israteperstay = ''
    try:
        statuscode = ''
        Mealtype   = ''
        conn   = boto.connect_s3(aws_access_key_id= 'AKIAIXEGZVXCWE2FV3SQ',aws_secret_access_key = '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') 
        bucket = conn.get_bucket("rmapi")
        StartDate = datetime.date.today()
        EndDate   = datetime.date.today() + datetime.timedelta(days=29)
        CheckIn_Check_OT_re = re.search(r'arrivaldate=(.*?)&departuredate=(.*?)&',url)
        if CheckIn_Check_OT_re:
            Checkin  = CheckIn_Check_OT_re.group(1)
            Checkout = CheckIn_Check_OT_re.group(2)
        else:
            Checkin  = ''
            Checkout = ''
        #print Checkin,Checkout
        RateDate = Checkin
        delta    = datetime.datetime.strptime(Checkout, "%Y-%m-%d") - datetime.datetime.strptime(Checkin, "%Y-%m-%d")
        LOS      = delta.days
        RoomType = ''
        Guests   = ''
        Guests_reg = re.search(r'adults1=(.*?)&', url)
        if Guests_reg:
            Guests = Guests_reg.group(1)
        #print"Adult:",Guests,LOS
        night ="nights="+str(LOS)+"&"
        url      = re.sub(r"nights=.*?&",night,url)
        Ratetype = ''
        RateDescription = ''
        Taxtype  = ''
        Curr     = ''
        MaxOccupancy = None
        isPromotionalRate  = 'N'
        Closed   = 'Y'
        NetRate  = 0
        Taxstatus= -1
        TaxAmount= 0
        Discount = 0
        GrossRate= 0
        OnsiteRate = 0
        Curr     = ''
        Promotion_Name= ''
        isAvailable = ''
        RoomAmenity_Type = ''
        url_insert = url
        #print url_insert
        proxies = {"https": "http://{}".format(proxyip)}
        region = ''
        ip = re.sub(r"\{'.*?@|'\}|:\d+", "", str(proxies))
        try:
            try:
                r = requests.get('http://freegeoip.net/json/' + ip, timeout=30)
            except Exception, e:
                r = requests.get('http://freegeoip.net/json/' + ip, timeout=30)
            js = r.json()
            region = js['country_name']
        except Exception, e:
            region = ''
        head = {'Host':'www.yourreservation.net','Connection':'keep-alive','Upgrade-Insecure-Requests':'1','User-Agent':'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36','Accept':'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8','Accept-Encoding':'gzip, deflate, br','Accept-Language':'en-GB,en-US;q=0.8,en;q=0.6'}
        try:
            source = sr.get(url,headers = head,proxies = proxies, timeout=100)
            htm = sr.get(url,headers = head,proxies = proxies, timeout=100)
        except Exception, e:
            value_error = str(re.sub("'", '', str(e)))
            stacktrace = sys.exc_traceback.tb_lineno
            try:
                source = sr.get(url,headers = head,proxies = proxies, timeout=120)
                htm = sr.get(url,headers = head,proxies = proxies, timeout=120)
            except Exception, e:
                try:
                    source = sr.get(url,headers = head,proxies = proxies, timeout=150)
                    htm = sr.get(url,headers = head,proxies = proxies, timeout=150)
                except Exception, e:
                    value_error = str(re.sub("'", '', str(e)))
                    stacktrace = sys.exc_traceback.tb_lineno
                    keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(Websitecode, datetime.datetime.now(), id_update)
                    key = bucket.new_key(keyvalue)
                    key.set_contents_from_string(str(e) + 'Where Line number' + str(stacktrace) + str(proxies))
                    statuscode = 5
                    Guests = ''
                    array.append(aws_insert.insert(id_update, inputid , Domainname, Websitecode, "", "", "", "", Guests, "", "", "", "", "", url, url, url, "", "", "", "", "", "", StartDate, EndDate , "", "", "", "", "", "", "", "", "", region, statuscode, israteperstay))
                    return json.dumps(array)
        if htm.status_code <> 200:
            source = sr.get(url,headers = head,proxies = proxies)
            htm = sr.get(url,headers = head,proxies = proxies)
        if (htm.status_code == 403 or htm.status_code == 407) or htm.status_code <> 200:
            try:
                if htm.status_code <> 200:
                    source = sr.get(url,headers = head)
                    htm = sr.get(url,headers = head)
            except Exception, e:
                value_error = str(re.sub("'", '', str(e)))
                stacktrace = sys.exc_traceback.tb_lineno
                keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(Websitecode, datetime.datetime.now(), id_update)
                key = bucket.new_key(keyvalue)
                key.set_contents_from_string(str(e) + 'Where Line number' + str(stacktrace) + str(proxies))
                statuscode = 5
                Guests = ''
                array.append(aws_insert.insert(id_update, inputid , Domainname, Websitecode, "", "", "", "", Guests, "", "", "", "", "", url, url, url, "", "", "", "", "", "", StartDate, EndDate , "", "", "", "", "", "", "", "", "", region, statuscode, israteperstay))
                return json.dumps(array)
        html = htm.text
        html = html.encode('ascii', 'ignore')
        Rtdate=re.sub(r'-|\-','',str(RateDate))
        Rtdate=re.sub(r'-|\-','',str(RateDate))
        keyvalue = "ondemand/{}/{:%Y%m%d}/source{}.html".format(Websitecode, datetime.datetime.now(), str(inputid) + '_' + str(Rtdate) + '_' + id_update)
        #print keyvalue
        key = bucket.new_key(keyvalue)
        key.set_contents_from_string(html) 
        if re.search(r'(<div id="room_.*?class="clear">.*?<div class="clear">.*?</div>\s*</div>\s*</div>\s*</div>)',html,re.DOTALL):
            for block1 in re.compile(r'<div id="room_.*?class="clear">.*?<div class="clear">.*?</div>\s*</div>\s*</div>\s*</div>',re.DOTALL).findall(html):
                for block in re.compile(r'<h4>.*?</div></span>.*?border">',re.DOTALL).findall(block1):
                    RoomType      = ''
                    Ratetype      = ''
                    OnsiteRate    = 0
                    RoomAmenity_Type = ''
                    RateDescription  = ''
                    MealInclusion    = ''
                    Mealtype         = ''
                    Curr             = ''
                    Closed           = 'N'
                    GrossRate        = 0
                    isAvailable      = ''
                    Taxstatus        = 2
                    roomtype_re = re.search(r'<h3>(.*?)</h3>', block1)            
                    if roomtype_re:
                        RomeType1 = re.sub(r"'","''", roomtype_re.group(1))
                        RoomType  = re.sub('\s\s+','',re.sub(r'&.*?;','',RomeType1))
                        
                    amenity_re  = re.search(r'<ul class="bulletlist.*?>(.*?)</ul>\s*</div>', block1, re.DOTALL)
                    if amenity_re:
                        Amenities_grp   = amenity_re.group(1)
                        Amenities_clean = re.sub(r'<.*?>','',re.sub(r'</li>',',',Amenities_grp))
                        Amenities_clean2 = re.sub(r"'","''",re.sub(r",$|",'',Amenities_clean))
                        RoomAmenity_Type = re.sub(r"\n",'',Amenities_clean2)
                        
                    desc1_re    = re.search(r'<div class="tab">\s*(.*?)\s*<', block1)
                    if desc1_re:
                        RateDescription = re.sub(r"'","''",desc1_re.group(1))
                        
                    ratetype_re     = re.search(r'<h4>(.*?)</h4>', block)
                    if ratetype_re:
                        Ratetype = re.sub(r"'","''",ratetype_re.group(1))
                        
                    price_re    = re.search(r'pricevalue">(.*?)<', block)
                    if price_re:
                        OnsiteRate = re.sub('\$|,|[A-Za-z]|&.*?;','',price_re.group(1)).strip()
                    GrossRate  = OnsiteRate 
                    meal_re = re.search(r'<div class="rateicons">(.*?)</div>', block, re.DOTALL)
                    if meal_re:
                        mealtype = meal_re.group(1)
                        if 'Includes Breakfast' in mealtype:
                            MealInclusion = 'Breakfast Included'
                            RoomAmenity_Type = RoomAmenity_Type
                    else:
                        MealInclusion = ''
                    curr_re =  re.search(r'pricevalue">(.*?)\d.*?<', block)
                    if curr_re:
                        Currency = re.sub(r"&|;","",curr_re.group(1))
                        if "$" in Currency:
                            Curr = 'USD'
                        elif "euro" in Curr:
                            Curr = 'EUR'
                    isAvailb_re = re.search(r'class="icon_warning">.*?>(.*?)<', block1)
                    if isAvailb_re:
                        isAvailable = re.sub(r'<.*?>|\D','',isAvailb_re.group(1))
                    Mealtype = MealInclusion
                    if OnsiteRate==0:
                        statuscode = 1
                        Closed='Y'
                    else:
                        statuscode = ''
                        Closed='N'
                    LOS = int(LOS)
                    if int(LOS) >1:
                        israteperstay = 'N'
                    else:
                        israteperstay ='Y'
                    #if #printdata:
                    #print "RoomType         :",RoomType          
                    #print "Ratetype         :",Ratetype          
                    #print "price            :",OnsiteRate             
                    #print "RoomAmenity_Type :",RoomAmenity_Type  
                    #print "RateDescription  :",RateDescription  
                    #print "MealInclusion    :",Mealtype
                    #print "Currency         :",Curr
                    #print "isAvailable      :",isAvailable
                    #print"&"*40
                    #print (id_update, inputid , Domainname, Websitecode, StartDate, RoomType, LOS, RateDate, Guests, OnsiteRate, NetRate, GrossRate, Curr, RateDescription, url_insert, url_insert, url_insert, RoomAmenity_Type, Mealtype, MaxOccupancy, isPromotionalRate, Closed, 30, StartDate , EndDate, intime, isAvailable, Taxtype, TaxAmount, Taxstatus, None, Ratetype, Discount,Promotion_Name,region,statuscode, israteperstay)
                    array.append(aws_insert.insert(id_update, inputid , Domainname, Websitecode, StartDate, RoomType, LOS, RateDate, Guests, OnsiteRate, NetRate, GrossRate, Curr, RateDescription, url_insert, url_insert, url_insert, RoomAmenity_Type, Mealtype, MaxOccupancy, isPromotionalRate, Closed, 30, StartDate , EndDate, intime, isAvailable, Taxtype, TaxAmount, Taxstatus, None, Ratetype, Discount,Promotion_Name,region,statuscode, israteperstay))
        else:
            Closed     = 'Y'
            statuscode = '2'
            #print "else"
            #print (id_update, inputid , Domainname, Websitecode, StartDate, RoomType, LOS, RateDate, Guests, OnsiteRate, NetRate, GrossRate, Curr, RateDescription, url_insert, url_insert, url_insert, RoomAmenity_Type, Mealtype, MaxOccupancy, isPromotionalRate, Closed, 30, StartDate , EndDate, intime, isAvailable, Taxtype, TaxAmount, Taxstatus, None, Ratetype, Discount,Promotion_Name,region,statuscode, israteperstay)
            array.append(aws_insert.insert(id_update, inputid , Domainname, Websitecode, StartDate, RoomType, LOS, RateDate, Guests, OnsiteRate, NetRate, GrossRate, Curr, RateDescription, url_insert, url_insert, url_insert, RoomAmenity_Type, Mealtype, MaxOccupancy, isPromotionalRate, Closed, 30, StartDate , EndDate, intime, isAvailable, Taxtype, TaxAmount, Taxstatus, None, Ratetype, Discount,Promotion_Name,region,statuscode, israteperstay))
        Rtdate = re.sub(r'-|\-', '', str(RateDate))
        keyvalue = "ondemand/{}/{:%Y%m%d}/delivery/{}.json".format(Websitecode,datetime.datetime.now(),str(inputid)+'_'+str(Rtdate)+'_'+id_update)
        key = bucket.new_key(keyvalue)
        key.set_contents_from_string(json.dumps(array))
        return json.dumps(array)
        gc.collect()
    except Exception as e:
        print e
        value_error = str(re.sub(r"'", '"', str(e)))
        stacktrace = sys.exc_traceback.tb_lineno
        Guests = ''
        region = ''
        insert_value_error = str(value_error) + 'Where line number ' + str(stacktrace) + str(proxyip)
        print insert_value_error
        #print "Websitecode =", Websitecode
        statuscode = '4'
        keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(Websitecode, datetime.datetime.now(), id_update)
        key = bucket.new_key(keyvalue)
        key.set_contents_from_string(insert_value_error)
        array.append(aws_insert.insert(id_update, inputid , Domainname, Websitecode, "", "", "", "", Guests, "", "", "", "", "", url, url, url, "", "", "", "", "", "", StartDate, EndDate , "", "", "", "", "", "", "", "", "", region, statuscode, israteperstay))
        return json.dumps(array)
