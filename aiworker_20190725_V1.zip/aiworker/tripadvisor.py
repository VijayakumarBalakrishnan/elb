import re
global requests
import requests
import datetime
import json
import sys 
import boto
import gc
import aws_insert

# url  = 'https://www.tripadvisor.in/Hotel_Review-g293925-d12311797-Reviews-Aquarizon_Boutique_Hostel_City_Bar-Ho_Chi_Minh_City.html#chkin=2019-07-18&chkout=2019-07-19&adults=1#'
# inputid = '12'
# id_update = '14'
# proxyip = 'user-23300:aggr3gat3inte11@45.64.106.43:1212'

def fetchrates(url ,inputid, id_update, proxyip):
	sr      = requests.Session()
	array = []
	israteperstay = ''
	intime=re.sub(r'\s','T',str(datetime.datetime.now()))
	functionname='tripadvisor.com'
	conn = boto.connect_s3(aws_access_key_id= 'AKIAIXEGZVXCWE2FV3SQ',aws_secret_access_key = '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') 
	bucket = conn.get_bucket("rmapi")
	Websitecode='324'
	try:
		StartDate = datetime.date.today()
		EndDate  = datetime.date.today()+datetime.timedelta(days=29)
		checkin=re.search(r'chkin=(.*?)&chk',url)
		if checkin:
			chkins=checkin.group(1)
		delta = datetime.datetime.strptime(re.search(r"chkout=(.*?)&", url).group(1), "%Y-%m-%d") - datetime.datetime.strptime(re.search(r"chkin=(.*?)&", url).group(1), "%Y-%m-%d")
		LOS = delta.days 
		#print "tripadvisor running"
		WebSiteName = functionname
		RoomType    =""
# 		LOS         = "1"
		RateDate    = chkins
		region      = ""
		Guests      = ""    
		OnsiteRate  ="0"
		NetRate     ="0"
		Curr        =""
		TaxStatus   = ''
		url         = re.sub(r"'","''",url)
		Mealtype    =""
		MaxOccupancy=""
		Closed      ="Y"
		StartDate   =StartDate
		EndDate     =EndDate
		isAvailable =""
		Taxtype     =""
		TaxAmount   ="0"
		Ratetype    =""
		statuscode  =''
		RateDescription= ""
		Promotion_Name = ""
		RoomAmenity_Type=""
		isPromotionalRate="N"
		proxies = {"https": "http://{}".format(proxyip)}
		staydates_re = re.search(r'chkin=((\d+)-(\d+)-(\d+)&chkout=(\d+)-(\d+)-(\d+))&ad', url).group(1)
		staydates=re.sub("&chkout=|-","_",staydates_re)
		#print staydates
		day    = re.search(r"chkin=(\d+)-(\d+)-(\d+)&chkout=(\d+)-(\d+)-(\d+)&ad", url).group(3)
		month  = re.search(r"chkin=(\d+)-(\d+)-(\d+)&chkout=(\d+)-(\d+)-(\d+)&ad", url).group(2)
		year   = re.search(r"chkin=(\d+)-(\d+)-(\d+)&chkout=(\d+)-(\d+)-(\d+)&ad", url).group(1)
		Oday   = re.search(r"chkin=(\d+)-(\d+)-(\d+)&chkout=(\d+)-(\d+)-(\d+)&ad", url).group(6)
		Omonth = re.search(r"chkin=(\d+)-(\d+)-(\d+)&chkout=(\d+)-(\d+)-(\d+)&ad", url).group(5)
		Oyear  = re.search(r"chkin=(\d+)-(\d+)-(\d+)&chkout=(\d+)-(\d+)-(\d+)&ad", url).group(4)
		adults = re.search(r"adults=(\d+)#", url)
		if adults:
			#print "regex matched"
			adults = adults.group(1)
		else:
			#print "regex not matched"
			adults=1
		region=''
		ip=re.sub(r"\{'.*?@|'\}|:\d+","",str(proxies))
		try:
			try:
				r = requests.get('http://freegeoip.net/json/'+ip,timeout=30)
			except Exception,e:
				r = requests.get('http://freegeoip.net/json/'+ip,timeout=30)
			js = r.json()
			region=js['country_name']
		except Exception,e:
			region=''
		#print "OTA site :",url
		payload = {'child_rm_ages':'','adults':adults, 'rooms':1, 'staydates':str(staydates), 'reqNum':1,'changeSet':'TRAVEL_INFO'}
		head    = {'User-Agent':'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:12.0) Gecko/20100101 Firefox/48.0', 'X-Requested-With': 'XMLHttpRequest', 'X-Puid' :'WOM-4AokKWEAAQnMSycAAAAt'}
		try:        
			response= sr.post(url, data=payload, headers=head,proxies=proxies)
			#print response.status_code
		except Exception as e:
			print e
			try:
				response= sr.post(url, data=payload, headers=head,proxies=proxies)
			except Exception as e:
				print e
				value_error=str(re.sub("'",'"',str(e)))
				stacktrace=sys.exc_traceback.tb_lineno
				statuscode=5
				keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(Websitecode,datetime.datetime.now(),id_update)
				key = bucket.new_key(keyvalue)
				key.set_contents_from_string(str(e))
			
				Guests=adults
				array.append(aws_insert.insert(id_update, inputid ,"",Websitecode, "", "", "", "", Guests, "", "", "", "", "",url, url, url, "", "", "", "", "", "",StartDate, EndDate , "", "", "", "", "", "", "", "", "",region,statuscode, israteperstay))
				return json.dumps(array)
				#continue
		if (response.status_code <> 200):
			response= sr.post(url, data=payload, headers=head,proxies=proxies)
		if (response.status_code == 403 or response.status_code == 407):
			try:
				if response.status_code <> 200:
					response= sr.post(url, data=payload, headers=head)
			except Exception as e:
				print e
				value_error=str(re.sub("'",'"',str(e)))
				stacktrace=sys.exc_traceback.tb_lineno
				keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(Websitecode,datetime.datetime.now(),id_update)
				key = bucket.new_key(keyvalue)
				key.set_contents_from_string(str(e))
				statuscode=5
				Guests=adults
				array.append(aws_insert.insert(id_update, inputid ,"",Websitecode, "", "", "", "", Guests, "", "", "", "", "",url, url, url, "", "", "", "", "", "",StartDate, EndDate , "", "", "", "", "", "",  "", "", "",region,statuscode, israteperstay))
				return json.dumps(array)
			
		a       = response.text
		html    = a.encode('ascii', 'ignore')
		Rtdate=re.sub(r'-|\-','',str(RateDate))
		keyvalue = "ondemand/{}/{:%Y%m%d}/source/{}.html".format(Websitecode,datetime.datetime.now(),str(inputid)+'_'+str(Rtdate)+'_'+id_update)
		key = bucket.new_key(keyvalue)
		key.set_contents_from_string(str(html))
		locationId_reg = re.search(r'Hotel_Review-g.*?-d(\d+)-', url)
		if locationId_reg:
			locationId = locationId_reg.group(1)
		imk_reg = re.search(r'"IMPRESSION_KEY":\s*"(.*?)"', a)
		if imk_reg:
			imkey = imk_reg.group(1)
		else:
			imkey = ''
		tracking_content_reg = re.search(r'"trackingContext":"(.*?)"', a)
		if tracking_content_reg:
			tracking_content = tracking_content_reg.group(1)
		else:
			tracking_content = ''
		highest_reg = re.search(r'"highestMetaPrice":(.*?)["|,]', a)
		if highest_reg:
			highest = highest_reg.group(1)
		else:
			highest = 0
		lowest_reg = re.search(r'"lowestMetaPrice":(.*?)["|,]', a)
		if lowest_reg:
			lowest = lowest_reg.group(1)
		else:
			lowest = 0
		highestMetaPriceDisplay_reg = re.search(r'"highestMetaPriceDisplay":(.*?)["|,]', a)
		if highestMetaPriceDisplay_reg:
			highestMetaPriceDisplay = highestMetaPriceDisplay_reg.group(1)
		else:
			highestMetaPriceDisplay = 0
		#print "here"
		commerceContentIds_reg = re.search(r'"contentIdMappings": {(.*?)}', a)
		if commerceContentIds_reg:
			commerceContentIds = re.sub(r"&quot;", r"",commerceContentIds_reg.group(1))
			List_Ids = re.findall(r'(\d+):',commerceContentIds)
			List_Ids_check = re.findall(r'(\d+):',commerceContentIds)
		else:
			loadurl = re.sub("#chkin.*", "", url)+"?servletClass=com.TripResearch.servlet.accommodation.AccommodationDetail&disableLazyLoading=true&staydates="+str(staydates)+"&rooms=1&adults="+str(adults)+"&child_rm_ages=&metaReferer=Hotel_Review"
			 
			head = {'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64; rv:64.0) Gecko/20100101 Firefox/64.0','Accept': 'text/html, */*','Accept-Language': 'en-US,en;q=0.5' }
			
			try:     
				gt = sr.get(loadurl, headers = head, verify = False ,proxies=proxies)   
	#                 response= sr.post(url, data=payload, headers=head,proxies=proxies)
				#print response.status_code
			except Exception as e:
				print e
				try:
					gt = sr.get(loadurl, headers = head, verify = False ,proxies=proxies)
	#                     response= sr.post(url, data=payload, headers=head,proxies=proxies)
				except Exception as e:
					print e
					value_error=str(re.sub("'",'"',str(e)))
					stacktrace=sys.exc_traceback.tb_lineno
					statuscode=5
					keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(Websitecode,datetime.datetime.now(),id_update)
					key = bucket.new_key(keyvalue)
					key.set_contents_from_string(str(e))
				
					Guests=adults
					array.append(aws_insert.insert(id_update, inputid ,"",Websitecode, "", "", "", "", Guests, "", "", "", "", "",url, url, url, "", "", "", "", "", "",StartDate, EndDate , "", "", "", "", "", "", "", "", "",region,statuscode, israteperstay))
					return json.dumps(array)
					#continue
			if (gt.status_code <> 200):
				gt = sr.get(loadurl, headers = head, verify = False ,proxies=proxies)
			if (gt.status_code == 403 or gt.status_code == 407):
				try:
					if gt.status_code <> 200:
						gt = sr.get(loadurl, headers = head, verify = False)
				except Exception as e:
					print e
					value_error=str(re.sub("'",'"',str(e)))
					stacktrace=sys.exc_traceback.tb_lineno
					keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(Websitecode,datetime.datetime.now(),id_update)
					key = bucket.new_key(keyvalue)
					key.set_contents_from_string(str(e))
					statuscode=5
					Guests=adults
					array.append(aws_insert.insert(id_update, inputid ,"",Websitecode, "", "", "", "", Guests, "", "", "", "", "",url, url, url, "", "", "", "", "", "",StartDate, EndDate , "", "", "", "", "", "",  "", "", "",region,statuscode, israteperstay))
					return json.dumps(array)
			
	#             gt = sr.get(loadurl, headers = head, verify = False, timeout = 10)
	#         print gt.status_code
			html = gt.text.encode('ascii','ignore')
			commerceContentIds_list = []
			List_Ids_check = []
			if re.compile(r'"contentId":\s*(.*?)\s*,"click').findall(html):
				for comm_id in  re.compile(r'"contentId":\s*(.*?)\s*,"click').findall(html):
					if str(comm_id) not in str(commerceContentIds_list):
						commerceContentIds_list.append(comm_id)
						List_Ids_check.append(comm_id)
			List_Ids = commerceContentIds_list
		if len(List_Ids)==0:#Status_check
			Unavailable_re = re.search(r'class="ibUnavailableMsg unavailableMsg"><span class="highlight">(.*?)</span></div>', html)
			if Unavailable_re:
				Closed      = "Y"
				statuscode='2' 
				#(ReportDate,RoomType,RoomTypeMapped,LOS,RateDate,Guests,OnsiteRate,NetRate,GrossRate,Curr,RateDescription,urlRate,urlInclusions,urlAmenities,RoomAmenity_Type,Mealtype,MaxOccupancy,isPromotionalRate,Closed,NumberOfDays,StartDate,EndDate,StarCategory,Rooms,PageOnRank,Featured,LastModified,isUpdated,isAvailable,Taxtype,TaxAmount,HotelBlock,Ratetype,Discount,Promotion_Name,TaxStatus)
				#print (id_update,inputid ,WebSiteName,Websitecode,StartDate,RoomType,LOS,RateDate,Guests,OnsiteRate,NetRate,OnsiteRate,Curr,RateDescription,url,url,url,RoomAmenity_Type,Mealtype,MaxOccupancy,isPromotionalRate,Closed,30,StartDate ,EndDate,intime,isAvailable,Taxtype,TaxAmount,TaxStatus,None,Ratetype,NetRate,Promotion_Name,region,statuscode)
				array.append(aws_insert.insert(id_update,inputid ,WebSiteName,Websitecode,StartDate,RoomType,LOS,RateDate,Guests,OnsiteRate,NetRate,OnsiteRate,Curr,RateDescription,url,url,url,RoomAmenity_Type,Mealtype,MaxOccupancy,isPromotionalRate,Closed,30,StartDate ,EndDate,intime,isAvailable,Taxtype,TaxAmount,TaxStatus,None,Ratetype,NetRate,Promotion_Name,region,statuscode, israteperstay))
				return json.dumps(array)
			else:
				Closed = "Y"
				statuscode='2'
				array.append(aws_insert.insert(id_update,inputid ,WebSiteName,Websitecode,StartDate,RoomType,LOS,RateDate,Guests,OnsiteRate,NetRate,OnsiteRate,Curr,RateDescription,url,url,url,RoomAmenity_Type,Mealtype,MaxOccupancy,isPromotionalRate,Closed,30,StartDate ,EndDate,intime,isAvailable,Taxtype,TaxAmount,TaxStatus,None,Ratetype,NetRate,Promotion_Name,region,statuscode, israteperstay))
				return json.dumps(array)

		
		def datas(List_Ids,List_Ids_check):
			RoomType    =""
			israteperstay = '' 
# 			region      = ""
			Guests      = adults   
			OnsiteRate  ="0"
# 			NetRate     ="0"
			Curr        =""
			TaxStatus   = ''
			Mealtype    =""
			MaxOccupancy=""
# 			Closed      ="Y"
			isAvailable =""
# 			Taxtype     =""
# 			TaxAmount   ="0"
			Ratetype    =""
# 			statuscode  =''
			RateDescription= ""
# 			Promotion_Name = ""
			RoomAmenity_Type=""
# 			isPromotionalRate="N"
			for ComIds in List_Ids:
				url1    = 'https://www.tripadvisor.in/HotelBookingRoomSelectionJson'
				payload = {"locationId":locationId,"bookingSessionId":"null","detailedAvailabilityKey":"null","commerceContentIds":[ComIds],"additionalContentIds":[],"pollCount":1,"checkin":{"day":str(day),"month":str(month),"year":str(year)},"checkout":{"day":str(Oday),"month":str(Omonth),"year":str(Oyear)},"adults":str(adults),"child_rm_ages":"","rooms":1,"display_rooms":300,"entryCurrency":"INR","complete":"true","formKey":"null","showAllRooms":False,"genNewBookingSessionId":False,"winningProviderAtClick":"","selectedRoomKey":None,"impressionKey":imkey,"navArea":"DesktopBookingArea_Mini|Text|Available|ib_second_one_premium_six_text|Desktop","referringServlet":"Hotel_Review","highestMetaPrice":highest,"lowestMetaPrice":lowest,"additionalPartner":False,"highestMetaPriceDisplay":highestMetaPriceDisplay,"roomsToVerify":[],"clazz":'null',"trackingContext":tracking_content}
				head    = {'User-Agent':'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:12.0) Gecko/20100101 Firefox/48.0', 'X-Requested-With': 'XMLHttpRequest', 'X-Puid' :'WOM-4AokKWEAAQnMSycAAAAt'}
				try:
					response= sr.post(url1, json=payload, headers=head,proxies=proxies)
				except Exception as e:
					print e                
					try:
						response= sr.post(url1, json=payload, headers=head)
						#jss     = re.sub(r"while\(1\);","",response.text.encode('ascii','ignore'))                    
					except Exception,e:
						print e
						value_error=str(re.sub("'",'"',str(e)))
						stacktrace=sys.exc_traceback.tb_lineno
						statuscode=5
						keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(Websitecode,datetime.datetime.now(),id_update)
						key = bucket.new_key(keyvalue)
						key.set_contents_from_string(str(e))
						Guests=''
						Guests=adults
						array.append(aws_insert.insert(id_update, inputid ,"",Websitecode, "", "", "", "", Guests, "", "", "", "", "",url, url, url, "", "", "", "", "", "",StartDate, EndDate , "", "", "", "", "", "", "", "", "",region,statuscode))
						return json.dumps(array)
						#continue
				if (response.status_code <> 200):
					response= sr.post(url, data=payload, headers=head,proxies=proxies)
				if (response.status_code == 403 or response.status_code == 407):
					try:
						if response.status_code <> 200:
							response= sr.post(url, data=payload, headers=head)
					except Exception as e:
						print e
						value_error=str(re.sub("'",'"',str(e)))
						stacktrace=sys.exc_traceback.tb_lineno
						keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(Websitecode,datetime.datetime.now(),id_update)
						key = bucket.new_key(keyvalue)
						key.set_contents_from_string(str(e))
						Guests=''
						statuscode=5
						Guests=adults
						array.append(aws_insert.insert(id_update, inputid ,"",Websitecode, "", "", "", "", Guests, "", "", "", "", "",url, url, url, "", "", "", "", "", "",StartDate, EndDate , "", "", "", "", "", "",  "", "", "",region,statuscode))
						return json.dumps(array)
						
				jss     = re.sub(r"while\(1\);","",response.text.encode('ascii','ignore'))
# 				print payload
				json_V = json.loads(jss)
				List_Ids.remove(ComIds)
# 				print 'ComIds:',ComIds
# 				fo = open(str(ComIds)+'.html','w')
# 				fo.write(jss)
				if 'partnerInfos' in json_V:
					if json_V['partnerInfos']:
						block = json_V['partnerInfos'][0]
						if 'roomList' in block:
							for Roomblock in block['roomList']:
								if 'amenities' in Roomblock:
									RoomAmenity_Type = re.sub(r"'",'"',re.sub(r"\[|\]|\u", r"",str(Roomblock['amenities'])))
								else:
									RoomAmenity_Type = ''
								if 'longDescription' in Roomblock:
									RateDescription = re.sub(r"\n",'',re.sub(r"'","''",re.sub(r"<.*?>|\s\s+", r"",str(Roomblock['longDescription']))))
								else:
									RateDescription = ''
								if 'numAvailable' in Roomblock:
									isAvailable = Roomblock['numAvailable']
								else:
									isAvailable = ''
								if 'shortDescription' in Roomblock:
									RoomType = Roomblock['shortDescription']
								else:
									RoomType = ''            
								if 'roomTypeCode' in Roomblock:
									roomTypeCode = Roomblock['roomTypeCode']
								else:
									roomTypeCode = ''   
								
								if 'standardAmenities' in Roomblock:
									Mealtype = re.sub("\[|\]|u'|'", "", str(Roomblock['standardAmenities']))
								else:
									Mealtype = ''
											
								try:
									OnsiteRate = re.sub("[A-Za-z]","",Roomblock['priceUI']['detailed']['roomTotal'])
									Curr       = Roomblock['priceUI']['tracking']['currency']
								except:
									Curr       = ''
									OnsiteRate = 0
								try:
									MaxOccupancy = block['roomTypes'][roomTypeCode]['maxOccupancy']['numberOfAdults']
								except Exception,e:
									MaxOccupancy = ''
								if 'cancellationDeadline' in Roomblock:
									if Roomblock['cancellationDeadline']!='':
										Ratetype = 'Free Cancellation until '+str(Roomblock['cancellationDeadline'])
									else:
										if re.search(r'non[-|\s+]refundable', RoomType,re.IGNORECASE):
											Ratetype = 'Non-Refundable'
										elif re.search(r'refundable', RoomType, re.IGNORECASE):
											Ratetype = "Refundable"
										else:
											Ratetype = Roomblock['cancellationPolicy']   
								else:
									Ratetype = ''                     
									
								OnsiteRate  = re.sub(r'US\$|,','',str(OnsiteRate))
								##print "MAX Occpy   :-",MaxOccupancy
								##print "standardA   :-",Mealtype
								##print "RoomType    :-",RoomType
								##print "Ratetype    :-",Ratetype
								##print "OnsiteRate  :-",OnsiteRate
								##print "Curr        :-",Curr
								##print "amenities   :-",RoomAmenity_Type
								##print "Description :-",RateDescription
								##print "isAvailable :-",isAvailable
								#print "_"*50
								if OnsiteRate!=0:
									Closed = "N"
									statuscode=''
									TaxStatus   = 2
									if int(LOS) > 1:
										israteperstay = 'N' 
									else:
										israteperstay = 'Y'
								else:
									Closed = "Y"
									statuscode='2'
								Guests=adults
								
								##print "Guests =" ,Guests
								#insert(ReportDate,RoomType,RoomTypeMapped,LOS,RateDate,Guests,OnsiteRate,NetRate,GrossRate,Curr,RateDescription,urlRate,urlInclusions,urlAmenities,RoomAmenity_Type,Mealtype,MaxOccupancy,isPromotionalRate,Closed,NumberOfDays,StartDate,EndDate,StarCategory,Rooms,PageOnRank,Featured,LastModified,isUpdated,isAvailable,Taxtype,TaxAmount,HotelBlock,Ratetype,Discount,Promotion_Name,TaxStatus)
	#                                 print (id_update,inputid ,WebSiteName,Websitecode,StartDate,RoomType,LOS,RateDate,Guests,OnsiteRate,NetRate,OnsiteRate,Curr,RateDescription,url,url,url,RoomAmenity_Type,Mealtype,MaxOccupancy,isPromotionalRate,Closed,30,StartDate ,EndDate,intime,isAvailable,Taxtype,TaxAmount,TaxStatus,None,Ratetype,NetRate,Promotion_Name,region,statuscode)
								array.append(aws_insert.insert(id_update,inputid ,WebSiteName,Websitecode,StartDate,RoomType,LOS,RateDate,Guests,OnsiteRate,NetRate,OnsiteRate,Curr,RateDescription,url,url,url,RoomAmenity_Type,Mealtype,MaxOccupancy,isPromotionalRate,Closed,30,StartDate ,EndDate,intime,isAvailable,Taxtype,TaxAmount,TaxStatus,None,Ratetype,NetRate,Promotion_Name,region,statuscode, israteperstay))
							
						else:
							Closed = "Y"
							statuscode='2'
							array.append(aws_insert.insert(id_update,inputid ,WebSiteName,Websitecode,StartDate,RoomType,LOS,RateDate,Guests,OnsiteRate,NetRate,OnsiteRate,Curr,RateDescription,url,url,url,RoomAmenity_Type,Mealtype,MaxOccupancy,isPromotionalRate,Closed,30,StartDate ,EndDate,intime,isAvailable,Taxtype,TaxAmount,TaxStatus,None,Ratetype,NetRate,Promotion_Name,region,statuscode, israteperstay))
					else:
						if len(List_Ids_check)==1:
							Closed = "Y"
							statuscode='2'
							array.append(aws_insert.insert(id_update,inputid ,WebSiteName,Websitecode,StartDate,RoomType,LOS,RateDate,Guests,OnsiteRate,NetRate,OnsiteRate,Curr,RateDescription,url,url,url,RoomAmenity_Type,Mealtype,MaxOccupancy,isPromotionalRate,Closed,30,StartDate ,EndDate,intime,isAvailable,Taxtype,TaxAmount,TaxStatus,None,Ratetype,NetRate,Promotion_Name,region,statuscode, israteperstay))
															   
				else:
					Closed = "Y"
					statuscode='2'
					array.append(aws_insert.insert(id_update,inputid ,WebSiteName,Websitecode,StartDate,RoomType,LOS,RateDate,Guests,OnsiteRate,NetRate,OnsiteRate,Curr,RateDescription,url,url,url,RoomAmenity_Type,Mealtype,MaxOccupancy,isPromotionalRate,Closed,30,StartDate ,EndDate,intime,isAvailable,Taxtype,TaxAmount,TaxStatus,None,Ratetype,NetRate,Promotion_Name,region,statuscode, israteperstay))
				
			if len(List_Ids)!=0:
				datas(List_Ids,List_Ids_check)
			if not array:
				Closed = "Y"
				statuscode='2'
				array.append(aws_insert.insert(id_update,inputid ,WebSiteName,Websitecode,StartDate,RoomType,LOS,RateDate,Guests,OnsiteRate,NetRate,OnsiteRate,Curr,RateDescription,url,url,url,RoomAmenity_Type,Mealtype,MaxOccupancy,isPromotionalRate,Closed,30,StartDate ,EndDate,intime,isAvailable,Taxtype,TaxAmount,TaxStatus,None,Ratetype,NetRate,Promotion_Name,region,statuscode, israteperstay))
								
# 		print 'List_Ids:',List_Ids
		datas(List_Ids,List_Ids_check)             
		keyvalue = "ondemand/{}/{:%Y%m%d}/delivery/{}.json".format(Websitecode,datetime.datetime.now(),str(inputid)+'_'+str(Rtdate)+'_'+id_update)
		key = bucket.new_key(keyvalue)
		key.set_contents_from_string(json.dumps(array))
# 		print("returning with response")
# 		print 'array:',array
		return json.dumps(array)
		gc.collect()
	except Exception as e:
		value_error=str(re.sub(r"'",'"',str(e)))
		stacktrace=sys.exc_traceback.tb_lineno
		insert_value_error=str(value_error)+'Where line number '+str(stacktrace)+str(proxyip)
		statuscode='4'
		print insert_value_error
		keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(Websitecode,datetime.datetime.now(),id_update)
		key = bucket.new_key(keyvalue)
		key.set_contents_from_string(insert_value_error)
		array.append(aws_insert.insert(id_update, inputid ,"",Websitecode, "", "", "", "", Guests, "", "", "", "", "",url, url, url, "", "", "", "", "", "",StartDate, EndDate , "", "", "", "", "", "", "", "", "",region,statuscode, israteperstay))
		return json.dumps(array)

# fetchrates(url ,inputid, id_update, proxyip)
