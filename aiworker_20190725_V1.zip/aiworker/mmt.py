# -*- coding: utf-8 -*-
import re
import requests
import datetime
import json
import sys 
import boto
import gc
import aws_insert
from unidecode import unidecode


# url = 'https://www.makemytrip.com/mmthtl/site/hotels/detail?roomStayQualifier=2e0e&city=CEB&country=PH&checkin=2019-02-24&checkout=2019-02-27&hotelId=8436720888264759'
# #url = 'https://www.makemytrip.com/mmthtl/site/hotels/detail?roomStayQualifier=1e0e&city=AMD&country=IN&checkin=2018-01-12&checkout=2018-01-13&hotelId=201305261221318440'
# inputid = 2
# id_update = '25'
# proxyip = 'user-34068:214859b73da0e174@103.250.184.229:1212'

def fetchrates(url ,inputid, id_update, proxyip):
    array = []
    israteperstay = ''
    StartDate = datetime.date.today()
    EndDate  = datetime.date.today()+datetime.timedelta(days=29)
    conn = boto.connect_s3(aws_access_key_id= 'AKIAIXEGZVXCWE2FV3SQ',aws_secret_access_key = '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') 
    bucket = conn.get_bucket("rmapi")
    intime=re.sub(r'\s','T',str(datetime.datetime.now()))
    Websitecode = 3
    region=''
    #head = {'Host': 'dtr-hoteldom.makemytrip.com','User-Agent' :'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:12.0) Gecko/20100101 Firefox/48.0', 'Origin': 'https://www.makemytrip.com', 'Accept': 'application/json, text/plain, */*', 'Accept-Encoding' : 'gzip, deflate', 'Referer' : url}
    head = {'Host': 'dtr-hoteldom.makemytrip.com','User-Agent' :'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:12.0) Gecko/20100101 Firefox/48.0', 'Origin': 'https://www.makemytrip.com', 'Accept': 'application/json, text/plain, */*', 'Accept-Encoding' : 'gzip, deflate', 'Referer' : 'http://www.localhost.com'}
    delta = datetime.datetime.strptime(re.search(r"checkout=(.*?)&", url).group(1), "%Y-%m-%d") - datetime.datetime.strptime(re.search(r"checkin=(.*?)&", url).group(1), "%Y-%m-%d")
    LOS = delta.days
    try:
        if re.search(r'checkin=(.*?)&',url):
            chkin_url=datetime.datetime.strptime(re.search(r'checkin=(.*?)&',url).group(1),str('%Y-%m-%d')).strftime('%m%d%Y')
        if re.search(r'checkout=(.*?)&',url):
            chkout_url=datetime.datetime.strptime(re.search(r'checkout=(.*?)&',url).group(1),str('%Y-%m-%d')).strftime('%m%d%Y')
        url=re.sub(r'checkin=.*?&checkout=.*?&','checkin='+chkin_url+'&checkout='+chkout_url+'&',url)
        if 'roomStayQualifier=' in url:
            adult=re.search(r'roomStayQualifier=(\d+)e0e&',url)
            if adult:
                adults=adult.group(1)
        #print url
        #print LOS
        RateDate_reg = re.search(r"checkin=(.*?)&", url)
        if RateDate_reg:
            Ratedate = RateDate_reg.group(1)
            Ratedate_conversion = datetime.datetime.strptime(Ratedate, "%m%d%Y")
            RateDate = datetime.datetime.strftime(Ratedate_conversion, "%Y-%m-%d")
        checkout_reg = re.search(r"checkout=(.*?)&", url)
        if checkout_reg:
            checkout = checkout_reg.group(1)
            checkout_conversion = datetime.datetime.strptime(checkout, "%m%d%Y")
            checkout = datetime.datetime.strftime(checkout_conversion, "%Y-%m-%d")
        City_reg = re.search(r"city=(.*?)&", url)
        if City_reg:
            City = City_reg.group(1)
        country_reg = re.search(r"country=(.*?)&", url)
        if country_reg:
            country = country_reg.group(1)
        hotelId_reg = re.search(r"hotelId=(\d+)", url)
        if hotelId_reg:
            hotelId = hotelId_reg.group(1)
        Domainname="MakeMyTrip"
        Url_concat = re.sub("http.*?\?|searchText.*?&", "", url)    
        RoomType = ""
        RateType=''
        Guests = adults
        OnsiteRate = 0
        Closed_up = 'N'
        MealInclusion_Type = " "
        RoomAmenityType = ""
        NetRate=0
        isAvailable=''
        MaxOccupancy=''
        Curr=''
        ispromupdate = 'N'
        statuscode=''
        promotion=''
        RateDesc=''
        Taxtype=''
        Taxamount=''
        Tax_status=''
        Price_url = re.sub(r"/mmthtl/site","",str(url))
        Detail_url = re.sub(r"/hotels/detail","/hotels/hotel-details/",re.sub(r"/mmthtl/site","",str(url)))
        #print Price_url
#         print Detail_url
        headers = {
            'origin': 'https://www.makemytrip.com',
            'accept-encoding': 'gzip, deflate, br',
            'accept-language': 'en-US,en;q=0.9',
            'user-agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Ubuntu Chromium/71.0.3578.80 Chrome/71.0.3578.80 Safari/537.36',
            'content-type': 'application/json',
            'accept': 'application/json',
            'referer': str(Price_url),
            'authority': 'mapi.makemytrip.com',
        }
        # data = '{"requestType":"B2CAgent","idContext":"B2C","channel":"B2Cweb","deviceId":"Chrome","deviceType":"Desktop","clientIp":"202.129.198.133","appVersion":"71.0.3578.80","bestOffersLimit":2,"applicationId":"410","expiryRequired":false,"pageContext":"DETAIL","email":null,"countryCode":"IN","cityCode":"XYE","hotelIds":["201305071046536570"],"bookingDevice":"DESKTOP","checkin":"2019-04-02","checkout":"2019-04-03","loggedIn":false,"roomStayCandidates":[{"guestCounts":[{"ageQualifyingCode":"10","count":"1"}]}],"responseFilterFlags":{"soldOutInfoReq":true,"staticData":true,"roomLevelDetails":true,"freeCancellationAvail":true,"bestCoupon":true,"priceInfoReq":true,"applyAbsorption":true,"topRatedCommentRequired":false,"walletRequired":true,"mmtPrime":false},"numberOfCoupons":1,"couponCount":1,"guestRecommendationEnabled":{"maxRecommendations":"1","text":"true"},"summaryOnly":false,"visitorId":"[CS]v1|2DE805CB852A1C5E-60000120E000093B[CE]","domain":"B2C","limit":0,"numberOfSoldOuts":0,"experimentData":"{APE:17,PAH:5,PAH5:T,WPAH:F,BNPL:T,MRS:T,PDO:PN}","srcClient":"DESKTOP","firstTimeUserState":0,"flowType":"B2C"}'
        
        # data = '{"requestType":"B2CAgent","idContext":"B2C","channel":"B2Cweb","deviceId":"Chrome","deviceType":"Desktop","bestOffersLimit":2,"applicationId":"410","expiryRequired":false,"pageContext":"DETAIL","email":null,"countryCode":"IN","cityCode":"XYE","hotelIds":["201305071046536570"],"bookingDevice":"DESKTOP","checkin":"2019-04-02","checkout":"2019-04-03","loggedIn":false,"roomStayCandidates":[{"guestCounts":[{"ageQualifyingCode":"10","count":"1"}]}],"responseFilterFlags":{"soldOutInfoReq":true,"staticData":true,"roomLevelDetails":true,"freeCancellationAvail":true,"bestCoupon":true,"priceInfoReq":true,"applyAbsorption":true,"topRatedCommentRequired":false,"walletRequired":true,"mmtPrime":false},"numberOfCoupons":1,"couponCount":1,"guestRecommendationEnabled":{"maxRecommendations":"1","text":"true"},"summaryOnly":false,"domain":"B2C","limit":0,"numberOfSoldOuts":0,"experimentData":"{APE:17,PAH:5,PAH5:T,WPAH:F,BNPL:T,MRS:T,PDO:PN}","srcClient":"DESKTOP","firstTimeUserState":0,"flowType":"B2C"}'
        
        data = '{"requestType":"B2CAgent","idContext":"B2C","channel":"B2Cweb","bestOffersLimit":2,"applicationId":"410","currency":"INR","expiryRequired":false,"pageContext":"DETAIL","email":null,"countryCode":"'+str(country)+'","cityCode":"'+str(City)+'","hotelIds":["'+str(hotelId)+'"],"bookingDevice":"DESKTOP","checkin":"'+str(RateDate)+'","checkout":"'+str(checkout)+'","loggedIn":false,"roomStayCandidates":[{"guestCounts":[{"ageQualifyingCode":"10","count":"'+str(adults)+'"}]}],"responseFilterFlags":{"soldOutInfoReq":true,"staticData":true,"roomLevelDetails":true,"freeCancellationAvail":true,"bestCoupon":true,"priceInfoReq":true,"applyAbsorption":true,"topRatedCommentRequired":false,"walletRequired":true,"mmtPrime":false},"numberOfCoupons":1,"couponCount":1,"guestRecommendationEnabled":{"maxRecommendations":"1","text":"true"},"summaryOnly":false,"domain":"B2C","limit":0,"numberOfSoldOuts":0,"experimentData":"{APE:17,PAH:5,PAH5:T,WPAH:F,BNPL:T,MRS:T,PDO:PN}","srcClient":"DESKTOP","firstTimeUserState":0,"flowType":"B2C"}'
#         print 'data:',data
        
        headers_detail = {
            'origin': 'https://www.makemytrip.com',
            'accept-encoding': 'gzip, deflate, br',
            'accept-language': 'en-US,en;q=0.9',
            'user-agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Ubuntu Chromium/71.0.3578.80 Chrome/71.0.3578.80 Safari/537.36',
            'content-type': 'application/json',
            'accept': 'application/json',
            'referer': str(Detail_url),
            'authority': 'mapi.makemytrip.com',
        }
        
        params = (
            ('srcClient', 'DESKTOP'),
            ('countryCode', "'"+str(country)+"'"),
        )
        
        data_detail = '{"checkin":"'+str(RateDate)+'","checkout":"'+str(checkout)+'","cityCode":"'+str(City)+'","cohertVar":{"apps":[],"isLoggedIn":false},"countryCode":"'+str(country)+'","currency":"INR","email":null,"experimentData":"{APE:17,PAH:5,PAH5:T,WPAH:F,BNPL:T,MRS:T,PDO:PN}","firstNReviewsCount":10,"heightDp":0,"hotelId":"'+str(hotelId)+'","idContext":"B2C","imageCategory":[{"category":"H","count":100,"height":350,"imageFormatType":"webp","width":520},{"category":"R","count":100,"height":350,"imageFormatType":"webp","width":520}],"imageType":["professional","traveller","panoramic"],"lastViewedHotelIds":[],"loggedIn":false,"mobileNumber":"","networkType":"WiFi","pEmailId":"","pageContext":"LISTING","placesMaxCount":20,"requestType":"B2CAgent","requiredApis":{"luxuryRequired":true,"persuasionsRequired":true,"placesRequired":true,"roomInfoRequired":true,"topReviewsRequired":false,"upsellRequired":true,"flyfishSummaryRequired":true},"resolution":"xxhdpi","reviewTypes":["TA","MMT"],"roomStayCandidates":[{"guestCounts":[{"ageQualifyingCode":"10","count":"'+str(adults)+'"}]}],"upsellImageHeight":"135","upsellImageWidth":"288","upsellMaxCount":6,"uuids":[],"widthDp":0,"latitude":null,"longitude":null,"flyfishSummaryRequest":{"filter":{"otas":["MMT","TA","OTHER"]}}}'
#         print 'data_detail:',data_detail
#         print "Price_url ",Price_url
        #print "Detail_url ",Detail_url
        proxies = {"http": "http://{}".format(proxyip)}
        region=''
        ip=re.sub(r"\{'.*?@|'\}|:\d+","",str(proxies))
        try:
            try:
                r = requests.get('http://freegeoip.net/json/'+ip,timeout=30)
            except Exception,e:
                r = requests.get('http://freegeoip.net/json/'+ip,timeout=30)
            js = r.json()
            region=js['country_name']
        except Exception,e:
            region=''
        if re.search(r"checkin=(.*?)&", url):
            RateDate = datetime.datetime.strptime(re.search(r"checkin=(.*?)&", url).group(1), "%m%d%Y").strftime("%Y-%m-%d")
            Rtdate=re.sub(r'-|\-','',str(RateDate))
        #if re.search(r"(checkin=.*?&)", url):
        #url = re.sub("https", "http", re.sub(r"&roomStayQualifier.*?&", "&roomStayQualifier=1e0e&", re.sub("&amp;|&amp;\%+", "&", url).replace('%20', '%%20')))
        try:
            response = requests.post('https://mapi.makemytrip.com/clientbackend/entity/api/hotels/searchPrice', headers=headers, data=data, proxies = proxies,timeout = 10)
            response_detail = requests.post('https://mapi.makemytrip.com/clientbackend/entity/api/mob/staticDetail', headers=headers_detail, params=params, data=data_detail, proxies = proxies,timeout = 10)
        except Exception,e:
            value_error=str(re.sub("'",'"',str(e)))
            stacktrace=sys.exc_traceback.tb_lineno
            try:
                proxies = {"http": "http://{}".format(proxyip)}
                response = requests.post('https://mapi.makemytrip.com/clientbackend/entity/api/hotels/searchPrice', headers=headers, data=data, proxies = proxies,timeout = 10)
                response_detail = requests.post('https://mapi.makemytrip.com/clientbackend/entity/api/mob/staticDetail', headers=headers_detail, params=params, data=data_detail, proxies = proxies,timeout = 10)
            except Exception,e:
                value_error=str(re.sub("'",'"',str(e)))
                stacktrace=sys.exc_traceback.tb_lineno
                keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(Websitecode,datetime.datetime.now(),id_update)
                #print keyvalue
                key = bucket.new_key(keyvalue)
                error= str(e)+'\n'+str(proxies)
                key.set_contents_from_string(error)
                statuscode=5
                Guests=adults
                array.append(aws_insert.insert(id_update, inputid ,"",Websitecode, "", "", "", "", Guests, "", "", "", "", "",url,url,url, "", "", "", "", "", "",StartDate, EndDate , "", "", "", "", "",  "", "", "","",region,statuscode, israteperstay))
                #array.append(aws_insert.insert(id_update, inputid ,"","", "", "", "", "", "", "", "", "", "", "","", "", "", "", "", "", "", "", "",StartDate, EndDate , "", "", "", "", "",  "", "", "",statuscode))
                return json.dumps(array)
        if (response.status_code <> 200):
            response = requests.post('https://mapi.makemytrip.com/clientbackend/entity/api/hotels/searchPrice', headers=headers, data=data, proxies = proxies)
        if (response.status_code == 403 or response.status_code == 407):
            try:
                #jproxy = json.loads(requests.get('http://www.gimmeproxy.com/api/getProxy?protocol=http').content)
                #proxies = { "http": jproxy["curl"] }
                session_request = requests.Session()
                session_request.get('http://mapi.makemytrip.com', headers = headers, proxies=proxies)
                response = requests.post('https://mapi.makemytrip.com/clientbackend/entity/api/hotels/searchPrice', headers=headers, data=data, proxies = proxies)
                if (response.status_code != 200):
                    response = requests.post('https://mapi.makemytrip.com/clientbackend/entity/api/hotels/searchPrice', headers=headers, data=data)
            except Exception,e:
                value_error=str(re.sub("'",'"',str(e)))
                value_error=str(e).enode('ascii','ignore')
                stacktrace=sys.exc_traceback.tb_lineno
                keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(Websitecode,datetime.datetime.now(),id_update)
                key = bucket.new_key(keyvalue)
                error= str(e)+'\n'+str(proxies)
                key.set_contents_from_string(error)
                statuscode=5
                Guests=adults
                array.append(aws_insert.insert(id_update, inputid ,"",Websitecode, "", "", "", "", Guests, "", "", "", "", "",url,url,url, "", "", "", "", "", "",StartDate, EndDate , "", "", "", "", "",  "", "", "","",region,statuscode, israteperstay))
                return json.dumps(array)
        if (response_detail.status_code <> 200):   
            response_detail = requests.post('https://mapi.makemytrip.com/clientbackend/entity/api/mob/staticDetail', headers=headers_detail, params=params, data=data_detail, proxies = proxies)
        if (response_detail.status_code == 403 or response_detail.status_code == 407):
            try:
                #jproxy = json.loads(requests.get('http://www.gimmeproxy.com/api/getProxy?protocol=http').content)
                #proxies = { "http": jproxy["curl"] }
                session_request = requests.Session()
                session_request.get('http://mapi.makemytrip.com', headers = headers_detail, proxies=proxies)
                response_detail = requests.post('https://mapi.makemytrip.com/clientbackend/entity/api/mob/staticDetail', headers=headers_detail, params=params, data=data_detail, proxies = proxies)
                if (response_detail.status_code != 200):
                    response_detail = requests.post('https://mapi.makemytrip.com/clientbackend/entity/api/mob/staticDetail', headers=headers_detail, params=params, data=data_detail)
            except Exception,e:
                value_error=str(re.sub("'",'"',str(e)))
                value_error=str(e).enode('ascii','ignore')
                stacktrace=sys.exc_traceback.tb_lineno
                keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(Websitecode,datetime.datetime.now(),id_update)
                key = bucket.new_key(keyvalue)
                error= str(e)+'\n'+str(proxies)
                key.set_contents_from_string(error)
                statuscode=5
                Guests=adults
                array.append(aws_insert.insert(id_update, inputid ,"",Websitecode, "", "", "", "", Guests, "", "", "", "", "",url,url,url, "", "", "", "", "", "",StartDate, EndDate , "", "", "", "", "",  "", "", "","",region,statuscode, israteperstay))
                return json.dumps(array)
        ##print json_load.text
        #print json_load.status_code, Djson_load.status_code
        if "bots.makemytrip.com" in response_detail.text or "bots.makemytrip.com" in response.text:
            #print "Requires Captcha"
            #statuscode ='9'
            value_error="Requires Captcha"
            proxies1 = str(proxies).encode('ascii', 'ignore')
            stacktrace='proxyError'
            key = bucket.new_key("ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(Websitecode,datetime.datetime.now(),id_update))
            key.set_contents_from_string(proxies1) 
            statuscode='9'
            #print "Captcha statuscode: =",statuscode
            array.append(aws_insert.insert(id_update, inputid ,"",Websitecode, "", "", "", "", Guests, "", "", "", "", "",url,url,url, "", "", "", "", "", "",StartDate, EndDate , "", "", "", "", "",  "", "", "","",region,statuscode, israteperstay))
            return json.dumps(array)
        else:
            try: 
#                 print response_detail.status_code
#                 print response.status_code
                html = unidecode(response.text).encode('ascii')
                open('name_mmt.html', 'w').write(str(html))
                Guests=adults
                jsonvalue = json.loads(response.text.encode('utf-8'))
                Djsonvalue = json.loads(response_detail.text.encode('utf-8'))
                keyvalue="ondemand/{}/{:%Y%m%d}/source/{}.json".format(Websitecode,datetime.datetime.now(),str(inputid)+'_'+str(Rtdate)+'_'+id_update)
                key = bucket.new_key(keyvalue)
                key.set_contents_from_string(response.text)
                price_json = jsonvalue
                detail_json = Djsonvalue
#                 print 'price_json:',price_json
                if price_json.has_key('hotelRates'):
                    for main_block in price_json['hotelRates']:
                        Curr='INR'
                        if main_block.has_key('roomTypeDetails'):
                            if main_block['roomTypeDetails'].has_key('roomType'):
                                if main_block['roomTypeDetails']['roomType']:
                                    for first_block in main_block['roomTypeDetails']['roomType']:
                                        
                                        block = main_block['roomTypeDetails']['roomType'][str(first_block)]
            #                             print block
            
                                        if block.has_key('roomTypeName'):
                                            RoomType = re.sub(r"'","''",str(block['roomTypeName']))
                                        else:
                                            RoomType = ''
    #                                     print 'RoomType:',RoomType
                                        
                                        if block.has_key('roomTypeCode'):
                                            RoomType_code = block['roomTypeCode']
                                        else:
                                            RoomType_code = ''
    #                                     print 'RoomType_code:',RoomType_code
                                        facilities_list = []
                                        if detail_json.has_key('roomInfoData'):
                                            if detail_json['roomInfoData'].has_key('roomInfoMap'):
                                                if detail_json['roomInfoData']['roomInfoMap']:
                                                    if str(RoomType_code) in str(detail_json['roomInfoData']['roomInfoMap']):
                                                        try:
                                                            desc_block = detail_json['roomInfoData']['roomInfoMap'][str(RoomType_code)]
                                                        except:
                                                            for des_block in detail_json['roomInfoData']['roomInfoMap']:
                                                                desc_block = detail_json['roomInfoData']['roomInfoMap'][str(des_block)]
                                                                if str(RoomType_code) in str(desc_block):
                                                                    break
                                                                else:
                                                                    desc_block = ''
                                                        if 'roomSize' in str(desc_block):
                                                            Roomsize = 'RoomSize:'+str(desc_block['roomSize'])
                                                            facilities_list.append(Roomsize)
                                                        else:
                                                            Roomsize = ''
                                                        if desc_block.has_key('facilityWithGrp'):
                                                            if desc_block['facilityWithGrp']:
                                                                for faci_block in desc_block['facilityWithGrp']:
                                                                    if faci_block.has_key('facilities'):
                                                                        if faci_block['facilities']:
                                                                            for facilities_block in faci_block['facilities']:
                                                                                facilities = facilities_block['name']
                                                                                facilities_list.append(facilities)
    #                                                     print 'Roomsize:',Roomsize
    #                                                     print 'facilities_list:',facilities_list
                                                        
                                        
                                        if block.has_key('ratePlanList'):
                                            if block['ratePlanList']:
                                                for rate_block in block['ratePlanList']:
                                                    inclu_type_list = []
                                                    ratetype_block = block['ratePlanList'][str(rate_block)]
                                                    if ratetype_block.has_key('inclusions'):
                                                        if ratetype_block['inclusions']:
                                                            for inclu_block in ratetype_block['inclusions']:
                                                                inclu_type = inclu_block['value']
                                                                inclu_type_list.append(inclu_type)
                                                    inclu_type_amen = re.sub(r"\[\]","",re.sub(r"'","''",re.sub(r"\'\, \u\'",", ",re.sub(r"\[\'|\'\]|\[\u\'","",str(inclu_type_list)))))
                                                    RoomAmenityType = (re.sub(r"\[\]","",re.sub(r"'","''",re.sub(r"\'\, \u\'",", ",re.sub(r"\[\'|\'\]","",str(facilities_list)))))+', '+str(inclu_type_amen)).strip().strip(',')
#                                                     print 'RoomAmenityType:',RoomAmenityType
                                                    
                                                    if ratetype_block.has_key('mealPlans'):
                                                        if ratetype_block['mealPlans']:
                                                            for meal_block in ratetype_block['mealPlans']:
                                                                MealInclusion_Type = re.sub(r"'","''",str(meal_block['value']))
                                                                break
                                                        else:
                                                            MealInclusion_Type = ''
                                                    else:
                                                        MealInclusion_Type = ''
    #                                                 print 'MealInclusion_Type:',MealInclusion_Type
                                                    
#                                                     if ratetype_block.has_key('availDetails'):
#                                                         if ratetype_block['availDetails']:
#                                                             if ratetype_block['availDetails'].has_key('occupancyDetails'):
#                                                                 if ratetype_block['availDetails']['occupancyDetails']:
#                                                                     if ratetype_block['availDetails']['occupancyDetails'].has_key('adult'):
#                                                                         MaxOccupancy = ratetype_block['availDetails']['occupancyDetails']['adult']
#                                                                     else:
#                                                                         MaxOccupancy = 0
#                                                                 else:
#                                                                     MaxOccupancy = 0
#                                                             else:
#                                                                 MaxOccupancy = 0
#                                                         else:
#                                                             MaxOccupancy = 0
#                                                     else:
#                                                         MaxOccupancy = 0
    #                                                 print 'MaxOccupancy:',MaxOccupancy
                                                    
                                                    if ratetype_block.has_key('cancelPenaltyList'):
                                                        if ratetype_block['cancelPenaltyList']:
                                                            for cancel_block in ratetype_block['cancelPenaltyList']:
                                                                RateType = re.sub(r"'","''",str(cancel_block['freeCancellationText']))
                                                                if 'None' in str(RateType):
                                                                    if cancel_block.has_key('penaltyDescription'):
                                                                        if cancel_block['penaltyDescription'].has_key('description'):
                                                                            ratetype_description = cancel_block['penaltyDescription']['description']
                                                                            if 'booking amount will be charged in case of cancellation' in str(ratetype_description).lower() or 'no refund' in str(ratetype_description).lower() or 'non-refundable' in str(ratetype_description).lower():
                                                                                RateType = 'Non-refundable'
                                                                            
                                                        else:
                                                            RateType = ''
                                                    else:
                                                        RateType = ''
    #                                                 print 'RateType:',RateType
                                                    
                                                                        
                                                                    
                                                        
                                                    NetRate = 0
                                                    OnsiteRate = 0
                                                    discount_NetRate = 0
                                                    if ratetype_block.has_key('displayFare'):
                                                        if ratetype_block['displayFare']:
                                                            if LOS > 1:
                                                                if ratetype_block['displayFare'].has_key('displayPriceBreakDown'):
                                                                    if ratetype_block['displayFare']['displayPriceBreakDown']:
                                                                        
                                                                        if ratetype_block['displayFare']['displayPriceBreakDown'].has_key('nonDiscountedPrice'):
                                                                            if ratetype_block['displayFare']['displayPriceBreakDown']['nonDiscountedPrice']:
                                                                                NetRate = ratetype_block['displayFare']['displayPriceBreakDown']['nonDiscountedPrice']
                                                                                ispromupdate = 'Y'
                                                                            else:
                                                                                NetRate = 0
                                                                                ispromupdate = 'N'
                                                                        else:
                                                                            NetRate = 0
                                                                            ispromupdate = 'N'
                                                                            
                                                                        if ratetype_block['displayFare']['displayPriceBreakDown'].has_key('displayPrice'):
                                                                            if ratetype_block['displayFare']['displayPriceBreakDown']['displayPrice']:
                                                                                OnsiteRate = ratetype_block['displayFare']['displayPriceBreakDown']['displayPrice']
                                                                            else:
                                                                                OnsiteRate = 0
                                                                        else:
                                                                            OnsiteRate = 0
                                                                                
                                                                    else:
                                                                        OnsiteRate = 0
                                                                        NetRate = 0
                                                                        ispromupdate = 'N'
                                                                else:
                                                                    OnsiteRate = 0
                                                                    NetRate = 0
                                                                    ispromupdate = 'N'
                                                            
                                                            else:
                                                                if ratetype_block['displayFare'].has_key('totalTariff'):
                                                                    if ratetype_block['displayFare']['totalTariff']:
                                                                        if ratetype_block['displayFare']['totalTariff'].has_key('subTotal'):
                                                                            NetRate = ratetype_block['displayFare']['totalTariff']['subTotal']
                                                                        else:
                                                                            NetRate = 0
                                                                            ispromupdate = 'N'
                                                                        if ratetype_block['displayFare']['totalTariff'].has_key('discount'):
                                                                            discount_NetRate = ratetype_block['displayFare']['totalTariff']['discount']
                                                                        else:
                                                                            discount_NetRate = 0
                                                                    else:
                                                                        NetRate = 0
                                                                        discount_NetRate = 0
                                                                
                                                                if ratetype_block['displayFare'].has_key('bestCouponByPaymode'):
                                                                    if ratetype_block['displayFare']['bestCouponByPaymode']:
                                                                        if ratetype_block['displayFare']['bestCouponByPaymode'].has_key('PAS'):
                                                                            if ratetype_block['displayFare']['bestCouponByPaymode']['PAS']:
                                                                                if ratetype_block['displayFare']['bestCouponByPaymode']['PAS'].has_key('discountAmount'):
                                                                                    sub_rate = ratetype_block['displayFare']['bestCouponByPaymode']['PAS']['discountAmount']
                                                                                    OnsiteRate = (float(NetRate)-float(sub_rate))-float(discount_NetRate)
                                                                                else:
                                                                                    OnsiteRate = 0
                                                                            else:
                                                                                OnsiteRate = 0
                                                                        else:
                                                                            OnsiteRate = 0
                                                                    else:
                                                                        OnsiteRate = 0
                                                                else:
                                                                    OnsiteRate = float(NetRate)-float(discount_NetRate)
                                                                        
                                                        else:
                                                            NetRate = 0
                                                            ispromupdate = 'N'
                                                            OnsiteRate = 0
                                                            discount_NetRate = 0
                                                    else:
                                                        NetRate = 0
                                                        ispromupdate = 'N'
                                                        OnsiteRate = 0
                                                        discount_NetRate = 0
    #                                                 print 'Onsiterate:',OnsiteRate
    #                                                 print 'NetRate:',NetRate
    #                                                 print 'Tax_status:',Tax_status
                                                    
                                                    if NetRate:
                                                        if OnsiteRate == 0:
                                                            OnsiteRate = NetRate
                                                            NetRate = 0
                                                        else:
                                                            ispromupdate = 'Y'
                                                    else:
                                                        ispromupdate = 'N'
                                                    GrossRate = OnsiteRate
                                                    discount_rate = NetRate
    #                                                 print 'OnsiteRate:',OnsiteRate
    #                                                 print 'NetRate:',NetRate     
                                                    
                                                    if ratetype_block.has_key('displayFare'):
                                                        if ratetype_block['displayFare']:
                                                            if ratetype_block['displayFare'].has_key('taxExcluded'):
                                                                Tax_status = ratetype_block['displayFare']['taxExcluded']
                                                            else:
                                                                Tax_status = True
#                                                     if ratetype_block.has_key('supplierDetails'):
#                                                         if ratetype_block['supplierDetails']:
#                                                             if ratetype_block['supplierDetails'].has_key('hotelierCurrencyCode'):
#                                                                 Curr = ratetype_block['supplierDetails']['hotelierCurrencyCode']
#                                                             else:
#                                                                 Curr = ''
#                                                         else:
#                                                             Curr = ''
#                                                     else:
#                                                         Curr = ''
#                                                     print 'Curr:',Curr
                                                
                                                    da_time = datetime.datetime.now()
                                                    intime = re.sub(r'\s','T',str(da_time))
                                                    if str(OnsiteRate) == '0' or str(OnsiteRate) == '' or OnsiteRate==0:
                                                        statuscode=1
                                                        Closed_up='Y'
                                                        Tax_status = '-1'
                                                    else:
                                                        statuscode=''
                                                        Closed_up='N'
                                                        if Tax_status:
                                                            Tax_status = '2'
                                                        else:
                                                            Tax_status = '1'
                                                        Tax_status = '2'
                                                        if LOS >1:
                                                            israteperstay = 'N'
                                                        else:
                                                            israteperstay = 'Y'
                                                    if float(OnsiteRate) > float(NetRate):
                                                        NetRate = 0
                                                        ispromupdate = 'N'
                                                    if float(OnsiteRate) == float(NetRate):
                                                        NetRate = 0
                                                        ispromupdate = 'N'
                                                    if NetRate == 0 or str(NetRate) == '0':
                                                        ispromupdate = 'N'
                                                    ##print url
#                                                     print(id_update, inputid , Domainname, Websitecode, StartDate, RoomType, LOS, RateDate, Guests, OnsiteRate, NetRate, OnsiteRate, Curr, RateDesc, url, url, url, RoomAmenityType, MealInclusion_Type, MaxOccupancy, ispromupdate, Closed_up, 30, StartDate , EndDate, intime, isAvailable, None, None,  None, RateType, NetRate,promotion,statuscode)
                                                    array.append(aws_insert.insert(id_update, inputid , Domainname, Websitecode, StartDate, RoomType, LOS, RateDate, Guests, OnsiteRate, NetRate, OnsiteRate, Curr, RateDesc, url, url, url, RoomAmenityType, MealInclusion_Type, MaxOccupancy, ispromupdate, Closed_up, 30, StartDate , EndDate, intime, isAvailable,Taxtype, Taxamount,Tax_status,  None, RateType, NetRate,promotion,region,statuscode, israteperstay))
                                        
                        elif main_block.has_key('recommendedRoomTypeDetails'):
                            if main_block['recommendedRoomTypeDetails'].has_key('roomType'):
                                if main_block['recommendedRoomTypeDetails']['roomType']:
                                    for first_block in main_block['recommendedRoomTypeDetails']['roomType']:
                                        
                                        block = main_block['recommendedRoomTypeDetails']['roomType'][str(first_block)]
            #                             print block
            
                                        if block.has_key('roomTypeName'):
                                            RoomType = re.sub(r"'","''",str(block['roomTypeName']))
                                        else:
                                            RoomType = ''
    #                                     print 'RoomType:',RoomType
                                        
                                        if block.has_key('roomTypeCode'):
                                            RoomType_code = block['roomTypeCode']
                                        else:
                                            RoomType_code = ''
    #                                     print 'RoomType_code:',RoomType_code
                                        facilities_list = []
                                        if detail_json.has_key('roomInfoData'):
                                            if detail_json['roomInfoData'].has_key('roomInfoMap'):
                                                if detail_json['roomInfoData']['roomInfoMap']:
                                                    if str(RoomType_code) in str(detail_json['roomInfoData']['roomInfoMap']):
                                                         
                                                        try:
                                                            desc_block = detail_json['roomInfoData']['roomInfoMap'][str(RoomType_code)]
                                                        except:
                                                            for des_block in detail_json['roomInfoData']['roomInfoMap']:
                                                                desc_block = detail_json['roomInfoData']['roomInfoMap'][str(des_block)]
                                                                if str(RoomType_code) in str(desc_block):
                                                                    break
                                                                else:
                                                                    desc_block = ''
                                                        if 'roomSize' in str(desc_block):
                                                            Roomsize = 'RoomSize:'+str(desc_block['roomSize'])
                                                            facilities_list.append(Roomsize)
                                                        else:
                                                            Roomsize = ''
                                                        if desc_block.has_key('facilityWithGrp'):
                                                            if desc_block['facilityWithGrp']:
                                                                for faci_block in desc_block['facilityWithGrp']:
                                                                    if faci_block.has_key('facilities'):
                                                                        if faci_block['facilities']:
                                                                            for facilities_block in faci_block['facilities']:
                                                                                facilities = facilities_block['name']
                                                                                facilities_list.append(facilities)
    #                                                     print 'Roomsize:',Roomsize
    #                                                     print 'facilities_list:',facilities_list
                                                        
                                        
                                        if block.has_key('ratePlanList'):
                                            if block['ratePlanList']:
                                                for rate_block in block['ratePlanList']:
                                                    
                                                    inclu_type_list = []
                                                    ratetype_block = block['ratePlanList'][str(rate_block)]
                                                    if ratetype_block.has_key('inclusions'):
                                                        if ratetype_block['inclusions']:
                                                            for inclu_block in ratetype_block['inclusions']:
                                                                inclu_type = inclu_block['value']
                                                                inclu_type_list.append(inclu_type)
    #                                                 print 'facilities_list:',facilities_list                                       
                                                    inclu_type_amen = re.sub(r"\[\]","",re.sub(r"'","''",re.sub(r"\'\, \u\'",", ",re.sub(r"\[\'|\'\]|\[\u\'","",str(inclu_type_list)))))
                                                    RoomAmenityType = (re.sub(r"\[\]","",re.sub(r"'","''",re.sub(r"\'\, \u\'",", ",re.sub(r"\[\'|\'\]","",str(facilities_list)))))+', '+str(inclu_type_amen)).strip().strip(',')
    #                                                 print 'RoomAmenityType:',RoomAmenityType
                                                    
                                                    if ratetype_block.has_key('mealPlans'):
                                                        if ratetype_block['mealPlans']:
                                                            for meal_block in ratetype_block['mealPlans']:
                                                                MealInclusion_Type = re.sub(r"'","''",str(meal_block['value']))
                                                                break
                                                        else:
                                                            MealInclusion_Type = ''
                                                    else:
                                                        MealInclusion_Type = ''
    #                                                 print 'MealInclusion_Type:',MealInclusion_Type
                                                    
#                                                     if ratetype_block.has_key('availDetails'):
#                                                         if ratetype_block['availDetails']:
#                                                             if ratetype_block['availDetails'].has_key('occupancyDetails'):
#                                                                 if ratetype_block['availDetails']['occupancyDetails']:
#                                                                     if ratetype_block['availDetails']['occupancyDetails'].has_key('adult'):
#                                                                         MaxOccupancy = ratetype_block['availDetails']['occupancyDetails']['adult']
#                                                                     else:
#                                                                         MaxOccupancy = 0
#                                                                 else:
#                                                                     MaxOccupancy = 0
#                                                             else:
#                                                                 MaxOccupancy = 0
#                                                         else:
#                                                             MaxOccupancy = 0
#                                                     else:
#                                                         MaxOccupancy = 0
    #                                                 print 'MaxOccupancy:',MaxOccupancy
                                                    
                                                    if ratetype_block.has_key('cancelPenaltyList'):
                                                        if ratetype_block['cancelPenaltyList']:
                                                            for cancel_block in ratetype_block['cancelPenaltyList']:
                                                                RateType = re.sub(r"'","''",str(cancel_block['freeCancellationText']))
                                                                if 'None' in str(RateType):
                                                                    if cancel_block.has_key('penaltyDescription'):
                                                                        if cancel_block['penaltyDescription'].has_key('description'):
                                                                            ratetype_description = cancel_block['penaltyDescription']['description']
                                                                            if 'booking amount will be charged in case of cancellation' in str(ratetype_description).lower() or 'no refund' in str(ratetype_description).lower() or 'non-refundable' in str(ratetype_description).lower():
                                                                                RateType = 'Non-refundable'
                                                                            
                                                        else:
                                                            RateType = ''
                                                    else:
                                                        RateType = ''
    #                                                 print 'RateType:',RateType
                                                    
                                                    
                                                    
                                                    NetRate = 0
                                                    OnsiteRate = 0
                                                    discount_NetRate = 0
                                                    if ratetype_block.has_key('displayFare'):
                                                        if ratetype_block['displayFare']:
                                                            if LOS > 1:
                                                                if ratetype_block['displayFare'].has_key('displayPriceBreakDown'):
                                                                    if ratetype_block['displayFare']['displayPriceBreakDown']:
                                                                        
                                                                        if ratetype_block['displayFare']['displayPriceBreakDown'].has_key('nonDiscountedPrice'):
                                                                            if ratetype_block['displayFare']['displayPriceBreakDown']['nonDiscountedPrice']:
                                                                                NetRate = ratetype_block['displayFare']['displayPriceBreakDown']['nonDiscountedPrice']
                                                                                ispromupdate = 'Y'
                                                                            else:
                                                                                NetRate = 0
                                                                        else:
                                                                            NetRate = 0
                                                                            
                                                                        if ratetype_block['displayFare']['displayPriceBreakDown'].has_key('displayPrice'):
                                                                            if ratetype_block['displayFare']['displayPriceBreakDown']['displayPrice']:
                                                                                OnsiteRate = ratetype_block['displayFare']['displayPriceBreakDown']['displayPrice']
                                                                            else:
                                                                                OnsiteRate = 0
                                                                        else:
                                                                            OnsiteRate = 0
                                                                                
                                                                    else:
                                                                        OnsiteRate = 0
                                                                        NetRate = 0
                                                                else:
                                                                    OnsiteRate = 0
                                                                    NetRate = 0
                                                            
                                                            else:
                                                                if ratetype_block['displayFare'].has_key('totalTariff'):
                                                                    if ratetype_block['displayFare']['totalTariff']:
                                                                        if ratetype_block['displayFare']['totalTariff'].has_key('subTotal'):
                                                                            NetRate = ratetype_block['displayFare']['totalTariff']['subTotal']
                                                                        else:
                                                                            NetRate = 0
                                                                        if ratetype_block['displayFare']['totalTariff'].has_key('discount'):
                                                                            discount_NetRate = ratetype_block['displayFare']['totalTariff']['discount']
                                                                        else:
                                                                            discount_NetRate = 0
                                                                    else:
                                                                        NetRate = 0
                                                                        discount_NetRate = 0
                                                                
                                                                if ratetype_block['displayFare'].has_key('bestCouponByPaymode'):
                                                                    if ratetype_block['displayFare']['bestCouponByPaymode']:
                                                                        if ratetype_block['displayFare']['bestCouponByPaymode'].has_key('PAS'):
                                                                            if ratetype_block['displayFare']['bestCouponByPaymode']['PAS']:
                                                                                if ratetype_block['displayFare']['bestCouponByPaymode']['PAS'].has_key('discountAmount'):
                                                                                    sub_rate = ratetype_block['displayFare']['bestCouponByPaymode']['PAS']['discountAmount']
                                                                                    OnsiteRate = (float(NetRate)-float(sub_rate))-float(discount_NetRate)
                                                                                else:
                                                                                    OnsiteRate = 0
                                                                            else:
                                                                                OnsiteRate = 0
                                                                        else:
                                                                            OnsiteRate = 0
                                                                    else:
                                                                        OnsiteRate = 0
                                                                else:
                                                                    OnsiteRate = float(NetRate)-float(discount_NetRate)
                                                                        
                                                        else:
                                                            NetRate = 0
                                                            OnsiteRate = 0
                                                            discount_NetRate = 0
                                                    else:
                                                        NetRate = 0
                                                        OnsiteRate = 0
                                                        discount_NetRate = 0
    #                                                 print 'Onsiterate:',OnsiteRate
    #                                                 print 'NetRate:',NetRate
    #                                                 print 'Tax_status:',Tax_status
                                                    
                                                    if NetRate:
                                                        if OnsiteRate == 0:
                                                            OnsiteRate = NetRate
                                                            NetRate = 0
                                                        else:
                                                            ispromupdate = 'Y'
                                                    else:
                                                        ispromupdate = 'N'
                                                    GrossRate = OnsiteRate
                                                    discount_rate = NetRate
    #                                                 print 'OnsiteRate:',OnsiteRate
    #                                                 print 'NetRate:',NetRate     
                                                    
                                                    if ratetype_block.has_key('displayFare'):
                                                        if ratetype_block['displayFare']:
                                                            if ratetype_block['displayFare'].has_key('taxExcluded'):
                                                                Tax_status = ratetype_block['displayFare']['taxExcluded']
                                                            else:
                                                                Tax_status = True
#                                                     if ratetype_block.has_key('supplierDetails'):
#                                                         if ratetype_block['supplierDetails']:
#                                                             if ratetype_block['supplierDetails'].has_key('hotelierCurrencyCode'):
#                                                                 Curr = ratetype_block['supplierDetails']['hotelierCurrencyCode']
#                                                             else:
#                                                                 Curr = ''
#                                                         else:
#                                                             Curr = ''
#                                                     else:
#                                                         Curr = ''
#                                                     print 'Curr:',Curr
                                                    da_time = datetime.datetime.now()
                                                    intime = re.sub(r'\s','T',str(da_time))
                                                    if str(OnsiteRate) == '0' or str(OnsiteRate) == '' or OnsiteRate==0:
                                                        statuscode=1
                                                        Closed_up='Y'
                                                        Tax_status = '-1'
                                                    else:
                                                        statuscode=''
                                                        Closed_up='N'
                                                        if Tax_status:
                                                            Tax_status = '2'
                                                        else:
                                                            Tax_status = '1'
                                                        Tax_status = '2'
                                                        if LOS >1:
                                                            israteperstay = 'N'
                                                        else:
                                                            israteperstay = 'Y'
                                                    if float(OnsiteRate) > float(NetRate):
                                                        NetRate = 0
                                                        ispromupdate = 'N'
                                                    if float(OnsiteRate) == float(NetRate):
                                                        NetRate = 0
                                                        ispromupdate = 'N'
                                                    if NetRate == 0 or str(NetRate) == '0':
                                                        ispromupdate = 'N'
                                                    ##print url
                                                    
#                                                     print(id_update, inputid , Domainname, Websitecode, StartDate, RoomType, LOS, RateDate, Guests, OnsiteRate, NetRate, OnsiteRate, Curr, RateDesc, url, url, url, RoomAmenityType, MealInclusion_Type, MaxOccupancy, ispromupdate, Closed_up, 30, StartDate , EndDate, intime, isAvailable, None, None,  None, RateType, NetRate,promotion,statuscode)
                                                    array.append(aws_insert.insert(id_update, inputid , Domainname, Websitecode, StartDate, RoomType, LOS, RateDate, Guests, OnsiteRate, NetRate, OnsiteRate, Curr, RateDesc, url, url, url, RoomAmenityType, MealInclusion_Type, MaxOccupancy, ispromupdate, Closed_up, 30, StartDate , EndDate, intime, isAvailable,Taxtype, Taxamount,Tax_status,  None, RateType, NetRate,promotion,region,statuscode, israteperstay))
                                        
                else:
#                     print 'else'
                    statuscode = '2'
                    Closed_up = 'Y'
                    array.append(aws_insert.insert(id_update, inputid , Domainname, Websitecode, StartDate, RoomType, LOS, RateDate, Guests, OnsiteRate, NetRate, OnsiteRate, Curr, RateDesc, url, url, url, RoomAmenityType, MealInclusion_Type, MaxOccupancy, ispromupdate, Closed_up, 30, StartDate , EndDate, intime, isAvailable,Taxtype, Taxamount,Tax_status,  None, RateType, NetRate,promotion,region,statuscode, israteperstay))
            except Exception,e:
                value_error=str(re.sub(r"'",'"',str(e)))
                stacktrace=sys.exc_traceback.tb_lineno
                insert_value_error=str(value_error)+'Where line number '+str(stacktrace)+' - '+str(proxyip)
                print insert_value_error
                statuscode='4'
                keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(Websitecode,datetime.datetime.now(),id_update)
                key = bucket.new_key(keyvalue)
                key.set_contents_from_string(insert_value_error) 
                Closed_up = 'Y'
                array.append(aws_insert.insert(id_update, inputid , Domainname, Websitecode, StartDate, RoomType, LOS, RateDate, Guests, OnsiteRate, NetRate, OnsiteRate, Curr, RateDesc, url, url, url, RoomAmenityType, MealInclusion_Type, MaxOccupancy, ispromupdate, Closed_up, 30, StartDate , EndDate, intime, isAvailable,Taxtype, Taxamount,Tax_status,  None, RateType, NetRate,promotion,region,statuscode, israteperstay))
                return json.dumps(array)
        keyvalue = "ondemand/{}/{:%Y%m%d}/delivery/{}.json".format(Websitecode,datetime.datetime.now(),str(inputid)+'_'+str(Rtdate)+'_'+id_update)
        key = bucket.new_key(keyvalue)
        key.set_contents_from_string(json.dumps(array))
        return json.dumps(array)
        gc.collect()
    except Exception as e:
        value_error=str(re.sub(r"'",'"',str(e)))
        stacktrace=sys.exc_traceback.tb_lineno
        insert_value_error=str(value_error)+'Where line number '+str(stacktrace)+' - '+str(proxyip)
        print insert_value_error
        statuscode='4'
        keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(Websitecode,datetime.datetime.now(),id_update)
        key = bucket.new_key(keyvalue)
        key.set_contents_from_string(insert_value_error)
        Guests='1'
        array.append(aws_insert.insert(id_update, inputid ,"",Websitecode, "", "", "", "", Guests, "", "", "", "", "",url,url,url, "", "", "", "", "", "",StartDate, EndDate , "", "", "", "", "",  "", "", "","",region,statuscode, israteperstay))
        return json.dumps(array)
# fetchrates(url ,inputid, id_update, proxyip)
