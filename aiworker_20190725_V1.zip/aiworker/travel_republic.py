# -*- coding: utf-8 -*-
import re
import requests
import datetime
import json
import uuid
import boto
import sys
import gc
import traceback
from unidecode import unidecode

import aws_insert


def fetchrates(url,inputid,id_update,proxyip):
    array      = []
    sr         = requests.session()
    proxies    = {"http": "http://{}".format(proxyip)}
#     proxies    = {"http": "http://media:M3diAproxy@%s"% proxyip}
    intime     = re.sub(r'\s','T',str(datetime.datetime.now()))
    Domainname = 'TRAVELREPUBLIC'
    Websitecode= '328'
    region     = ''
    statuscode = ''
    Mealtype   = ''
    stacktrace = 'traceback not imported'
    israteperstay = ''
    try:
        conn   = boto.connect_s3(aws_access_key_id= 'AKIAIXEGZVXCWE2FV3SQ',aws_secret_access_key = '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') 
        bucket = conn.get_bucket("rmapi")
        StartDate = datetime.date.today()
        EndDate   = datetime.date.today() + datetime.timedelta(days=29)
        CheckIn_Check_OT_re = re.search(r'chkin=(.*?)&chkout=(.*?)&',url)
        if CheckIn_Check_OT_re:
            Checkin  = CheckIn_Check_OT_re.group(1)
            Checkout = CheckIn_Check_OT_re.group(2)
        else:
            Checkin  = ''
            Checkout = ''
        #print Checkin,Checkout
#         #print url
        RateDate = Checkin
        delta    = datetime.datetime.strptime(Checkout, "%Y-%m-%d") - datetime.datetime.strptime(Checkin, "%Y-%m-%d")
        LOS      = delta.days
        RoomType = ''
        Guests   = re.search(r'adults=(\d+)', url).group(1)
        #print Guests,LOS
        Ratetype = ''
        RateDescription = ''
        Taxtype  = ''
        Curr     = ''
        MaxOccupancy = None
        isPromotionalRate  = 'N'
        Closed   = 'Y'
        NetRate  = 0
        Taxstatus= -1
        TaxAmount= 0
        Discount = 0
        GrossRate= 0
        OnsiteRate = 0
        Curr     = ''
        Promotion_Name= ''
        isAvailable = ''
        RoomAmenity_Type = ''
        
        url_insert = re.sub(r"#hotelid.*",'',url)
        ids_re   = re.search(r'hotelid=(.*?)&destid=(.*?)#', url)
        HotelId  = ids_re.group(1)
        DestinId = ids_re.group(2)
        CurrencyCode = re.search(r'curr=(.*?)#', url).group(1)
        Curr         = CurrencyCode
        curr_lst = ['USD','GBP','EUR']
        Tid = uuid.uuid4()
        if CurrencyCode not in curr_lst:
            Closed    = 'Y'
            statuscode = 8
            Guests = ''
            array.append(aws_insert.insert(id_update, inputid , Domainname, Websitecode, "", "", "", "", Guests, "", "", "", "", "", url_insert, url_insert, url_insert, "", "", "", "", "", "", StartDate, EndDate , "", "", "", "", "", "", "", "", "", region, statuscode, israteperstay))
            return json.dumps(array)
        
        ip = re.sub(r"\{'.*?@|'\}|:\d+", "", str(proxies))
        try:
            try:
                r = requests.get('http://freegeoip.net/json/' + ip, timeout=30)
            except Exception, e:
                r = requests.get('http://freegeoip.net/json/' + ip, timeout=30)
            js = r.json()
            region = js['country_name']
        except Exception, e:
            region = ''
        url = 'https://www.travelrepublic.co.uk/api/hotels/availability/createsearch'
        sec_url = 'https://www.travelrepublic.co.uk/api/hotels/availability/gethotel'
        payload = {"CultureCode":"en-gb","DomainId":1,"CurrencyCode":CurrencyCode,"Paging":{"Index":0,"Size":8},"IncludeAggregates":'true',"AvailabilitySearchId":'false',"TripId":str(Tid),"Rooms":[{"ChildAges":[],"Adults":Guests}],"CheckInDate":Checkin+"T00:00:00.000Z","CheckOutDate":Checkout+"T00:00:00.000Z","SearchArea":'null',"SortCriterion":1,"Destination":{"Id":DestinId,"Type":2}}
        head =  {'User-Agent':'Mozilla/5.0 (X11; Linux i686; rv:40.0) Gecko/20100101 Firefox/40.0', 'Host': 'www.travelrepublic.co.uk', 'Referer' : 'https://www.travelrepublic.co.uk/v2/hotels/'+str(Tid)+'/'+str(HotelId), 'x-callback': '8', 'x-timer' : '1502945379740'}
        try:
            hml1 = sr.post(url, json = payload, headers=head, proxies = proxies, verify = False)
        except:
            hml1 = sr.post(url, json = payload, headers=head, verify = False)
        #get Available search id
        Avbid =  str(hml1.json())
        #print Avbid
        payload1 = {"Id":HotelId,"AvailabilitySearchId":Avbid,"CultureCode":"en-gb","CurrencyCode":CurrencyCode,"DomainId":1,"BoardTypesFilter":[],"FieldFlags":'2873311',"DiscountCode":'null',"TripId":str(Tid)}
        try:
            htm = sr.post(sec_url, json = payload1, headers=head, proxies = proxies,timeout=100)
        except Exception, e:
            value_error = str(re.sub("'", '', str(e)))
            stacktrace = sys.exc_traceback.tb_lineno
            
            try:
                htm = sr.post(sec_url, json = payload1, headers=head, proxies = proxies,timeout=120)
                #print htm.status_code
            except Exception, e:
                try:
                    htm = sr.post(sec_url, json = payload1, headers=head, proxies = proxies,timeout=150)
                except Exception, e:
                    value_error = str(re.sub("'", '', str(e)))
                    stacktrace = sys.exc_traceback.tb_lineno
                    keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(Websitecode, datetime.datetime.now(), id_update)
                    key = bucket.new_key(keyvalue)
                    key.set_contents_from_string(str(e) + 'Where Line number' + str(stacktrace) + str(proxies))
                    statuscode = 5
                    Guests = ''
                    array.append(aws_insert.insert(id_update, inputid , Domainname, Websitecode, "", "", "", "", Guests, "", "", "", "", "", url, url, url, "", "", "", "", "", "", StartDate, EndDate , "", "", "", "", "", "", "", "", "", region, statuscode, israteperstay))
                    return json.dumps(array)
        if htm.status_code <> 200:
            htm = sr.post(sec_url, json = payload1, headers=head, proxies = proxies)
        if (htm.status_code == 403 or htm.status_code == 407) or htm.status_code <> 200:
            try:
                if htm.status_code <> 200:
                    htm = sr.post(sec_url, json = payload1, headers=head)
            except Exception, e:
                Closed    = 'Y'
                value_error = str(re.sub("'", '', str(e)))
                stacktrace = sys.exc_traceback.tb_lineno
                keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(Websitecode, datetime.datetime.now(), id_update)
                key = bucket.new_key(keyvalue)
                key.set_contents_from_string(str(e) + 'Where Line number' + str(stacktrace) + str(proxies))
                statuscode = 5
                Guests = ''
                array.append(aws_insert.insert(id_update, inputid , Domainname, Websitecode, "", "", "", "", Guests, "", "", "", "", "", url, url, url, "", "", "", "", "", "", StartDate, EndDate , "", "", "", "", "", "", "", "", "", region, statuscode, israteperstay))
                return json.dumps(array)
        html1 = unidecode(htm.text).encode('ascii')
        html  = json.loads(html1)
        keyvalue = "ondemand/{}/{:%Y%m%d}/source/{}.json".format(Websitecode,datetime.datetime.now(),str(inputid)+'_'+str(Checkin)+'_'+id_update)
        key = bucket.new_key(keyvalue)
        key.set_contents_from_string(json.dumps(html))
        if 'RequestedRooms' in html:
            for Block in  html['RequestedRooms']:
                if 'Availability' in Block:
                    for Block1 in Block['Availability']:
                        RoomType = ''
                        RoomType = Block1['RoomDescription']
                        for Rate_block in Block1['BoardOptions']:
                            Ratetype   = ''
                            GrossRate  = 0
                            OnsiteRate = 0
                            NetRate    = 0
                            MaxOccupancy = None
                            isPromotionalRate = 'N'
                            RoomAmenity_Type  = ''
                            RateDescription   = ''
                            Taxtype  = ''
                            Promotion_Name = ''
                            if 'BoardDescription' in Rate_block:
                                Ratetype = Rate_block['BoardDescription']
                            else:
                                Ratetype = ''
                            if 'Cost' in Rate_block:
                                OnsiteRate = round(Rate_block['Cost'],2)
                            else:
                                OnsiteRate = 0
                            GrossRate = OnsiteRate
                            if 'OriginalCost' in Rate_block:
                                NetRate = round(Rate_block['OriginalCost'],2)
    #                             NetRate = round(NetRate)
                                if NetRate != 0:
                                    isPromotionalRate  = 'Y'
                                else:
                                    isPromotionalRate  = 'N'
                                    NetRate = 0
                            if 'NonRefundable' in Rate_block:
                                check = Rate_block['NonRefundable']
                                check = str(check)
                                if 'True' in check:
                                    Ratetype = Ratetype + ' NonRefundable'
                                else:
                                    Ratetype = Ratetype + ' Flexible'
                            if 'QuantityAvailable' in Block1:
                                isAvailable  = Block1['QuantityAvailable']
                            if 'SpecialOfferText' in Rate_block:
                                Promotion_Name = Rate_block['SpecialOfferText']
                                isPromotionalRate = 'Y'
                            Masterid = Block1['MasterId']
                            Des_block = html['RoomDetails']
                            for descr in Des_block:
                                if str(Masterid) in str(descr['MasterId']):
                                    if 'Description' in descr:
                                        RateDescription = re.sub(r"<.*?>"," ",re.sub(r"'|</strong>|&nbsp;",'',descr['Description'])).strip()
                                        if 'Services' in str(RateDescription):
                                            des         = re.search(r'(.*?)Services', RateDescription, re.DOTALL).group(1)
                                            RateDescription = re.sub(r"\s\s+",'',des)
                                    else:
                                        RateDescription = ''
                            Mealtypes = str(RateDescription)+' '+str(RoomAmenity_Type)+' '+str(RoomType)+''+str(Ratetype)
                            if Mealtypes !=None:
                                Mealtype_str = str(Mealtypes)
                                if 'breakfast' in Mealtype_str.lower() and 'dinner' in Mealtype_str.lower()  and 'lunch' in Mealtype_str.lower():
                                    Meal = 'Breakfast, Lunch and Dinner'
                                elif 'breakfast' in Mealtype_str.lower() and 'dinner' in Mealtype_str.lower():
                                    Meal = 'Breakfast and dinner'
                                elif 'breakfast included' in Mealtype_str.lower():
                                    Meal = 'Breakfast included'
                                elif 'BREAKFAST' in Mealtype_str:
                                    Meal = 'Breakfast'
                                elif 'breakfast' in Mealtype_str.lower() and 'lunch' in Mealtype_str.lower():
                                    Meal = 'Breakfast and Lunch'
                                elif 'Lunch' in Mealtype_str and 'Dinner' in Mealtype_str :
                                    Meal = "Lunch and Dinner"
                                elif 'breakfast' in Mealtype_str.lower() and 'lunch' in Mealtype_str.lower() and 'dinner' in Mealtype_str.lower():
                                    Meal = 'Breakfast, Lunch and dinner'
                                elif 'Break fast' in Mealtype_str:
                                    Meal = 'BreakFast' 
                                elif 'breakfast' in Mealtype_str.lower():
                                    Meal = 'BreakFast' 
                                elif 'halfboard' in Mealtype_str.lower():
                                    Meal = 'Halfboard'
                                elif 'half board' in Mealtype_str.lower():
                                    Meal = 'Half board' 
                                elif 'full board' in Mealtype_str.lower():
                                    Meal = 'Full Board'
                                elif 'fullboard' in Mealtype_str.lower():
                                    Meal = 'FullBoard'
                                elif 'All-Inclusive' in Mealtype_str:
                                    Meal = 'All-Inclusive'
                                elif 'All Inclusive' in Mealtype_str:
                                    Meal = 'All Inclusive'
                                elif 'All Meals' in Mealtype_str:
                                    Meal = 'All Meals'
                                elif 'All Meal' in Mealtype_str:
                                    Meal = 'All Meal'
                                else:
                                    Meal = ''
                            else:
                                Meal = ''    
                            Mealtype = Meal
                            if OnsiteRate==0:
                                statuscode = 1
                                Closed='Y'
                            else:
                                statuscode = ''
                                Closed='N'
                            israteperstay = 'Y'
#                             #print 'RoomType           :',RoomType
#                             #print 'RateType           :',Ratetype
#                             #print 'Onsiterate         :',OnsiteRate
#                             #print 'NetRate            :',NetRate
#                             #print "isAvailable        :",isAvailable
#                             #print "deescription       :",RateDescription
#                             #print "isPromotionalRate  :",isPromotionalRate
#                             #print "Promotion_Name     :",Promotion_Name
#                             #print "Mealtype           :",Mealtype
#                             #print 'Curr_code          :',Curr
#                             #print "************************************"
                            #print (id_update, inputid , Domainname, Websitecode, StartDate, RoomType, LOS, RateDate, Guests, OnsiteRate, NetRate, GrossRate, Curr, RateDescription, url_insert, url_insert, url_insert, RoomAmenity_Type, Mealtype, MaxOccupancy, isPromotionalRate, Closed, 30, StartDate , EndDate, intime, isAvailable, Taxtype, TaxAmount, Taxstatus, None, Ratetype, Discount,Promotion_Name,region,statuscode, israteperstay)
                            array.append(aws_insert.insert(id_update, inputid , Domainname, Websitecode, StartDate, RoomType, LOS, RateDate, Guests, OnsiteRate, NetRate, GrossRate, Curr, RateDescription, url_insert, url_insert, url_insert, RoomAmenity_Type, Mealtype, MaxOccupancy, isPromotionalRate, Closed, 30, StartDate , EndDate, intime, isAvailable, Taxtype, TaxAmount, Taxstatus, None, Ratetype, Discount,Promotion_Name,region,statuscode, israteperstay))
                else:
                    Closed     = 'Y'
                    statuscode = '2'
                    Taxstatus  =  0
                    array.append(aws_insert.insert(id_update, inputid , Domainname, Websitecode, StartDate, RoomType, LOS, RateDate, Guests, OnsiteRate, NetRate, GrossRate, Curr, RateDescription, url_insert, url_insert, url_insert, RoomAmenity_Type, Mealtype, MaxOccupancy, isPromotionalRate, Closed, 30, StartDate , EndDate, intime, isAvailable, Taxtype, TaxAmount, Taxstatus, None, Ratetype, Discount,Promotion_Name,region,statuscode, israteperstay))
        else:
            Closed     = 'Y'
            statuscode = '2'
            Taxstatus  =  0
            array.append(aws_insert.insert(id_update, inputid , Domainname, Websitecode, StartDate, RoomType, LOS, RateDate, Guests, OnsiteRate, NetRate, GrossRate, Curr, RateDescription, url_insert, url_insert, url_insert, RoomAmenity_Type, Mealtype, MaxOccupancy, isPromotionalRate, Closed, 30, StartDate , EndDate, intime, isAvailable, Taxtype, TaxAmount, Taxstatus, None, Ratetype, Discount,Promotion_Name,region,statuscode, israteperstay))
        keyvalue = "ondemand/{}/{:%Y%m%d}/delivery/{}.json".format(Websitecode,datetime.datetime.now(),str(inputid)+'_'+str(RateDate)+'_'+id_update)
        key = bucket.new_key(keyvalue)
        key.set_contents_from_string(json.dumps(array))
        return json.dumps(array)
        gc.collect()
    except Exception as e:
        value_error = str(re.sub(r"'", '"', str(e)))
        stacktrace = sys.exc_traceback.tb_lineno
        #print value_error    ,    stacktrace
        Guests = ''
        region = ''
        statuscode = '4'
        array.append(aws_insert.insert(id_update, inputid , Domainname, Websitecode, "", "", "", "", Guests, "", "", "", "", "", url, url, url, "", "", "", "", "", "", StartDate, EndDate , "", "", "", "", "", "", "", "", "", region, statuscode, israteperstay))
        keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.json".format(Websitecode,datetime.datetime.now(),id_update)
        key = bucket.new_key(keyvalue)
        key.set_contents_from_string(json.dumps(value_error))
        return json.dumps(array)  
