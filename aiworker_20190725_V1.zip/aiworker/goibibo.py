# -*- coding: utf-8 -*-
import re
import requests
import datetime
import json
import sys 
import boto
import gc
import aws_insert
import random

# url       = 'https://www.goibibo.com/hotels/oyo-9417-seaside-residency-hotel-in-alleppey-7886723872215902387/?hquery=%7B%22ci%22%3A%222018-11-26%22%2C%22co%22%3A%222018-11-27%22%2C%22r%22%3A%221-1_0%22%2C%22ibp%22%3A%22na%22%7D|31335703284729576'
# inputid   = ''
# id_update = ''
# proxyip   = 'media:M3diAproxy@170.130.162.98:80'
# proxyip   = 'user-23300:97c98f461884720d@43.241.44.135:1212'


def fetchrates(url ,inputid, id_update, proxyip):
	array         = []
	israteperstay = ''
	intime		  = re.sub(r'\s','T',str(datetime.datetime.now()))
	region		  =''
	Websitecode   = 7
	conn   = boto.connect_s3(aws_access_key_id= 'AKIAIXEGZVXCWE2FV3SQ',aws_secret_access_key = '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') 
	bucket = conn.get_bucket("rmapi")
	StartDate= datetime.date.today()
	EndDate  = datetime.date.today() + datetime.timedelta(days=29)
	try:
		proxies      = {"https": "http://{}".format(proxyip)}	
		Domainname   = 'Goibibo'
		RoomType 	 = ""
		Ratetype	 = ''
		OnsiteRate   = 0
		Closed_up 	 = 'N'
		Netrate		 = 0
		Tax_status	 = ""
		Isprom		 = 'N'
		isAvailable	 =''
		Curr		 ='INR'
		MaxOccupancy = ''
		statuscode   = ''
		promotion    = ''
		url_details	 = ''
		MealInclusion_Type= ""
		RateDescription   = ""
		RoomAmenity_Type  = ""
		Guests_rre = re.search(r'1-(\d+)_0%22%',url)
		if Guests_rre:
			Guests = Guests_rre.group(1)
		else:
			Guests = ''
		if re.search(r"hquery=.*?A%22(.*?)%22", url):
			checkin = re.search(r"hquery=.*?A%22(.*?)%22", url).group(1)
			RateDate = checkin
			checkout = re.search(r"hquery=.*?A%22(.*?)%22.*?3A%22(.*?)%22", url).group(2)
			checkin_date = datetime.datetime.strptime(checkin,'%Y-%m-%d').strftime('%Y%m%d')
			checkout_date = datetime.datetime.strptime(checkout,'%Y-%m-%d').strftime('%Y%m%d')
		delta = datetime.datetime.strptime(re.search(r"hquery=.*?A%22(.*?)%22.*?3A%22(.*?)%22", url).group(2), "%Y-%m-%d") - datetime.datetime.strptime(re.search(r"hquery=.*?A%22(.*?)%22", url).group(1), "%Y-%m-%d")
		LOS   = delta.days    
		url_rep  = re.sub(checkin,checkin_date,url)
		url_rep2 = re.sub(checkout,checkout_date,url_rep)
		db_insert= re.sub(r'\\|\|\d+','',url_rep2)
		if re.search(r"(\d+.*?)/hquery=", url):
			urlvhid = re.search(r"(\d+.*?)/hquery=", url).group(1)
		elif re.search(r'hc=(.*?)&', url):
			urlvhid = re.search(r'hc=(.*?)&', url).group(1)
		elif re.search(r'-(\d\d\d\d\d.*?\d)/\?', url):
			urlvhid = re.search(r'-(\d\d\d\d\d.*?\d)/\?', url).group(1)
		elif re.search(r'\w-(\d.*?\d)/h',url):
			urlvhid=re.search(r'\w-(\d.*?\d)/h',url).group(1)
		else:
			urlvhid = ''   
# 		print "urlvhid",urlvhid
		
		if re.search(r'\|(.*?)$',url):
			Hotels = re.search(r'\|(.*?)$',url).group(1)
		elif re.search(r'hotels-(.*?)-',url):
			Hotels = re.search(r'hotels-(.*?)-',url).group(1)
		else:
			Hotels = ''
		if re.search(r"-(\d{8}-\d{8})-",url):
			datefromto =re.search(r"-(\d{8}-\d{8})-",url).group(1)
		elif re.search(r"%22(\d{8}.*?\d{8})%22",url):
			datefromto =re.search(r"%22(\d{8}.*?\d{8})%22",url).group(1)
			date_fromto =re.search(r"(?sim)^\d{8}(%22.*?)\d{8}$",datefromto).group(1)
			datefromto = re.sub(date_fromto,"-",datefromto)
		elif re.search(r'ci.*?"(\d{8}.*?\d{8})"',url):
			datefromto =re.search(r'ci.*?"(\d{8}.*?\d{8})"',url).group(1)
			date_fromto =re.search(r"(?sim)^\d{8}(.*?)\d{8}$",datefromto).group(1)
			datefromto = re.sub(date_fromto,"-",datefromto)
		else:
			datefromto= (checkin_date)+'-'+str(checkout_date)
		url= db_insert
		inpl = ['user-37082:a7d2c0d3ace90f48@45.64.105.154:1212','user-37082:a7d2c0d3ace90f48@103.250.184.172:1212','user-37082:a7d2c0d3ace90f48@103.12.211.82:1212','user-37082:a7d2c0d3ace90f48@45.64.106.37:1212','user-37082:a7d2c0d3ace90f48@45.64.106.5:1212','user-37082:a7d2c0d3ace90f48@45.64.106.27:1212','user-37082:a7d2c0d3ace90f48@103.250.184.229:1212','user-37082:a7d2c0d3ace90f48@45.64.106.62:1212','user-37082:a7d2c0d3ace90f48@45.64.106.41:1212','user-37082:a7d2c0d3ace90f48@103.250.184.252:1212']
		ip = re.sub(r"\{'.*?@|'\}|:\d+","",str(proxies))
		try:
			try:
				r = requests.get('http://freegeoip.net/json/'+ip,timeout=30)
			except Exception,e:
				r = requests.get('http://freegeoip.net/json/'+ip,timeout=30)
			js = r.json()
			region=js['country_name']
		except Exception,e:
			region=''
		mainurl = re.sub(r'\|.*','',url) 
		#print mainurl
		
		jsonurl = "https://hermes.goibibo.com/hotels/v7/detail/price/v3/"+Hotels+'/'+re.sub("-", "/", datefromto)+'/1-'+str(Guests)+'-0/'+urlvhid+'?ibp=&im=true&slot=false'
		print jsonurl
		#headr1  = {'User-Agent':'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Ubuntu Chromium/63.0.3239.84 Chrome/63.0.3239.84 Safari/537.36'}
		headr1  = {'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/50.0.2661.102 Safari/537.36'}
		headr2  = {'Accept':'application/json, text/plain, */*','Accept-Encoding':'gzip, deflate, br','Accept-Language':'en-GB,en-US;q=0.9,en;q=0.8','Connection':'keep-alive','Host':'hermes.goibibo.com','Origin':'https://www.goibibo.com','Referer':str(mainurl),'User-Agent':'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Ubuntu Chromium/63.0.3239.84 Chrome/63.0.3239.84 Safari/537.36'}
		try:
			resp1   = requests.get(mainurl,headers=headr1,proxies=proxies, timeout=10)
			resp2   = requests.get(jsonurl,headers=headr2,proxies=proxies, timeout=10)
		except Exception,e:
			#print e, sys.exc_traceback.tb_lineno
			value_error=str(re.sub("'",'"',str(e)))
			value_error=str(e).encode('ascii','ignore')
			stacktrace=sys.exc_traceback.tb_lineno
			try:
				prox = random.choice(inpl)
				proxies      = {"https": "http://{}".format(prox)}
				resp1   = requests.get(mainurl,headers=headr1,proxies=proxies,timeout=15)
				resp2   = requests.get(jsonurl,headers=headr2,proxies=proxies,timeout=15)
			except Exception,e:
				try:
					prox = random.choice(inpl)
					proxies      = {"https": "http://{}".format(prox)}
					resp1   = requests.get(mainurl,headers=headr1,proxies=proxies,timeout=20)
					resp2   = requests.get(jsonurl,headers=headr2,proxies=proxies,timeout=20)
				except Exception,e:
					value_error=str(re.sub(r"'",'"',str(e)))
					stacktrace=sys.exc_traceback.tb_lineno
					insert_value_error=str(value_error)+' Where line number '+str(stacktrace)+' '+str(proxyip)
					##print str(value_error)+' Where line number '+str(stacktrace)+' '+str(proxyip)
					keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(Websitecode,datetime.datetime.now(),id_update)
					key = bucket.new_key(keyvalue)
					key.set_contents_from_string(insert_value_error)
					statuscode=5
					Guests1=re.search(r'1-(\d+)_0%22%',url)
					if Guests1:
						Guests=Guests1.group(1)
					else:
						Guests=''
					array.append(aws_insert.insert(id_update, inputid ,"",Websitecode, "", "", "", "", Guests, "", "", "", "", "",db_insert, db_insert, db_insert, "", "", "", "", "", "",StartDate, EndDate , "", "", "", "", "", "", "", "", "",region,statuscode, israteperstay))
					return json.dumps(array)
		if (resp2.status_code <> 200): 
			prox = random.choice(inpl)
			proxies      = {"https": "http://{}".format(prox)}
			resp1   = requests.get(mainurl,headers=headr1,proxies=proxies,timeout=10)
			resp2   = requests.get(jsonurl,headers=headr2,proxies=proxies,timeout=10)  
		if (resp2.status_code == 403 or resp2.status_code == 407):
			try:
				prox = random.choice(inpl)
				proxies      = {"https": "http://{}".format(prox)}
				resp1   = requests.get(mainurl,headers=headr1,proxies=proxies,timeout=10)
				resp2   = requests.get(jsonurl,headers=headr2,proxies=proxies,timeout=10)  
			except Exception,e:
				value_error=str(re.sub(r"'",'"',str(e)))
				stacktrace=sys.exc_traceback.tb_lineno
				insert_value_error=str(value_error)+' Where line number '+str(stacktrace)+' '+str(proxyip)
				##print str(value_error)+' Where line number '+str(stacktrace)+' '+str(proxyip)
				keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(Websitecode,datetime.datetime.now(),id_update)
				key = bucket.new_key(keyvalue)
				key.set_contents_from_string(insert_value_error)
				statuscode=5
				Guests1=re.search(r'1-(\d+)_0%22%',url)
				if Guests1:
					Guests=Guests1.group(1)
				else:
					Guests=''
				array.append(aws_insert.insert(id_update, inputid ,"",Websitecode, "", "", "", "", Guests, "", "", "", "", "",db_insert, db_insert, db_insert, "", "", "", "", "", "",StartDate, EndDate , "", "", "", "", "", "", "", "", "",region,statuscode, israteperstay))
				return json.dumps(array)
		
		html  = str(resp2.text.encode('utf-8'))+'response1::-'+str(resp1.text.encode('utf-8'))
		Rtdate= re.sub(r'-|\-','',str(RateDate))
		keyvalue = "ondemand/{}/{:%Y%m%d}/source/{}.json".format(Websitecode,datetime.datetime.now(),str(inputid)+'_'+str(Rtdate)+'_'+id_update)
		key      = bucket.new_key(keyvalue)
		key.set_contents_from_string(html)
		if 'Access Denied' in resp1.text:
			statuscode=9
			Guests1=re.search(r'1-(\d+)_0%22%',url)
			if Guests1:
				Guests=Guests1.group(1)
			else:
				Guests=''
			array.append(aws_insert.insert(id_update, inputid ,"",Websitecode, "", "", "", "", Guests, "", "", "", "", "",db_insert, db_insert, db_insert, "", "", "", "", "", "",StartDate, EndDate , "", "", "", "", "", "", "", "", "",region,statuscode, israteperstay))
			return json.dumps(array)
		try:
			jsonval2_re = re.search(r'{"room_info":(.*?}\]),"ch"', resp1.text.encode('ascii','ignore'))
			if jsonval2_re:
				jsonval2 = jsonval2_re.group(1)
			else:
				jsonval2 = "{}"
			#print jsonval2
			json_val2 = json.loads(jsonval2)
			json_val1 = json.loads(resp2.text.encode('ascii','ignore'))
		except Exception,e:
			value_error=str(re.sub("'",'"',str(e)))
			stacktrace=sys.exc_traceback.tb_lineno
			insert_value_error=str(value_error)+' Where line number '+str(stacktrace)+str(proxyip)+"And json url is"+str(url_details)
			#print insert_value_error
			keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(Websitecode,datetime.datetime.now(),id_update)
			key = bucket.new_key(keyvalue)
			key.set_contents_from_string(str(insert_value_error))
			statuscode='4'
			israteperstay = ''
			array.append(aws_insert.insert(id_update,inputid,"",Websitecode,StartDate,"","",RateDate,"","","","","","",db_insert,db_insert,db_insert,"","","","","Y","",StartDate,"","","","","","","","","","",region,4, israteperstay))			
			return json.dumps(array)
		try:
			Details   = {}
			json_val2 = json.loads(jsonval2)
			for detail in json_val2:
				Details[detail['type_code']]=detail
			if 'data' in json_val1:
				if json_val1['data']!=None:
					if json_val1['data']['reg']!=None:
						for block in json_val1['data']['reg']:
							Description1 = ''
							Max_Occ      = ''
							roomsize     = ''
							bedtype      = ''
							Amenits2     = ''
							if Details.has_key(block['rtc']):
								Details_BK = Details[block['rtc']]
								if 'description' in Details_BK:
									Description1 = Details_BK['description']
								else:
									Description1 = ''
								if 'max_occ' in Details_BK:
									print 'yes'
									Max_Occ = Details_BK['max_occ']
								else:
									Max_Occ = ''
								if 'roomsize' in Details_BK:
									roomsize = 'roomsize:'+str(Details_BK['roomsize'])
								else:
									roomsize = ''
								if 'bedtype' in Details_BK:
									bedtype = "bedtype:"+str(Details_BK['bedtype'])
								Amenits2 = json.dumps(Details_BK['facilities'])
							else:
								Description1 = ''
								Max_Occ      = ''
								roomsize     = ''
								bedtype      = ''
								Amenits2     = ''
							for block2 in block['rp_list']:
								Closed_up = 'N'
								if 'shrs' in block2:
									continue
								if 'rtn' in block2:
									Roomtype = block2['rtn']
								else:
									Roomtype = ''
								if 'cltxt' in block2:
									Ratetype = block2['cltxt']
								else:
									Ratetype = ''
								'''if 'cur' in block2:
									Curr = block2['cur']
								else:
									Curr = '''''
								Amenits1 = json.dumps(block2['am'])
								pricedatas = {}
								if 'occ_data' in block2:
									for pricedata in block2['occ_data']:
										pricedatas[pricedata['a']]=pricedata
									var = pricedatas[int(Guests)]['price_data'][0]
									if 'spr' in var:
										OnsiteRate=var['spr'] 
									else:
										OnsiteRate=var['tp'] 
									if 'opr' in var:
										Netrate = var['opr']
										if float(Netrate) > float(OnsiteRate):
											if Netrate:
												Isprom="Y"
											else:
												Isprom='N'
										else:
											Netrate = 0 
											Isprom='N'
									else:
										Netrate = 0
										Isprom='N'
								else:
									OnsiteRate = 0
									Netrate    = 0
									Isprom='N'
								Amenits     = re.sub(r'"\]\["','", "',str(Amenits1+Amenits2)).strip()
								Description = str(Description1)+' '+str(roomsize)+' '+str(bedtype)
								RoomType        = re.sub(r"'","''",str(Roomtype))
								Netrate         = re.sub(r"'","''",str(Netrate))
								RateDescriptio1 = re.sub(r"'","''",str(Description))
								Ratetype        = re.sub(r"'","''",str(Ratetype))
								RoomAmenity_Typ = re.sub(r"'","''",str(Amenits))
								MaxOccupancy    = re.sub(r"'","''",str(Max_Occ))
								RateDescription = re.sub(r"\s\s+", r"", re.sub(r"\s\s+",r"",re.sub(r"<.*?>",r' ',str(RateDescriptio1))))
								RoomAmenity_Type= re.sub(r"\[|\]", r"",re.sub(r"\[\]",r"",str(RoomAmenity_Typ)))
								if str(MaxOccupancy) == '0' or MaxOccupancy == 0:
									MaxOccupancy=''
								if 'breakfast' in str(Amenits1).lower():
									MealInclusion_Type = re.sub(r"\[|\]", r"",Amenits1)
								else:
									MealInclusion_Type = ''
								
								if str(OnsiteRate) == '0' or str(OnsiteRate) == '' or OnsiteRate==0:
									statuscode=1
									Closed_up='Y'
									Tax_status = '-1'
								else:
									statuscode=''
									Closed_up='N'
									Tax_status = '2'
								if LOS >1:
									israteperstay = 'N'
								else:
									israteperstay ='Y'
								if (Netrate == 0 or Netrate == ''):
									Isprom = 'N'
								print RoomType
								array.append(aws_insert.insert(id_update, inputid , Domainname, Websitecode, StartDate, RoomType, LOS, RateDate, Guests, OnsiteRate, Netrate, OnsiteRate, Curr, RateDescription, db_insert, db_insert, db_insert, RoomAmenity_Type, MealInclusion_Type, MaxOccupancy, Isprom, Closed_up, 30, StartDate , EndDate, intime, isAvailable, None, None, Tax_status, None, Ratetype, Netrate,promotion,region,statuscode, israteperstay))
					else:
						##print "No Rooms Available"
						Closed_up   = "Y"    
						Websitecode = '7'
						statuscode  = '2'
						array.append(aws_insert.insert(id_update, inputid , Domainname, Websitecode, StartDate, RoomType, LOS, RateDate, Guests, OnsiteRate, Netrate, OnsiteRate, Curr, RateDescription, db_insert, db_insert, db_insert, RoomAmenity_Type, MealInclusion_Type, MaxOccupancy, Isprom, Closed_up, 30, StartDate , EndDate, intime, isAvailable, None, None, Tax_status, None, Ratetype, Netrate,promotion,region,statuscode, israteperstay))
				else:
					##print "No Rooms Available"
					Closed_up   = "Y"    
					Websitecode = '7'
					statuscode  = '2'
					array.append(aws_insert.insert(id_update, inputid , Domainname, Websitecode, StartDate, RoomType, LOS, RateDate, Guests, OnsiteRate, Netrate, OnsiteRate, Curr, RateDescription, db_insert, db_insert, db_insert, RoomAmenity_Type, MealInclusion_Type, MaxOccupancy, Isprom, Closed_up, 30, StartDate , EndDate, intime, isAvailable, None, None, Tax_status, None, Ratetype, Netrate,promotion,region,statuscode, israteperstay))
			else:
				##print "No Rooms Available"
				Closed_up   = "Y"    
				Websitecode = '7'
				statuscode  = '2'
				array.append(aws_insert.insert(id_update, inputid , Domainname, Websitecode, StartDate, RoomType, LOS, RateDate, Guests, OnsiteRate, Netrate, OnsiteRate, Curr, RateDescription, db_insert, db_insert, db_insert, RoomAmenity_Type, MealInclusion_Type, MaxOccupancy, Isprom, Closed_up, 30, StartDate , EndDate, intime, isAvailable, None, None, Tax_status, None, Ratetype, Netrate,promotion,region,statuscode, israteperstay))
		except Exception,e:
			print e
			value_error=str(re.sub("'",'"',str(e)))
			stacktrace=sys.exc_traceback.tb_lineno
			print stacktrace
			insert_value_error=str(value_error)+' Where line number '+str(stacktrace)+str(proxyip)+"And json url is"+str(url_details)
			#print insert_value_error
			keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(Websitecode,datetime.datetime.now(),id_update)
			key = bucket.new_key(keyvalue)
			key.set_contents_from_string(str(insert_value_error))
			statuscode='4'
			array.append(aws_insert.insert(id_update,inputid,"",Websitecode,StartDate,"","",RateDate,"","","","","","",db_insert,db_insert,db_insert,"","","","","Y","",StartDate,"","","","","","","","","","",region,4, israteperstay))
		keyvalue = "ondemand/{}/{:%Y%m%d}/delivery/{}.json".format(Websitecode,datetime.datetime.now(),str(inputid)+'_'+str(Rtdate)+'_'+id_update)
		key = bucket.new_key(keyvalue)
		key.set_contents_from_string(json.dumps(array))
		return json.dumps(array)
		gc.collect()
	except Exception as e:
		print e
		db_insert = url
		value_error=str(re.sub(r"'",'"',str(e)))
		stacktrace=sys.exc_traceback.tb_lineno
		print stacktrace
		insert_value_error=str(value_error)+' Where line number '+str(stacktrace)+str(proxyip)+"And json url is"+str(url_details)
		#print insert_value_error
		statuscode='4'
		keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(Websitecode,datetime.datetime.now(),id_update)
		key = bucket.new_key(keyvalue)
		key.set_contents_from_string(insert_value_error)
		Guests1=re.search(r'1-(\d+)_0%22%',url)
		if Guests1:
			Guests=Guests1.group(1)
		else:
			Guests=''
		array.append(aws_insert.insert(id_update, inputid ,"",Websitecode, insert_value_error, "", "", "", Guests, "", "", "", "", "",db_insert, db_insert, db_insert, "", "", "", "", "", "",StartDate, EndDate , "", "", "", "", "","", "", "", "",region,statuscode, israteperstay))
		return json.dumps(array)


# fetchrates(url, inputid, id_update, proxyip)
