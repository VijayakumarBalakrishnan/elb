# -*- coding: utf-8 -*-
import re
import requests
import datetime
import json
import sys 
import boto
import gc

import traceback
import aws_insert

'''url= 'http://secure3.hilton.com/en_US/es/reservation/book.htm?check-in_date=22&check-in_month=09/2017&check-out_date=23&inputModule=HOTEL_SEARCH&fromId=HOUGPHF-WEB&DateHidden=&DateHidden=&DateType=&IntiCI=&IntiCO=&hotel=HOUGPHF&adId=ThayerHOUGPHF&arrivalDay=22&arrivalMonth=09&arrivalYear=2017&departureDay=23&departureMonth=09&departureYear=2017&#chkin=2017-09-22&chkout=2017-09-23&'
inputid= 'HIL'
id_update= ''
proxyip = '195.155.97.244:8080'
'''
def fetchrates(url,inputid,id_update,proxyip):
    sr1 = False
    array = []
    intime=re.sub(r'\s','T',str(datetime.datetime.now()))
    functionname='Hilton'
    israteperstay = ''
    try:
        conn = boto.connect_s3(aws_access_key_id= 'AKIAIXEGZVXCWE2FV3SQ',aws_secret_access_key = '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') 
        bucket = conn.get_bucket("rmapi")
        StartDate = datetime.date.today()
        EndDate  = datetime.date.today() + datetime.timedelta(days=29)                
        Domainname="Hilton.com"
        Websitecode = '83'
        functionname=Domainname
        Roomtype = ""
        Ratetype=''
        Guests = 1
        OnsiteRate = 0
        Closed_up = 'N'
        MealInclusion_Type = ""
        RoomDescp = ""
        RoomAmenityType = ""
        NetRate=0
        Curr=''
        Roomavilable=''
        promotion=''
        Maxocp=''
        ispromupdate = 'N'
        LOS = 1
        Taxtype = ''
        Taxamount = ''
        Tax_status = ''
        Spaceblock = ''
        discount_rate = ''
        statuscode = ''
        israteperstay = ''
        region = ''
        chk_re=re.search(r'#chkin=(.*?)&chkout=(.*?)&',url)
        if chk_re:
            chkin=chk_re.group(1)
            chkout=chk_re.group(2)
        
        checkin1=datetime.datetime.strptime(chkin,str('%Y-%m-%d')).strftime('%d')
        checkin2=datetime.datetime.strptime(chkin,str('%Y-%m-%d')).strftime('%m')
        checkin3=datetime.datetime.strptime(chkin,str('%Y-%m-%d')).strftime('%Y')
        checkout1=datetime.datetime.strptime(chkout,str('%Y-%m-%d')).strftime('%d')
        checkout2=datetime.datetime.strptime(chkout,str('%Y-%m-%d')).strftime('%m')
        checkout3=datetime.datetime.strptime(chkout,str('%Y-%m-%d')).strftime('%Y')
        url_strip=re.sub(r'#chkin=.*?&chkout.*?&','',url)
        Date_func='arrivalDay='+checkin1+'&arrivalMonth='+checkin2+'&arrivalYear='+checkin3+'&departureDay='+checkout1+'&departureMonth='+checkout2+'&departureYear='+checkout3+'&'
        url=re.sub(r'arrivalDay=.*?&arrivalMonth=.*?&arrivalYear=.*?&departureDay=.*?&departureMonth=.*?&departureYear=.*?&',Date_func,url_strip)
        #print url
        keyvalue = "ondemand/{}/{:%Y%m%d}/source/{}-url.txt".format(Websitecode,datetime.datetime.now(),id_update)
        #print keyvalue
        key = bucket.new_key(keyvalue)
        key.set_contents_from_string(url)

        if sr1:
            sr.keep_alive = False
        sr = requests.Session()
        url_clean = re.search('&(arrivalDay=.*?&arrivalMonth=.*?&arrivalYear=.*?)&',url)
        if url_clean:
            rate_date = url_clean.group(1)
            RateDate = datetime.datetime.strptime(str(rate_date),'arrivalDay=%d&arrivalMonth=%m&arrivalYear=%Y').strftime('%Y-%m-%d')

        proxies = {"http": "http://{}".format(proxyip)}
        
        head = {'Host':'secure3.hilton.com','Connection':'keep-alive','Cache-Control':'max-age=0','Upgrade-Insecure-Requests':'1','User-Agent':'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36'}
        try:    
            htm = sr.get(url, headers=head,timeout=50)
            ##print htm.status_code
        except Exception,e:
            print e
            value_error=str(re.sub("'",'"',str(e)))
            stacktrace=sys.exc_traceback.tb_lineno
            try:
                htm = sr.get(url, headers=head,proxies=proxies,verify = False,timeout=50)
                #print htm.status_code
            except Exception,e:
                value_error=str(e)
                #print value_error
                stacktrace=sys.exc_traceback.tb_lineno
                keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(Websitecode,datetime.datetime.now(),id_update)
                #print keyvalue
                key = bucket.new_key(keyvalue)
                key.set_contents_from_string(str(e))
                statuscode=5
                Guests='1'
                array.append(aws_insert.insert(id_update, inputid ,functionname,Websitecode, "", "", "", "", Guests, "", "", "", "", "",url, url, url, "", "", "", "", "", "",StartDate, EndDate , "", "", "", "", "",  "", "", "","", "",statuscode, israteperstay))
                return json.dumps(array)
        if (htm.status_code <> 200):
            htm = sr.get(url, headers=head,proxies=proxies,verify = False)
        if (htm.status_code == 403 or htm.status_code == 407):
            try:
                proxyresult = requests.get('http://www.gimmeproxy.com/api/getProxy?protocol=http')
                jproxy  = json.loads(proxyresult.content)
                proxies = { "http": jproxy["curl"] }
                htm = requests.get(url, headers=head,proxies=proxies,verify = False)
                if htm.status_code <> 200:
                    htm = requests.get(url, headers=head,verify = False)
            except Exception,e:
                value_error=str(e)
                #print value_error
                stacktrace=sys.exc_traceback.tb_lineno
                keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(Websitecode,datetime.datetime.now(),id_update)
                #print keyvalue
                key = bucket.new_key(keyvalue)
                key.set_contents_from_string(str(e))
                statuscode=5
                Guests='1'
                array.append(aws_insert.insert(id_update, inputid ,functionname,Websitecode, "", "", "", "", Guests, "", "", "", "", "",url, url, url, "", "", "", "", "", "",StartDate, EndDate , "", "", "", "", "",  "", "", "","", "",statuscode, israteperstay))
                return json.dumps(array)
        html = htm.text
        html = html.encode('ascii', 'ignore')
        #fo = open('apihilton.txt','w')
        #fo.write(str(html))
        keyvalue = "ondemand/{}/{:%Y%m%d}/source/{}.html".format(Websitecode,datetime.datetime.now(),str(inputid)+'_'+str(RateDate)+'_'+id_update)
        #print keyvalue
        key = bucket.new_key(keyvalue)
        key.set_contents_from_string(html)
        try:
            reg_blo = re.search(r'<div class="itemTitleAndDesc">.*?</form>\s*</div>\s*</li>\s*</ul>\s*</div>',html,re.DOTALL)
            if reg_blo:
                for block in re.compile(r'<div class="itemTitleAndDesc">.*?</form>\s*</div>\s*</li>\s*</ul>\s*</div>',re.DOTALL).findall(html):
                    roomtype_re = re.search(r'<h2>\s*<a.*?>(.*?)<',block,re.DOTALL)
                    if roomtype_re:
                        RoomType1 = roomtype_re.group(1)
                        Roomtype = re.sub("'","''",RoomType1)
                        #print"Room_Type   :",Roomtype
                    for block1 in re.compile(r'<div class="rate-desc-wrapper.*?</form>\s*</div>',re.DOTALL).findall(block):
                        HotelBlock = re.sub("'","''",block)
                        onsite_re = re.search(r'class="priceamount currencyCode-.*?">\s*.*?(\d+.*?)\s*<',block1)
                        if onsite_re:
                            onsite_1 = onsite_re.group(1)
                            OnsiteRate = re.sub('<.*?>|,','',str(onsite_1))
                            if OnsiteRate == None:
                                onsite_re = re.search(r'new-price">\s*<span.*?(\d.*?)\s*<',block1)
                            if onsite_re:
                                onsite_2 = onsite_re.group(1)
                                OnsiteRate = re.sub('<.*?>|,','',str(onsite_2))
                            else:
                                OnsiteRate = 0
                        else:
                            onsite_re = re.search(r'new-price">\s*<span.*?(\d.*?)\s*<',block1,re.DOTALL)
                            if onsite_re:
                                onsite_1 = onsite_re.group(1)
                                OnsiteRate = re.sub('<.*?>|,','',str(onsite_1))
                            else:
                                OnsiteRate = 0
                        GrossRate = OnsiteRate
                        #print "OnsiteRate",OnsiteRate
                        #print"Price       :",GrossRate
                        strik_re = re.search(r'<span.*?(\d.*?)</span>\s*</del>',block1)
                        if strik_re:
                            strikrat = strik_re.group(1)
                            NetRate = re.sub(',','',re.sub('<.*?>','',strikrat))
                            isPromotionalRate = 'Y'
                            #print"Strike       :",NetRate
                        else:
                            NetRate=0
                            isPromotionalRate = 'N'
                        if NetRate <> 0:
                            israteperstay = 'Y'
                        curr_re = re.search(r'class="priceamount currencyCode-(.*?)[\s|"]',block1,re.DOTALL)
                        if curr_re:
                            Currency = curr_re.group(1)
                        if "USD" in Currency:
                            Curr = "USD"
                        elif "AMD" in Currency:
                            Curr = "AMD"
                        elif "PLN" in Currency:
                            Curr = "PLN"
                        ##print"Currency   :",Curr
                        #if "USD" in Currency:
                        #    Curr = "USD"
                        ratetype_re = re.search(r'<span class="hidden">.*?</span>(.*?)rate type',block1)
                        if ratetype_re:
                            Ratetype1 = ratetype_re.group(1)
                            Ratetype = re.sub(r'<.*?>','',re.sub("'","''",Ratetype1))
                            #print"Rate_Type   :",Ratetype
                        if 'breakfast' in Ratetype.lower():
                            MealInclusion_Type = Ratetype
                            ##print"MealInclusion_Type   :",MealInclusion_Type
                        
                        #print id_update, inputid , Domainname, Websitecode, StartDate, Roomtype, LOS, RateDate, Guests, OnsiteRate, NetRate, OnsiteRate, Curr, RoomDescp, url, url, url, RoomAmenityType, MealInclusion_Type, Maxocp, ispromupdate, Closed_up, 30, StartDate , EndDate, intime, Roomavilable, Taxtype, Taxamount,  Spaceblock, Ratetype, discount_rate,promotion,statuscode, israteperstay
                        array.append(aws_insert.insert(id_update, inputid , Domainname, Websitecode, StartDate, Roomtype, LOS, RateDate, Guests, OnsiteRate, NetRate, OnsiteRate, Curr, RoomDescp, url, url, url, RoomAmenityType, MealInclusion_Type, Maxocp, ispromupdate, Closed_up, 30, StartDate , EndDate, intime, Roomavilable, None, None, Tax_status,  None, Ratetype, discount_rate,promotion,region, statuscode, israteperstay))
                        
            else:        
                nooroom = re.search(r'CrossSellErrorMessage.*?>(.*?)<br />',html)
                if nooroom:
                    NoBlock = nooroom.group(1)
                    HotelBlock = re.sub('<.*?>','',NoBlock)
                Closed_up = "Y"
                statuscode=2
                array.append(aws_insert.insert(id_update, inputid , Domainname, Websitecode, StartDate, Roomtype, LOS, RateDate, Guests, OnsiteRate, NetRate, OnsiteRate, Curr, RoomDescp, url, url, url, RoomAmenityType, MealInclusion_Type, Maxocp, ispromupdate, Closed_up, 30, StartDate , EndDate, intime, Roomavilable, None, None,  Tax_status, None, Ratetype, NetRate,promotion, region, statuscode, israteperstay))
        except Exception,e:
            value_error=str(e)
            stacktrace=sys.exc_traceback.tb_lineno
            keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(Websitecode,datetime.datetime.now(),id_update)
            #print keyvalue
            key = bucket.new_key(keyvalue)
            key.set_contents_from_string(str(e))
            statuscode=5
            Guests='1'
            array.append(aws_insert.insert(id_update, inputid ,functionname,Websitecode, "", "", "", "", Guests, "", "", "", "", "",url, url, url, "", "", "", "", "", "",StartDate, EndDate , "", "", "", "", "",  "", "", "", "", "",statuscode, israteperstay))
            return json.dumps(array)
        keyvalue = "ondemand/{}/{:%Y%m%d}/delivery/{}.json".format(Websitecode,datetime.datetime.now(),str(inputid)+'_'+str(RateDate)+'_'+id_update)
        key = bucket.new_key(keyvalue)
        key.set_contents_from_string(json.dumps(array))
        return json.dumps(array)
        gc.collect()
    except Exception,e:
        value_error=str(re.sub(r"'",'"',str(e)))
        stacktrace=sys.exc_traceback.tb_lineno
        insert_value_error=str(value_error)+'Where line number '+str(stacktrace)+str(proxyip)
        statuscode='4'
        Websitecode='83'
        keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(Websitecode,datetime.datetime.now(),id_update)
        key = bucket.new_key(keyvalue)
        key.set_contents_from_string(insert_value_error)
        Guests='1'
        array.append(aws_insert.insert(id_update, inputid ,functionname,Websitecode, "", "", "", "", Guests, "", "", "", "", "",url, url, url, "", "", "", "", "", "",StartDate, EndDate , "", "", "", "", "",  "", "", "", "", "",statuscode, israteperstay))
        return json.dumps(array)    
        
#fetchrates(url, inputid, id_update, proxyip)
