# -*- coding: utf-8 -*-
import re
import requests
import datetime
import json
import time 
import urllib2
import sys 
import boto
import random
import gc


def insert(Provider,Rank,RoomName,RoomFacilities,OnsiteRate,NetRate,Pricepernight,Curr,Ratedate,Los,Reportadate,Hotelcode,websitecode,url_db,HotelBlock,checkin_date,statuscode):
	global array
	json = {"hotelcode": Hotelcode,"rank":Rank,"pricepernight":Pricepernight,"provider":Provider,"los":Los, "websitecode": websitecode, "roomtype": RoomName, "onsiterate":OnsiteRate, "netrate":NetRate, "curr":Curr,"roomamenity":RoomFacilities,"url":url_db,"checkin":checkin_date,"statuscode":statuscode}
	return json


