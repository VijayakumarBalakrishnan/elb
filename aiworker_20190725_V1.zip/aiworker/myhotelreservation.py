# -*- coding: utf-8 -*-
import re
import requests
import datetime
import operator
import json
import sys 
import boto
import gc

import aws_insert


def fetchrates(url , inputid, id_update, proxyip):
    array = []
    intime = re.sub(r'\s', 'T', str(datetime.datetime.now()))
    functionname = 'aldrovandi.com'
    Websitecode = 375
    LastModified = intime
    israteperstay = ''
    try:
        conn = boto.connect_s3(aws_access_key_id='AKIAIXEGZVXCWE2FV3SQ', aws_secret_access_key='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') 
        bucket = conn.get_bucket("rmapi")
        StartDate = datetime.date.today()
        EndDate = datetime.date.today() + datetime.timedelta(days=29)
        Websitecode = 375
        Domainname = "aldrovandi.com"
        chkins = re.search(r'f=(.*?)&', url).group(1)
        chkouts = re.search(r't=(.*?)&', url).group(1)
        checkins = datetime.datetime.strptime(chkins, str("%Y-%m-%d")).strftime("%Y, %m, %d")
        checkouts = datetime.datetime.strptime(chkouts, str("%Y-%m-%d")).strftime("%Y, %m, %d")
        ccin = datetime.datetime.strptime(checkins, '%Y, %m, %d')
        ccout = datetime.datetime.strptime(checkouts, '%Y, %m, %d')
        LOS = ccout - ccin
        LOS = LOS.days
        RateDate = chkins
        head = {'User-Agent':'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:12.0) Gecko/20100101 Firefox/12.0'}
        proxies = {"http": "http://{}".format(proxyip)}
        region = ''
        ip = re.sub(r"\{'.*?@|'\}|:\d+", "", str(proxies))
        try:
            try:
                r = requests.get('http://freegeoip.net/json/' + ip, timeout=30)
            except Exception, e:
                r = requests.get('http://freegeoip.net/json/' + ip, timeout=30)
            js = r.json()
            region = js['country_name']
        except Exception, e:
            region = ''
        try:
            hml = requests.get(url,headers=head, proxies=proxies, timeout=100)
        except Exception, e:
            value_error = str(re.sub("'", '', str(e)))
            stacktrace = sys.exc_traceback.tb_lineno
            try:
                hml = requests.get(url,headers=head, proxies=proxies, timeout=120)
            except Exception, e:
                try:
                    hml = requests.get(url,headers=head, proxies=proxies, timeout=150) 
                except Exception, e:
                    value_error = str(re.sub("'", '', str(e)))
                    stacktrace = sys.exc_traceback.tb_lineno
                    keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(Websitecode, datetime.datetime.now(), id_update)
                    key = bucket.new_key(keyvalue)
                    key.set_contents_from_string(str(e) + 'Where Line number' + str(stacktrace) + str(proxies))
                    statuscode = 5
                    Guests = ''
                    array.append(aws_insert.insert(id_update, inputid , functionname, Websitecode, "", "", "", "", Guests, "", "", "", "", "", url, url, url, "", "", "", "", "", "", StartDate, EndDate , "", "", "", "", "", "", "", "", "", region, statuscode, israteperstay))
                    return json.dumps(array)
        if hml.status_code <> 200:
            hml = requests.get(url,headers=head, proxies=proxies)
        if (hml.status_code == 403 or hml.status_code == 407) or hml.status_code <> 200:
            try:
                if hml.status_code <> 200:
                    hml = requests.get(url,headers=head)
            except Exception, e:
                value_error = str(re.sub("'", '', str(e)))
                stacktrace = sys.exc_traceback.tb_lineno
                keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(Websitecode, datetime.datetime.now(), id_update)
                key = bucket.new_key(keyvalue)
                key.set_contents_from_string(str(e) + 'Where Line number' + str(stacktrace) + str(proxies))
                statuscode = 5
                Guests = ''
                array.append(aws_insert.insert(id_update, inputid , functionname, Websitecode, "", "", "", "", Guests, "", "", "", "", "", url, url, url, "", "", "", "", "", "", StartDate, EndDate , "", "", "", "", "", "", "", "", "", region, statuscode, israteperstay))
                return json.dumps(array)
        html = hml.text
        html = html.encode('ascii', 'ignore')
        Rtdate=re.sub(r'-|\-','',str(RateDate))
        Rtdate=re.sub(r'-|\-','',str(RateDate))
        keyvalue = "ondemand/{}/{:%Y%m%d}/source{}.html".format(Websitecode, datetime.datetime.now(), str(inputid) + '_' + str(Rtdate) + '_' + id_update)
        #print keyvalue
        key = bucket.new_key(keyvalue)
        key.set_contents_from_string(html)     
        Websitecode = Websitecode
        RoomType = ""
        Guests = ""
        Guests_reg = re.search(r'a=(.*?)&', url)
        if Guests_reg:
            Guests = Guests_reg.group(1)
        OnsiteRate = 0
        NetRate = 0
        Curr = ""
        RateDescription = ""
        RoomAmenity_Type = ""
        MealInclusion_Type = ""
        MaxOccupancy = None
        isPromotionalRate = "N"
        Closed_up = "Y"
        LastModified = LastModified
        isAvailable = ""
        Taxtype = ""
        TaxAmount = 0
        RateType = ""
        Promotion_Name = ""
        Tax_status = ''
        if re.compile('<div class="col-xs-\d+ col-sm-\d+">\s*<div class="abe-r-title">\s*(.*?)\s*</div>\s*</div>\s*</div>\s*</div>\s*</div>\s*</div>\s*</div>', re.DOTALL).findall(html):
            for block_first in re.compile('<div class="col-xs-\d+ col-sm-\d+">\s*<div class="abe-r-title">\s*(.*?)\s*</div>\s*</div>\s*</div>\s*</div>\s*</div>\s*</div>\s*</div>', re.DOTALL).findall(html):
                ##print block_first
                RoomType=""
                OnsiteRate=0
                NetRate=0
                Curr=""
                RateDescription=""
                RoomAmenity_Type=""
                MealInclusion_Type=""
                MaxOccupancy= None
                isPromotionalRate="N"
                Closed_up="N"
                isAvailable=""
                Taxtype=""
                TaxAmount=0
                RateType=""
                Promotion_Name=""
                statuscode = ''
                Roomtype_reg=re.search('<h4 class="abe-room-description">\s*(.*?)\s*</h4>',block_first)
                if Roomtype_reg:
                    Roomtype_reg1=Roomtype_reg.group(1)
                    Roomtype_reg2=re.sub(r"<.*?>","",Roomtype_reg1)
                    RoomType= re.sub(r"'","''",Roomtype_reg2)
                    #print "Roomtype:",RoomType
                descript=re.search('<div class="abe-rate-room-info-summary">\s*(.*?)\s*</div>',block_first,re.DOTALL)
                if descript:
                    RateDescription_1=descript.group(1).strip()
                    RateDescription_1 = re.sub("<td>[A-z][A-z][A-z]$","",RateDescription_1)
                    RateDescription_2 = re.sub("\$|<.*?>|amp;","",RateDescription_1)
                    RateDescription_3 = re.sub("'","''",RateDescription_2)
                    RateDescription = re.sub("\s+"," ",RateDescription_3)
                    #print "Descriptipon        :",RateDescription
                Avaible=re.search('<div class="abe-r-title">\s*<div class="pull-right abe-room-warning">\s*<div class="abe-room-warning">.*?only\s*(\d+)\s*room',block_first,re.DOTALL)
                if Avaible:
                    isAvailable_1=Avaible.group(1)
                    isAvailable_2=re.sub('<.*?>','',isAvailable_1)
                    isAvailable=re.sub('\s+',' ',isAvailable_2)
                    #print "isAvailable        :",isAvailable
                Ameints_re = re.search('Amenities:</strong>.*?<ul>\s*(.*?)\s*</ul>\s*</div>\s*</div>\s*<div class="abe-rate-room-info-summary">', block_first, re.DOTALL)
                if Ameints_re:
                    Amentes = Ameints_re.group(1)
                    click1 = re.sub(r'</li>', ', ', Amentes)
                    RoomAmenity_Type1 = re.sub('<.*?>|&amp;|\t+|\n', '', click1)
                    RoomAmenity_Type3 = re.sub('\s+', ' ', RoomAmenity_Type1)
                    RoomAmenity_Type2 = re.sub("'", "''", RoomAmenity_Type3).strip()
                    RoomAmenity_Type4 = re.sub('^\s|,$', '', RoomAmenity_Type2)
                    RoomAmenity_Type = RoomAmenity_Type4
                    #print RoomAmenity_Type
                curr_re = re.search('hotelCurrency":"(.*?)"',html)
                if curr_re:
                    Curr= curr_re.group(1)
                    #print"Currency   :",Curr
                i = 1
                for ratetype_block_reg in re.compile('<div class="col-xs-12 abe-room-rate">\s*(.*?)\s*</a>\s*</div>\s*</li>\s*</ul>\s*</div>\s*</div>\s*</div>\s*</div>\s*<div class="col-xs-12 abe-no-padding">', re.DOTALL).findall(block_first):
                    ratetype_block = ratetype_block_reg
                    if i == 2:
                        Old_OnsiteRate = ''
                        Old_RateType = ''
                        if re.compile('<div class="col-xs-12 col-sm-6 abe-room-header">\s*(.*?)\s*</div>\s*</div>\s*</div>\s*</div>\s*</div>\s*</div>', re.DOTALL).findall(ratetype_block):
                            for block_second in re.compile('<div class="col-xs-12 col-sm-6 abe-room-header">\s*(.*?)\s*</div>\s*</div>\s*</div>\s*</div>\s*</div>\s*</div>', re.DOTALL).findall(ratetype_block):
                                RateType = ''
                                OnsiteRate = 0
                                Meal = ''
                                Ratetype_reg=re.search('<div class="abe-r-title">\s*(.*?)\s*</div>',block_second)
                                if Ratetype_reg:
                                    Ratetype_reg1=Ratetype_reg.group(1)
                                    Ratetype_reg2=re.sub(r"<.*?>","",Ratetype_reg1)
                                    RateType= re.sub(r"'","''",Ratetype_reg2)
                                    #print "Ratetype:",RateType
                                old_price=re.search('<span class="abe-md-lg-pull-right">\s*<strong>\s*.*?(\d+.*?)\s*</strong>',block_second)
                                if old_price:
                                    price=old_price.group(1)
                                    OnsiteRate = re.sub("\$|,","",price)
                                    #print "OnsiteRate        :",OnsiteRate
                                Mealtype_str = str(RateType)
                                if 'breakfast' in Mealtype_str.lower() and 'dinner' in Mealtype_str.lower()  and 'lunch' in Mealtype_str.lower():
                                    Meal = 'Breakfast, Lunch and Dinner'
                                elif 'breakfast' in Mealtype_str.lower() and 'dinner' in Mealtype_str.lower():
                                    Meal = 'Breakfast and dinner'
                                elif 'breakfast included' in Mealtype_str.lower():
                                    Meal = 'Breakfast included'
                                elif 'breakfast buffet' in Mealtype_str.lower():
                                    Meal = 'Breakfast Buffet' 
                                elif 'BREAKFAST' in Mealtype_str:
                                    Meal = 'Breakfast'
                                elif 'breakfast' in Mealtype_str.lower() and 'lunch' in Mealtype_str.lower():
                                    Meal = 'Breakfast and Lunch'
                                elif 'Lunch' in Mealtype_str and 'Dinner' in Mealtype_str :
                                    Meal = "Lunch and Dinner"
                                elif 'breakfast' in Mealtype_str.lower() and 'lunch' in Mealtype_str.lower() and 'dinner' in Mealtype_str.lower():
                                    Meal = 'Breakfast, Lunch and dinner'
                                elif 'Break fast' in Mealtype_str:
                                    Meal = 'BreakFast' 
                                elif 'breakfast' in Mealtype_str.lower():
                                    Meal = 'BreakFast' 
                                elif 'halfboard' in Mealtype_str.lower():
                                    Meal = 'Halfboard'
                                elif 'half board' in Mealtype_str.lower():
                                    Meal = 'Half board' 
                                elif 'full board' in Mealtype_str.lower():
                                    Meal = 'Full Board'
                                elif 'fullboard' in Mealtype_str.lower():
                                    Meal = 'FullBoard'
                                elif 'All-Inclusive' in Mealtype_str:
                                    Meal = 'All-Inclusive'
                                elif 'All Inclusive' in Mealtype_str:
                                    Meal = 'All Inclusive'
                                elif 'All Meals' in Mealtype_str:
                                    Meal = 'All Meals'
                                elif 'All Meal' in Mealtype_str:
                                    Meal = 'All Meal'
                                else:
                                    Meal = ''
                                MealInclusion_Type = Meal
                                if OnsiteRate <> 0:
                                    statuscode = ''
                                else:
                                    statuscode = 1
                                    Closed_up = 'Y'
                                LOS = int(LOS)
                                if int(LOS) >1:
                                    israteperstay = 'N'
                                else:
                                    israteperstay ='Y'
                                Tax_status = 2
                                if (Old_OnsiteRate != OnsiteRate) or (Old_RateType != RateType):
                                    #print (id_update, inputid , Domainname, Websitecode, StartDate, RoomType, LOS, RateDate, Guests, OnsiteRate, NetRate, OnsiteRate, Curr, RateDescription, url, url, url, RoomAmenity_Type, MealInclusion_Type, MaxOccupancy, isPromotionalRate, Closed_up, 30, StartDate , EndDate, intime, isAvailable, Taxtype, TaxAmount, Tax_status, None, RateType, NetRate, Promotion_Name, region, statuscode, israteperstay)
                                    array.append(aws_insert.insert(id_update, inputid , Domainname, Websitecode, StartDate, RoomType, LOS, RateDate, Guests, OnsiteRate, NetRate, OnsiteRate, Curr, RateDescription, url, url, url, RoomAmenity_Type, MealInclusion_Type, MaxOccupancy, isPromotionalRate, Closed_up, 30, StartDate , EndDate, intime, isAvailable, Taxtype, TaxAmount, Tax_status, None, RateType, NetRate, Promotion_Name, region, statuscode, israteperstay))
                                Old_OnsiteRate = OnsiteRate
                                Old_RateType = RateType
                        break
                    i = i + 1
        else:
            statuscode = '2'
            #print "statuscode    :", statuscode
            Closed_up = "Y"
            da_time = datetime.datetime.now()
            LastModified = re.sub(r'\s', 'T', str(da_time))
            Tax_status = ''
            # insert(HotelCode,Websitecode,ReportDate,RoomType,LOS,RateDate,Guests,OnsiteRate,NetRate,GrossRate,Curr,RateDescription,HotelId,urlRate,urlInclusions,urlAmenities,RoomAmenity_Type,MealInclusion_Type,MaxOccupancy,isPromotionalRate,Closed,NumberOfDays,StartDate,EndDate,LastModified,isAvailable,Taxtype,TaxAmount,HotelBlock,RateType,Discount,Promotion_Name)
            array.append(aws_insert.insert(id_update, inputid , Domainname, Websitecode, StartDate, RoomType, LOS, RateDate, Guests, OnsiteRate, NetRate, OnsiteRate, Curr, RateDescription, url, url, url, RoomAmenity_Type, MealInclusion_Type, MaxOccupancy, isPromotionalRate, Closed_up, 30, StartDate , EndDate, intime, isAvailable, Taxtype, TaxAmount, Tax_status, None, RateType, NetRate, Promotion_Name, region, statuscode, israteperstay))
            # #print ("UPDATE
        #print "completed"
        Rtdate = re.sub(r'-|\-', '', str(RateDate))
        Rtdate = re.sub(r'-|\-', '', str(RateDate))
        keyvalue = "ondemand/{}/{:%Y%m%d}/delivery/{}.json".format(Websitecode, datetime.datetime.now(), str(inputid) + '_' + str(Rtdate) + '_' + id_update)
        key = bucket.new_key(keyvalue)
        key.set_contents_from_string(json.dumps(array))
        return json.dumps(array)
        gc.collect()

    except Exception as e:
        print e
        value_error = str(re.sub(r"'", '"', str(e)))
        stacktrace = sys.exc_traceback.tb_lineno
        Guests = ''
        region = ''
        Websitecode = '375'
        insert_value_error = str(value_error) + 'Where line number ' + str(stacktrace) + str(proxyip)
        print insert_value_error
        #print "Websitecode =", Websitecode
        statuscode = '4'
        keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(Websitecode, datetime.datetime.now(), id_update)
        key = bucket.new_key(keyvalue)
        key.set_contents_from_string(insert_value_error)
        # array.append(aws_insert.insert(id_update,inputid ,Domainname,Websitecode,StartDate,'',LOS,RateDate,Guests,OnsiteRate,Netrate,OnsiteRate,Curr,RateDescription,url,url,url,RoomAmenity_Type,MealInclusion_Type,MaxOccupancy,isPromotionalRate,Closed_up,30,StartDate ,EndDate,intime,isAvailable,None,None,None,RateType,Netrate,promotion,region,statuscode, israteperstay))
        array.append(aws_insert.insert(id_update, inputid , functionname, Websitecode, "", "", "", "", Guests, "", "", "", "", "", url, url, url, "", "", "", "", "", "", StartDate, EndDate , "", "", "", "", "", "", "", "", "", region, statuscode, israteperstay))
        return json.dumps(array)
'''url= 'https://www.myhotelreservation.net/b/hllw2103/HLLW2103/?f=2017-11-02&t=2017-11-03&a=1&c=0&lang=en_US'
inputid= ''
id_update = ''
proxyip   = '62.210.106.225:3681'
fetchrates(url ,inputid, id_update, proxyip)'''
