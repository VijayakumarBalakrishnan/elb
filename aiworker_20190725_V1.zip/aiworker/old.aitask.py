import re
import pymysql
import pymysql.cursors
import json
import datetime
import sys
import operator
import os 
import boto3 
import requests
import threading
import botocore 
import traceback 
import sys 
import time 
import gc
import os

_dbhost = 'rmapiqr.cj3numypvgef.us-west-2.rds.amazonaws.com' 
_dbuser = 'root' 
_dbpass = 'P5Aq7ctJ' 
_dbname = 'rmapiqr' 
_updurl = 'http://aihotelrates-vhlbdup.us-west-2.elasticbeanstalk.com/queueupdate'


sqs = boto3.client('sqs', aws_access_key_id='AKIAI3ZTEOXURCYJUOFA',aws_secret_access_key='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',region_name='us-west-2')
logclient = boto3.client('logs', aws_access_key_id='AKIAI3ZTEOXURCYJUOFA',aws_secret_access_key='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',region_name='us-west-2')

array=[]

def roomcode(description):
	#print description
	roomcodes =[[7,'(.*?Suite)|(.*?Duplex)'],[3,'(.*?Cottage)|(.*?bungalow)|(.*?Villa)|(.*?domek)'],[6,'(.*?Hostel)|(.*?Dormitory)|(.*?Capsule)|(.*?dorm)'],[4,'(.*?Studio)|(.*?Apart)|(.*?Comfort)|(.*?Honeymoon)|(.*?Maisonette)|(.*?Attic)|(.*?Appartment)'],[5,'(.*?delux)|(.*?premium)|(.*?superior)|(.*?Premier)|(.*?Executive)|(.*?Corner)|(.*?Club)|(.*?Family)|(.*?Guest)|(.*?Loft)|(.*?Business)|(.*?Concierge)|(.*?Diamond)|(.*?Luxury)|(.*?Prestige)|(.*?Privilege)|(.*?Swiss Advantage)|(.*?Deluks)|(.*?de lux)|(.*?de-lux)']]
	code = 2
	try:
		for roomcode in roomcodes:
			cpattern =re.compile(roomcode[1], re.IGNORECASE)
			if cpattern.findall(description):
				code = roomcode[0]
				#print code
				break
	except Exception as e:
		pass
	return code

def conditioncode(description):
	ratecodes = [[3,'(.*?Pay at the Property)'],[3,'(.*?Pay when you stay)'],[3,'(.*?Cancellation polic)|(.*?Flexible_Cancellation)|(.*?Flexible Rate)|(.*?Cancellation Conditional)|(.*?fully refundable)'],[2,'(.*?Free cancellation)|(.*?Semi-Flexible)|(.*?Cancel free of charge before)|(.*?Freecancellation)|(.*?cancellation is free)|(.*?Free_cancellation)|(.*?Cancellations are not possible without incurring a charge)|(.*?Partially Refundable)'],[1,'(.*?Non-refundable)|(.*?Non refundable)|(.*?Non_refundable)|(.*?Cancellation not free-of-charge)|(.*?Nonrefundable)|(.*?Low rate)|(.*?no money back)|(.*?Cancellation Charg)|(.*?Cancellation Fee)'],[2,'(.*?SPECIAL_CONDITIONS)|(.*?Special Conditions)']]
	code = None
	try:
		for ratecode in ratecodes:
			cpattern =re.compile(ratecode[1], re.IGNORECASE)
			if cpattern.findall(description):
				code = ratecode[0]
				#print code
				break
	except Exception as e:
		pass
	return code
	
def mealcode(description):
	#print " in meal test =",description
	#mealcodes = [[3,'(.*?Breakfast)(.*?Lunch)(.*?Dinner)|(.*?Breakfast)(.*?Lunch)(.*?Supper)'],[3,'(.*?Full Board)|(.*?Full-Board)|(.*?FullBoard)|(.*?All Meal)|(.*?All-Meal)'],[4,'(.*?Half Board)|(.*?Half-Board)|(.*?HalfBoard)|(.*?food and beverage)(.*?credit)'],[4,'(.*?Breakfast)(.*?Lunch)'],[4,'(.*?Breakfast)(.*?Dinner)|(.*?Breakfast)(.*?Supper)'],[2,'(.*?Breakfast)(.*?\\$)|(.*?Breakfast)(.*?cost)|(.*?Breakfast)(.*?Rs\\.)|(.*?Paid Breakfast)|(.*?Breakfast charges)'],['Null','(.*?Lunch)|(.*?Cost)'],['Null','(.*?Dinner) (.*?Cost)'],[6,'(.*?Breakfast)|(.*?Break fast)|(.*?Meals Inclusive)|(.*?B&B)|(.*?Continental Plan)'],['Null','(.*?Lunch)'],['Null','(.*?Dinner)'],[1,'(.*?All)|(.*?inclusive)'],[5,'(.*?No Meal)(.*?No Breakfast)(.*?Breakfast not)(.*?Meal not)(.*?Excl|Breakfast)(.*?Excl)|(.*?Meal)(.*?Mealsnotavailable)(.*?Complimentary exclusive)(.*?European Plan)']]
	mealcodes = [[3,'(.*?Breakfast)(.*?Lunch)(.*?Dinner)|(.*?Breakfast)(.*?Lunch)(.*?Supper)'],[3,'(.*?Full Board)|(.*?Full-Board)|(.*?FullBoard)|(.*?All Meal)|(.*?All-Meal)'],[4,'(.*?Half Board)|(.*?Half-Board)|(.*?HalfBoard)|(.*?food and beverage)(.*?credit)'],[4,'(.*?Breakfast)(.*?Lunch)'],[4,'(.*?Breakfast)(.*?Dinner)|(.*?Breakfast)(.*?Supper)'],[2,'(.*?Breakfast)(.*?\\$)|(.*?Breakfast)(.*?cost)|(.*?Breakfast)(.*?Rs\\.)|(.*?Paid Breakfast)|(.*?Breakfast charges)'],[6,'(.*?Breakfast)|(.*?Break fast)|(.*?Meals Inclusive)|(.*?B&B)|(.*?Continental Plan)']]
	code = None
	try:
		for mealcode in mealcodes:
			cpattern =re.compile(mealcode[1], re.IGNORECASE)
			if cpattern.findall(description):
				code = mealcode[0]
				break
	except Exception as e:
		pass
	#print "mcode =",code    
	return code

def getProxy(proxy, pos, websitecode):
	retval = proxy
	try:
		for z in range(5):
			try:
				conn =pymysql.connect(host='rmapi-cluster.cluster-cj3numypvgef.us-west-2.rds.amazonaws.com',user='root',password='SpY&76aJ',db='rmapi',charset='utf8mb4',cursorclass=pymysql.cursors.DictCursor) 
				conn.threadsafety = 3
				cursorn = conn.cursor()
				print "connected logs table"
				break
			except Exception as e:
				print e
				continue
		_pos = pos
		if pos == None: 
			_pos = 'null'
		cursorn.execute("call getproxy({pos}, {websitecode}, null)".format(pos=_pos, websitecode=websitecode))
		#cursorn.execute("call getproxy({pos}, {websitecode}, null)".format(pos=pos, websitecode=websitecode))
		results = cursorn.fetchall()
		cursorn.close()
		for result in results:
			#retval = str(result['proxy'])
			retval = str(result['_proxy'])
	except Exception, e:
		expstr = "{msg}, {trace}".format(msg=e, trace=traceback.format_exc())
		resd = logclient.describe_log_streams(logGroupName="rmapi", logStreamNamePrefix="scheduler")
		token = resd["logStreams"][0]['uploadSequenceToken']
		logclient.put_log_events(logGroupName="rmapi", logStreamName="scheduler", logEvents=[{'timestamp':int(round(time.time() * 1000)),'message': expstr }], sequenceToken = token)

	return retval


def sqsruntask(queueid):
	try:
		#from firebase import firebase
		#firebase = firebase.FirebaseApplication('https://aifirestore.firebaseio.com/', None)
		queue_url = "https://sqs.us-west-2.amazonaws.com/982499500900/{qid}".format(qid=queueid)
		print queue_url
		sqs.set_queue_attributes(
			QueueUrl=queue_url,
			Attributes={'ReceiveMessageWaitTimeSeconds': '0'}
		)

		_emsg = 0
		_run = True
		while(_run):
			print "run"
			try:
				print "Waiting for message"
				response = sqs.receive_message(
					QueueUrl=queue_url,
					AttributeNames=[
						'SentTimestamp'
					],
					MaxNumberOfMessages=1,
					MessageAttributeNames=[
						'All'
					],
					WaitTimeSeconds=0
				)
				print response
				resultq = []
				if response.has_key("Messages"):
					def runmsg(message):
						rhandle = message['ReceiptHandle']
						sqs.change_message_visibility(QueueUrl=queue_url,ReceiptHandle=rhandle,VisibilityTimeout=120)
						row = json.loads(message["Body"])
						subjecthotelcode=None
						searchkeyword=None
						roomtypecode=None
						conditionscode=None
						mealplancode=None
						hotelcode=row["hotelcode"]
						proxy=row["proxy"]
						url=row["url"]
						websitecode=row["websitecode"]
						queueid=row["queueid"]
						refid=row["debugid"]
						pos=row["pos"]
						snapshoturl=row["snapshoturl"]
						checkin=row["checkin"]
						checkout=row["checkout"]
						Los=row["los"]
						RateDate=checkin
						intime = re.sub(r'\s', 'T', str(datetime.datetime.now()))
						c_date = datetime.datetime.now().date()
						_rerun = 0
						while(_rerun <= 3):
							_rerun+=1
							if websitecode == 378 or websitecode == 380 or websitecode == 381 or websitecode == 379 or websitecode == 377 or websitecode == 376 or websitecode == 383 or websitecode == 393 or websitecode == 392 or websitecode == 389 or websitecode == 386 or websitecode == 385 or websitecode == 391 or websitecode == 382 or websitecode == 390 or websitecode == 387 or websitecode == 388 or websitecode == 384 or websitecode == 398 or websitecode == 402 or websitecode == 396 or websitecode == 394 or websitecode == 399 or websitecode == 401 or websitecode == 403 or websitecode == 400 or websitecode == 395 or websitecode == 397 or websitecode == 404 or websitecode == 409 or websitecode == 410 or websitecode == 412 or websitecode == 406 or websitecode == 405 or websitecode == 407 or websitecode == 411 or websitecode == 414 or websitecode == 413 or websitecode == 408 or websitecode == 425 or websitecode == 418 or websitecode == 419 or websitecode == 423 or websitecode == 415 or websitecode == 422 or websitecode == 417 or websitecode == 421 or websitecode == 420 or websitecode == 424 or websitecode == 416 or websitecode == 435 or websitecode == 432 or websitecode == 426 or websitecode == 434 or websitecode == 430 or websitecode == 431 or websitecode == 429 or websitecode == 428 or websitecode == 427 or websitecode == 433 or websitecode == 442 or websitecode == 438 or websitecode == 439 or websitecode == 436 or websitecode == 441 or websitecode == 440 or websitecode == 437 or websitecode == 444 or websitecode == 445 or websitecode == 443 or websitecode == 449 or websitecode == 451 or websitecode == 446 or websitecode == 447 or websitecode == 450 or websitecode == 452 or websitecode == 448 or websitecode == 459 or websitecode == 456 or websitecode == 462 or websitecode == 454 or websitecode == 453 or websitecode == 455 or websitecode == 460 or websitecode == 458 or websitecode == 461 or websitecode == 457 or websitecode == 474 or websitecode == 469 or websitecode == 466 or websitecode == 470 or websitecode == 464 or websitecode == 472 or websitecode == 471 or websitecode == 467 or websitecode == 463 or websitecode == 465 or websitecode == 468 or websitecode == 473 or websitecode == 484 or websitecode == 475 or websitecode == 478 or websitecode == 486 or websitecode == 476 or websitecode == 485 or websitecode == 483 or websitecode == 477 or websitecode == 482 or websitecode == 480 or websitecode == 481 or websitecode == 479 or websitecode == 490 or websitecode == 487 or websitecode == 488 or websitecode == 491 or websitecode == 497 or websitecode == 493 or websitecode == 492 or websitecode == 489 or websitecode == 494 or websitecode == 496 or websitecode == 495 or websitecode == 506 or websitecode == 502 or websitecode == 501 or websitecode == 499 or websitecode == 505 or websitecode == 500 or websitecode == 507 or websitecode == 498 or websitecode == 503 or websitecode == 508 or websitecode == 504 or websitecode == 519 or websitecode == 518 or websitecode == 515 or websitecode == 513 or websitecode == 511 or websitecode == 514 or websitecode == 516 or websitecode == 517 or websitecode == 509 or websitecode == 512 or websitecode == 510 or websitecode == 528 or websitecode == 526 or websitecode == 529 or websitecode == 522 or websitecode == 530 or websitecode == 524 or websitecode == 525 or websitecode == 521 or websitecode == 520 or websitecode == 523 or websitecode == 527 or websitecode == 540 or websitecode == 539 or websitecode == 531 or websitecode == 538 or websitecode == 532 or websitecode == 537 or websitecode == 533 or websitecode == 534 or websitecode == 536 or websitecode == 535 or websitecode == 550 or websitecode == 549 or websitecode == 547 or websitecode == 545 or websitecode == 546 or websitecode == 548 or websitecode == 541 or websitecode == 543 or websitecode == 542 or websitecode == 544 or websitecode == 555 or websitecode == 553 or websitecode == 554 or websitecode == 557 or websitecode == 551 or websitecode == 559 or websitecode == 556 or websitecode == 558 or websitecode == 560 or websitecode == 561 or websitecode == 552 or websitecode == 570 or websitecode == 563 or websitecode == 562 or websitecode == 565 or websitecode == 568 or websitecode == 567 or websitecode == 566 or websitecode == 572 or websitecode == 564 or websitecode == 571 or websitecode == 569 or websitecode == 576 or websitecode == 575 or websitecode == 579 or websitecode == 573 or websitecode == 582 or websitecode == 581 or websitecode == 580 or websitecode == 574 or websitecode == 577 or websitecode == 578 or websitecode == 583 or websitecode == 585 or websitecode == 584 or websitecode == 590 or websitecode == 591 or websitecode == 589 or websitecode == 588 or websitecode == 586 or websitecode == 587 or websitecode == 593 or websitecode == 592 or websitecode == 597 or websitecode == 599 or websitecode == 603 or websitecode == 596 or websitecode == 601 or websitecode == 600 or websitecode == 602 or websitecode == 604 or websitecode == 595 or websitecode == 594 or websitecode == 598 or websitecode == 606 or websitecode == 607 or websitecode == 613 or websitecode == 610 or websitecode == 614 or websitecode == 611 or websitecode == 609 or websitecode == 615 or websitecode == 612 or websitecode == 608 or websitecode == 605 or websitecode == 620 or websitecode == 625 or websitecode == 626 or websitecode == 622 or websitecode == 619 or websitecode == 624 or websitecode == 623 or websitecode == 616 or websitecode == 617 or websitecode == 618 or websitecode == 621 or websitecode == 631 or websitecode == 628 or websitecode == 627 or websitecode == 632 or websitecode == 635 or websitecode == 636 or websitecode == 637 or websitecode == 630 or websitecode == 634 or websitecode == 629 or websitecode == 633 or websitecode == 643 or websitecode == 640 or websitecode == 638 or websitecode == 647 or websitecode == 642 or websitecode == 644 or websitecode == 646 or websitecode == 641 or websitecode == 639 or websitecode == 645 or websitecode == 656 or websitecode == 651 or websitecode == 650 or websitecode == 653 or websitecode == 654 or websitecode == 648 or websitecode == 652 or websitecode == 655 or websitecode == 649 or websitecode == 666 or websitecode == 662 or websitecode == 663 or websitecode == 661 or websitecode == 660 or websitecode == 667 or websitecode == 668 or websitecode == 657 or websitecode == 659 or websitecode == 664 or websitecode == 658 or websitecode == 665 or websitecode == 671 or websitecode == 670 or websitecode == 672 or websitecode == 674 or websitecode == 679 or websitecode == 675 or websitecode == 669 or websitecode == 677 or websitecode == 676 or websitecode == 673 or websitecode == 678 or websitecode == 680 or websitecode == 686 or websitecode == 681 or websitecode == 688 or websitecode == 683 or websitecode == 684 or websitecode == 685 or websitecode == 682 or websitecode == 689 or websitecode == 687 or websitecode == 690 or websitecode == 698 or websitecode == 694 or websitecode == 696 or websitecode == 697 or websitecode == 695 or websitecode == 693 or websitecode == 691 or websitecode == 692 or websitecode == 710 or websitecode == 705 or websitecode == 706 or websitecode == 701 or websitecode == 709 or websitecode == 707 or websitecode == 708 or websitecode == 702 or websitecode == 700 or websitecode == 699 or websitecode == 703 or websitecode == 704 or websitecode == 718 or websitecode == 715 or websitecode == 716 or websitecode == 721 or websitecode == 717 or websitecode == 719 or websitecode == 720 or websitecode == 722 or websitecode == 711 or websitecode == 712 or websitecode == 713 or websitecode == 714 or websitecode == 726 or websitecode == 732 or websitecode == 724 or websitecode == 727 or websitecode == 723 or websitecode == 729 or websitecode == 730 or websitecode == 731 or websitecode == 728 or websitecode == 725 or websitecode == 741 or websitecode == 733 or websitecode == 738 or websitecode == 734 or websitecode == 740 or websitecode == 739 or websitecode == 736 or websitecode == 742 or websitecode == 743 or websitecode == 735 or websitecode == 737 or websitecode == 749 or websitecode == 747 or websitecode == 750 or websitecode == 752 or websitecode == 754 or websitecode == 753 or websitecode == 744 or websitecode == 745 or websitecode == 755 or websitecode == 748 or websitecode == 746 or websitecode == 751 or websitecode == 762 or websitecode == 758 or websitecode == 765 or websitecode == 764 or websitecode == 756 or websitecode == 759 or websitecode == 760 or websitecode == 757 or websitecode == 763 or websitecode == 761 or websitecode == 766 or websitecode == 771 or websitecode == 774 or websitecode == 770 or websitecode == 768 or websitecode == 767 or websitecode == 775 or websitecode == 772 or websitecode == 776 or websitecode == 769 or websitecode == 773 or websitecode == 777 or websitecode == 780 or websitecode == 782 or websitecode == 787 or websitecode == 783 or websitecode == 788 or websitecode == 784 or websitecode == 786 or websitecode == 785 or websitecode == 779 or websitecode == 781 or websitecode == 778 or websitecode == 790 or websitecode == 793 or websitecode == 789 or websitecode == 795 or websitecode == 798 or websitecode == 791 or websitecode == 794 or websitecode == 792 or websitecode == 797 or websitecode == 796 or websitecode == 799 or websitecode == 804 or websitecode == 809 or websitecode == 802 or websitecode == 810 or websitecode == 807 or websitecode == 808 or websitecode == 803 or websitecode == 806 or websitecode == 805 or websitecode == 801 or websitecode == 800 or websitecode == 821 or websitecode == 820 or websitecode == 811 or websitecode == 812 or websitecode == 819 or websitecode == 813 or websitecode == 814 or websitecode == 815 or websitecode == 818 or websitecode == 817 or websitecode == 816 or websitecode == 822 or websitecode == 828 or websitecode == 830 or websitecode == 831 or websitecode == 829 or websitecode == 827 or websitecode == 824 or websitecode == 826 or websitecode == 825 or websitecode == 832 or websitecode == 823 or websitecode == 838 or websitecode == 833 or websitecode == 834 or websitecode == 836 or websitecode == 835 or websitecode == 842 or websitecode == 841 or websitecode == 840 or websitecode == 837 or websitecode == 839 or websitecode == 851 or websitecode == 845 or websitecode == 843 or websitecode == 846 or websitecode == 850 or websitecode == 849 or websitecode == 848 or websitecode == 844 or websitecode == 847 or websitecode == 859 or websitecode == 853 or websitecode == 861 or websitecode == 855 or websitecode == 856 or websitecode == 860 or websitecode == 857 or websitecode == 852 or websitecode == 854 or websitecode == 858 or websitecode == 870 or websitecode == 864 or websitecode == 871 or websitecode == 866 or websitecode == 869 or websitecode == 862 or websitecode == 867 or websitecode == 865 or websitecode == 863 or websitecode == 868 or websitecode == 878 or websitecode == 872 or websitecode == 876 or websitecode == 875 or websitecode == 877 or websitecode == 873 or websitecode == 874 or websitecode == 879 or websitecode == 881 or websitecode == 885 or websitecode == 882 or websitecode == 880 or websitecode == 887 or websitecode == 883 or websitecode == 884 or websitecode == 888 or websitecode == 886 or websitecode == 896 or websitecode == 895 or websitecode == 893 or websitecode == 890 or websitecode == 889 or websitecode == 891 or websitecode == 892 or websitecode == 894 or websitecode == 906 or websitecode == 899 or websitecode == 904 or websitecode == 898 or websitecode == 905 or websitecode == 901 or websitecode == 902 or websitecode == 897 or websitecode == 900 or websitecode == 903 or websitecode == 907 or websitecode == 911 or websitecode == 908 or websitecode == 910 or websitecode == 913 or websitecode == 915 or websitecode == 909 or websitecode == 912 or websitecode == 914 or websitecode == 917 or websitecode == 920 or websitecode == 919 or websitecode == 922 or websitecode == 916 or websitecode == 918 or websitecode == 921 or websitecode == 928 or websitecode == 924 or websitecode == 925 or websitecode == 929 or websitecode == 931 or websitecode == 930 or websitecode == 926 or websitecode == 927 or websitecode == 923 or websitecode == 932 or websitecode == 933 or websitecode == 934 or websitecode == 935 or websitecode == 938 or websitecode == 936 or websitecode == 942 or websitecode == 941 or websitecode == 937 or websitecode == 940 or websitecode == 939 or websitecode == 943 or websitecode == 945 or websitecode == 947 or websitecode == 948 or websitecode == 949 or websitecode == 950 or websitecode == 946 or websitecode == 944 or websitecode == 955 or websitecode == 954 or websitecode == 957 or websitecode == 956 or websitecode == 951 or websitecode == 959 or websitecode == 953 or websitecode == 958 or websitecode == 952 or websitecode == 961 or websitecode == 962 or websitecode == 963 or websitecode == 966 or websitecode == 968 or websitecode == 967 or websitecode == 965 or websitecode == 960 or websitecode == 964 or websitecode == 970 or websitecode == 973 or websitecode == 974 or websitecode == 975 or websitecode == 977 or websitecode == 978 or websitecode == 972 or websitecode == 971 or websitecode == 969 or websitecode == 976 or websitecode == 979 or websitecode == 986 or websitecode == 985 or websitecode == 980 or websitecode == 982 or websitecode == 981 or websitecode == 987 or websitecode == 983 or websitecode == 984 or websitecode == 988 or websitecode == 991 or websitecode == 997 or websitecode == 993 or websitecode == 996 or websitecode == 992 or websitecode == 994 or websitecode == 990 or websitecode == 995 or websitecode == 989 or websitecode == 1007 or websitecode == 1004 or websitecode == 1000 or websitecode == 1003 or websitecode == 1002 or websitecode == 1005 or websitecode == 1001 or websitecode == 1006 or websitecode == 998 or websitecode == 999 or websitecode == 1014 or websitecode == 1010 or websitecode == 1013 or websitecode == 1015 or websitecode == 1009 or websitecode == 1008 or websitecode == 1016 or websitecode == 1012 or websitecode == 1011 or websitecode == 1025 or websitecode == 1026 or websitecode == 1017 or websitecode == 1024 or websitecode == 1022 or websitecode == 1018 or websitecode == 1023 or websitecode == 1019 or websitecode == 1021 or websitecode == 1020 or websitecode == 1031 or websitecode == 1030 or websitecode == 1029 or websitecode == 1034 or websitecode == 1028 or websitecode == 1033 or websitecode == 1027 or websitecode == 1032 or websitecode == 1035 or websitecode == 1038 or websitecode == 1040 or websitecode == 1045 or websitecode == 1042 or websitecode == 1041 or websitecode == 1043 or websitecode == 1037 or websitecode == 1036 or websitecode == 1039 or websitecode == 1044 or websitecode == 1053 or websitecode == 1050 or websitecode == 1054 or websitecode == 1051 or websitecode == 1046 or websitecode == 1052 or websitecode == 1049 or websitecode == 1048 or websitecode == 1047 or websitecode == 1058 or websitecode == 1055 or websitecode == 1056 or websitecode == 1057 or websitecode == 1059 or websitecode == 1060 or websitecode == 1061 or websitecode == 1062 or websitecode == 1063 or websitecode == 1068 or websitecode == 1072 or websitecode == 1069 or websitecode == 1070 or websitecode == 1071 or websitecode == 1066 or websitecode == 1065 or websitecode == 1067 or websitecode == 1064 or websitecode == 1076 or websitecode == 1074 or websitecode == 1075 or websitecode == 1073 or websitecode == 1081 or websitecode == 1078 or websitecode == 1082 or websitecode == 1080 or websitecode == 1083 or websitecode == 1079 or websitecode == 1077 or websitecode == 1090 or websitecode == 1086 or websitecode == 1084 or websitecode == 1091 or websitecode == 1088 or websitecode == 1087 or websitecode == 1089 or websitecode == 1085 or websitecode == 1092 or websitecode == 1095 or websitecode == 1099 or websitecode == 1094 or websitecode == 1097 or websitecode == 1093 or websitecode == 1096 or websitecode == 1100 or websitecode == 1098 or websitecode == 1101 or websitecode == 1108 or websitecode == 1107 or websitecode == 1103 or websitecode == 1102 or websitecode == 1110 or websitecode == 1104 or websitecode == 1106 or websitecode == 1109 or websitecode == 1105 or websitecode == 1117 or websitecode == 1111 or websitecode == 1118 or websitecode == 1113 or websitecode == 1119 or websitecode == 1116 or websitecode == 1115 or websitecode == 1114 or websitecode == 1112 or websitecode == 1123 or websitecode == 1124 or websitecode == 1121 or websitecode == 1122 or websitecode == 1126 or websitecode == 1125 or websitecode == 1127 or websitecode == 1128 or websitecode == 1120 or websitecode == 1133 or websitecode == 1136 or websitecode == 1135 or websitecode == 1129 or websitecode == 1132 or websitecode == 1137 or websitecode == 1138 or websitecode == 1130 or websitecode == 1134 or websitecode == 1131 or websitecode == 1148 or websitecode == 1147 or websitecode == 1139 or websitecode == 1141 or websitecode == 1144 or websitecode == 1142 or websitecode == 1143 or websitecode == 1146 or websitecode == 1140 or websitecode == 1145 or websitecode == 1151 or websitecode == 1152 or websitecode == 1157 or websitecode == 1154 or websitecode == 1155 or websitecode == 1156 or websitecode == 1149 or websitecode == 1158 or websitecode == 1153 or websitecode == 1150 or websitecode == 1164 or websitecode == 1163 or websitecode == 1168 or websitecode == 1162 or websitecode == 1166 or websitecode == 1159 or websitecode == 1161 or websitecode == 1165 or websitecode == 1160 or websitecode == 1167 or websitecode == 1173 or websitecode == 1177 or websitecode == 1169 or websitecode == 1171 or websitecode == 1172 or websitecode == 1170 or websitecode == 1175 or websitecode == 1176 or websitecode == 1174 or websitecode == 1182 or websitecode == 1185 or websitecode == 1179 or websitecode == 1178 or websitecode == 1183 or websitecode == 1180 or websitecode == 1184 or websitecode == 1186 or websitecode == 1181 or websitecode == 1189 or websitecode == 1188 or websitecode == 1195 or websitecode == 1191 or websitecode == 1196 or websitecode == 1190 or websitecode == 1187 or websitecode == 1194 or websitecode == 1193 or websitecode == 1192 or websitecode == 1205 or websitecode == 1203 or websitecode == 1206 or websitecode == 1199 or websitecode == 1200 or websitecode == 1197 or websitecode == 1201 or websitecode == 1198 or websitecode == 1202 or websitecode == 1204 or websitecode == 1213 or websitecode == 1212 or websitecode == 1210 or websitecode == 1211 or websitecode == 1208 or websitecode == 1209 or websitecode == 1214 or websitecode == 1207 or websitecode == 1215 or websitecode == 1221 or websitecode == 1222 or websitecode == 1223 or websitecode == 1217 or websitecode == 1216 or websitecode == 1219 or websitecode == 1218 or websitecode == 1220 or websitecode == 1224 or websitecode == 1227 or websitecode == 1226 or websitecode == 1225 or websitecode == 1229 or websitecode == 1228 or websitecode == 1231 or websitecode == 1230 or websitecode == 1233 or websitecode == 1232 or websitecode == 1235 or websitecode == 1239 or websitecode == 1242 or websitecode == 1240 or websitecode == 1234 or websitecode == 1237 or websitecode == 1236 or websitecode == 1241 or websitecode == 1238 or websitecode == 1249 or websitecode == 1247 or websitecode == 1250 or websitecode == 1243 or websitecode == 1244 or websitecode == 1251 or websitecode == 1246 or websitecode == 1252 or websitecode == 1245 or websitecode == 1248 or websitecode == 1259 or websitecode == 1262 or websitecode == 1261 or websitecode == 1257 or websitecode == 1256 or websitecode == 1253 or websitecode == 1255 or websitecode == 1258 or websitecode == 1254 or websitecode == 1260 or websitecode == 1271 or websitecode == 1266 or websitecode == 1269 or websitecode == 1264 or websitecode == 1270 or websitecode == 1268 or websitecode == 1263 or websitecode == 1265 or websitecode == 1267 or websitecode == 1272 or websitecode == 1273 or websitecode == 1274 or websitecode == 1275 or websitecode == 1276:
								exp = __import__('aiworker.travelclick', globals(), locals(), "fetchrates", -1)
								res_body = exp.fetchrates(url,hotelcode,refid,proxy)
							elif websitecode == 1278 or websitecode == 1279 or websitecode == 1280 or websitecode == 1281 or websitecode == 1282 or websitecode == 1283 or websitecode == 1284 or websitecode == 1285 or websitecode == 1286 or websitecode == 1287 or websitecode == 1288 or websitecode == 1289 or websitecode == 1290 or websitecode == 1291 or websitecode == 1292 or websitecode == 1293 or websitecode == 1294 or websitecode == 1295 or websitecode == 1296 or websitecode == 1297 or websitecode == 1298 or websitecode == 1299 or websitecode == 1300 or websitecode == 1301 or websitecode == 1302 or websitecode == 1303 or websitecode == 1304 or websitecode == 1305 or websitecode == 1306 or websitecode == 1307 or websitecode == 1308 or websitecode == 1309 or websitecode == 1310 or websitecode == 1311 or websitecode == 1312 or websitecode == 1313 or websitecode == 1314 or websitecode == 1315 or websitecode == 1316 or websitecode == 1317 or websitecode == 1318 or websitecode == 1319 or websitecode == 1320 or websitecode == 1321 or websitecode == 1322 or websitecode == 1323 or websitecode == 1324 or websitecode == 1325 or websitecode == 1326 or websitecode == 1327 or websitecode == 1328 or websitecode == 1329 or websitecode == 1330 or websitecode == 1331 or websitecode == 1332 or websitecode == 1333 or websitecode == 1334 or websitecode == 1335 or websitecode == 1336 or websitecode == 1337 or websitecode == 1338 or websitecode == 1339 or websitecode == 1340 or websitecode == 1341 or websitecode == 1342 or websitecode == 1343 or websitecode == 1344 or websitecode == 1345 or websitecode == 1346 or websitecode == 1347 or websitecode == 1348 or websitecode == 1349 or websitecode == 1350 or websitecode == 1351 or websitecode == 1352 or websitecode == 1353 or websitecode == 1354 or websitecode == 1355 or websitecode == 1356 or websitecode == 1357 or websitecode == 1358 or websitecode == 1359 or websitecode == 1360 or websitecode == 1361 or websitecode == 1362 or websitecode == 1363 or websitecode == 1364 or websitecode == 1365 or websitecode == 1366 or websitecode == 1367 or websitecode == 1368 or websitecode == 1369 or websitecode == 1370 or websitecode == 1371 or websitecode == 1372 or websitecode == 1373 or websitecode == 1374 or websitecode == 1375 or websitecode == 1376 or websitecode == 1377 or websitecode == 1378 or websitecode == 1379 or websitecode == 1380 or websitecode == 1381 or websitecode == 1382 or websitecode == 1383 or websitecode == 1384 or websitecode == 1385 or websitecode == 1386 or websitecode == 1387 or websitecode == 1388 or websitecode == 1389 or websitecode == 1390 or websitecode == 1391 or websitecode == 1392 or websitecode == 1393 or websitecode == 1394 or websitecode == 1395 or websitecode == 1396 or websitecode == 1397 or websitecode == 1398 or websitecode == 1399 or websitecode == 1400 or websitecode == 1401 or websitecode == 1402 or websitecode == 1403 or websitecode == 1404 or websitecode == 1405 or websitecode == 1406 or websitecode == 1407 or websitecode == 1408 or websitecode == 1409 or websitecode == 1410 or websitecode == 1411 or websitecode == 1412 or websitecode == 1413 or websitecode == 1414 or websitecode == 1415 or websitecode == 1416 or websitecode == 1417 or websitecode == 1418 or websitecode == 1419 or websitecode == 1420 or websitecode == 1421 or websitecode == 1422 or websitecode == 1423 or websitecode == 1424 or websitecode == 1425 or websitecode == 1426 or websitecode == 1427 or websitecode == 1428 or websitecode == 1429 or websitecode == 1430 or websitecode == 1431 or websitecode == 1432 or websitecode == 1433 or websitecode == 1434 or websitecode == 1435 or websitecode == 1436 or websitecode == 1437 or websitecode == 1438 or websitecode == 1439 or websitecode == 1440 or websitecode == 1441 or websitecode == 1442 or websitecode == 1443 or websitecode == 1444 or websitecode == 1445 or websitecode == 1446 or websitecode == 1447 or websitecode == 1448 or websitecode == 1449 or websitecode == 1450 or websitecode == 1451 or websitecode == 1452 or websitecode == 1453 or websitecode == 1454 or websitecode == 1455 or websitecode == 1456 or websitecode == 1457 or websitecode == 1458 or websitecode == 1459 or websitecode == 1460 or websitecode == 1461 or websitecode == 1462 or websitecode == 1463 or websitecode == 1464 or websitecode == 1465 or websitecode == 1466 or websitecode == 1467 or websitecode == 1468 or websitecode == 1469 or websitecode == 1470 or websitecode == 1471 or websitecode == 1472 or websitecode == 1473 or websitecode == 1474 or websitecode == 1475 or websitecode == 1476 or websitecode == 1477 or websitecode == 1478 or websitecode == 1479 or websitecode == 1480 or websitecode == 1481 or websitecode == 1482 or websitecode == 1483 or websitecode == 1484 or websitecode == 1485 or websitecode == 1486 or websitecode == 1487 or websitecode == 1488 or websitecode == 1489 or websitecode == 1490 or websitecode == 1491 or websitecode == 1492 or websitecode == 1493 or websitecode == 1494 or websitecode == 1495 or websitecode == 1496 or websitecode == 1497 or websitecode == 1498 or websitecode == 1499 or websitecode == 1500 or websitecode == 1501 or websitecode == 1502 or websitecode == 1503 or websitecode == 1504 or websitecode == 1505 or websitecode == 1506 or websitecode == 1507 or websitecode == 1508 or websitecode == 1509 or websitecode == 1510 or websitecode == 1511 or websitecode == 1512 or websitecode == 1513 or websitecode == 1514 or websitecode == 1515 or websitecode == 1516 or websitecode == 1517 or websitecode == 1518 or websitecode == 1519 or websitecode == 1520 or websitecode == 1521 or websitecode == 1522 or websitecode == 1523 or websitecode == 1524 or websitecode == 1525 or websitecode == 1526 or websitecode == 1527 or websitecode == 1528 or websitecode == 1529 or websitecode == 1530 or websitecode == 1531 or websitecode == 1532 or websitecode == 1533 or websitecode == 1534 or websitecode == 1535 or websitecode == 1536 or websitecode == 1537 or websitecode == 1538 or websitecode == 1539 or websitecode == 1540 or websitecode == 1541 or websitecode == 1542 or websitecode == 1543 or websitecode == 1544 or websitecode == 1545 or websitecode == 1546 or websitecode == 1547 or websitecode == 1548 or websitecode == 1549 or websitecode == 1550 or websitecode == 1551 or websitecode == 1552 or websitecode == 1553 or websitecode == 1554 or websitecode == 1555 or websitecode == 1556 or websitecode == 1557 or websitecode == 1558 or websitecode == 1559 or websitecode == 1560 or websitecode == 1561 or websitecode == 1562 or websitecode == 1563 or websitecode == 1564 or websitecode == 1565 or websitecode == 1566 or websitecode == 1567 or websitecode == 1568 or websitecode == 1569 or websitecode == 1570 or websitecode == 1571 or websitecode == 1572 or websitecode == 1573 or websitecode == 1574 or websitecode == 1575 or websitecode == 1576 or websitecode == 1577 or websitecode == 1578 or websitecode == 1579 or websitecode == 1580 or websitecode == 1581 or websitecode == 1582 or websitecode == 1583 or websitecode == 1584 or websitecode == 1585 or websitecode == 1586 or websitecode == 1587 or websitecode == 1588 or websitecode == 1589 or websitecode == 1590 or websitecode == 1591 or websitecode == 1592 or websitecode == 1593 or websitecode == 1594 or websitecode == 1595 or websitecode == 1596 or websitecode == 1597 or websitecode == 1598 or websitecode == 1599 or websitecode == 1600 or websitecode == 1601 or websitecode == 1602 or websitecode == 1603 or websitecode == 1604 or websitecode == 1605 or websitecode == 1606 or websitecode == 1607 or websitecode == 1608 or websitecode == 1609 or websitecode == 1610 or websitecode == 1611 or websitecode == 1612 or websitecode == 1613 or websitecode == 1614 or websitecode == 1615 or websitecode == 1616 or websitecode == 1617 or websitecode == 1618 or websitecode == 1619 or websitecode == 1620 or websitecode == 1621 or websitecode == 1622 or websitecode == 1623 or websitecode == 1624 or websitecode == 1625 or websitecode == 1626 or websitecode == 1627 or websitecode == 1628 or websitecode == 1629 or websitecode == 1630 or websitecode == 1631 or websitecode == 1632 or websitecode == 1633 or websitecode == 1634 or websitecode == 1635 or websitecode == 1636 or websitecode == 1637 or websitecode == 1638 or websitecode == 1639 or websitecode == 1640 or websitecode == 1641 or websitecode == 1642 or websitecode == 1643 or websitecode == 1644 or websitecode == 1645 or websitecode == 1646 or websitecode == 1647 or websitecode == 1648 or websitecode == 1649 or websitecode == 1650 or websitecode == 1651 or websitecode == 1652 or websitecode == 1653 or websitecode == 1654 or websitecode == 1655 or websitecode == 1656 or websitecode == 1657 or websitecode == 1658 or websitecode == 1659 or websitecode == 1660 or websitecode == 1661 or websitecode == 1662 or websitecode == 1663 or websitecode == 1664 or websitecode == 1665 or websitecode == 1666 or websitecode == 1667 or websitecode == 1668 or websitecode == 1669 or websitecode == 1670 or websitecode == 1671 or websitecode == 1672 or websitecode == 1673 or websitecode == 1674 or websitecode == 1675 or websitecode == 1676 or websitecode == 1677 or websitecode == 1678 or websitecode == 1679 or websitecode == 1680 or websitecode == 1681 or websitecode == 1682 or websitecode == 1683 or websitecode == 1684 or websitecode == 1685 or websitecode == 1686 or websitecode == 1687 or websitecode == 1688 or websitecode == 1689:
								exp = __import__('aiworker.simplebooking', globals(), locals(), "fetchrates", -1)
								res_body = exp.fetchrates(url,hotelcode,refid,proxy,websitecode)
							else:					
								jdata={'3662':'airbnb','3660':'travelocity','3661':'cheaptickets','3659':'wotif','1699':'tripadvisor_india','3656':'Fab_api','3657':'treebo_API','1690':'mrandmrssmith','138':'wyndham','1277':'tablehotels','319':'secure_rezovation','155':'bookassit','287':'verticalbooking','318':'thinkreservations','328':'travel_republic','48':'resontheweb','289':'innroad','183':'choice_hotel','149':'uk2_roomlynx','375':'myhotelreservation','374':'booklogic','366':'almadelpacifico_com','364':'casacondebeach_com','331':'luxburyinn_com','329':'roombahotel_com','330':'theadmiraltyinn_com','356':'unicoilodge_com','365':'xandari_com','355':'zincksinn_com','311':'tickets','297':'paytm','260':'traveljumia','-325':'seekda','324':'tripadvisor','315':'secure','316':'blastnessbooking','306':'travelok','310':'pegipegi','311':'tickets','281':'kayak','282':'trivago_ebbean','283':'google','284':'tripadvisor_ebbean','2':'booking','108':'laquinta','83':'hilton','1':'expedia','34':'priceline','204':'americasinn','134':'motel6','5':'agoda','12':'hotelcom','116':'hrs','35':'orbitz','6':'travelguru','3':'mmt','4':'cleartrip','7':'goibibo','269':'laterooms','270':'splendia','272':'thinkhotels','271':'bestday','280':'pricetravel','262':'hostel','296':'lastminuite','261':'yatra_ebbean','298':'via_ebbean','322':'travel_rakuten','323':'Ctrip_ebbean','274':'adantehotel_API','274':'adantehotel_API','333':'airtelplaza_API','342':'andrewjacksonhotel_API','346':'banffhighcountryinn_API','358':'beachcomberresort_API','350':'casasdelxvi_API','334':'Cody_API','351':'Hallmark_Inn_API','332':'Lepavillon_API','348':'rundlestone_API','347':'soleontheocean_API','349':'warwickwa_API','357':'ranch_API','341':'t23hotel_API','345':'adelaidemeridien','339':'basecamphotels','338':'bhotelsandresorts','340':'cocokeyorlando','360':'crystalbeachsuites','359':'grandcasebeachclub','343':'grandhotelorlando','361':'lakeblackshearresort','353':'montreal_gouverneur','362':'oban','337':'OLDKINDERHOOK','336':'rixos','363':'schlitterbahn','335':'solipanema','354':'tcbeaches','344':'thekenthotel','352':'webersinn','373':'roma_lifestyle_hotel','369':'starhotels_michelangel_rome','372':'the_church_palace','371':'ihg','37':'ihg','368':'nh_hotels_carpe','367':'nh_hotels_giust'}
								if jdata.has_key(str(websitecode)):
									source =  jdata[str(websitecode)]
									print source
									exp = __import__("aiworker."+source, globals(), locals(), "fetchrates", -1)
									res_body = exp.fetchrates(url,hotelcode,refid,proxy)					
							res_body = json.loads(res_body)
							statusresult = filter(lambda obj: (200 if str(obj['statuscode']) == '' else (int(str(obj['statuscode'])) + 200)) > 203 and (200 if str(obj['statuscode']) == '' else (int(str(obj['statuscode'])) + 200)) <= 206 or  (200 if str(obj['statuscode']) == '' else (int(str(obj['statuscode'])) + 200)) == 209, res_body)
							if len((statusresult)) > 0:
								proxy = getProxy(proxy,pos,websitecode)
							else:
								_rerun = 4
							#print "printing ==",res_body
							#print "queueid ===",queueid
							#firedata = firebase.post('https://aifirestore.firebaseio.com/queuerates/'+str(c_date)+'/'+str(queueid)+'/', res_body)
							#print "Firedata ==",firedata
						resultq.append({"resp": res_body, "message": message})
						#for resp_body in res_body:
						#	cursor = conn.cursor()					
						#	cursor.execute("insert into queuerates(queueid,hotelcode,subjecthotelcode,websitecode,dtcollected,ratedate,los,guests,roomtype,onsiterate,netrate,currency,ratedescription,ratetype,sourceurl,roomamenities,maxoccupancy,ispromo,closed,checkin,checkout,discount,promoname,searchkeyword,roomtypecode,conditionscode,mealplancode,status_code,taxstatus,taxtype,taxamount,region,pos,proxyused,debugid,israteperstay,snapshoturl) values (%s,%s,%s,%s,now(),%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)",(queueid,hotelcode,subjecthotelcode,websitecode,RateDate,Los,resp_body['guests'],resp_body['roomtype'],resp_body['onsiterate'],resp_body['netrate'],resp_body['curr'],resp_body['roomdescription'],resp_body['ratetype'],resp_body['url'],resp_body['roomamenity'],resp_body['maxocp'],resp_body['isprom'],resp_body['closed_up'],checkin,checkout,resp_body['netrate'],resp_body['promotion'],searchkeyword,roomtypecode,conditionscode,mealplancode,200 if resp_body['statuscode'] == '' else int(resp_body['statuscode']) + 200,resp_body['taxstatus'],resp_body['taxtype'],resp_body['taxamount'],resp_body['region'],pos,proxy,refid,resp_body['israteperstay'],snapshoturl,))
						#	cursor.close()
						#conn.commit()
						#statusresult = filter(lambda obj: (200 if obj['statuscode'] == '' else (int(obj['statuscode']) + 200)) > 203, res_body)
						#if len(statusresult) <= 0:
						#	receipt_handle = message['ReceiptHandle']
						#	sqs.delete_message(QueueUrl=queue_url, ReceiptHandle=receipt_handle)
						return
		
					_emsg = 0
					for message in response["Messages"]:
						runmsg(message)
					#threads = [threading.Thread(target=runmsg, args=(message,)) for message in response["Messages"]]
		
					#for thread in threads:
					#	thread.start()
					#for thread in threads:
					#	thread.join()
					_retryctr = 0
					while(_retryctr <= 3):
						_retryctr += 1
						try:
							conn =pymysql.connect(host=_dbhost,user=_dbuser,password=_dbpass,db=_dbname,charset='utf8mb4',cursorclass=pymysql.cursors.DictCursor)
							_retryctr = 4
						except Exception as e:
							pass
					try:
						#conn =pymysql.connect(host='rmapi-cluster.cluster-cj3numypvgef.us-west-2.rds.amazonaws.com',user='root',password='SpY&76aJ',db='rmapi',charset='utf8mb4',cursorclass=pymysql.cursors.DictCursor) 
						conn.threadsafety = 3
						for _result in resultq:
							res_body = _result["resp"]
							message = _result["message"]
							row = json.loads(message["Body"])
							subjecthotelcode=None
							searchkeyword=None
							roomtypecode=None
							conditionscode=None
							mealplancode=None
							hotelcode=row["hotelcode"]
							proxy=row["proxy"]
							url=row["url"]
							websitecode=row["websitecode"]
							queueid=row["queueid"]
							refid=row["debugid"]
							pos=row["pos"]
							snapshoturl=row["snapshoturl"]
							checkin=row["checkin"]
							checkout=row["checkout"]
							roomamenity = None
							
							Los=row["los"]
							RateDate=checkin
							#print "resp_body =",res_body
							try:
								array=[]
								for resp_body in res_body:
									if resp_body['statuscode'] == '': 
										roomamenity = resp_body['roomamenity']+"\nMeal Inclusion: "+ resp_body['mealinclusion']
										conditionscode = conditioncode(str(resp_body['roomtype']) + str(resp_body['roomdescription'])+str(resp_body['ratetype']) + str(roomamenity) +str(resp_body['taxtype']))
										roomtypecode = roomcode(str(resp_body['roomtype']) + str(resp_body['roomdescription'])+str(resp_body['ratetype']) + str(roomamenity) +str(resp_body['taxtype']))
										mealplancode = mealcode(str(resp_body['roomtype']) + str(resp_body['roomdescription'])+str(resp_body['ratetype']) + str(roomamenity) +str(resp_body['taxtype']))
										#print " codes == ",roomtypecode, conditionscode, mealplancode
									cursor = conn.cursor()				
									cursor.execute("insert into queuerates(queueid,hotelcode,subjecthotelcode,websitecode,dtcollected,ratedate,los,guests,roomtype,onsiterate,netrate,currency,ratedescription,ratetype,sourceurl,roomamenities,maxoccupancy,ispromo,closed,checkin,checkout,discount,promoname,searchkeyword,roomtypecode,conditionscode,mealplancode,status_code,taxstatus,taxtype,taxamount,region,pos,proxyused,debugid,israteperstay,snapshoturl) values (%s,%s,%s,%s,now(),%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)",(queueid,hotelcode,subjecthotelcode,websitecode,RateDate,Los,resp_body['guests'],resp_body['roomtype'],resp_body['onsiterate'],resp_body['netrate'],resp_body['curr'],resp_body['roomdescription'],resp_body['ratetype'],resp_body['url'],roomamenity,resp_body['maxocp'],resp_body['isprom'],resp_body['closed_up'],checkin,checkout,resp_body['disc'],resp_body['promotion'],searchkeyword,roomtypecode,conditionscode,mealplancode,200 if resp_body['statuscode'] == '' else int(resp_body['statuscode']) + 200,resp_body['taxstatus'],resp_body['taxtype'],resp_body['taxamount'],resp_body['region'],pos,proxy,refid,resp_body['israteperstay'],snapshoturl,))
									#fdata = {queueid = queueid,hotelcode = 	hotelcode,subjecthotelcode=subjecthotelcode,websitecode=websitecode,dtcollected=datetime.datetime.now(),ratedate=RateDate,los=Los,guests=resp_body['guests'],roomtype=resp_body['roomtype'],onsiterate=resp_body['onsiterate'],netrate=resp_body['netrate'],currency=resp_body['curr'],ratedescription=resp_body['roomdescription'],ratetype=resp_body['ratetype'],sourceurl=resp_body['url'],roomamenities=roomamenity,maxoccupancy=resp_body['maxocp'],ispromo=resp_body['isprom'],closed=resp_body['closed_up'],checkin=checkin,checkout=checkout,discount=resp_body['disc'],promoname=resp_body['promotion'],searchkeyword=searchkeyword,roomtypecode=roomtypecode,conditionscode=conditionscode,mealplancode=mealplancode,status_code=200 if resp_body['statuscode'] == '' else int(resp_body['statuscode']) + 200,taxstatus=resp_body['taxstatus'],taxtype=resp_body['taxtype'],taxamount=resp_body['taxamount'],region=resp_body['region'],pos=pos,proxyused=proxy,debugid=refid,israteperstay=resp_body['israteperstay'],snapshoturl=snapshoturl }
									#fdata={'queueid':queueid,'hotelcode':hotelcode,'subjecthotelcode':subjecthotelcode,'websitecode':websitecode,'dtcollected':datetime.datetime.now(),'ratedate':RateDate,'los':int(Los),'guests':resp_body['guests'],'roomtype':resp_body['roomtype'],'onsiterate':resp_body['onsiterate'],'netrate':resp_body['netrate'],'currency':resp_body['curr'],'ratedescription':resp_body['roomdescription'],'ratetype':resp_body['ratetype'],'sourceurl':resp_body['url'],'roomamenities':roomamenity,'maxoccupancy':resp_body['maxocp'],'ispromo':resp_body['isprom'],'closed':resp_body['closed_up'],'checkin':checkin,'checkout':checkout,'discount':resp_body['disc'],'promoname':resp_body['promotion'],'searchkeyword':searchkeyword,'roomtypecode':roomtypecode,'conditionscode':conditionscode,'mealplancode':mealplancode,'status_code':200 if resp_body['statuscode'] == '' else int(resp_body['statuscode']) + 200,'taxstatus':resp_body['taxstatus'],'taxtype':resp_body['taxtype'],'taxamount':resp_body['taxamount'],'region':resp_body['region'],'pos':pos,'proxyused':proxy,'debugid':refid,'israteperstay':resp_body['israteperstay'],'snapshoturl':snapshoturl}
									#array.append(fdata)
									#firebase.post("https://aifirestore.firebaseio.com/queuerates/{date}/{qid}/".format(date=datetime.datetime.now().strftime("%Y%m%d"), qid=queueid), array)
									cursor.close()
								conn.commit()
								conn.close()
								#firebase.post("https://aifirestore.firebaseio.com/queuerates/{date}/{qid}/".format(date=datetime.datetime.now().strftime("%Y%m%d"), qid=queueid), array)
								receipt_handle = message['ReceiptHandle']
								sqs.delete_message(QueueUrl=queue_url, ReceiptHandle=receipt_handle)
							except botocore.errorfactory.ClientError as e: 
								if e.response["Error"]["Code"] == "AWS.SimpleQueueService.NonExistentQueue":
									_run = False
									pass
								else:
									expstr = "[001] - {queueid}, {msg}, {trace}".format(queueid=queueid, msg=e, trace=traceback.format_exc())
									resd = logclient.describe_log_streams(logGroupName="rmapi", logStreamNamePrefix="scheduler")
									token = resd["logStreams"][0]['uploadSequenceToken']
									#logclient.put_log_events(logGroupName="rmapi", logStreamName="scheduler", logEvents=[{'timestamp':int(round(time.time() * 1000)),'message': expstr }], sequenceToken = token)
									#sqs.change_message_visibility(QueueUrl=queue_url,ReceiptHandle=receipt_handle,VisibilityTimeout=0)
								pass
							except Exception, e:
								expstr = "[002] - {queueid}, {msg}, {trace}".format(queueid=queueid, msg=e, trace=traceback.format_exc())
								resd = logclient.describe_log_streams(logGroupName="rmapi", logStreamNamePrefix="scheduler")
								token = resd["logStreams"][0]['uploadSequenceToken']
								#logclient.put_log_events(logGroupName="rmapi", logStreamName="scheduler", logEvents=[{'timestamp':int(round(time.time() * 1000)),'message': expstr }], sequenceToken = token)
								#sqs.change_message_visibility(QueueUrl=queue_url,ReceiptHandle=receipt_handle,VisibilityTimeout=0)
								pass
						
					except Exception as e: 
						expstr = "[003] - {queueid}, {msg}, {trace}".format(queueid=queueid, msg=e, trace=traceback.format_exc())
						resd = logclient.describe_log_streams(logGroupName="rmapi", logStreamNamePrefix="scheduler")
						token = resd["logStreams"][0]['uploadSequenceToken']
						#logclient.put_log_events(logGroupName="rmapi", logStreamName="scheduler", logEvents=[{'timestamp':int(round(time.time() * 1000)),'message': expstr }], sequenceToken = token)
						#sqs.change_message_visibility(QueueUrl=queue_url,ReceiptHandle=receipt_handle,VisibilityTimeout=0)
						pass
				else:
					#requests.post("{updurl}/{qid}".format(updurl=_updurl, qid=queueid))
					#requests.post("http://api.ratemetrics.com/queueupdate/{qid}".format(qid=queueid))
					_emsg += 1
					if (_emsg > 4):
						_run = False
			except botocore.errorfactory.ClientError as e: 
				if e.response["Error"]["Code"] == "AWS.SimpleQueueService.NonExistentQueue":
					_run = False
					pass
				else:
					expstr = "[004] - {queueid}, {msg}, {trace}".format(queueid=queueid, msg=e, trace=traceback.format_exc())
					resd = logclient.describe_log_streams(logGroupName="rmapi", logStreamNamePrefix="scheduler")
					token = resd["logStreams"][0]['uploadSequenceToken']
					#logclient.put_log_events(logGroupName="rmapi", logStreamName="scheduler", logEvents=[{'timestamp':int(round(time.time() * 1000)),'message': expstr }], sequenceToken = token)
					#sqs.change_message_visibility(QueueUrl=queue_url,ReceiptHandle=receipt_handle,VisibilityTimeout=0)
					
			except KeyboardInterrupt:
				_run = False
				pass
			except Exception as e:
				expstr = "[005] - {queueid}, {msg}, {trace}".format(queueid=queueid, msg=e, trace=traceback.format_exc())
				resd = logclient.describe_log_streams(logGroupName="rmapi", logStreamNamePrefix="scheduler")
				token = resd["logStreams"][0]['uploadSequenceToken']
				#logclient.put_log_events(logGroupName="rmapi", logStreamName="scheduler", logEvents=[{'timestamp':int(round(time.time() * 1000)),'message': expstr }], sequenceToken = token)
				#sqs.change_message_visibility(QueueUrl=queue_url,ReceiptHandle=receipt_handle,VisibilityTimeout=0)
				pass	
		_run = False
		requests.post("{updurl}/{qid}".format(updurl=_updurl, qid=queueid))
		expstr = "[006] - {queueid}, {msg}".format(queueid=queueid, msg='Exited from sqs_run_task')
		resd = logclient.describe_log_streams(logGroupName="rmapi", logStreamNamePrefix="scheduler")
		token = resd["logStreams"][0]['uploadSequenceToken']
		#logclient.put_log_events(logGroupName="rmapi", logStreamName="scheduler", logEvents=[{'timestamp':int(round(time.time() * 1000)),'message': expstr }], sequenceToken = token)
		return 
	except Exception as e:
		if e.response["Error"]["Code"] != "AWS.SimpleQueueService.NonExistentQueue":
			expstr = "[007] - {queueid}, {msg}, {trace}".format(queueid=queueid, msg=e, trace=traceback.format_exc())
			resd = logclient.describe_log_streams(logGroupName="rmapi", logStreamNamePrefix="scheduler")
			token = resd["logStreams"][0]['uploadSequenceToken']
			logclient.put_log_events(logGroupName="rmapi", logStreamName="scheduler", logEvents=[{'timestamp':int(round(time.time() * 1000)),'message': expstr }], sequenceToken = token)
			#sqs.change_message_visibility(QueueUrl=queue_url,ReceiptHandle=receipt_handle,VisibilityTimeout=0)
		print "error in aitask ==",e








