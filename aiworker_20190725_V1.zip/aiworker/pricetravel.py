# -*- coding: utf-8 -*-
import re
import requests
import datetime
import json
import sys 
import boto
import random
import gc

import aws_insert


def fetchrates(url ,inputid, id_update, proxyip):
	#print url
	israteperstay = ''
	if re.search(r'CheckIn=(\d+.*?)&',url):
		CheckIn=re.search(r'CheckIn=(\d+.*?)&',url).group(1) 
	Referer=re.sub(r'hotelCheckIn=(.*?)&','hotelCheckIn='+CheckIn+'&',url)
	##print Referer
	array = []
	try:
		RateDate=''
		region=''
		intime=re.sub(r'\s','T',str(datetime.datetime.now()))
		functionname='PriceTravel'
		Domainname=functionname
		Websitecode='280'
		conn = boto.connect_s3(aws_access_key_id= 'AKIAIXEGZVXCWE2FV3SQ',aws_secret_access_key = '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') 
		bucket = conn.get_bucket("rmapi")
		StartDate = datetime.date.today()
		EndDate  = datetime.date.today() + datetime.timedelta(days=29)
		proxies = {"http": "http://{}".format(proxyip)}
		name_regex=r'http://www.pricetravel.com/(.*?)/'
		name_re=re.search(name_regex,Referer)
		if name_re:
			name=name_re.group(1)
		delta = datetime.datetime.strptime(re.search(r"CheckOut=(.*?)&", url).group(1), "%Y-%m-%d") - datetime.datetime.strptime(re.search(r"CheckIn=(.*?)&", url).group(1), "%Y-%m-%d")
		LOS = delta.days
		CheckIn_regex=r'CheckIn=(\d+.*?)&'
		CheckIn_re=re.search(CheckIn_regex,Referer)
		if CheckIn_re:
			CheckIn=CheckIn_re.group(1)  			
		CheckOut_regex=r'CheckOut=(\d+.*?)&'
		CheckOut_re=re.search(CheckOut_regex,Referer)
		if CheckOut_re:
			CheckOut=CheckOut_re.group(1)     		
		placeId_regex=r'placeId=(.*?)&'
		placeId_re=re.search(placeId_regex,Referer)
		if placeId_re:
			placeId=placeId_re.group(1)
		placeType_regex=r'&placeType=(\d+.*?)'
		placeType_re=re.search(placeType_regex,Referer)
		if placeType_re:
			placeType=placeType_re.group(1)
		RateDate= CheckIn
		
		url = 'http://www.pricetravel.com.mx/roomsSection?hotelUri='+name+'&isPackage=true'
		refer='http://www.pricetravel.com.mx/'+name+'/hotel-detalle?CheckIn='+CheckIn+'&CheckOut='+CheckOut+'&Rooms=1&Room1.Adults=1&Room1.Kids=0&Room1.AgeKids=&Adults=1&Kids=0&AgeKids=&Source=HotelList&IsPackage=false&placeId='+placeId+'&placeType='+placeType+''	
		payload = {'CheckIn':''+CheckIn+'','CheckOut':''+CheckOut+'','checkInWasModified':'False','checkInWasModifiedFromUser':'False','prevSelectedOutboundFlight':'','prevSelectedReturnFlight':'','hotelCheckIn':''+CheckIn+'','Rooms':'1','Room1.Adults':'1','Room1.Kids':'0','Room1.AgeKids':'','Adults':'1','Kids':'0','AgeKids':'','QuoteList':'False','placeId':''+placeId+'','placeType':''+placeType+'','idHotel':'0','idRoom':'','idRate':'','Source':'Rooms','isPackage':'False','tripMode':'','tripCabin':'','lastPackageRate':'0','HotelNameSearch':'','pageHotelList':'0','ChainId':'0','selectedFilter':'','showingMapContainer':'0','IdAgentcall':'','referralDisplay':'','referralUrl':'','avgRateFromHeader':'0'}	
		head = {'Host': 'www.pricetravel.com.mx', 'User-Agent':'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:12.0) Gecko/20100101 Firefox/48.0', 'X-Requested-With': 'XMLHttpRequest','Accept':'application/json, text/javascript, */*; q=0.01','Accept-Language':'en-US,en;q=0.5','Accept-Encoding':'gzip, deflate','Referer': refer}		
		url_insert=refer
		try:
			response = requests.post(url, data=payload, headers=head,timeout=50)
		except Exception,e:	
			try:
				response = requests.post(url, data=payload, headers=head,timeout=50)
			except Exception,e:
				value_error=str(re.sub("'",'"',str(e)))
				stacktrace=sys.exc_traceback.tb_lineno
				keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(Websitecode,datetime.datetime.now(),id_update)
				key = bucket.new_key(keyvalue)
				key.set_contents_from_string(str(e))
				region=''
				ip=re.sub(r"\{'.*?@|'\}|:\d+","",str(proxies))
				try:
					try:
						r = requests.get('http://freegeoip.net/json/'+ip,timeout=30)
					except Exception,e:
						r = requests.get('http://freegeoip.net/json/'+ip,timeout=30)
					js = r.json()
					region=js['country_name']
				except Exception,e:
					region=''
				statuscode=5
				Guests='1'
				array.append(aws_insert.insert(id_update, inputid ,functionname,Websitecode, "","", "", "", Guests, "", "", "", "", "","", "", "", "", "", "", "", "", "",StartDate, EndDate , "", "", "", "", "", "", "", "", "",region,statuscode, israteperstay))
				return json.dumps(array)
		if (response.status_code <> 200):
			random_proxy=['media:M3diAproxy@155.94.165.12:80','media:M3diAproxy@107.175.67.126:80','media:M3diAproxy@155.94.165.237:80','media:M3diAproxy@165.231.24.13:80','media:M3diAproxy@107.175.67.87:80','media:M3diAproxy@23.231.99.37:80','media:M3diAproxy@23.231.99.91:80']
			proxyy=random.choice(random_proxy)
			proxies = {"http": "http://{}".format(proxyy)}			
			response = requests.post(url, data=payload, headers=head,proxies=proxies)
		if (response.status_code == 403 or response.status_code == 407 or response.status_code <> 200):
			try:
				random_proxy=['media:M3diAproxy@155.94.165.12:80','media:M3diAproxy@107.175.67.126:80','media:M3diAproxy@155.94.165.237:80','media:M3diAproxy@165.231.24.13:80','media:M3diAproxy@107.175.67.87:80','media:M3diAproxy@23.231.99.37:80','media:M3diAproxy@23.231.99.91:80']
				proxyy=random.choice(random_proxy)
				proxies = {"http": "http://{}".format(proxyy)}	
				response = requests.post(url, data=payload, headers=head,proxies=proxies)
			except Exception,e:
				value_error=str(re.sub("'",'"',str(e)))		
				stacktrace=sys.exc_traceback.tb_lineno
				region=''
				ip=re.sub(r"\{'.*?@|'\}|:\d+","",str(proxies))
				try:
					try:
						r = requests.get('http://freegeoip.net/json/'+ip,timeout=30)
					except Exception,e:
						r = requests.get('http://freegeoip.net/json/'+ip,timeout=30)
					js = r.json()
					region=js['country_name']
				except Exception,e:
					region=''
				statuscode=5
				Guests='1'
				keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(Websitecode,datetime.datetime.now(),id_update)
				key = bucket.new_key(keyvalue)
				key.set_contents_from_string(str(e))
				array.append(aws_insert.insert(id_update, inputid ,functionname,Websitecode, "","", "", "", Guests, "", "", "", "", "",url, url, url, "", "", "", "", "", "",StartDate, EndDate , "", "", "", "", "", "", "", "", "",region,statuscode, israteperstay))
				return json.dumps(array)   		
		jval =response.text.encode('ascii','ignore')
		jsonvalue = json.loads(jval)
		Rtdate=re.sub(r'-|\-','',str(RateDate))
		keyvalue = "ondemand/{}/{:%Y%m%d}/source/{}.json".format(Websitecode,datetime.datetime.now(),str(inputid)+'_'+str(Rtdate)+'_'+id_update)
		key = bucket.new_key(keyvalue)
		key.set_contents_from_string(response.text)
		Roomtype=''
		Guests='1'
		Currencycode=''
		RoomDescp=''
		Maxocp=''
		ispromupdate=''
		Roomavilable=''
		Taxtype=''
		Taxamount=''
		Spaceblock=''
		Ratetype=''
		Tax_status=''
		promotion=''
		statuscode=''
		OnsiteRate=''
		net_rate=''
		Mealtype=''
		RoomAmenityType=''
		region=''
		ip=re.sub(r"\{'.*?@|'\}|:\d+","",str(proxies))
		try:
			try:
				r = requests.get('http://freegeoip.net/json/'+ip,timeout=30)
			except Exception,e:
				r = requests.get('http://freegeoip.net/json/'+ip,timeout=30)
			js = r.json()
			region=js['country_name']
		except Exception,e:
			region=''
		if 'roomsData' in jsonvalue:
			Closed_up='N'
			for block2 in jsonvalue['roomsData']['HotelRoomTemplateModel']:
				Roomtype=''
				RoomAmenityType=''
				Ratetype=''
				promotion=''
				statuscode=''
				OnsiteRate=''
				net_rate=''
				Mealtype=''
				Roomtype=block2['DefaultSection']['name']
				RoomAmenityType=block2['DefaultSection']['Amenities']
				##print block2
				if 'rate_end' in str(block2):
					for block1 in block2['RateSection']:
						##print "Hello"
						Ratetype=''
						promotion=''
						statuscode=''
						OnsiteRate=''
						net_rate=''
						Mealtype=''
						OnsiteRate1=block1['rate_end']
						OnsiteRate=OnsiteRate1
						if OnsiteRate == None:
							OnsiteRate=0
							Closed_up='Y'
						else:
							OnsiteRate1=block1['rate_end']
							OnsiteRate = re.sub(r"\$","",OnsiteRate1) 
							OnsiteRate = re.sub(r",","",OnsiteRate)
							Closed_up='N' 
						if "$" in str(OnsiteRate1):
							Currencycode='USD'
						else:
							Currencycode=''
						net_rate=block1['rate_noDisc']
						if net_rate == None:
							net_rate=0
							ispromupdate='N'
						else:    
							net_rate=block1['rate_noDisc'] 
							net_rate = re.sub(r"\$","",net_rate)
							net_rate = re.sub(r",","",net_rate)
							##print "NetRate",NetRate
						Mealtype=block1['mealPlan']
						Ratetype=block1['rateAvgMsg']
						if str(OnsiteRate)=='0' or OnsiteRate==0 or OnsiteRate=='':
							Closed_up='Y'
							statuscode='1'
						else:
							Closed_up='N'
							statuscode=''
							if LOS>1:
								israteperstay = 'N'
							else:
								israteperstay = 'Y'
						array.append(aws_insert.insert(id_update, inputid , Domainname, Websitecode, StartDate, Roomtype, LOS, RateDate, Guests, OnsiteRate, net_rate, OnsiteRate, Currencycode, RoomDescp, url_insert, url_insert, url_insert, RoomAmenityType, Mealtype, Maxocp, ispromupdate, Closed_up,30, StartDate , EndDate, intime, Roomavilable, Taxtype, Taxamount, Tax_status, Spaceblock, Ratetype, net_rate,promotion,region,statuscode, israteperstay))
				else:
					#print "Else"
					Closed_up='Y'
					statuscode='1'
					##print (id_update, inputid , Domainname, Websitecode, StartDate, Roomtype, LOS, RateDate, Guests, OnsiteRate, net_rate, OnsiteRate, Currencycode, RoomDescp, url, url, url, RoomAmenityType, Mealtype, Maxocp, ispromupdate, Closed_up,30, StartDate , EndDate, intime, Roomavilable, Taxtype, Taxamount,  Spaceblock, Ratetype, net_rate,promotion,statuscode)
					array.append(aws_insert.insert(id_update, inputid , Domainname, Websitecode, StartDate, Roomtype, LOS, RateDate, Guests, OnsiteRate, net_rate, OnsiteRate, Currencycode, RoomDescp, url_insert, url_insert, url_insert, RoomAmenityType, Mealtype, Maxocp, ispromupdate, Closed_up,30, StartDate , EndDate, intime, Roomavilable, Taxtype, Taxamount,Tax_status, Spaceblock, Ratetype, net_rate,promotion,region,statuscode, israteperstay))
					return json.dumps(array)	
		else:
			#print "Else"
			Closed_up='Y'
			statuscode='2'
			##print (id_update, inputid , Domainname, Websitecode, StartDate, Roomtype, LOS, RateDate, Guests, OnsiteRate, net_rate, OnsiteRate, Currencycode, RoomDescp, url, url, url, RoomAmenityType, Mealtype, Maxocp, ispromupdate, Closed_up,30, StartDate , EndDate, intime, Roomavilable, Taxtype, Taxamount,  Spaceblock, Ratetype, discount_rate,promotion,statuscode)
			array.append(aws_insert.insert(id_update, inputid , Domainname, Websitecode, StartDate, Roomtype, LOS, RateDate, Guests, OnsiteRate, net_rate, OnsiteRate, Currencycode, RoomDescp, url_insert, url_insert, url_insert, RoomAmenityType, Mealtype, Maxocp, ispromupdate, Closed_up,30, StartDate , EndDate, intime, Roomavilable, Taxtype, Taxamount, Tax_status, Spaceblock, Ratetype, net_rate,promotion,region,statuscode, israteperstay))
		keyvalue = "ondemand/{}/{:%Y%m%d}/delivery/{}.json".format(Websitecode,datetime.datetime.now(),str(inputid)+'_'+str(Rtdate)+'_'+id_update)
		key = bucket.new_key(keyvalue)
		key.set_contents_from_string(json.dumps(array))
		gc.collect()
		return json.dumps(array)		
	except Exception as e:
		value_error=str(re.sub(r"'",'"',str(e)))
		stacktrace=sys.exc_traceback.tb_lineno
		#print value_error,stacktrace
		Guests ='1'
		insert_value_error=str(value_error)+'Where line number '+str(stacktrace)+str(proxyip)
		statuscode='4'
		keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(Websitecode,datetime.datetime.now(),id_update)
		key = bucket.new_key(keyvalue)
		key.set_contents_from_string(insert_value_error)
		array.append(aws_insert.insert(id_update, inputid ,functionname,Websitecode, "","", "", "", Guests, "", "", "", "", "",url_insert, url_insert, url_insert, "", "", "", "", "", "",StartDate, EndDate , "", "", "", "", "", "", "", "", "",region,statuscode, israteperstay))
		return json.dumps(array)	
