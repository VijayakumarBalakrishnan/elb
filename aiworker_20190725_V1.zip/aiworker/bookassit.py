# -*- coding: utf-8 -*-
import re
import requests
import datetime
import json
import gc
import boto
import sys

import aws_insert
def fetchrates(url ,inputid, id_update, proxyip):
    array      = []
    israteperstay=''
    proxies    = {"http": "http://{}".format(proxyip)}
    intime     = re.sub(r'\s','T',str(datetime.datetime.now()))
    Domainname ='LOCHGREEN HOUSE'
    Websitecode='155'
    region     =''
    statuscode =''
    Mealtype   =''
    conn       = boto.connect_s3(aws_access_key_id= 'AKIAIXEGZVXCWE2FV3SQ',aws_secret_access_key = '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') 
    bucket     = conn.get_bucket("rmapi")
    StartDate  = datetime.date.today()
    EndDate    = datetime.date.today() + datetime.timedelta(days=29)
    try:
        CheckIn_Check_OT_re = re.search(r'Checkin=(.*?)&Checkout=(.*?)&',url)
        if CheckIn_Check_OT_re:
            Checkin = CheckIn_Check_OT_re.group(1)
            CheckOT = CheckIn_Check_OT_re.group(2)
        else:
            Checkin = ''
            CheckOT = ''
        RateDate = Checkin
        delta    = datetime.datetime.strptime(str(CheckOT), "%Y-%m-%d") - datetime.datetime.strptime(Checkin, "%Y-%m-%d")
        LOS      = delta.days
        RoomType = ''
        Guests   = re.search(r'adults=(\d+)',url).group(1)
        Ratetype = ''
        RateDescription = ''
        Meal     = ''
        Taxtype  = ''
        MaxOccupancy  = None
        isPromotionalRate  = 'N'
        Closed   = 'Y'
        NetRate  = 0
        Taxstatus= -1
        TaxAmount= 0
        Discount = 0
        GrossRate= 0
        OnsiteRate = 0
        Promotion_Name= ''
        isAvailable = ''
        RoomAmenity_Type = ''
        inMonth_re = re.search(r'Checkin=(\d+)-(\d+)-(\d+)&Checkout=(\d+)-(\d+)-(\d+)&',url)
        if inMonth_re:
            inYear  = inMonth_re.group(1)            
            inMonth = inMonth_re.group(2)
            inDay   = inMonth_re.group(3)
            otYear  = inMonth_re.group(4)            
            otMonth = inMonth_re.group(5)
            otDay   = inMonth_re.group(6)            
        else:
            inMonth = ""
            inDay   = ''
            inYear  = '' 
        currency_reg = re.search(r'user_currency=(.*?)&',url)
        if currency_reg:
            Curr = currency_reg.group(1)
        url        = 'http://www.bookassist.com/cb/c_1.jsp?pr=false&rpt86767=0&user_currency='+str(Curr)+'&rpt86768=0&rpt86769=0&from_page=c_1.jsp&hotel_id=1229&hotel_id=1229&user_language=en&infants=0&outday='+str(otDay)+'&bp=http://www.lochgreenhouse.com/local/bookassist/?hotel_id=1229&rpt18330=0&inday='+str(inDay)+'&vgo4720=0&rpt86697=0&rpt87501=0&rpt87524=0&rpt87525=0&rpt87526=0&rpt87527=0&rpt87528=0&rpt51547=0&vgt6847=0&rpt51546=0&vgt4720=0&vgo6847=1&rpt86479=0&cp=/conduit/c_1.jsp&service_model=2&outmonthyear='+str(otYear)+'-'+str(otMonth)+'&set_curr_menu=0&vgo9022=1&vgo9023=1&action=c_1.jsp&inmonthyear='+str(inYear)+'-'+str(inMonth)+'&rpt86481=0&vgt9022=0&vgt9023=0&adults='+str(Guests)+'&rpt18329=1&guide_id=401&children=0'
        url_insert = url
        #print url
        proxyip = re.sub(r':.*','',str(proxyip))
        headers = {'User-Agent':'Mozilla/5.0 (X11; Linux i686; rv:45.0) Gecko/20100101 Firefox/45.0'}
        try:
            try:
                r = requests.get('http://freegeoip.net/json/' + proxyip, timeout=30)
            except Exception, e:
                r = requests.get('http://freegeoip.net/json/' + proxyip, timeout=30)
            js = r.json()
            region = js['country_name']
        except Exception, e:
            region = ''
        try:
            hml = requests.get(url,headers=headers,proxies=proxies,timeout=50)
        except Exception, e:
            value_error = str(re.sub("'", '', str(e)))
            stacktrace = sys.exc_traceback.tb_lineno
            try:
                hml = requests.get(url,headers=headers,proxies=proxies,timeout=50)
            except Exception, e:
                value_error = str(re.sub("'", '', str(e)))
                stacktrace = sys.exc_traceback.tb_lineno
                keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(Websitecode, datetime.datetime.now(), id_update)
                key = bucket.new_key(keyvalue)
                key.set_contents_from_string(str(e) + 'Where Line number' + str(stacktrace) + str(proxies))
                statuscode = 5
                Guests = ''
                array.append(aws_insert.insert(id_update, inputid , Domainname, Websitecode, "", "", "", "", Guests, "", "", "", "", "", url, url, url, "", "", "", "", "", "", StartDate, EndDate , "", "", "", "", "", "", "", "", "", region, statuscode,israteperstay))
                return json.dumps(array)
        if hml.status_code <> 200:
            hml = requests.get(url,headers=headers,proxies=proxies,timeout=50)
        if (hml.status_code == 403 or hml.status_code == 407) or hml.status_code <> 200:
            try:
                if hml.status_code <> 200:
                    hml = requests.get(url,headers=headers,timeout=50)
            except Exception, e:
                print e
                value_error = str(re.sub("'", '', str(e)))
                stacktrace = sys.exc_traceback.tb_lineno
                keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(Websitecode, datetime.datetime.now(), id_update)
                key = bucket.new_key(keyvalue)
                key.set_contents_from_string(str(e) + 'Where Line number' + str(stacktrace) + str(proxies))
                statuscode = 5
                Guests = ''
                array.append(aws_insert.insert(id_update, inputid , Domainname, Websitecode, "", "", "", "", Guests, "", "", "", "", "", url, url, url, "", "", "", "", "", "", StartDate, EndDate , "", "", "", "", "", "", "", "", "", region, statuscode,israteperstay))
                return json.dumps(array) 
        json_data = re.sub('amp;|&nbsp;|nbsp;','',hml.text.encode('utf-8'))
        Rtdate=re.sub(r'-|\-','',str(RateDate))
        keyvalue = "ondemand/{}/{:%Y%m%d}/source{}.html".format(Websitecode,datetime.datetime.now(),str(inputid)+'_'+str(Rtdate)+'_'+id_update)
        key = bucket.new_key(keyvalue)
        key.set_contents_from_string(hml.text.encode('utf-8'))
        if re.compile(r'<span id="packageTittle.*?</sc', re.DOTALL).findall(json_data):
            for mainblock in re.compile(r'<span id="packageTittle.*?</sc', re.DOTALL).findall(json_data):
                block_desc_code_re = re.search(r"packageTittle_(\d+)", mainblock)
                if block_desc_code_re:
                    block_desc_code = block_desc_code_re.group(1)
                else:
                    block_desc_code = ""
                for block in re.compile(r'<div class="variationStripTitle.*? dir="auto">.*?<!-- end of theVar_-->', re.DOTALL).findall(mainblock):
                    if  re.search(r'<div class="variationStripTitle.*?" dir="auto">(.*?)<', block):
                        RoomType = re.sub("'", "''", re.search(r'<div class="variationStripTitle.*?" dir="auto">(.*?)<', block).group(1))
                    else:
                        RoomType = ''
                    if re.search(r"(\d+).*?P", RoomType):
                        MaxOccupancy = re.search(r"(\d+).*?P", RoomType).group(1)
                    else:
                        MaxOccupancy = ''
                    if re.search(r'read more about">\s*(.*?)<', mainblock):
                        Ratetype = re.sub("'", "''", re.search(r'read more about">\s*(.*?)<', mainblock).group(1))  
                    else:
                        Ratetype = ''
                    if re.search(r'variationRoomStayPrice.*?>(\w.*?).*?&.*?;(.*?)</span> </div>\s*</div><!--book', block):
                        OnsiteRate = re.search(r'variationRoomStayPrice.*?>(\w.*?).*?&.*?;(.*?)</span> </div>\s*</div><!--book', block).group(2)
                    else:
                        OnsiteRate = 0
                    desc_reg = r'"description":\s*"(.*?)",\s*"num_vars": \d+,\s*"hotelId":\s*\d+,\s*"id": '+str(block_desc_code)+','
                    if re.search(desc_reg, json_data):
                        RateDescription =re.sub(r"<.*?>|\\r|\\n", r"",re.search(desc_reg, json_data).group(1))
                    else:
                        RateDescription = ''
                    if re.search(r'<ul.*?>(.*?)</ul', block):
                        Ameits_cln= re.sub(r'<strong>|</strong>','',re.search(r'<ul.*?>(.*?)</ul', block).group(1)) 
                        RoomAmeinties1 = re.sub(r"</li><li.*?>|</li> <li.*?>", r',', Ameits_cln)
                        RoomAmeinties1 = re.sub(r'^\s','',RoomAmeinties1)
                        RoomAmenity_Type  = re.sub(r'^<.*?>|<.*?>$','',RoomAmeinties1)  
                                          
                    else:
                        RoomAmenity_Type  = ''
                    Mealtypes = str(RateDescription)+' '+str(RoomType)+' '+str(RoomAmenity_Type)+' '+str(Ratetype)
                    if Mealtypes !=None:
                        Mealtype_str = str(Mealtypes)
                        if 'breakfast' in Mealtype_str.lower() and 'dinner' in Mealtype_str.lower()  and 'lunch' in Mealtype_str.lower():
                            Meal = 'Breakfast, Lunch and Dinner'
                        elif 'breakfast' in Mealtype_str.lower() and 'dinner' in Mealtype_str.lower():
                            Meal = 'Breakfast and dinner'
                        elif 'breakfast included' in Mealtype_str.lower():
                            Meal = 'Breakfast included'
                        elif 'BREAKFAST' in Mealtype_str:
                            Meal = 'Breakfast'
                        elif 'breakfast' in Mealtype_str.lower() and 'lunch' in Mealtype_str.lower():
                            Meal = 'Breakfast and Lunch'
                        elif 'Lunch' in Mealtype_str and 'Dinner' in Mealtype_str :
                            Meal = "Lunch and Dinner"
                        elif 'breakfast' in Mealtype_str.lower() and 'lunch' in Mealtype_str.lower() and 'dinner' in Mealtype_str.lower():
                            Meal = 'Breakfast, Lunch and dinner'
                        elif 'Break fast' in Mealtype_str:
                            Meal = 'BreakFast' 
                        elif 'breakfast' in Mealtype_str.lower():
                            Meal = 'BreakFast' 
                        elif 'halfboard' in Mealtype_str.lower():
                            Meal = 'Halfboard'
                        elif 'half board' in Mealtype_str.lower():
                            Meal = 'Half board' 
                        elif 'full board' in Mealtype_str.lower():
                            Meal = 'Full Board'
                        elif 'fullboard' in Mealtype_str.lower():
                            Meal = 'FullBoard'
                        elif 'All-Inclusive' in Mealtype_str:
                            Meal = 'All-Inclusive'
                        elif 'All Inclusive' in Mealtype_str:
                            Meal = 'All Inclusive'
                        elif 'All Meals' in Mealtype_str:
                            Meal = 'All Meals'
                        elif 'All Meal' in Mealtype_str:
                            Meal = 'All Meal'
                        else:
                            Meal = ''
                    else:
                        Meal = ''              
                    if OnsiteRate==0:
                        statuscode = 1
                        Closed='Y'
                    else:
                        statuscode = ''
                        Closed='N'
                    RoomAmenity_Type = re.sub('<.*?>', '', RoomAmenity_Type)
                    #print "RoomType :-",RoomType
                    #print "Ratetype :-",Ratetype
                    #print "RateDescription :-",RateDescription
                    #print "Amount   :-",OnsiteRate
                    #print "Prmotion :-",Promotion_Name
                    #print "MaxOccupancy:",MaxOccupancy
                    #print "isPromotionalRate  :-",isPromotionalRate
                    #print "NetRate  :-",NetRate
                    #print "Currency :-",Curr
                    #print "Discount :-",Discount
                    #print "MealType :-",Meal
                    #print "Closed   :-",Closed
                    #print "Taxstatus:-",Taxstatus
                    #print "status_cd:-",statuscode
                    GrossRate = OnsiteRate
                    Mealtype  = Meal
                    RateDate  = Checkin
                    #print "israteperstay :",israteperstay
                    #print "_"*30
                    israteperstay = 'Y'
                    array.append(aws_insert.insert(id_update, inputid , Domainname, Websitecode, StartDate, RoomType, LOS, RateDate, Guests, OnsiteRate, NetRate, GrossRate, Curr, RateDescription, url_insert, url_insert, url_insert, RoomAmenity_Type, Mealtype, MaxOccupancy, isPromotionalRate, Closed, 30, StartDate , EndDate, intime, isAvailable, Taxtype, TaxAmount, Taxstatus, None, Ratetype, Discount,Promotion_Name,region,statuscode,israteperstay))
        else:
            Closed     = 'Y'
            statuscode ='2'
            array.append(aws_insert.insert(id_update, inputid , Domainname, Websitecode, StartDate, RoomType, LOS, RateDate, Guests, OnsiteRate, NetRate, GrossRate, Curr, RateDescription, url_insert, url_insert, url_insert, RoomAmenity_Type, Mealtype, MaxOccupancy, isPromotionalRate, Closed, 30, StartDate , EndDate, intime, isAvailable, Taxtype, TaxAmount, Taxstatus, None, Ratetype, Discount,Promotion_Name,region,statuscode,israteperstay))
        Rtdate = re.sub(r'-|\-', '', str(RateDate))
        keyvalue = "ondemand/{}/{:%Y%m%d}/delivery/{}.json".format(Websitecode,datetime.datetime.now(),str(inputid)+'_'+str(Rtdate)+'_'+id_update)
        key = bucket.new_key(keyvalue)
        key.set_contents_from_string(json.dumps(array))
        return json.dumps(array)
        gc.collect()
    except Exception as e:
        print e
        value_error = str(re.sub(r"'", '"', str(e)))
        stacktrace = sys.exc_traceback.tb_lineno
        Guests = ''
        region = ''
        insert_value_error = str(value_error) + 'Where line number ' + str(stacktrace) + str(proxyip)
        statuscode = '4'
        keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(Websitecode, datetime.datetime.now(), id_update)
        key = bucket.new_key(keyvalue)
        key.set_contents_from_string(insert_value_error)
        array.append(aws_insert.insert(id_update, inputid , Domainname, Websitecode, "", "", "", "", Guests, "", "", "", "", "", url, url, url, "", "", "", "", "", "", StartDate, EndDate , "", "", "", "", "", "", "", "", "", region, statuscode,israteperstay))
        return json.dumps(array)


'''url       = 'http://www.bookassist.com/cb/c_1.jsp?pr=false&rpt86767=0&user_currency=USD&rpt86768=0&rpt86769=0&from_page=c_1.jsp&hotel_id=1229&hotel_id=1229&user_language=en&infants=0&outday=16&bp=http%3A%2F%2Fwww.lochgreenhouse.com%2Flocal%2Fbookassist%2F%3Fhotel_id%3D1229&rpt18330=0&inday=15&vgo4720=0&rpt86697=0&rpt87501=0&rpt87524=0&rpt87525=0&rpt87526=0&rpt87527=0&rpt87528=0&rpt51547=0&vgt6847=0&rpt51546=0&vgt4720=0&vgo6847=1&rpt86479=0&cp=%2Fconduit%2Fc_1.jsp&service_model=2&outmonthyear=2017-11&set_curr_menu=0&vgo9022=1&vgo9023=1&action=c_1.jsp&inmonthyear=2017-11&rpt86481=0&vgt9022=0&vgt9023=0&adults=2&rpt18329=1&guide_id=401&children=0#Checkin=2017-11-01&Checkout=2017-11-02&'
inputid   = 'Test'            
id_update = ''
proxyip   = '104.129.4.243:80'
fetchrates(url ,inputid, id_update, proxyip)'''
