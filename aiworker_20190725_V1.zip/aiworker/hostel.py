# -*- coding: utf-8 -*-
import re
import requests
import datetime
import json
import boto
import sys 
import random
from boto.s3.key import Key

#import arora_insert
import traceback
import aws_insert
from unidecode import unidecode


# inputid   = 'HostelWorld'
# url       = "https://www.hostelworld.com/hosteldetails.php/Atlantic-Point-Backpackers/Cape-Town/42860?dateFrom=2018-05-15&dateTo=2018-05-17&number_of_guests=1&sc_pos=1&currency=ZAR"
# id_update = 'Hostel'
# proxyip   = 'user-34068:214859b73da0e174@45.64.106.56:1212'

def fetchrates(url,inputid, id_update, proxyip):
	israteperstay = ''
	try:
		array = []
		conn = boto.connect_s3(aws_access_key_id= 'AKIAIXEGZVXCWE2FV3SQ',aws_secret_access_key = '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') 
		bucket = conn.get_bucket("rmapi")
		StartDate = datetime.date.today()
		EndDate  = datetime.date.today() + datetime.timedelta(days=29)
		RateDate = re.sub("http.*?dateFrom=|&dateTo=.*", "", url)
		##print "url	=",url
		Domainname = 'hostelworld'
		intime = re.sub(r'\s','T',str(datetime.datetime.now()))
		functionname=Domainname
		RoomType=''
		websitecode = 262
		OnsiteRate=0
		RoomDescp=''
		Currencycode = ''
		RoomAmenity_Type = ''
		RateType = ''
		Tax_status=''
		Meal = ''
		Closed_up='N'
		delta = datetime.datetime.strptime(re.search(r"dateTo=(.*?)&", url).group(1), "%Y-%m-%d") - datetime.datetime.strptime(re.search(r"dateFrom=(.*?)&", url).group(1), "%Y-%m-%d")
		LOS = delta.days
		Guests=''
		NetRate=0
		MaxOccupancy=''
		promotion=''
		statuscode=''
		region=''
		Isprom='N'
		Room_avb=''
		curl=''
		if re.search(r'&number_of_guests=(\d+)&',url):
			Guests=re.search(r'&number_of_guests=(\d+)&',url).group(1)
		else:
			Guests='1'
		proxies = {"https": "http://{}".format(proxyip)}
		try:
			curl = requests.get(url, headers={'User-Agent':'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:12.0) Gecko/20100101 Firefox/31.0'}, proxies = proxies,timeout=50)
		except ValueError as e:
			try:	
				curl = requests.get(url, headers={'User-Agent':'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:12.0) Gecko/20100101 Firefox/31.0'},proxies=proxies,timeout=50)
			except ValueError as e:
				value_error=str(re.sub("'",'"',str(e)))
				stacktrace=sys.exc_traceback.tb_lineno
				keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(websitecode,datetime.datetime.now(),id_update)
				key = bucket.new_key(keyvalue)
				key.set_contents_from_string(str(e))
				region=''
				ip=re.sub(r"\{'.*?@|'\}|:\d+","",str(proxies))
				try:
					try:
						r = requests.get('http://freegeoip.net/json/'+ip,timeout=30)
					except Exception,e:
						r = requests.get('http://freegeoip.net/json/'+ip,timeout=30)
					js = r.json()
					region=js['country_name']
				except Exception,e:
					region=''
				statuscode=5
				Guests='1'
				array.append(aws_insert.insert(id_update, inputid ,functionname,websitecode, "","", "", "", Guests, "", "", "", "", "",url, url, url, "", "", "", "", "", "",StartDate, EndDate , "", "", "", "", "", "", "", "", "",region,statuscode))
				return json.dumps(array)
		if curl.status_code <> 200:
			curl = requests.get(url, headers={'User-Agent':'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:12.0) Gecko/20100101 Firefox/31.0'},proxies=proxies)
		if (curl.status_code == 403 or curl.status_code == 407):
			curl = requests.get(url, headers={'User-Agent':'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:12.0) Gecko/20100101 Firefox/31.0'},proxies=proxies)
		##print curl.status_code
		if curl.status_code == 200:
			currency_source = curl.text
			Currency_reg  = re.search('propertyCurrency":"(.*?)"', currency_source)
			if Currency_reg:
				Currencycode = Currency_reg.group(1)
			else:
				Currencycode = ''
			##print "Currencycode	:",Currencycode
			Room_amnty_reg =  re.search(r'<ul class="facilities no-bullet">(.*?)</ul>',currency_source, re.DOTALL)
			if Room_amnty_reg:
				Room_amnty_group = re.sub("<.*?>", "", Room_amnty_reg.group(1))
				Room_amnty = re.sub("&#039;|'", "''", re.sub("\s+", " ", Room_amnty_group))
			else:
				Room_amnty = ''
			RateType_reg = re.search(r"<h2>Cancellation Policy(.*?)</p>", currency_source, re.DOTALL)
			if RateType_reg:
				RateType_group = re.sub("<.*?>", "", RateType_reg.group(1))
				RateType = re.sub("\s+", " ", RateType_group.replace("'", "''"))
			else:
				RateType = ''
		else:
			Currencycode = ''
			Room_amnty = ''
			RateType = ''
		if Currencycode == '':
			Rtdate=re.sub(r'-|\-','',str(RateDate))
			curl_text = 'Currency Values NULL'
			keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(websitecode,datetime.datetime.now(),id_update)
			key = bucket.new_key(keyvalue)
			key.set_contents_from_string(str(curl_text))
			keyvalue = "ondemand/{}/{:%Y%m%d}/source/{}.html".format(websitecode,datetime.datetime.now(),str(inputid)+'_'+str(Rtdate)+'_'+id_update)
			key = bucket.new_key(keyvalue)
			key.set_contents_from_string(str(curl.text.encode('ascii', 'ignore')))
			region=''
			ip=re.sub(r"\{'.*?@|'\}|:\d+","",str(proxies))
			try:
				try:
					r = requests.get('http://freegeoip.net/json/'+ip,timeout=30)
				except Exception,e:
					r = requests.get('http://freegeoip.net/json/'+ip,timeout=30)
				js = r.json()
				region=js['country_name']
			except Exception,e:
				region=''
			statuscode=8
			Guests='1'
			array.append(aws_insert.insert(id_update, inputid ,functionname,websitecode, "","", "", "", Guests, "", "", "", "", "",url, url, url, "", "", "", "", "", "",StartDate, EndDate , "", "", "", "", "", "", "", "", "",region,statuscode, israteperstay))
			#array.append(aws_insert.insert(id_update, inputid ,functionname,Websitecode, "","", "", "", Guests, "", "", "", "", "","", "", "", "", "", "", "", "", "",StartDate, EndDate , "", "", "", "", "",  "", "", "",statuscode))
			return json.dumps(array)
		##print 'RateType:',RateType
		RoomAmenity_Type=Room_amnty
		curr="&currency="+str(Currencycode)
		url=url+curr
		Room_avb= ''
		RoomDescp = ''
		Closed_up = 'N' 
		head = {'User-Agent':'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:12.0) Gecko/20100101 Firefox/31.0', 'referer' : url}
		if 'propNum' in url:
			propid = re.search("propNum=(.*?)&", url).group(1)
			json_concat = re.sub("http.*?\?|#availability", "", url)
			jsonlink = "https://www.hostelworld.com/properties/"+propid+"/availability?"+json_concat
		else:
			propid = re.sub(r"https://www.*?/(\d+)\?.*", r"\1", url)
			json_concat_datefromto = re.sub("http.*?\?|#availability|&sc_pos.*", "", url)
			json_concat = "propNum="+re.sub(r"https://www.*?/(\d+)\?.*", r"\1", url)+'&'+json_concat_datefromto
			print json_concat
			jsonlink = "https://www.hostelworld.com/properties/"+propid+"/availability?"+json_concat
			print jsonlink
		##print jsonlink
		try:
			hml = requests.get(jsonlink, headers=head, proxies = proxies,timeout=50)
		except ValueError as e:
			##print "ValueError	=",e
			try:
				hml = requests.get(jsonlink, headers=head, proxies = proxies,timeout=50)
			except ValueError as e:
				value_error=str(re.sub("'",'"',str(e)))
				stacktrace=sys.exc_traceback.tb_lineno
				keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(websitecode,datetime.datetime.now(),id_update)
				key = bucket.new_key(keyvalue)
				key.set_contents_from_string(str(e))
				region=''
				ip=re.sub(r"\{'.*?@|'\}|:\d+","",str(proxies))
				try:
					try:
						r = requests.get('http://freegeoip.net/json/'+ip,timeout=30)
					except Exception,e:
						r = requests.get('http://freegeoip.net/json/'+ip,timeout=30)
					js = r.json()
					region=js['country_name']
				except Exception,e:
					region=''
				statuscode=5
				Guests='1'
				array.append(aws_insert.insert(id_update, inputid ,functionname,websitecode, "","", "", "", Guests, "", "", "", "", "",url, url, url, "", "", "", "", "", "",StartDate, EndDate , "", "", "", "", "", "", "", "", "",region,statuscode, israteperstay))
				return json.dumps(array)
			
		if hml.status_code <> 200:
			hml = requests.get(jsonlink, headers=head, proxies = proxies)
		if (hml.status_code == 403 or hml.status_code == 407):
			try:
				proxyresult = requests.get('http://www.gimmeproxy.com/api/getProxy?protocol=http',timeout=40)
				jproxy = json.loads(proxyresult.content)
				proxies = { "http": jproxy["curl"] }
				hml = requests.get(jsonlink, headers=head, proxies = proxies)
				##print "gimmeprox ", hml.status_code
				if hml.status_code <> 200:
					hml = requests.get(jsonlink, headers=head)
					##print "simple ", hml.status_code
			except ValueError as e:
				value_error=str(re.sub("'",'"',str(e)))
				stacktrace=sys.exc_traceback.tb_lineno
				keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(websitecode,datetime.datetime.now(),id_update)
				key = bucket.new_key(keyvalue)
				key.set_contents_from_string(str(e))
				region=''
				ip=re.sub(r"\{'.*?@|'\}|:\d+","",str(proxies))
				try:
					try:
						r = requests.get('http://freegeoip.net/json/'+ip,timeout=30)
					except Exception,e:
						r = requests.get('http://freegeoip.net/json/'+ip,timeout=30)
					js = r.json()
					region=js['country_name']
				except Exception,e:
					region=''
				statuscode=5
				Guests='1'
				array.append(aws_insert.insert(id_update, inputid ,functionname,websitecode, "","", "", "", Guests, "", "", "", "", "",url, url, url, "", "", "", "", "", "",StartDate, EndDate , "", "", "", "", "", "", "", "", "",region,"5", israteperstay))
				#array.append(aws_insert.insert(id_update, inputid ,functionname,Websitecode, "","", "", "", Guests, "", "", "", "", "","", "", "", "", "", "", "", "", "",StartDate, EndDate , "", "", "", "", "",  "", "", "",statuscode))
				return json.dumps(array)
		Rtdate=re.sub(r'-|\-','',str(RateDate))
		keyvalue = "ondemand/{}/{:%Y%m%d}/source/{}.json".format(websitecode,datetime.datetime.now(),str(inputid)+'_'+str(Rtdate)+'_'+id_update)
		key = bucket.new_key(keyvalue)
		key.set_contents_from_string(str(hml.text.encode('ascii', 'ignore')))
		html=json.loads(unidecode(hml.text).encode('ascii'))
		region=''
		ip=re.sub(r"\{'.*?@|'\}|:\d+","",str(proxies))
		try:
			try:
				r = requests.get('http://freegeoip.net/json/'+ip,timeout=30)
			except Exception,e:
				r = requests.get('http://freegeoip.net/json/'+ip,timeout=30)
			js = r.json()
			region=js['country_name']
		except Exception,e:
			region=''
		if 'hasAvailability":true' in hml.text:
			for room_loop in html['rooms']:
				for roomblock in html['rooms'][room_loop]:
					Roomtype = ''
					RoomDescp = ''
					Room_avb = ''
					Roomtype = re.sub("&amp;", "&", re.sub(":.*", "", re.sub("'", "''", str(unidecode(roomblock['labelToRender']).encode('ascii')))))+' '+re.sub("&amp;", "&", re.sub(":.*", "", re.sub("'", "''", str(unidecode(roomblock['numofbeds']).encode('ascii')))))+' '+re.sub("&amp;", "&", re.sub(":.*", "", re.sub("'", "''", str(unidecode(roomblock['roomtypename']).encode('ascii')))))
					RoomType = re.sub("^ ", "", Roomtype).strip()
					###print Roomtype
					for Rates in roomblock['ratePlans']:
						if 'paymentProcedure' in Rates:
							if 'description' in Rates['paymentProcedure']:
								RateType1 = re.sub("<.*?>", "", re.sub("</b><br>", "", Rates['paymentProcedure']['description'].replace("'", "''")))
								RateType  = re.sub(r"\n", r" ", RateType1)
							else:
								RateType = ''
						else:
							RateType = ''
						if re.search(r'"'+str(Rates['id'])+'": "(.*?)"', str(json.dumps(roomblock['averagePrice']))):
							OnsiteRate = re.sub(r"\[|\]","",str(re.search(r'"'+str(Rates['id'])+'": "(.*?)"', str(json.dumps(roomblock['averagePrice']))).group(1)))
							Closed_up  = 'N'
							statuscode = ''
						else:
							OnsiteRate = 0
							Closed_up  = 'Y'
							statuscode = 1
						
						RoomDescp = re.sub("&amp;", "&", re.sub("\.", ",", re.sub("'", "''", str(roomblock['roomtypedescription']))))+' '+re.sub("&amp;", "&", re.sub("\.", ",", re.sub("'", "''", str(unidecode(roomblock['labeldescriptionToRender']).encode('ascii')))))
						if roomblock.has_key('beds'):
							RoomDescp = re.sub("&amp;", "&", re.sub("\.", ",", re.sub("'", "''", str(unidecode(roomblock['beds']).encode('ascii')))))+' '+RoomDescp
						else:
							RoomDescp = RoomDescp
						Room_avb = unidecode(roomblock['ensuite']).encode('ascii')
						MaxOccupancy = roomblock['beds']
						Mealtype = Room_amnty
						if Mealtype:
							Meal = re.sub("Complimentary chef crafted kids lunch|dinner charges|dinner directly payable at hotel", "", str(Mealtype)+' '+Roomtype+' '+RoomDescp)
						###print Meal
						if int(LOS) > 1:
							israteperstay = 'N'
						else:
							israteperstay = 'Y'
						if (NetRate == 0 or NetRate == '') and (promotion == 0 or promotion == ''):
							Isprom = 'N'
						else:
							Isprom = 'Y'
						###print (id_update, inputid, Domainname, websitecode, StartDate, RoomType, LOS, RateDate, Guests, OnsiteRate, NetRate, OnsiteRate, Currencycode, RoomDescp, url, url, url,  RoomAmenity_Type, Meal,MaxOccupancy,Isprom,Closed_up,30,StartDate,EndDate, intime, Room_avb, None, None,Tax_status, None, RateType, NetRate,promotion,region,statuscode, israteperstay)
						array.append(aws_insert.insert(id_update, inputid, Domainname, websitecode, StartDate, RoomType, LOS, RateDate, Guests, OnsiteRate, NetRate, OnsiteRate, Currencycode, RoomDescp, url, url, url,  RoomAmenity_Type, Meal,MaxOccupancy,Isprom,Closed_up,30,StartDate,EndDate, intime, Room_avb, None, None,Tax_status, None, RateType, NetRate,promotion,region,statuscode, israteperstay))
		else:
			##print "Else working"
			room_loop =''
			Closed_up = 'Y'
			statuscode='2'
			array.append(aws_insert.insert(id_update, inputid, Domainname, websitecode, StartDate, RoomType, LOS, RateDate, Guests, OnsiteRate, NetRate, OnsiteRate, Currencycode, RoomDescp, url, url, url,  RoomAmenity_Type, Meal,MaxOccupancy,Isprom,Closed_up,30,StartDate,EndDate, intime, Room_avb, None, None,Tax_status, None, RateType, NetRate,promotion,region,statuscode, israteperstay))
		keyvalue = "ondemand/{}/{:%Y%m%d}/delivery/{}.json".format(websitecode,datetime.datetime.now(),str(inputid)+'_'+str(Rtdate)+'_'+id_update)
		key = bucket.new_key(keyvalue)
		#print json.dumps(array)
		key.set_contents_from_string(json.dumps(array))
		return json.dumps(array)
	except Exception as e:
		value_error=str(re.sub(r"'",'"',str(e)))
		stacktrace=sys.exc_traceback.tb_lineno
		#print stacktrace, e
		Guests ='1'
		insert_value_error=str(value_error)+'Where line number '+str(stacktrace)+str(proxyip)
		keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(websitecode,datetime.datetime.now(),id_update)
		key = bucket.new_key(keyvalue)
		key.set_contents_from_string(insert_value_error)
		array.append(aws_insert.insert(id_update, inputid ,functionname,websitecode, "","", "", "", Guests, "", "", "", "", "",url, url, url, "", "", "", "", "", "",StartDate, EndDate , "", "", "", "", "","", "", "", "",region,"4", israteperstay))
		return json.dumps(array)	

# fetchrates(url,inputid, id_update, proxyip)
