# -*- coding: utf-8 -*-
import re
import requests
import datetime
import json
import boto,gc,sys

import aws_insert


def fetchrates(url,inputid,id_update,proxyip):
    array      = []
    sr  = requests.session()
    proxies    = {"https": "http://{}".format(proxyip)}
    intime     = re.sub(r'\s','T',str(datetime.datetime.now()))
    Domainname = 'hallmarkinn.com'
    Websitecode= '351'
    israteperstay = ''
    try:
        statuscode = ''
        Mealtype   = ''
        conn   = boto.connect_s3(aws_access_key_id= 'AKIAIXEGZVXCWE2FV3SQ',aws_secret_access_key = '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') 
        bucket = conn.get_bucket("rmapi")
        StartDate = datetime.date.today()
        EndDate   = datetime.date.today() + datetime.timedelta(days=29)
        CheckIn_Check_OT_re = re.search(r'arrivaldate=(.*?)&departuredate=(.*?)&',url)
        if CheckIn_Check_OT_re:
            Checkin  = CheckIn_Check_OT_re.group(1)
            Checkout = CheckIn_Check_OT_re.group(2)
        else:
            Checkin  = ''
            Checkout = ''
        #print Checkin,Checkout
        RateDate = Checkin
        delta    = datetime.datetime.strptime(Checkout, "%Y-%m-%d") - datetime.datetime.strptime(Checkin, "%Y-%m-%d")
        LOS      = delta.days
        RoomType = ''
        Guests   = ''
        Guests_reg = re.search(r'adults=(.*?)&', url)
        if Guests_reg:
            Guests = Guests_reg.group(1)
        night ="nights="+str(LOS)+"&"
        url      = re.sub(r"nights=.*?&",night,url)
        Ratetype = ''
        RateDescription = ''
        Taxtype  = ''
        Curr     = ''
        MaxOccupancy = None
        isPromotionalRate  = 'N'
        Closed   = 'Y'
        NetRate  = 0
        Taxstatus= -1
        TaxAmount= 0
        Discount = 0
        GrossRate= 0
        OnsiteRate = 0
        Curr     = ''
        Promotion_Name= ''
        isAvailable = ''
        RoomAmenity_Type = ''
        url_insert = url
        region = ''
        ip = re.sub(r"\{'.*?@|'\}|:\d+", "", str(proxies))
        try:
            try:
                r = requests.get('http://freegeoip.net/json/' + ip, timeout=30)
            except Exception, e:
                r = requests.get('http://freegeoip.net/json/' + ip, timeout=30)
            js = r.json()
            region = js['country_name']
        except Exception, e:
            region = ''
        head = {'Host':'www.yourreservation.net','Connection':'keep-alive','Upgrade-Insecure-Requests':'1','User-Agent':'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36','Accept':'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8','Accept-Encoding':'gzip, deflate, br','Accept-Language':'en-GB,en-US;q=0.8,en;q=0.6'}
        try:
            htt  = sr.get('http://www.hallmarkinn.com/', proxies = proxies, timeout=50)
            source = sr.get(url,headers = head,proxies = proxies, timeout=50)
            htm = sr.get(url,headers = head,proxies = proxies, timeout=50)
        except Exception, e:
            value_error = str(re.sub("'", '', str(e)))
            stacktrace = sys.exc_traceback.tb_lineno
            try:
                htt  = sr.get('http://www.hallmarkinn.com/', proxies = proxies, timeout=50)
                source = sr.get(url,headers = head,proxies = proxies, timeout=50)
                htm = sr.get(url,headers = head,proxies = proxies, timeout=50)
            except Exception, e:
                value_error = str(re.sub("'", '', str(e)))
                stacktrace = sys.exc_traceback.tb_lineno
                keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(Websitecode, datetime.datetime.now(), id_update)
                key = bucket.new_key(keyvalue)
                key.set_contents_from_string(str(e) + 'Where Line number' + str(stacktrace) + str(proxies))
                statuscode = 5
                Guests = ''
                array.append(aws_insert.insert(id_update, inputid , Domainname, Websitecode, "", "", "", "", Guests, "", "", "", "", "", url, url, url, "", "", "", "", "", "", StartDate, EndDate , "", "", "", "", "", "", "", "", "", region, statuscode, israteperstay))
                return json.dumps(array)
        if htm.status_code <> 200:
            htt  = sr.get('http://www.hallmarkinn.com/',proxies = proxies, timeout=50)
            source = sr.get(url,headers = head,proxies = proxies, timeout=50)
            htm = sr.get(url,headers = head,proxies = proxies, timeout=50)
        if (htm.status_code == 403 or htm.status_code == 407) or htm.status_code <> 200:
            try:
                if htm.status_code <> 200:
                    htt  = sr.get('http://www.hallmarkinn.com/', timeout=50)
                    source = sr.get(url,headers = head, timeout=50)
                    htm = sr.get(url,headers = head, timeout=50)
            except Exception, e:
                value_error = str(re.sub("'", '', str(e)))
                stacktrace = sys.exc_traceback.tb_lineno
                keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(Websitecode, datetime.datetime.now(), id_update)
                key = bucket.new_key(keyvalue)
                key.set_contents_from_string(str(e) + 'Where Line number' + str(stacktrace) + str(proxies))
                statuscode = 5
                Guests = ''
                array.append(aws_insert.insert(id_update, inputid , Domainname, Websitecode, "", "", "", "", Guests, "", "", "", "", "", url, url, url, "", "", "", "", "", "", StartDate, EndDate , "", "", "", "", "", "", "", "", "", region, statuscode, israteperstay))
                return json.dumps(array)
        html = htm.text
        html = html.encode('ascii', 'ignore')
        Rtdate=re.sub(r'-|\-','',str(RateDate))
        Rtdate=re.sub(r'-|\-','',str(RateDate))
        keyvalue = "ondemand/{}/{:%Y%m%d}/source{}.html".format(Websitecode, datetime.datetime.now(), str(inputid) + '_' + str(Rtdate) + '_' + id_update)
        #print keyvalue
        key = bucket.new_key(keyvalue)
        key.set_contents_from_string(html) 
        if re.search(r'(<div id="room_.*?class="clear">.*?<div class="clear">.*?</div>\s*</div>\s*</div>\s*</div>)',html,re.DOTALL):
            for block1 in re.compile(r'<div id="room_.*?class="clear">.*?<div class="clear">.*?</div>\s*</div>\s*</div>\s*</div>',re.DOTALL).findall(html):
                for block in re.compile(r'<h4>.*?</div></span>.*?border">',re.DOTALL).findall(block1):
                    RoomType      = ''
                    Ratetype      = ''
                    OnsiteRate    = 0
                    RoomAmenity_Type = ''
                    RateDescription  = ''
                    MealInclusion    = ''
                    Mealtype         = ''
                    Curr             = ''
                    Closed           = 'N'
                    GrossRate        = 0
                    isAvailable      = ''
                    Taxstatus        = 2
                    roomtype_re = re.search(r'<h3>(.*?)</h3>', block1)            
                    if roomtype_re:
                        RomeType1 = re.sub(r"'","''", roomtype_re.group(1))
                        RoomType  = re.sub('\s\s+','',re.sub(r'&.*?;','',RomeType1))
                    
                    amenity_re  = re.search(r'<ul class="bulletlist.*?>(.*?)</ul>\s*</div>', block1, re.DOTALL)
                    if amenity_re:
                        Amenities_grp   = amenity_re.group(1)
                        Amenities_clean = re.sub(r'<.*?>','',re.sub(r'</li>',',',Amenities_grp))
                        Amenities_clean2 = re.sub(r"'","''",re.sub(r",$|",'',Amenities_clean))
                        RoomAmenity_Type = re.sub(r"\n",'',Amenities_clean2)
                    desc1_re    = re.search(r'<div class="tab">\s*(.*?)\s*<', block1)
                    if desc1_re:
                        RateDescription = re.sub(r"'","''",desc1_re.group(1))
                        RateDescription = re.sub(RoomType,'',RateDescription).strip()
                    ratetype_re     = re.search(r'<h4>(.*?)</h4>', block)
                    if ratetype_re:
                        Ratetype = re.sub(r"'","''",ratetype_re.group(1))
                        
                    price_re    = re.search(r'pricevalue">(.*?)<', block)
                    if price_re:
                        OnsiteRate = re.sub('\$|,|[A-Za-z]|&.*?;','',price_re.group(1)).strip()
                    GrossRate  = OnsiteRate 
                    '''meal_re = re.search(r'<div class="rateicons">(.*?)</div>', block, re.DOTALL)
                    if meal_re:
                        mealtype = meal_re.group(1)
                        if 'Includes Breakfast' in mealtype:
                            MealInclusion = 'Breakfast Included'
                            RoomAmenity_Type = RoomAmenity_Type+"; MealInclusion:"+MealInclusion
                    else:
                        MealInclusion = '''
                    curr_re =  re.search(r'pricevalue">(.*?)\d.*?<', block)
                    if curr_re:
                        Currency = re.sub(r"&|;","",curr_re.group(1))
                        if "$" in Currency:
                            Curr = 'USD'
                        elif "euro" in Curr:
                            Curr = 'EUR'
                    Mealtypes = str(RateDescription)+' '+str(RoomAmenity_Type)+' '+str(RoomType)+''+str(Ratetype)
                    if Mealtypes !=None:
                        Mealtype_str = str(Mealtypes)
                        if 'breakfast' in Mealtype_str.lower() and 'dinner' in Mealtype_str.lower()  and 'lunch' in Mealtype_str.lower():
                            Meal = 'Breakfast, Lunch and Dinner'
                        elif 'breakfast' in Mealtype_str.lower() and 'dinner' in Mealtype_str.lower():
                            Meal = 'Breakfast and dinner'
                        elif 'breakfast included' in Mealtype_str.lower():
                            Meal = 'Breakfast included'
                        elif 'BREAKFAST' in Mealtype_str:
                            Meal = 'Breakfast'
                        elif 'breakfast' in Mealtype_str.lower() and 'lunch' in Mealtype_str.lower():
                            Meal = 'Breakfast and Lunch'
                        elif 'Lunch' in Mealtype_str and 'Dinner' in Mealtype_str :
                            Meal = "Lunch and Dinner"
                        elif 'breakfast' in Mealtype_str.lower() and 'lunch' in Mealtype_str.lower() and 'dinner' in Mealtype_str.lower():
                            Meal = 'Breakfast, Lunch and dinner'
                        elif 'Break fast' in Mealtype_str:
                            Meal = 'BreakFast' 
                        elif 'breakfast' in Mealtype_str.lower():
                            Meal = 'BreakFast' 
                        elif 'halfboard' in Mealtype_str.lower():
                            Meal = 'Halfboard'
                        elif 'half board' in Mealtype_str.lower():
                            Meal = 'Half board' 
                        elif 'full board' in Mealtype_str.lower():
                            Meal = 'Full Board'
                        elif 'fullboard' in Mealtype_str.lower():
                            Meal = 'FullBoard'
                        elif 'All-Inclusive' in Mealtype_str:
                            Meal = 'All-Inclusive'
                        elif 'All Inclusive' in Mealtype_str:
                            Meal = 'All Inclusive'
                        elif 'All Meals' in Mealtype_str:
                            Meal = 'All Meals'
                        elif 'All Meal' in Mealtype_str:
                            Meal = 'All Meal'
                        else:
                            Meal = ''
                    else:
                        Meal = ''    
                    Mealtype = Meal
                    isAvailb_re = re.search(r'class="icon_warning">.*?>(.*?)<', block1)
                    if isAvailb_re:
                        isAvailable = re.sub(r'<.*?>|\D','',isAvailb_re.group(1))
                    if OnsiteRate==0:
                        statuscode = 1
                        Closed='Y'
                    else:
                        statuscode = ''
                        Closed='N'
                    LOS = int(LOS)
                    if int(LOS) >1:
                        israteperstay = 'N'
                    else:
                        israteperstay ='Y'
                    #if #printdata:
                    #print "RoomType         :",RoomType          
                    #print "Ratetype         :",Ratetype          
                    #print "price            :",OnsiteRate             
                    #print "RoomAmenity_Type :",RoomAmenity_Type  
                    #print "RateDescription  :",RateDescription  
                    #print "MealInclusion    :",Mealtype
                    #print "Currency         :",Curr
                    #print "isAvailable      :",isAvailable
                    #print"&"*40
                    #print (id_update, inputid , Domainname, Websitecode, StartDate, RoomType, LOS, RateDate, Guests, OnsiteRate, NetRate, GrossRate, Curr, RateDescription, url_insert, url_insert, url_insert, RoomAmenity_Type, Mealtype, MaxOccupancy, isPromotionalRate, Closed, 30, StartDate , EndDate, intime, isAvailable, Taxtype, TaxAmount, Taxstatus, None, Ratetype, Discount,Promotion_Name,region,statuscode, israteperstay)
                    array.append(aws_insert.insert(id_update, inputid , Domainname, Websitecode, StartDate, RoomType, LOS, RateDate, Guests, OnsiteRate, NetRate, GrossRate, Curr, RateDescription, url_insert, url_insert, url_insert, RoomAmenity_Type, Mealtype, MaxOccupancy, isPromotionalRate, Closed, 30, StartDate , EndDate, intime, isAvailable, Taxtype, TaxAmount, Taxstatus, None, Ratetype, Discount,Promotion_Name,region,statuscode, israteperstay))
        else:
            Closed     = 'Y'
            statuscode = '2'
            #print "else"
            #print (id_update, inputid , Domainname, Websitecode, StartDate, RoomType, LOS, RateDate, Guests, OnsiteRate, NetRate, GrossRate, Curr, RateDescription, url_insert, url_insert, url_insert, RoomAmenity_Type, Mealtype, MaxOccupancy, isPromotionalRate, Closed, 30, StartDate , EndDate, intime, isAvailable, Taxtype, TaxAmount, Taxstatus, None, Ratetype, Discount,Promotion_Name,region,statuscode, israteperstay)
            array.append(aws_insert.insert(id_update, inputid , Domainname, Websitecode, StartDate, RoomType, LOS, RateDate, Guests, OnsiteRate, NetRate, GrossRate, Curr, RateDescription, url_insert, url_insert, url_insert, RoomAmenity_Type, Mealtype, MaxOccupancy, isPromotionalRate, Closed, 30, StartDate , EndDate, intime, isAvailable, Taxtype, TaxAmount, Taxstatus, None, Ratetype, Discount,Promotion_Name,region,statuscode, israteperstay))
        Rtdate = re.sub(r'-|\-', '', str(RateDate))
        keyvalue = "ondemand/{}/{:%Y%m%d}/delivery/{}.json".format(Websitecode,datetime.datetime.now(),str(inputid)+'_'+str(Rtdate)+'_'+id_update)
        key = bucket.new_key(keyvalue)
        key.set_contents_from_string(json.dumps(array))
        return json.dumps(array)
        gc.collect()
    except Exception as e:
        print e
        value_error = str(re.sub(r"'", '"', str(e)))
        stacktrace = sys.exc_traceback.tb_lineno
        Guests = ''
        region = ''
        insert_value_error = str(value_error) + 'Where line number ' + str(stacktrace) + str(proxyip)
        print insert_value_error
        #print "Websitecode =", Websitecode
        statuscode = '4'
        keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(Websitecode, datetime.datetime.now(), id_update)
        key = bucket.new_key(keyvalue)
        key.set_contents_from_string(insert_value_error)
        array.append(aws_insert.insert(id_update, inputid , Domainname, Websitecode, "", "", "", "", Guests, "", "", "", "", "", url, url, url, "", "", "", "", "", "", StartDate, EndDate , "", "", "", "", "", "", "", "", "", region, statuscode, israteperstay))
        return json.dumps(array)
    
