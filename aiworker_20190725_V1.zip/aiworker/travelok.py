# -*- coding: utf-8 -*-
import re
import requests
import datetime
import json
import boto

import sys
import aws_insert
from unidecode import unidecode
sr = requests.Session()

# url		 ='https://www.traveloka.com/en/hotel/malaysia/ancasa-hotel--spa-kuala-lumpur-by-ancasa-hotels--resorts-2000000074094?spec=2018-08-25.2018-08-26.1.1.HOTEL.2000000074094.1&prevSearchId=1566827663444689316&prevSearchId=1566827663444689316&currency=USD&'
# inputid  ='Testing'
# id_update='12345'
# proxyip  ='media:M3diAproxy@192.227.253.244:80'

def fetchrates(url ,inputid, id_update, proxyip):	
	array = []
	intime=re.sub(r'\s','T',str(datetime.datetime.now()))
	Domainname='Travelok.com'
	Websitecode='306'
	region=''
	israteperstay = ''
	statuscode=''
	conn = boto.connect_s3(aws_access_key_id= 'AKIAIXEGZVXCWE2FV3SQ',aws_secret_access_key = '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') 
	bucket = conn.get_bucket("rmapi")
	StartDate = datetime.date.today()
	EndDate  = datetime.date.today() + datetime.timedelta(days=29)
	try:		
		RoomType        = ''
		if re.search(r'&currency=(.*?)&',url):
			curr=re.search(r'&currency=(.*?)&',url).group(1)
		if re.search(r'.(\d+)&pr',url):
			adults=re.search(r'.(\d+)&pr',url).group(1)
		if re.search(r'spec=(\d+-\d+-\d+)', url):
			RateDate      = re.search(r'spec=(\d+-\d+-\d+)', url).group(1)
			Checkin_date  = datetime.datetime.strptime(str(re.search(r'spec=(\d+-\d+-\d+)', url).group(1)),'%Y-%m-%d').strftime("%d")
			Checkin_month = datetime.datetime.strptime(str(re.search(r'spec=(\d+-\d+-\d+)', url).group(1)),'%Y-%m-%d').strftime("%m")
			Checkin_year  = datetime.datetime.strptime(str(re.search(r'spec=(\d+-\d+-\d+)', url).group(1)),'%Y-%m-%d').strftime("%Y")
			Checkout_date = datetime.datetime.strptime(str(re.search(r'spec=\d+-\d+-\d+\.(\d+-\d+-\d+)', url).group(1)),'%Y-%m-%d').strftime("%d")
			Checkout_month= datetime.datetime.strptime(str(re.search(r'spec=\d+-\d+-\d+\.(\d+-\d+-\d+)', url).group(1)),'%Y-%m-%d').strftime("%m")
			Checkout_year = datetime.datetime.strptime(str(re.search(r'spec=\d+-\d+-\d+\.(\d+-\d+-\d+)', url).group(1)),'%Y-%m-%d').strftime("%Y")
		else:
			RateDate    = ''
		Checkout_d = re.search(r'spec=\d+-\d+-\d+\.(\d+-\d+-\d+)', url).group(1)
		url1 = datetime.datetime.strptime(RateDate,'%Y-%m-%d').strftime("%d-%m-%Y")
		url2=datetime.datetime.strptime(Checkout_d,'%Y-%m-%d').strftime("%d-%m-%Y")
		delta = datetime.datetime.strptime(Checkout_d, "%Y-%m-%d") - datetime.datetime.strptime(RateDate, "%Y-%m-%d")
		LOS   = delta.days
		url = re.sub('spec=\d+-\d+-\d+\.\d+-\d+-\d+.\d+.','spec='+url1+'.'+url2+'.'+str(LOS)+'.',url)
		#LOS = 

		Guests          = adults
		OnsiteRate      = 0
		NetRate         = 0
		GrossRate       = 0
		Curr            = ''
		RateDescription = ''
		url_insert      = url
		RoomAmenity_Type= ''
		Mealtype        = ''
		MaxOccupancy    = ''
		Closed          = 'Y'
		isAvailable     = ''
		Taxtype         = ''
		TaxAmount       = 0
		Taxstatus       = ''
		HotelBlock      = ''
		Ratetype        = ''
		Discount        = 0
		Promotion_Name  = ''
		isPromotionalRate='N'
		#page-Load    
		head     = {'User-Agent':'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:12.0) Gecko/20100101 Firefox/48.0'}
		proxies  = {"http": "http://{}".format(proxyip)}
		ip=re.sub(r"\{'.*?@|'\}|:\d+","",str(proxies))
		try:
			try:
				r = requests.get('http://freegeoip.net/json/'+ip,timeout=30)
			except Exception,e:
				r = requests.get('http://freegeoip.net/json/'+ip,timeout=30)
			js = r.json()
			region=js['country_name']
		except Exception,e:
			region=''
		try:
			response = sr.get(url, headers=head,proxies=proxies,timeout=30)
			#print response.status_code
		except Exception as e: 
			print e,"Re-run"
			try:
				response = sr.get(url, headers=head,proxies=proxies,timeout=30)	
				#print response.status_code			
			except Exception as e: 
				print e,"Re-run"
				keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(Websitecode,datetime.datetime.now(),id_update)
				key = bucket.new_key(keyvalue)
				key.set_contents_from_string(str(e))
				statuscode=5
				Guests='1'
				array.append(aws_insert.insert(id_update, inputid ,Domainname,Websitecode, "","", "", "", Guests, "", "", "", "", "",url_insert, url_insert, url_insert, "", "", "", "", "", "",StartDate, EndDate , "", "", "", "", "", "",  "", "", "",region,statuscode, israteperstay))
				return json.dumps(array)
		if (response.status_code<> 200):
			response = sr.get(url, headers=head,proxies=proxies,timeout=30)
			#print response.status_code
		if (response.status_code == 403 or response.status_code == 407 or response.status_code <> 200):
			response = sr.get(url, headers=head)	
			#print response.status_code
		a        = response.text	
		html     = unidecode(a).encode('ascii')
		data     = response.headers['Set-Cookie']
		print "data	",data
		
		if re.search('tv-lifetime-.*?="(.*?)"', str(data)):
			tvlifetime = re.search('tv-lifetime-.*?="(.*?)"', str(data)).group(1)
			tvsession  = re.search('tv-session-.*?="(.*?)"', str(data)).group(1)
		else:
			tvlifetime = re.search('tvl=(.*?)=', str(data)).group(1)
			tvsession  = re.search('tvs=(.*?)=', str(data)).group(1)
		
		
		hotel_id  = re.search('-(\d+)\?', str(url)).group(1)	
		url1    = 'https://api.traveloka.com/en/v2/hotel/searchRooms'
		payload = {"context":{"tvLifetime":tvlifetime,"tvSession":tvsession},"clientInterface":"desktop","data":{"checkInDate":{"year":Checkin_year,"month":Checkin_month,"day":Checkin_date},"checkOutDate":{"year":Checkout_year,"month":Checkout_month,"day":Checkout_date},"numOfNights":LOS,"currency":str(curr),"numAdults":adults,"numChildren":0,"numInfants":0,"numRooms":1,"ccGuaranteeOptions":{"ccInfoPreferences":["CC_TOKEN"],"ccGuaranteeRequirementOptions":["CC_GUARANTEE"]},"rateTypes":["PAY_NOW","PAY_AT_PROPERTY"],"contexts":{"shouldDisplayAllRooms":'true'},"hotelId":hotel_id,"labelContext":{},"monitoringSpec":{"lastKeyword":"helpsuggest","referrer":"https://www.traveloka.com/en/"},"preview":'true'},"fields":[]}
		head    = {'User-Agent':'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:12.0) Gecko/20100101 Firefox/52.0', 'Host': 'api.traveloka.com', 'Origin' : 'https://www.traveloka.com', 'Referer' : 'https://www.traveloka.com/en/', 'Content-Type':'application/json', 'Accept' : 'application/json'}	
		try:			
			response= sr.post(url1, json=payload, headers=head,proxies=proxies,timeout=30)
			#print "statuscode ==",response.status_code		
		except Exception as e:
			print e,"Re-run"
			try:
				response= sr.post(url1, json=payload, headers=head,proxies=proxies,timeout=30)
				#print "statuscode ==", response.status_code
			except Exception as e:
				print e,"Re-run"
				keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(Websitecode,datetime.datetime.now(),id_update)
				key = bucket.new_key(keyvalue)
				key.set_contents_from_string(str(e))
				statuscode=5
				Guests='1'
				array.append(aws_insert.insert(id_update, inputid ,Domainname,Websitecode, "","", "", "", Guests, "", "", "", "", "",url_insert, url_insert, url_insert, "", "", "", "", "", "",StartDate, EndDate , "", "", "", "", "", "",  "", "", "",region,statuscode, israteperstay))
				return json.dumps(array)
		if (response.status_code<> 200):
			response = sr.post(url1, headers=head,proxies=proxies)
			#print "statuscode == 200"
		if (response.status_code == 403 or response.status_code == 407 or response.status_code <> 200):
			response = sr.post(url1, headers=head)
			#print "statuscode == 400"
		if response.status_code ==500 and 'errorType":"SERVER_ERROR"' in response.text:
			keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(Websitecode,datetime.datetime.now(),id_update)
			key = bucket.new_key(keyvalue)
			Err = 'Invalid Currency'
			print err
			key.set_contents_from_string(str(Err))
			statuscode=8
			Guests='1'
			array.append(aws_insert.insert(id_update, inputid ,Domainname,Websitecode, "","", "", "", Guests, "", "", "", "", "",url_insert, url_insert, url_insert, "", "", "", "", "", "",StartDate, EndDate , "", "", "", "", "", "",  "", "", "",region,statuscode, israteperstay))
			return json.dumps(array)			
		
		a       = response.text
		html    = unidecode(a).encode('ascii')
		#fo = open('html.html', 'w')
		#fo.write(html)
		json_v  = json.loads(html)
		Rtdate=re.sub(r'-|\-','',str(RateDate))
		keyvalue = "ondemand/{}/{:%Y%m%d}/source/{}.json".format(Websitecode,datetime.datetime.now(),str(inputid)+'_'+str(Rtdate)+'_'+id_update)
		key = bucket.new_key(keyvalue)
		key.set_contents_from_string(str(html))
		if 'data' in json_v:
			Data = json_v['data']
			if 'recommendedEntries' in Data:
				if Data['recommendedEntries']:
					for Data1 in Data['recommendedEntries']:
						if 'roomList' in Data1:
							List_Amein = []
							for block in Data1['roomList']:
								Closed     = 'N'
								HotelBlock = re.sub(r"'",'',str(block))
								if 'name' in block:
									RoomType = block['name']
								else:
									RoomType = ''
								if 'description' in block:
									description = block['description']
								else:
									description = ''                        
			
								if 'maxOccupancy' in block:
									MaxOccupancy = block['maxOccupancy']
								else:
									MaxOccupancy = ''                        
								if 'numRemainingRooms' in block:
									isAvailable = block['numRemainingRooms']
								else:
									isAvailable = '' 
								if 'originalRateDisplay' in block:
									Rates = block['originalRateDisplay']
									if 'totalFare' in Rates:
										NetRate = Rates['totalFare']['amount']
										isPromotionalRate = 'Y'
									else:
										NetRate    = 0
										isPromotionalRate = 'N'
								else:
									NetRate = 0
									isPromotionalRate = 'N'
								if 'rateDisplay' in block:
									Rates = block['rateDisplay']
									if 'totalFare' in Rates:
										Curr       = Rates['totalFare']['currency']
										OnsiteRate = Rates['totalFare']['amount']
										numOfDecimalPoint = Rates['numOfDecimalPoint']
										if LOS > 1:
											israteperstay = 'N'
										else:
											israteperstay = 'Y'
									else:
										Curr        = ''
										OnsiteRate  = 0
									if 'taxes' in Rates:
										TaxAmount  = Rates['taxes']['amount']
									else:
										TaxAmount  = 0	
									if TaxAmount==0:
										if 'fees' in Rates:
											TaxAmount  = Rates['fees']['amount']
										else:
											TaxAmount  = 0
								else:
									Curr        = ''
									OnsiteRate  = 0
									TaxAmount  = 0
								if 'hotelPromoType' in block:
									promotion = block['hotelPromoType']
									if promotion:
										Promotion_Name  = promotion['promoDescription']
										isPromotionalRate = 'Y'
									else:
										Promotion_Name  = ''
								if 'isBreakfastIncluded' in block:
									if block['isBreakfastIncluded']:
										Meal = "Breakfast Included"
									else:
										Meal = 'Without Breakfast'
								else:
									Meal = None
								if 'isWifiIncluded' in   block:
									if block['isWifiIncluded']:
										Wifi = "Wifi-Included"
									else:
										Wifi = 'Without Wifi'
								else:
									Wifi = None
								'''if 'isRefundable' in block:
									if block['isRefundable']:
										Ratetype = "Refundable"
									else:
										Ratetype = 'Non-Refundable'
								else:
									Ratetype = None'''      
								if 'roomCancellationPolicy' in block:
									rate_re = block['roomCancellationPolicy']
									if rate_re:
										Ratetype  = rate_re['cancellationPolicyString']
									else:
										Ratetype  = ''
								if 'amenitiesIncluded' in block:
									for Amenities in block['amenitiesIncluded']:
										List_Amein.append(Amenities)
								else:
									List_Amein = ''  
								TaxAmount = int(TaxAmount)
								OnsiteRate = int(OnsiteRate)
								NetRate = int(NetRate)
								if int(numOfDecimalPoint) == 2:
									if OnsiteRate!=0:
										OnsiteRate1 = re.search('(\d+)(\d\d$)', str(OnsiteRate)).group(1)
										OnsiteRate2 = re.search('(\d+)(\d\d)$', str(OnsiteRate)).group(2)
										OnsiteRate = OnsiteRate1+'.'+OnsiteRate2
									if NetRate!=0:
										NetRate1 = re.search('(\d+)(\d\d$)', str(NetRate)).group(1)
										NetRate2 = re.search('(\d+)(\d\d)$', str(NetRate)).group(2)
										NetRate = NetRate1+'.'+NetRate2
									if TaxAmount!=0:
										TaxAmount1 = re.search('(\d+)(\d\d$)', str(TaxAmount)).group(1)
										TaxAmount2 = re.search('(\d+)(\d\d)$', str(TaxAmount)).group(2)
										TaxAmount = TaxAmount1+'.'+TaxAmount2              
								if LOS>1:
									TaxAmount  = round(float(TaxAmount)/float(LOS),2)  
									OnsiteRate = round(float(OnsiteRate)/float(LOS),2)
									NetRate    = round(float(NetRate)/float(LOS),2)								
								GrossRate       = OnsiteRate
								Discount        = NetRate
								Mealtype        = Meal
								RateDescription = re.sub(r'<.*?>','',re.sub(r"'","''",str(description)))    
								RoomAmenity_Type= re.sub(r'\[|\]','',re.sub(r"u|'","",str(List_Amein)))
								##print RoomType, Ratetype
								RoomType        = re.sub(r"'","''",str(RoomType))
								Ratetype        = re.sub(r"'","''",unidecode(Ratetype).encode('ascii'))
								Promotion_Name  = re.sub(r"'","''",str(Promotion_Name))
								OnsiteRate      = re.sub(r"'","''",str(OnsiteRate))
								GrossRate       = re.sub(r"'","''",str(GrossRate))
								NetRate         = re.sub(r"'","''",str(NetRate))
								Curr            = re.sub(r"'","''",str(Curr))
								MaxOccupancy    = re.sub(r"'","''",str(MaxOccupancy))
								Mealtype        = re.sub(r"'","''",str(Mealtype))
								RateDescription = re.sub(r"'","''",str(RateDescription))
								RoomAmenity_Type= re.sub(r"'","''",str(RoomAmenity_Type))
								if OnsiteRate==0:
									Closed = 'Y'
								else:
									Closed = 'N'
								if TaxAmount:
									Taxstatus = '1'
								else:
									Taxstatus = '2'
								print"RoomType :",RoomType
								print"RateType :",Ratetype
								print"OnsiteRat:",OnsiteRate
								##print"GrossRate:",GrossRate
								##print"NetRate  :",NetRate
								##print"Currecy  :",Curr
								##print"MaxOcpy  :",MaxOccupancy
								##print"Meal     :",Mealtype
								##print"Descript :",RateDescription
								##print"Amenities:",RoomAmenity_Type
								##print"_"*50
								array.append(aws_insert.insert(id_update, inputid , Domainname, Websitecode, StartDate, RoomType, LOS, RateDate, Guests, OnsiteRate, NetRate, GrossRate, Curr, RateDescription, url_insert, url_insert, url_insert, RoomAmenity_Type, Mealtype, MaxOccupancy, isPromotionalRate, Closed, 30, StartDate , EndDate, intime, isAvailable, Taxtype, TaxAmount, Taxstatus, None, Ratetype, Discount,Promotion_Name,region,statuscode, israteperstay))
								#insert                                                           (ReportDate,RoomType,RoomTypeMapped,LOS,RateDate,Guests,OnsiteRate,NetRate,GrossRate,Curr,RateDescription,urlRate,urlInclusions,urlAmenities,RoomAmenity_Type,Mealtype,MaxOccupancy,isPromotionalRate,Closed,NumberOfDays,StartDate,EndDate,StarCategory,Rooms,PageOnRank,Featured,LastModified,isUpdated,isAvailable,Taxtype,TaxAmount,HotelBlock,Ratetype,Discount,Promotion_Name)
						else:
							Closed = 'Y'
							statuscode='2'
							array.append(aws_insert.insert(id_update, inputid , Domainname, Websitecode, StartDate, RoomType, LOS, RateDate, Guests, OnsiteRate, NetRate, GrossRate, Curr, RateDescription, url_insert, url_insert, url_insert, RoomAmenity_Type, Mealtype, MaxOccupancy, isPromotionalRate, Closed, 30, StartDate , EndDate, intime, isAvailable, Taxtype, TaxAmount, Taxstatus, HotelBlock, Ratetype, Discount,Promotion_Name,region,statuscode, israteperstay))
				else:
					Closed = 'Y'
					statuscode='2'
					array.append(aws_insert.insert(id_update, inputid , Domainname, Websitecode, StartDate, RoomType, LOS, RateDate, Guests, OnsiteRate, NetRate, GrossRate, Curr, RateDescription, url_insert, url_insert, url_insert, RoomAmenity_Type, Mealtype, MaxOccupancy, isPromotionalRate, Closed, 30, StartDate , EndDate, intime, isAvailable, Taxtype, TaxAmount, Taxstatus, HotelBlock, Ratetype, Discount,Promotion_Name,region,statuscode, israteperstay))
			else:
				Closed = 'Y'
				statuscode='2'
				array.append(aws_insert.insert(id_update, inputid , Domainname, Websitecode, StartDate, RoomType, LOS, RateDate, Guests, OnsiteRate, NetRate, GrossRate, Curr, RateDescription, url_insert, url_insert, url_insert, RoomAmenity_Type, Mealtype, MaxOccupancy, isPromotionalRate, Closed, 30, StartDate , EndDate, intime, isAvailable, Taxtype, TaxAmount, Taxstatus, HotelBlock, Ratetype, Discount,Promotion_Name,region,statuscode, israteperstay))
		else:
			Closed = 'Y'
			statuscode='2'
			array.append(aws_insert.insert(id_update, inputid , Domainname, Websitecode, StartDate, RoomType, LOS, RateDate, Guests, OnsiteRate, NetRate, GrossRate, Curr, RateDescription, url_insert, url_insert, url_insert, RoomAmenity_Type, Mealtype, MaxOccupancy, isPromotionalRate, Closed, 30, StartDate , EndDate, intime, isAvailable, Taxtype, TaxAmount, Taxstatus, HotelBlock, Ratetype, Discount,Promotion_Name,region,statuscode, israteperstay))
		keyvalue = "ondemand/{}/{:%Y%m%d}/delivery/{}.json".format(Websitecode,datetime.datetime.now(),str(inputid)+'_'+str(Rtdate)+'_'+id_update)
		key = bucket.new_key(keyvalue)
		key.set_contents_from_string(json.dumps(array))
		return json.dumps(array)
	except Exception as e:
		insert_value_error=str(str(re.sub(r"'",'"',str(e))))+'Where line number '+str(sys.exc_traceback.tb_lineno)+str(proxyip)
		statuscode='4'
		print insert_value_error
		Guests='1'
		keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(Websitecode,datetime.datetime.now(),id_update)
		key = bucket.new_key(keyvalue)
		key.set_contents_from_string(insert_value_error)
		array.append(aws_insert.insert(id_update, inputid ,Domainname,Websitecode, "","", "", "", Guests, "", "", "", "", "",url_insert, url_insert, url_insert, "", "", "", "", "", "",StartDate, EndDate , "", "", "", "", "", "",  "", "", "",region,statuscode, israteperstay))
		return json.dumps(array)

# fetchrates(url ,inputid, id_update, proxyip)
