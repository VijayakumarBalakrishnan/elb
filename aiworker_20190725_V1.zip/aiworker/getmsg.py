import pika 
from retry import retry 
import random
import pymysql 
import json
import boto3

conn =pymysql.connect(host='rmapi-cluster.cluster-cj3numypvgef.us-west-2.rds.amazonaws.com',user='root',password='SpY&76aJ',db='rmapi',charset='utf8mb4',cursorclass=pymysql.cursors.DictCursor) 


cred = pika.credentials.PlainCredentials('admin','Pr0tect3d')

def on_message(channel, method_frame, header_frame, body):
	
	msgbody = json.loads(body)
	res_body = msgbody["resp"]
	row = msgbody["row"]
	queueid, hotelcode,websitecode,RateDate,Los,checkin,checkout, snapshoturl, pos, refid, proxy = (row["queueid"], row["hotelcode"], row["websitecode"], row["checkin"], row["los"], row["checkin"], row["checkout"], row["snapshoturl"], row["pos"], row["debugid"], row["proxy"])
	print queueid
	searchkeyword,roomtypecode,conditionscode,mealplancode,subjecthotelcode = (None,)*5

	for resp_body in res_body:					
	    cursor = conn.cursor()
	    cursor.execute("insert into queuerates(queueid,hotelcode,subjecthotelcode,websitecode,dtcollected,ratedate,los,guests,roomtype,onsiterate,netrate,currency,ratedescription,ratetype,sourceurl,roomamenities,maxoccupancy,ispromo,closed,checkin,checkout,discount,promoname,searchkeyword,roomtypecode,conditionscode,mealplancode,status_code,taxstatus,taxtype,taxamount,region,pos,proxyused,debugid,israteperstay,snapshoturl) values (%s,%s,%s,%s,now(),%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)",(queueid,hotelcode,subjecthotelcode,websitecode,RateDate,Los,resp_body['guests'],resp_body['roomtype'],resp_body['onsiterate'],resp_body['netrate'],resp_body['curr'],resp_body['roomdescription'],resp_body['ratetype'],resp_body['url'],resp_body['roomamenity'],resp_body['maxocp'],resp_body['isprom'],resp_body['closed_up'],checkin,checkout,resp_body['netrate'],resp_body['promotion'],searchkeyword,roomtypecode,conditionscode,mealplancode,200 if resp_body['statuscode'] == '' else int(resp_body['statuscode']) + 200,resp_body['taxstatus'],resp_body['taxtype'],resp_body['taxamount'],resp_body['region'],pos,proxy,refid,resp_body['israteperstay'],snapshoturl,))
	conn.commit()

	channel.basic_ack(delivery_tag=method_frame.delivery_tag)

node1 = pika.URLParameters("amqp://admin:Pr0tect3d@52.8.190.159:5672")

all_endpoints = [ node1 ]

@retry(pika.exceptions.AMQPConnectionError, delay=5, jitter=(1, 3))
def consume():
	connection = pika.BlockingConnection(pika.ConnectionParameters(host='52.8.190.159', port=5672, credentials=cred))
	channel = connection.channel()
	channel.basic_qos(prefetch_count=1)

	channel.queue_declare('rmapiq', durable=True)
	channel.basic_consume(on_message, 'rmapiq')

	try:
		channel.start_consuming()
	except KeyboardInterrupt:
		channel.stop_consuming()
		channel.close()
	except pika.exceptions.ConnectionClosed:
		pass
#		continue

consume()