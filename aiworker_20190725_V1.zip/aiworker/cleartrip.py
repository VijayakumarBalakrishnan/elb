# -*- coding: utf-8 -*-
import re
import requests
import datetime
import json
import sys 
import boto
import gc
import aws_insert
import time
import random
from unidecode import unidecode

start = time.time()
#print start

# url       = 'https://www.cleartrip.com/hotels/details/1350594?c=2018-08-10|2018-08-11&r=1,0'
# inputid   = ''
# id_update = ''
# proxyip = 'user-34068:214859b73da0e174@45.64.106.56:1212'



def fetchrates(url , inputid, id_update, proxyip):
	array = []
	add = []
	curr_fix = ''
	israteperstay = ''
	if re.search(r'Currency=.*?&', url, re.DOTALL):
		curr_fix = re.search(r'Currency=(.*?)&', url, re.DOTALL).group(1)
	url = re.sub(r'Currency=.*?&', '', url)

	intime = re.sub(r'\s', 'T', str(datetime.datetime.now()))
	functionname = 'Cleartrip'
	#print functionname
	StartDate = datetime.date.today()
	EndDate = datetime.date.today() + datetime.timedelta(days=29)
	conn = boto.connect_s3(aws_access_key_id='AKIAIXEGZVXCWE2FV3SQ', aws_secret_access_key='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') 
	bucket = conn.get_bucket("rmapi")
	region = ''
	##print url
	try:
		checkin = re.search(r'c=(.*?)\|(.*?)&', url)
		if checkin:
			chkins = checkin.group(1)
			chkouts = checkin.group(2)
		checkin_format = datetime.datetime.strptime(str(chkins), "%Y-%m-%d").strftime("%d%m%y")
		checkout_format = datetime.datetime.strptime(str(chkouts), "%Y-%m-%d").strftime("%d%m%y")
		guest = re.search(r'r=(\d+),', url)
		if guest:
			adlts = guest.group(1)
		chk_concat = 'c=' + checkin_format + '|' + checkout_format + '&r=' + adlts + ',0'
		url = re.sub(r'c=.*', chk_concat, url)
		chkin = datetime.datetime.strptime(re.sub("http.*?c=|\|.*", "", url), "%d%m%y").strftime("%d/%m/%Y")
		chkout = datetime.datetime.strptime(re.sub("http.*?=.*?\||&.*", "", url), "%d%m%y").strftime("%d/%m/%Y")
		RateDate = datetime.datetime.strptime(re.sub("http.*?c=|\|.*", "", url), "%d%m%y").strftime("%Y-%m-%d")
		hotelid = re.sub("http.*?details/|\?c.*", "", url.replace("\\", ""))
		# #print hotelid
		checkins = datetime.datetime.strptime(chkins, str("%Y-%m-%d")).strftime("%Y, %m, %d")
		checkouts = datetime.datetime.strptime(chkouts, str("%Y-%m-%d")).strftime("%Y, %m, %d")
		ccin = datetime.datetime.strptime(checkins, '%Y, %m, %d')
		ccout = datetime.datetime.strptime(checkouts, '%Y, %m, %d')
		LOS = ccout - ccin
		LOS = LOS.days
		sr = requests.Session()
		Websitecode = '4'
		Domainname = 'ClearTrip'
		StartDate = ''
		Roomtype = ''
		Guests = adlts
		OnsiteRate = 0
		NetRate = 0
		GrossRate = 0
		region = ''
		currency = ''
		RateDescription = ''
		Tax_status = ""
		RoomAmenity_Type = ''
		Mealtype = ''
		MaxOccupancy = ''
		isPromotionalRate = 'N'
		Closed_up = 'N'
		Roomavilable = ''
		Taxtype = ''
		Taxamount = ''
		Ratetype = ''
		NetRate = ''
		Promotion_Name = ''
		statuscode = ''
		#print url
		inpl = ['user-37082:a7d2c0d3ace90f48@45.64.105.154:1212','user-37082:a7d2c0d3ace90f48@103.250.184.172:1212','user-37082:a7d2c0d3ace90f48@103.12.211.82:1212','user-37082:a7d2c0d3ace90f48@45.64.106.37:1212','user-37082:a7d2c0d3ace90f48@45.64.106.5:1212','user-37082:a7d2c0d3ace90f48@45.64.106.27:1212','user-37082:a7d2c0d3ace90f48@103.250.184.229:1212','user-37082:a7d2c0d3ace90f48@45.64.106.62:1212','user-37082:a7d2c0d3ace90f48@45.64.106.41:1212','user-37082:a7d2c0d3ace90f48@103.250.184.252:1212']
		head = {'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/50.0.2661.102 Safari/537.36'}
		Rtp_header = {'Host':'www.cleartrip.com','User-Agent':'Mozilla/5.0 (X11; Linux x86_64; rv:45.0) Gecko/20100101 Firefox/45.0','Accept':'application/json, text/javascript, */*; q=0.01','Accept-Language':'en-US,en;q=0.5','Accept-Encoding':'gzip, deflate, br','X-CT-SOURCETYPE':'','X-Requested-With':'XMLHttpRequest','Referer':str(url),'Connection':'keep-alive'}
		proxies = {"https": "http://{}".format(proxyip)}
		headj = {'Host':'www.cleartrip.com','User-Agent':'Mozilla/5.0 (X11; Linux x86_64; rv:45.0) Gecko/20100101 Firefox/45.0','Accept':'application/json, text/javascript, */*; q=0.01','Accept-Language':'en-US,en;q=0.5','Accept-Encoding':'gzip, deflate, br','X-CT-DOCUMENT_REFERER':'','X-Requested-With':'XMLHttpRequest','Referer':str(url),'Connection':'keep-alive'}
		json_url = "https://www.cleartrip.com/hotels/service/rate-calendar?chk_in=" + chkin + "&chk_out=" + chkout + "&num_rooms=1&adults1=" + adlts + "&children1=0&ct_hotelid=" + hotelid + "&pahCCRequired=true" 
		#print json_url
		#headj = {'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/50.0.2661.102 Safari/537.36' }
		try:
			hml = sr.get(url, headers=head, proxies=proxies, timeout=15)
			json_load = requests.get(json_url, headers=headj, proxies=proxies, timeout = 15)
			# #print hml.status_code
# 			print json_load.status_code
# 			print json_load.headers
# 			print json_load.histroy
# 			print json_load.url
		except Exception, e:
			try:
				prox = random.choice(inpl)
				proxies      = {"https": "http://{}".format(prox)}
				hml = sr.get(url, headers=head, proxies=proxies, timeout=20)
				json_load = requests.get(json_url, headers=headj, proxies=proxies, timeout = 20)
			except Exception, e:
				try:
					prox = random.choice(inpl)
					proxies      = {"https": "http://{}".format(prox)}
					hml = sr.get(url, headers=head, proxies=proxies, timeout=25)
					json_load = requests.get(json_url, headers=headj, proxies=proxies, timeout = 25)
				except Exception, e:
					value_error = str(re.sub("'", '"', str(e)))
					stacktrace = sys.exc_traceback.tb_lineno
					value_error = str(e)
					stacktrace = sys.exc_traceback.tb_lineno
					keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(Websitecode, datetime.datetime.now(), id_update)
					#print keyvalue
					key = bucket.new_key(keyvalue)
					key.set_contents_from_string(str(e))
					region = ''
					statuscode = 5
					Guests = adlts
					array.append(aws_insert.insert(id_update, inputid , functionname, Websitecode, "", "", "", "", Guests, "", "", "", "", "", url, url, url, "", "", "", "", "", "", StartDate, EndDate , "", "", "", "", "", "", "", "", "", region, statuscode, israteperstay))
					return json.dumps(array)

		html = hml.text
		html = unidecode(html).encode('ascii')
# 		open('name.html', 'w').write(str(html))
		
		ip = re.sub(r"\{'.*?@|'\}|:\d+", "", str(proxies))
		try:
			try:
				r = requests.get('http://freegeoip.net/json/' + ip, timeout=30)
			except Exception, e:
				r = requests.get('http://freegeoip.net/json/' + ip, timeout=30)
			js = r.json()
			region = js['country_name']
		except Exception, e:
			region = ''
		# #print json_load.text
		source_save = 'Html:'+str(unidecode(html).encode('ascii'))+' json:'+str(unidecode(json_load.text).encode('ascii'))
		scode =hml.status_code, json_load.status_code
		Rtdate=re.sub(r'-|\-','',str(RateDate))
		keyvalue = "ondemand/{}/{:%Y%m%d}/source/{}.json".format(Websitecode, datetime.datetime.now(), str(inputid) + '_' + str(Rtdate) + '_' + id_update)
		#print keyvalue
		key = bucket.new_key(keyvalue)
		key.set_contents_from_string(source_save)
		if json_load.status_code == 429:
			#value_error = '429'
			#stacktrace = sys.exc_traceback.tb_lineno
			insert_value_error = 'html and json statuscodes :'+ str(scode)+'where proxy'+str(proxyip)
			print insert_value_error
			statuscode = '7'
			Websitecode = '4'
			keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(Websitecode, datetime.datetime.now(), id_update)
			key = bucket.new_key(keyvalue)
			key.set_contents_from_string(insert_value_error)
			Guests = adlts
			array.append(aws_insert.insert(id_update, inputid , functionname, Websitecode, "", "", "", "", Guests, "", "", "", "", "", url, url, url, "", "", "", "", "", "", StartDate, EndDate , "", "", "", "", "", "", "", "", "", region, statuscode, israteperstay))
			return json.dumps(array)
		try:	
			#jsonsource = json.loads(json_load.text)
			jsonsource=json.loads(unidecode(json_load.text).encode('ascii'))
		except Exception as e:
			value_error = str(re.sub(r"'", '"', str(e)))
			stacktrace = sys.exc_traceback.tb_lineno
			insert_value_error = str(value_error) + 'Where line number ' + str(stacktrace) + str(proxyip) + 'html and json statuscodes :'+ str(scode)
			print insert_value_error
			statuscode = '4'
			Websitecode = '4'
			keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(Websitecode, datetime.datetime.now(), id_update)
			key = bucket.new_key(keyvalue)
			key.set_contents_from_string(insert_value_error)
			Guests = adlts
			array.append(aws_insert.insert(id_update, inputid , functionname, Websitecode, "", "", "", "", Guests, "", "", "", "", "", url, url, url, "", "", "", "", "", "", StartDate, EndDate , "", "", "", "", "", "", "", "", "", region, statuscode, israteperstay))
			return json.dumps(array)	
		
		
# 		open('json.html', 'w').write(str(unidecode(json_load.text).encode('ascii')))
		if 'rms' in json_load.text:
			for roomblock in jsonsource['rc']['d0']['rms']:
				main_block = ''
				Roomtype = re.sub("&amp;", "&", re.sub(":.*", "", re.sub("'", "''", str(roomblock['rm']))))
				# #print Roomtype
				if roomblock.has_key('i'):
					RateDescription = re.sub("&amp;", "&", re.sub("\.", ",", re.sub("'", "''", str(roomblock['i']))))
				else:
					RateDescription = ''
				OnsiteRate1 = roomblock['tot']
				if str(curr_fix) == 'USD':
					test = OnsiteRate1 / 66.09
					currency = 'USD'
				elif str(curr_fix) == 'GBP':
					test = OnsiteRate1 / 80.44
					currency = 'GBP'
				elif str(curr_fix) == 'AUD':
					test = OnsiteRate1 / 49.97
					currency = 'AUD'
				elif str(curr_fix) == 'EUR':
					test = OnsiteRate1 / 70.33
					currency = 'EUR'
				elif str(curr_fix) == 'AED':
					test = OnsiteRate1 / 17.91
					currency = 'AED'
				elif str(curr_fix) == 'BHD':
					test = OnsiteRate1 / 176.60
					currency = 'BHD'
				elif str(curr_fix) == 'SGD':
					test = OnsiteRate1 / 46.72
					currency = 'SGD'
				elif str(curr_fix) == 'MYR':
					test = OnsiteRate1 / 14.86
					currency = 'MYR'
				elif str(curr_fix) == 'NPR':
					test = OnsiteRate1 / 0.63
					currency = 'NPR'
				else:
					test = OnsiteRate1
					currency = 'INR'
				OnsiteRate = int(round(test))
				# #print "OnsiteRate ==",OnsiteRate
				# OnsiteRate=int(OnsiteRate)/int(LOS)
				# #print "LOS =",LOS
				# #print "OnsiteRate per nyt ==",OnsiteRat
				GrossRate = OnsiteRate
				Closed_up = 'N'
				if roomblock.has_key('d'):
					Netrate_add = float(roomblock['d'])
					if Netrate_add <> 0.0:
						NetRate = round(float(OnsiteRate) + Netrate_add)
						ispromupdate = 'Y'
					else:
						NetRate = '0'
						ispromupdate = 'N'
				else:
					ispromupdate = 'N'
				Mealtype = roomblock['srn']
				# #print Meal
				if OnsiteRate:
					Tax_status = '1'
				else:
					Tax_status = '-1'
				roomtypecode = roomblock['rmtc']
				Bookingcode = roomblock['rtc']
				roomcode = str(roomblock['rtid'])
				if re.search(r'"' + roomcode + '":({.*?}}]})', html, re.DOTALL):
					jsonamnty = re.search(r'"' + roomcode + '":({.*?}}]})', html, re.DOTALL).group(1)
					jsnval = json.loads(str(jsonamnty))
					for cat in jsnval['roomAmenity']:
						amntyp = cat['category']
						amntyp = amntyp + ' : '
						jsonamntys = cat['amenities']['amenity']
						amntremov = re.sub(r"\[|\]|u|'", "", str(jsonamntys))
						amntytyp = amntyp, amntremov
						add.append(amntytyp)
					amntrem = re.sub(r"\[|\]|u|'", "", str(add))
					#print "inside amnt"
					RoomAmenity_clean = re.sub(r"\(|\)", "", str(amntrem))
					RoomAmenity_Type = RoomAmenity_clean
				elif re.search(r'"' + roomcode + '":({"roomAmenity":\[{.*?}]})', html, re.DOTALL):
					jsonamnty = re.search(r'"' + roomcode + '":({.*?}]})', html, re.DOTALL).group(1)
					jsnval = json.loads(str(jsonamnty))
					for cat in jsnval['roomAmenity']:
						amntyp = cat['category']
						amntyp = amntyp + ' : '
						jsonamntys = cat['amenities']['amenity']
						amntremov = re.sub(r"\[|\]|u|'", "", str(jsonamntys))
						amntytyp = amntyp, amntremov
						add.append(amntytyp)
					amntrem = re.sub(r"\[|\]|u|'", "", str(add))
					#print "inside amnt"
					amntrem = re.sub(r":\s*,", ":", amntrem)
					RoomAmenity_clean = re.sub(r"\(|\)", "", str(amntrem))
					RoomAmenity_Type = RoomAmenity_clean
				else:
					RoomAmenity_Type = ''
				
				
				if re.search(r'(rmtc="' + roomcode + '.*?rateTagsContainer"></div>)', html, re.DOTALL):
					main_block = re.search(r'(rmtc="' + roomcode + '.*?rateTagsContainer"></div>)', html, re.DOTALL).group(1)
					if re.search(r'<div class="roomInfo">(.*?)</div>', main_block, re.DOTALL):
						RoomAmenity_Type = re.sub("&amp;", "&", re.sub(" ;", "; ", re.sub("\s+", " ", re.sub("^;", "", re.sub("<.*?>", "", re.sub("<strong>", ";", re.sub("</strong>", ":", re.sub("\s+", " ", re.search(r'<div class="roomInfo">(.*?)</div>', main_block, re.DOTALL).group(1))))).strip()))))
						# RoomAmenity_Type = RoomAmenity_Typ + RoomAmenity_Type
						# #print RoomAmenity_Type
						if re.search(r'h5>\s*<script type="text/javascript">(.*?)</div>', main_block, re.DOTALL):
							RateDescription = RateDescription + ',' + re.sub("'", "''", re.sub("<.*?>|var .*? =.*?;|View room details", "", re.sub("</small>", ",", re.sub("\s+", " ", re.search(r'h5>\s*<script type="text/javascript">(.*?)</div>', main_block, re.DOTALL).group(1))).replace('View,', 'View')).replace('  ', ''))
						else:
							RateDescription = RateDescription
				# #print " RoomAmenity_Type =", RoomAmenity_Type
				
				add = []
				
				'''Ratetype_link = 'https://www.cleartrip.com/hotels/cancelPolicy?chk_in=' + re.sub("/", "%2F", chkin) + '&chk_out=' + re.sub("/", "%2F", chkout) + '&num_rooms=1&adults1=' + adlts + '&children1=0&city=""&state=""&cnm=""&country=&roomTypeCode=' + re.sub(":", "%3A", roomtypecode) + '&bookingCode=' + re.sub(":", "%3A", Bookingcode.replace("#", "%23")) + '&ct_hotelid=' + hotelid
				#print Ratetype_link
				try:
					Ratetype_load = sr.get(Ratetype_link, headers=Rtp_header, proxies=proxies)
				except Exception, e:
					value_error = str(e)
					stacktrace = sys.exc_traceback.tb_lineno
					#arora_insert.Errorlog(id_update, Domainname, value_error, stacktrace, intime, url, proxy_arora)
				Ratetype_load = sr.get(Ratetype_link, headers=Rtp_header)
				if Ratetype_load.status_code == 200:
					Ratetype_source = Ratetype_load.text
					Ratetype_source = Ratetype_source.encode('ascii', 'ignore')
					# Ratetype = re.sub("<.*?>|\..*", "", re.sub("'", "''", Ratetype_source))
					Ratetype = Ratetype_load.text
				# #print "Ratetype", Ratetype'''
				Ratetype=''
				if OnsiteRate == 0 or str(OnsiteRate) == '0':
					Closed_up = 'Y'
					statuscode = '1'
				else:
					Closed_up = 'N'
					statuscode = ''
					Tax_status = '1'
					israteperstay = 'Y'	
# 				print (id_update, inputid , Domainname, Websitecode, StartDate, Roomtype, LOS, RateDate, Guests, OnsiteRate, NetRate, GrossRate, currency, RateDescription, url, url, url, RoomAmenity_Type, Mealtype, MaxOccupancy, ispromupdate, Closed_up, 30, StartDate , EndDate, intime, Roomavilable, Taxtype, Taxamount, Tax_status, None, Ratetype, NetRate,Promotion_Name,region,statuscode)
				array.append(aws_insert.insert(id_update, inputid , Domainname, Websitecode, StartDate, Roomtype, LOS, RateDate, Guests, OnsiteRate, NetRate, GrossRate, currency, RateDescription, url, url, url, RoomAmenity_Type, Mealtype, MaxOccupancy, ispromupdate, Closed_up, 30, StartDate , EndDate, intime, Roomavilable, Taxtype, Taxamount, Tax_status, None, Ratetype, NetRate, Promotion_Name, region, statuscode, israteperstay))
				
		elif "unable to find rates currently" in json_load.text:
			Closed_up = 'Y'
			ispromupdate = 'N'
			statuscode = '2'
# 			print (id_update, inputid , Domainname, Websitecode, StartDate, Roomtype, LOS, RateDate, Guests, OnsiteRate, NetRate, GrossRate, currency, RateDescription, url, url, url, RoomAmenity_Type, Mealtype, MaxOccupancy, ispromupdate, Closed_up, 30, StartDate , EndDate, intime, Roomavilable, Taxtype, Taxamount,  None, Ratetype, NetRate,Promotion_Name,statuscode)
			array.append(aws_insert.insert(id_update, inputid , Domainname, Websitecode, StartDate, Roomtype, LOS, RateDate, Guests, OnsiteRate, NetRate, GrossRate, currency, RateDescription, url, url, url, RoomAmenity_Type, Mealtype, MaxOccupancy, isPromotionalRate, Closed_up, 30, StartDate , EndDate, intime, Roomavilable, Taxtype, Taxamount, Tax_status, None, Ratetype, NetRate, Promotion_Name, region, statuscode, israteperstay))		
		else:
			#print "else"
			Closed_up = 'Y'
			ispromupdate = 'N'
			statuscode = '2'
			array.append(aws_insert.insert(id_update, inputid , Domainname, Websitecode, StartDate, Roomtype, LOS, RateDate, Guests, OnsiteRate, NetRate, GrossRate, currency, RateDescription, url, url, url, RoomAmenity_Type, Mealtype, MaxOccupancy, isPromotionalRate, Closed_up, 30, StartDate , EndDate, intime, Roomavilable, Taxtype, Taxamount, Tax_status, None, Ratetype, NetRate, Promotion_Name, region, statuscode, israteperstay))	
		Rtdate=re.sub(r'-|\-','',str(RateDate))
		keyvalue = "ondemand/{}/{:%Y%m%d}/delivery/{}.json".format(Websitecode, datetime.datetime.now(), str(inputid) + '_' + str(Rtdate) + '_' + id_update)
		key = bucket.new_key(keyvalue)
		key.set_contents_from_string(json.dumps(array))
		return json.dumps(array)
		gc.collect()	
	except Exception, e:
		value_error = str(re.sub(r"'", '"', str(e)))
		stacktrace = sys.exc_traceback.tb_lineno
		insert_value_error = str(value_error) + 'Where line number ' + str(stacktrace) + str(proxyip)
		print insert_value_error
		statuscode = '4'
		Websitecode = '4'
		keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(Websitecode, datetime.datetime.now(), id_update)
		key = bucket.new_key(keyvalue)
		key.set_contents_from_string(insert_value_error)
		Guests = adlts
		array.append(aws_insert.insert(id_update, inputid , functionname, Websitecode, "", "", "", "", Guests, "", "", "", "", "", url, url, url, "", "", "", "", "", "", StartDate, EndDate , "", "", "", "", "", "", "", "", "", region, statuscode, israteperstay))
		return json.dumps(array)
# fetchrates(url , inputid, id_update, proxyip)
end = time.time() - start
#print end
