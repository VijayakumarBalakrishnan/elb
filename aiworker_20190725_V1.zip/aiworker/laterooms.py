# -*- coding: utf-8 -*-
import re
import requests
import datetime
import json
import boto
import sys 

import aws_insert



'''url = 'https://www.laterooms.com/en/hotel-reservations/156684_the-bermondsey-square-hotel-a-bespoke-hotel-london.aspx?d=2017-11-13&n=1&rt=2-0&rt-adult=1&child=0&checkout=2017-11-14#&currency=GBP#'
inputid = '233'
id_update = '2345'
proxyip = 'media:M3diAproxy@107.175.37.72:80'''

def fetchrates(url , inputid, id_update, proxyip):
	array = []
	sr = requests.Session()
	israteperstay = ''
	intime=re.sub(r'\s','T',str(datetime.datetime.now()))
	functionname='Laterooms'
	Domainname=functionname
	StartDate = datetime.date.today()
	EndDate  = datetime.date.today() + datetime.timedelta(days=29)
	conn = boto.connect_s3(aws_access_key_id= 'AKIAIXEGZVXCWE2FV3SQ',aws_secret_access_key = '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') 
	bucket = conn.get_bucket("rmapi")
	RateDate=''
	region=''
	Websitecode = "269"
	refer_url=''
	try:
		proxies = {"https": "http://{}".format(proxyip)}
		head = {'User-Agent':'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:12.0) Gecko/20100101 Firefox/48.0'}
		rid = re.search(r'reservations/(\d+)_',url).group(1)
		date = re.search("\?d=(.*?)&n",url)
		if date:
			chkins = date.group(1)
			chkin = re.sub(r'-','',chkins)
		adlt = re.search("adult=(.*?)&",url)
		if adlt:
			adults = adlt.group(1)	
		RateDate = chkins
		cout = re.search("&checkout=(.*?)#",url)
		if cout:
			chkout = cout.group(1)
		curr_reg = re.search("&currency=(.*?)#",url)
		if curr_reg:
			curr = curr_reg.group(1)
		delta = datetime.datetime.strptime(chkout, "%Y-%m-%d") - datetime.datetime.strptime(RateDate, "%Y-%m-%d") 
		LOS=delta.days
		refer_url = re.sub(r"\?d=.*", r"", url)+'?d='+chkin+'&n='+str(LOS)+'&rt='+adults+'-0&rt-adult='+adults+'&child=0&currency='+str(curr)
		if proxies:
			hml = sr.get(refer_url, headers=head, proxies = proxies)
		else:
			hml = sr.get(refer_url, headers=head)
		#print hml.status_code
		html = hml.text
		html = html.encode('ascii', 'ignore')
		spe = re.search("data-provider-id=[\'|\"](.*?)[\'|\"]",html)
		if spe:
			sp1 = spe.group(1)
			Providerid = re.sub("&amp;|,|'|<.*?>",'',sp1)
		spe = re.search("data-id=[\'|\"](.*?)[\'|\"]",html)
		if spe:
			sp1 = spe.group(1)
			dataid = re.sub("&amp;|,|'|<.*?>",'',sp1)
		else:
			statuscode='9'
			insert_value_error="dataid not found"
			keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(Websitecode,datetime.datetime.now(),id_update)
			key = bucket.new_key(keyvalue)
			key.set_contents_from_string(insert_value_error)
			Guests=''
			region=''
			array.append(aws_insert.insert(id_update, inputid ,"",Websitecode, "", "", "", "", Guests, "", "", "", "", "",refer_url,refer_url,refer_url, "", "", "", "", "", "",StartDate, EndDate , "", "", "", "", "", "", "", "", "",region,statuscode, israteperstay))
			return json.dumps(array)
			


		#print "url	:=",url
		#RateDate = datetime.datetime.strptime(str(chkin),'%Y%m%d').strftime('%Y-%m-%d')
		url_db = 'https://www.laterooms.com/en/rates/'+dataid+'/?d='+chkin+'&n='+str(LOS)+'&rt='+adults+'-0&rt-adult='+adults+'&child=0&providerId='+Providerid+'&allRates=false&currency='+str(curr)
		head = {'User-Agent':'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:12.0) Gecko/20100101 Firefox/48.0', 'Host':'www.laterooms.com', 'Referer': str(refer_url) , 'X-Requested-With':'XMLHttpRequest', 'If-None-Match':'W/"0-1B2M2Y8AsgTpgAmY7PhCfg"', 'Cache-Control':'max-age=0', 'Accept-Encoding':'gzip, deflate', 'Accept-Language':'en-US,en;q=0.5'}
		#head = {'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/35.0.1916.47 Safari/537.36'}
		try:
			hml = sr.get(url_db, headers= head,proxies=proxies,timeout=50)
			#print "Statuscode 1	:",hml.status_code
		except Exception,e:
			try:
				hml = sr.get(url_db, headers= head, proxies=proxies)
			except Exception,e:
				value_error=str(re.sub("'",'"',str(e)))
				stacktrace=sys.exc_traceback.tb_lineno
				keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(Websitecode,datetime.datetime.now(),id_update)
				key = bucket.new_key(keyvalue)
				key.set_contents_from_string(str(e))
				region=''
				ip=re.sub(r"\{'.*?@|'\}|:\d+","",str(proxies))
				try:
					try:
						r = requests.get('http://freegeoip.net/json/'+ip,timeout=30)
					except Exception,e:
						r = requests.get('http://freegeoip.net/json/'+ip,timeout=30)
					js = r.json()
					region=js['country_name']
				except Exception,e:
					region=''
				statuscode=5
				Guests=adults
				array.append(aws_insert.insert(id_update, inputid ,"",Websitecode, "", "", "", "", Guests, "", "", "", "", "",refer_url, refer_url, refer_url, "", "", "", "", "", "",StartDate, EndDate , "", "", "", "", "", "", "", "", "",region,statuscode, israteperstay))
				return json.dumps(array)
		if (hml.status_code <> 200): 
			hml = sr.get(url_db, headers= head, proxies=proxies)  
		if (hml.status_code == 403 or hml.status_code == 407):
			try:
				'''proxyresult = requests.get('http://www.gimmeproxy.com/api/getProxy?protocol=http')
				jproxy = json.loads(proxyresult.content)
				proxies = { "http": jproxy["curl"] }'''
				hml = sr.get(url_db, headers= head,proxies=proxies)
				if (hml.status_code != 200):
					hml = sr.get(url_db, headers=head)
			except Exception as e:
				value_error=str(re.sub("'",'"',str(e)))
				value_error=str(e).enode('ascii','ignore')
				stacktrace=sys.exc_traceback.tb_lineno
				keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(Websitecode,datetime.datetime.now(),id_update)
				key = bucket.new_key(keyvalue)
				key.set_contents_from_string(str(e))
				region=''
				ip=re.sub(r"\{'.*?@|'\}|:\d+","",str(proxies))
				try:
					try:
						r = requests.get('http://freegeoip.net/json/'+ip,timeout=30)
					except Exception,e:
						r = requests.get('http://freegeoip.net/json/'+ip,timeout=30)
					js = r.json()
					region=js['country_name']
				except Exception,e:
					region=''
				statuscode=5
				Guests=adults
				array.append(aws_insert.insert(id_update, inputid ,"",Websitecode, "", "", "", "", Guests, "", "", "", "", "",refer_url,refer_url,refer_url, "", "", "", "", "", "",StartDate, EndDate , "", "", "", "", "", "", "", "", "",region,statuscode, israteperstay))
				#array.append(aws_insert.insert(id_update, inputid ,"",Websitecode, "", "", "", "", Guests, "", "", "", "", "","", "", "", "", "", "", "", "", "",StartDate, EndDate , "", "", "", "", "",  "", "", "",statuscode))
				return json.dumps(array)
		html = hml.text
		html = html.encode('ascii', 'ignore')
		Rtdate=re.sub(r'-|\-','',str(RateDate))
		keyvalue = "ondemand/{}/{:%Y%m%d}/source/{}.txt".format(Websitecode,datetime.datetime.now(),str(inputid)+'_'+str(Rtdate)+'_'+id_update)
		key = bucket.new_key(keyvalue)
		key.set_contents_from_string(html)
		region=''
		ip=re.sub(r"\{'.*?@|'\}|:\d+","",str(proxies))
		try:
			try:
				r = requests.get('http://freegeoip.net/json/'+ip,timeout=30)
			except Exception,e:
				r = requests.get('http://freegeoip.net/json/'+ip,timeout=30)
			js = r.json()
			region=js['country_name']
		except Exception,e:
			region=''
		try:
			reg_blo1 = re.compile('<div class="room-group"\s*(.*?</div>\s*</div>\s*</div>\s*</div>)', re.DOTALL).findall(html)
			if reg_blo1:
				url_db = 'https://www.laterooms.com/en/rates/'+dataid+'/?d='+chkin+'&n='+str(LOS)+'&rt='+adults+'-0&rt-adult='+adults+'&child=0&providerId='+Providerid+'&allRates=false&currency='+str(curr)
				hml = sr.get(url_db, headers=head)
				#print hml.status_code
				if (hml.status_code <> 200):
					hml = sr.get(url_db, headers=head,proxies=proxies)
				if (hml.status_code == 403 or hml.status_code == 407):
					try:
						proxyresult = requests.get('http://www.gimmeproxy.com/api/getProxy?protocol=http')
						jproxy = json.loads(proxyresult.content)
						proxies = { "http": jproxy["curl"] }
						hml = sr.get(url_db, headers=head,proxies=proxies)
					except ValueError as e:
						hml = sr.get(url_db, headers=head)
				html = hml.text
				html = html.encode('ascii', 'ignore')
			keyvalue = "ondemand/{}/{:%Y%m%d}/source/{}.txt".format(Websitecode,datetime.datetime.now(),str(inputid)+'_'+str(Rtdate)+'_'+id_update)
			key = bucket.new_key(keyvalue)
			key.set_contents_from_string(html)
			RoomType=""
			LOS=LOS
			Guests=adults
			OnsiteRate="0"
			Curr=""
			RateDescription=""
			urlRate= refer_url
			urlInclusions= refer_url
			urlAmenities= refer_url
			RoomAmenity_Type=""
			MealInclusion_Type=""
			MaxOccupancy=""
			Isprom="N"
			Closed_up="Y"
			NumberOfDays=""
			Tax_status=""
			intime=""
			isAvailable=""
			RateDescription=''
			RateType=""
			Discount="0"
			Promotion_Name=""
			Netrate=0
			statuscode=''
			RateDate = RateDate
			reg_blo1 = re.compile('<div class="room-group"\s*(.*?</div>\s*</div>\s*</div>\s*</div>)', re.DOTALL).findall(html)
			if reg_blo1:
				for block1 in re.compile('<div class="room-group"\s*(.*?</div>\s*</div>\s*</div>\s*</div>)', re.DOTALL).findall(html):
					for block in re.compile('<div class=[\'|\"]room-breakdown.*?\s*[\'|\"]>\s*(.*?</div>\s*</div>\s*</div>)', re.DOTALL).findall(block1):
						RoomType=""
						OnsiteRate="0"
						Curr=""
						urlRate= refer_url
						urlInclusions= refer_url
						urlAmenities= refer_url
						RoomAmenity_Type=""
						MealInclusion_Type=""
						MaxOccupancy=""
						Isprom="N"
						Netrate=''
						Closed_up="N"
						NumberOfDays=NumberOfDays
						isAvailable=""
						RateType=""
						Discount="0"
						Promotion_Name=""
						
						pri = re.search(r"</i><i class=[\'|\"]icon-arrow-right[\'|\"]></i>(.*?)</span></h3>",block1)
						if pri:
							RoomType1 = pri.group(1)
							RoomType = re.sub("amp;|'|&.*?;|<.*?>",'',RoomType1)
						spe = re.search(r'<div class=[\'|\"]room-breakdown__price[\'|\"]>\s*(.*?)\s*<',block)
						if spe:
							sp1 = spe.group(1)
							OnsiteRate = re.sub("&amp;|,|'|<.*?>|[A-Z]|[a-z]",'',sp1)
						netrate_reg = re.search(r'<div class=[\'|\"]room-breakdown__price[\'|\"]>\s*.*?\s*<.*?>\s*(.*?)\s*</div>',block)
						if netrate_reg:
							netrate_ = netrate_reg.group(1)
							Netrate = re.sub("&amp;|,|'|<.*?>|[A-Z]|[a-z]",'',netrate_)
						else:
							Netrate=0
							Isprom="N"
						spe1 = re.search(r'name=[\'|\"]Currency[\'|\"] type=[\'|\"]hidden[\'|\"] value=[\'|\"](.*?)[\'|\"]>',html)
						if spe1:
							sp11 = spe1.group(1)
							Curr = re.sub('&amp;|<.*?>','',sp11)
						Curr = re.sub(r'US\$','USD',Curr)
						Curr = re.sub(r'Rs\.','INR',Curr)
						Curr = re.sub(r'\d+|,','',Curr)
						ratetype = re.search(r"<div class=[\'|\"]cancellation-policy[\'|\"]>\s*<h4>(.*?)\s*</h4>",block,re.DOTALL)
						if ratetype:
							ratetype1 = ratetype.group(1)
							RateType1 = re.sub("amp;|'|'|<.*?>",'',ratetype1)
							RateType = re.sub("\s+",' ',RateType1)
						promotion = re.search(r'<h5 class=[\'|\"]room-breakdown__highlight room-breakdown__highlight--offer[\'|\"]>\s*(.*?)\s*</h5>',block,re.DOTALL)
						if promotion:
							promotion1 = promotion.group(1)
							Promotion_Name1 = re.sub("amp;|'|'|<.*?>",'',promotion1)
							Promotion_Name = re.sub("\s+",' ',Promotion_Name1)
							Isprom = 'Y'
						isava = re.search(r'data-remaining=[\'|\"](\d+)[\'|\"] data-singular=[\'|\"]\d+ Room left[\'|\"]',block1)
						if isava:
							isava1 = isava.group(1)
							isAvailable = re.sub("&amp;|'|'|<.*?>",'',isava1)
						mealinclusion = re.search(r'<h4 class=.*?\s*<i class=[\'|\"]icon-arrow-right[\'|\"]></i>\s*(.*?)</span>\s*</h4>',block,re.DOTALL)
						if mealinclusion:
							mealinclusion1 = mealinclusion.group(1)
							MealInclusion_Type = re.sub("amp;|'|,|<.*?>",'',mealinclusion1)
						roomid_url = re.search(r'data-url=[\'|\"](.*?)[\'|\"]',block1)
						if roomid_url:
							roomid_url1 = roomid_url.group(1)
						else:
							roomid_url1 = ''
						url2 = 'https://www.laterooms.com'+roomid_url1
						html2 = ''
						try:
							request = sr.get(url2, headers=head, proxies=proxies)
							if (hml.status_code <> 200): 
								hml = sr.get(url2, headers= head, proxies=proxies)  
							if (hml.status_code == 403 or hml.status_code == 407):
								request = sr.get(url2, headers=head)
						except Exception as e:
							print e
							request = sr.get(url2, headers=head, proxies=proxies)
						jsonvalue = request.text.encode('ascii','ignore')
						html2 = str(jsonvalue)
						des2 = re.search(r'<div class="room-extra__notes">\s*(.*?)\s*</div>',html2)
						if des2:
							d2 = des2.group(1)
							d21 = re.sub(r"'","''", d2)
							RateDescription_feature = re.sub(r'</dd>',',',d21)
							d22_space = re.sub(r'<.*?>|[F|f]eature[s|\s]|:|^\s+|amp;','', RateDescription_feature)
							RateDescription = re.sub(r'\s+|\n',' ', d22_space)
						Maxocp_reg = re.search(r"Price for\s*(\d+)", block1)
						if Maxocp_reg:
							MaxOccupancy = Maxocp_reg.group(1)
						else:
							MaxOccupancy = ""
						#print "MaxOccupancy", MaxOccupancy
						#Discount = Netrate
						if OnsiteRate <> 0:
							Tax_status = 1
							israteperstay = 'Y'
						if OnsiteRate:
							Closed_up = 'N'
						else:
							Closed_up = 'Y'
							statuscode = '2'
						##print "\n-------------------------^^^^^^^^^^^^^^^^^^^^^^^^^---------------------------\n"
						da_time = datetime.datetime.now()
						intime = re.sub(r'\s','T',str(da_time))	
						##print (id_update, inputid , Domainname, Websitecode, StartDate, RoomType, LOS, RateDate, Guests, OnsiteRate, Netrate, OnsiteRate, Curr, RateDescription, urlRate, urlInclusions, urlAmenities, RoomAmenity_Type, MealInclusion_Type, MaxOccupancy, Isprom, Closed_up, 30, StartDate , EndDate, intime, isAvailable, None, None, Tax_status, None, RateType, Discount,Promotion_Name,region,statuscode, israteperstay)
						array.append(aws_insert.insert(id_update, inputid , Domainname, Websitecode, StartDate, RoomType, LOS, RateDate, Guests, OnsiteRate, Netrate, OnsiteRate, Curr, RateDescription, urlRate, urlInclusions, urlAmenities, RoomAmenity_Type, MealInclusion_Type, MaxOccupancy, Isprom, Closed_up, 30, StartDate , EndDate, intime, isAvailable, None, None, Tax_status, None, RateType, Discount,Promotion_Name,region,statuscode, israteperstay))
			else:
				Closed_up = "Y"
				statuscode = '2'
				#print"Rooms are Not Avilable Hotel CLosed"
				array.append(aws_insert.insert(id_update, inputid , Domainname, Websitecode, StartDate, RoomType, LOS, RateDate, Guests, OnsiteRate, Netrate, OnsiteRate, Curr, RateDescription, urlRate, urlInclusions, urlAmenities, RoomAmenity_Type, MealInclusion_Type, MaxOccupancy, Isprom, Closed_up, 30, StartDate , EndDate, intime, isAvailable, None, None, Tax_status, None, RateType, Discount,Promotion_Name,region,statuscode, israteperstay))
		except Exception as e:
			value_error=str(re.sub("'",'"',str(e)))
			#print value_error
			stacktrace=sys.exc_traceback.tb_lineno
			#print "line no :", stacktrace
			keyvalue = "ondemand/{}/{:%Y%m%d}/delivery/Error/{}.txt".format(Websitecode,datetime.datetime.now(),id_update)
			key = bucket.new_key(keyvalue)
			key.set_contents_from_string(str(e))
			statuscode='4'
			Guests=''
			array.append(aws_insert.insert(id_update, inputid ,"",Websitecode, "", "", "", "", Guests, "", "", "", "", "",refer_url,refer_url,refer_url, "", "", "", "", "", "",StartDate, EndDate , "", "", "", "", "", "",  "", "", "",region,statuscode, israteperstay))
			#array.append(aws_insert.insert(id_update,inputid,"",Websitecode,StartDate,"","",RateDate,"","","","","","",urlRate,urlInclusions,urlAmenities,"","","","","Y","",StartDate,"","","","","","","","","",4))
		keyvalue = "ondemand/{}/{:%Y%m%d}/delivery/{}.json".format(Websitecode,datetime.datetime.now(),id_update+'_'+str(Rtdate)+'_'+str(inputid))
		key = bucket.new_key(keyvalue)
		key.set_contents_from_string(json.dumps(array))
		return json.dumps(array)
	except Exception as e:
		value_error=str(re.sub(r"'",'"',str(e)))
		stacktrace=sys.exc_traceback.tb_lineno
		#print value_error, stacktrace
		insert_value_error=str(value_error)+'Where line number '+str(stacktrace)+' - '+str(proxyip)
		statuscode='4'
		keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(Websitecode,datetime.datetime.now(),id_update)
		key = bucket.new_key(keyvalue)
		key.set_contents_from_string(insert_value_error)
		Guests=''
		array.append(aws_insert.insert(id_update, inputid ,"",Websitecode, "", "", "", "", Guests, "", "", "", "", "",refer_url,refer_url,refer_url, "", "", "", "", "", "",StartDate, EndDate , "", "", "", "", "", "", "", "", "",region,statuscode, israteperstay))
		return json.dumps(array)
			

#fetchrates(url , inputid, id_update, proxyip)
