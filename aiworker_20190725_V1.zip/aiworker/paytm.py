# -*- coding: utf-8 -*-
import re
import requests
import datetime
import json
import sys 
import boto

import aws_insert


'''url = "https://paytm.com/hotels/Ganga_Kinare_-_A_Riverside_Boutique_Hotel-details-Rishikesh-57e4a3551b907d4d3dbcf54f?checkIn=2017-08-01&checkOut=2017-08-02&ota={%22city_id%22:%2255cb317225555dce751e9479%22,%22hotelid%22:%2241405%22,%22country_name%22:%22India%22,%22pid%22:74835207,%22freeCancellable%22:null,%22freeCancellableTill%22:null,%22otas%22:%22Cleartrip%22,%22index%22:65,%22sortBy%22:%22popularity%22,%22searchType%22:%22city%22}&rooms=room0_1_0"
inputid = "lokesh"
id_update = "12345"
proxyip = "media:M3diAproxy@196.17.7.6:80"
'''

sr = requests.Session()
def fetchrates(url, inputid, id_update, proxyip):
	israteperstay = ''
	array = []
	intime = re.sub(r'\s', 'T', str(datetime.datetime.now()))
	functionname = 'Paytm'
	inputid = inputid
	url_db = url
	#print 'main url',url_db
	Domainname = "Paytm"
	###print time_1
	Websitecode= "297"
	region = ''
	try:
		conn = boto.connect_s3(aws_access_key_id='AKIAIXEGZVXCWE2FV3SQ', aws_secret_access_key='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') 
		bucket = conn.get_bucket("rmapi")
		StartDate = datetime.date.today()
		EndDate = datetime.date.today() + datetime.timedelta(days=29)
		hotel_id_reg = re.search('-(\d.*?)\?',url_db)
		if hotel_id_reg:
			hotel_id = hotel_id_reg.group(1)
			#print "hotel_id:",hotel_id
		checkIn_reg = re.search('checkIn=(.*?)&',url_db)
		if checkIn_reg:
			checkIn_ = checkIn_reg.group(1)
			checkIn = re.sub(r"_","-",checkIn_)
			Ratedate = checkIn
			check_in_date = datetime.datetime.strptime(str(checkIn),'%Y-%m-%d').strftime('%Y, %m, %d')
			check_in_date = datetime.datetime.strptime(check_in_date,'%Y, %m, %d')
			#print "checkIn_:",checkIn
		checkOut_reg = re.search('checkOut=(.*?)&',url_db)
		if checkOut_reg:
			checkOut_ = checkOut_reg.group(1)
			checkOut = re.sub(r"_","-",checkOut_)
			check_out_date = datetime.datetime.strptime(str(checkOut),'%Y-%m-%d').strftime('%Y, %m, %d')
			check_out_date = datetime.datetime.strptime(check_out_date,'%Y, %m, %d')
			#print "checkOut:",checkOut
		ota_reg = re.search('ota=(.*?)&',url_db)
		if ota_reg:
			ota = ota_reg.group(1)
			#print "ota:",ota
		Guests = ''
		Guests_reg = re.search('room\d+_(\d+)_',url_db)
		if Guests_reg:
			Guests = Guests_reg.group(1)
		LOS = check_out_date - check_in_date
		LOS = LOS.days
		
		proxies = {"http": "http://{}".format(proxyip)}
		ip=re.sub(r"\{'.*?@|'\}|:\d+","",str(proxies))
		try:
			r = requests.get('http://freegeoip.net/json/'+ip,timeout=30)
			js = r.json()
			region=js['country_name']
		except Exception,e:
			r = requests.get('http://freegeoip.net/json/'+ip,timeout=30)
			js = r.json()
			region=js['country_name']
		url_post = 'https://travel.paytm.com/api/hotels/v1/details/?client=web&child_site_id=1&site_id=1'
		payload = {'city':'', 'check_in_date':str(checkIn), 'check_out_date':str(checkOut), 'num_rooms':'1', 'hotel_id':str(hotel_id), 'ota_data':str(ota), 'rooms_details':'[{"num_of_adults":"1","num_of_children":0,"child_ages":[]}]', 'channel':'web', 'version':'2'}
	
		head = {'User-Agent':'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:12.0) Gecko/20100101 Firefox/31.0'}
		try:
			hml = sr.post(url_post, data=payload, headers=head,proxies = proxies,  verify=False, timeout = 50)
		except Exception as e:
			print e
			try:
				hml = sr.post(url_post, data=payload, headers=head,proxies = proxies,  verify=False, timeout = 50)
			except Exception as e:
				value_error = str(re.sub(r"'", '', str(e)))
				stacktrace = sys.exc_traceback.tb_lineno
				keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(Websitecode, datetime.datetime.now(), id_update)
				key = bucket.new_key(keyvalue)
				key.set_contents_from_string(str(e))
				statuscode = 5
				Guests = '1'
				array.append(aws_insert.insert(id_update, inputid , functionname, Websitecode, "", "", "", "", Guests, "", "", "", "", "", url_db, url_db, url_db, "", "", "", "", "", "", StartDate, EndDate , "", "", "", "", "", "", "", "", "", region, statuscode, israteperstay))
				return json.dumps(array)					
		if hml.status_code <> 200:
			hml = sr.post(url_post, data=payload, headers=head,proxies = proxies,  verify=False, timeout = 50)
		if hml.status_code == 403 or hml.status_code == 407:
			try:
				hml = sr.post(url_post, data=payload, headers=head,proxies = proxies,  verify=False, timeout = 50)
			except Exception as e:
				value_error = str(re.sub(r"'", '', str(e)))
				stacktrace = sys.exc_traceback.tb_lineno
				keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(Websitecode, datetime.datetime.now(), id_update)
				key = bucket.new_key(keyvalue)
				key.set_contents_from_string(str(e))
				statuscode = 5
				Guests = '1'
				array.append(aws_insert.insert(id_update, inputid , functionname, Websitecode, "", "", "", "", Guests, "", "", "", "", "", url_db, url_db, url_db, "", "", "", "", "", "", StartDate, EndDate , "", "", "", "", "", "", "", "", "", region, statuscode, israteperstay))
				return json.dumps(array)	
		try:
			html = json.loads(hml.text.encode('ascii', 'ignore').decode('ascii', 'ignore'))
		except Exception as e:
			value_error = str(re.sub(r"'", '', str(e)))
			stacktrace = sys.exc_traceback.tb_lineno
			keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(Websitecode, datetime.datetime.now(), id_update)
			key = bucket.new_key(keyvalue)
			key.set_contents_from_string(str(e))
			statuscode = 4
			Guests = '1'
			array.append(aws_insert.insert(id_update, inputid , functionname, Websitecode, "", "", "", "", Guests, "", "", "", "", "", url_db, url_db, url_db, "", "", "", "", "", "", StartDate, EndDate , "", "", "", "", "", "", "", "", "", region, statuscode, israteperstay))
			return json.dumps(array)
		Rtdate = re.sub(r'-|\-', '', str(Ratedate))
		keyvalue = "ondemand/{}/{:%Y%m%d}/source/{}.json".format(Websitecode, datetime.datetime.now(), str(inputid) + '_' + str(Rtdate) + '_' + id_update)
		#print keyvalue
		key = bucket.new_key(keyvalue)
		key.set_contents_from_string(hml.text)
		RoomType=""
		LOS=LOS
		RateDate= Ratedate
		OnsiteRate="0"
		NetRate="0"
		Curr = 'INR'
		RateDescription=""
		RoomAmenity_Type=""
		MealInclusion_Type=""
		MaxOccupancy=""
		isPromotionalRate="N"
		Closed="Y"
		isAvailable=""
		Taxtype=""
		TaxAmount="0"
		includedtype_comment=''
		Ratetype=""
		Promotion_Name=""
		if 'data' in html:
			block_reg1 = html['data']
			if 'roomOptions' in block_reg1:
				check_block = html['data']['roomOptions']
				if check_block:
					for block in html['data']['roomOptions']:
						Closed = 'N'
						NetRate = '0'
						OnsiteRate = '0'
						Rate_Description = ''
						Rate_Description1 = ''
						Rate_Description2 = ''
						amnt = ''
						description = ''
						RoomType = ''
						meal_type = ''
						if block.has_key('description'):
							Rate_Description = re.sub("'", "''", str(block['description']))
						if block.has_key('bedType'):
							Rate_Description1 = re.sub("'", "''", str(block['bedType']))
						if 'view' in block:
							for descript in block['view']:
								description +=', '+descript
							Rate_Description2 = re.sub("'", "''", re.sub("^, |, $|,$", "", description))
						RateDescription = Rate_Description+', '+Rate_Description1+', '+Rate_Description2
						RateDescription = re.sub("'", "''", re.sub("^, |, $|,$", "", RateDescription))
						for block1 in block['subRooms']:
							RoomType =  re.sub("'", "''", str(block1['name']))
							##print RoomType
							if 'includes' in block1:
								for amt in block1['includes']:
									amnt +=', '+amt
								RoomAmenity_Type = re.sub("'", "''", re.sub("^, ", "", amnt))
								##print "amnt",  RoomAmenity_Type
							price_check = block1['priceData']
							if 'totalPrice' in price_check:
								OnsiteRate = block1['priceData']['totalPriceWithTax']
								##print OnsiteRate
								NetRate = block1['priceData']['originalPriceWithTax']
								##print NetRate
								isPromotionalRate = 'Y'
							
						if RoomAmenity_Type !=None:
							meal_type_reg = re.search(r'lease\s*note\s*:\s*(.*?)$',RoomAmenity_Type,re.DOTALL)
							if meal_type_reg:
								meal_type = meal_type_reg.group(1)
							Mealtype_str = str(RoomAmenity_Type)
							if 'half board' in Mealtype_str.lower():
								MealInclusion_Type = 'Half board' 
							elif ('half board' in Mealtype_str.lower()) and ('breakfast' in Mealtype_str.lower()):
								MealInclusion_Type = 'Half board and Breakfast' 
							elif 'full board' in Mealtype_str.lower():
								MealInclusion_Type = 'Full Board'
							elif 'halfboard' in Mealtype_str.lower():
								MealInclusion_Type = 'Halfboard'
							elif 'fullboard' in Mealtype_str.lower():
								MealInclusion_Type = 'FullBoard'
							elif 'breakfast' in Mealtype_str.lower() and 'dinner' in Mealtype_str.lower():
								MealInclusion_Type = 'Breakfast and dinner'
							elif 'breakfast' in Mealtype_str.lower() and 'lunch' in Mealtype_str.lower():
								MealInclusion_Type = 'Breakfast and Lunch'
							elif 'Lunch' in Mealtype_str and 'Dinner' in Mealtype_str :
								MealInclusion_Type = "Lunch and Dinner"
							elif 'breakfast' in Mealtype_str.lower() and 'lunch' in Mealtype_str.lower() and 'dinner' in Mealtype_str.lower():
								MealInclusion_Type = 'Breakfast, Lunch and dinner'
							elif 'Break fast' in Mealtype_str:
								MealInclusion_Type = 'BreakFast' 
							elif 'breakfast' in Mealtype_str.lower():
								MealInclusion_Type = 'BreakFast' 
							elif 'All-Inclusive' in Mealtype_str:
								MealInclusion_Type = 'All-Inclusive'
							elif 'All Inclusive' in Mealtype_str:
								MealInclusion_Type = 'All Inclusive'
							elif 'All Meals' in Mealtype_str:
								MealInclusion_Type = 'All Meals'
							elif 'All Meal' in Mealtype_str:
								MealInclusion_Type = 'All Meal'
							else:
								MealInclusion_Type = ''
						else:
							MealInclusion_Type = ''
						MealInclusion_Type = MealInclusion_Type+' '+meal_type
						if OnsiteRate == NetRate:
							NetRate = '0'
							isPromotionalRate = 'N'
						if OnsiteRate:
							includedtype_comment = '1'
						else:
							includedtype_comment = '-1'
						if block.has_key('book_params'):
							sec_block = block['book_params']
							if sec_block.has_key('rtc'):
								rtc = sec_block['rtc']
							if sec_block.has_key('bc'):
								bc = sec_block['bc']
							if sec_block.has_key('hotelId'):
								hotelId = sec_block['hotelId']
							if sec_block.has_key('ota'):
								ota = sec_block['ota']
							if sec_block.has_key('pid'):
								pid = sec_block['pid']
							if sec_block.has_key('otaCity'):
								otaCity = sec_block['otaCity']
							if sec_block.has_key('country_name'):
								country_name = sec_block['country_name']
							if sec_block.has_key('city_id'):
								city_id = sec_block['city_id']
							if sec_block.has_key('freeCancellable'):
								freeCancellable = sec_block['freeCancellable']
								freeCancellable = str(freeCancellable).lower()
								freeCancellable = re.sub(r'none','null',freeCancellable)
							if sec_block.has_key('freeCancellableTill'):
								freeCancellableTill = sec_block['freeCancellableTill']
								freeCancellableTill = re.sub(r'None','',str(freeCancellableTill))
							if sec_block.has_key('index'):
								index = sec_block['index']
							if sec_block.has_key('sortBy'):
								sortBy = sec_block['sortBy']
							if sec_block.has_key('searchType'):
								searchType = sec_block['searchType']
							if sec_block.has_key('price'):
								price = sec_block['price']
								##print 'price',price
							if sec_block.has_key('totalPartnerPrice'):
								totalPartnerPrice = sec_block['totalPartnerPrice']
								##print 'totalPartnerPrice',totalPartnerPrice
							if html.has_key('extra'):
								request_id = html['extra']['requestId']
								##print 'request_id',request_id 
							url_check = 'https://travel.paytm.com/api/hotels/v1/get-cancellation-policy/?requestId='+str(request_id)+'&child_site_id=1&site_id=1'
							payload = {'city':str(otaCity), 'check_in_date':str(checkIn), 'check_out_date':str(checkOut), 'num_rooms':'1', 'ota_data':'{"rtc":"'+str(rtc)+'","bc":"'+str(bc)+'","hotelId":"'+str(hotelId)+'","ota":"'+str(ota)+'","price":'+str(price)+',"pid":'+str(pid)+',"otaCity":"'+str(otaCity)+'","country_name":"'+str(country_name)+'","city_id":"'+str(city_id)+'","freeCancellable":'+str(freeCancellable)+',"freeCancellableTill":"'+str(freeCancellableTill)+'","totalPartnerPrice":'+str(totalPartnerPrice)+',"index":'+str(index)+',"sortBy":"'+str(sortBy)+'","searchType":"'+str(searchType)+'"}', 'rooms_details':'[{"num_of_adults":"1","num_of_children":0,"child_ages":[]}]', 'ota':str(ota), 'num_adults':'1', 'num_children':'0', 'channel':'web', 'version':'2', 'hotel_id':str(hotel_id)}
							#payload = {'city': 'Mumbai', 'check_in_date': '2017-05-19', 'check_out_date': '2017-05-20', 'num_rooms': '1', 'ota_data': '%7B%22rtc%22%3A%22155447%3A1457025%22%2C%22bc%22%3A%225%3A33719%3A6855954%7Csi-7fc83351-610a-4af9-917a-356a0f7dde77%22%2C%22hotelId%22%3A%22161985%22%2C%22ota%22%3A%22Cleartrip%22%2C%22price%22%3A5074%2C%22pid%22%3A74835206%2C%22otaCity%22%3A%22Mumbai%22%2C%22country_name%22%3A%22IN%22%2C%22city_id%22%3A%2255cb317125555dce751e9385%22%2C%22freeCancellable%22%3Atrue%2C%22freeCancellableTill%22%3A%222017-05-16%2B05%3A30%22%2C%22totalPartnerPrice%22%3A5074%2C%22index%22%3A1%2C%22sortBy%22%3A%22popularity%22%2C%22searchType%22%3A%22hotelName%22%7D', 'rooms_details': '%5B%7B%22num_of_adults%22%3A%221%22%2C%22num_of_children%22%3A0%2C%22child_ages%22%3A%5B%5D%7D%5D', 'ota': 'Cleartrip', 'num_adults': '1', 'num_children': '0', 'channel': 'web', 'version': '2', 'hotel_id': '57e4a2d01b907d4d3dbcdd5d'}
							hml = sr.post(url_check, data=payload, headers=head,proxies = proxies,  verify=False)
							##print hml.status_code
							html2 = json.loads(hml.text.encode('ascii', 'ignore').decode('ascii', 'ignore'))
							if 'data' in html2:
								block_reg2 = html2['data']
								if block_reg2.has_key('cancellationPolicy'):
									Ratetype = block_reg2['cancellationPolicy']
									##print 'Ratetype:',Ratetype
						statuscode=''
						array.append(aws_insert.insert(id_update, inputid , Domainname, Websitecode, StartDate, RoomType, LOS, RateDate, Guests, OnsiteRate, NetRate, OnsiteRate, Curr, RateDescription, url, url, url, RoomAmenity_Type, MealInclusion_Type, MaxOccupancy, isPromotionalRate, Closed, 30, StartDate , EndDate, intime, isAvailable, Taxtype, TaxAmount, includedtype_comment, None, Ratetype, NetRate, Promotion_Name, region, statuscode, israteperstay))
				else:
					statuscode = 2
					Closed = 'Y'
					array.append(aws_insert.insert(id_update, inputid , Domainname, Websitecode, StartDate, RoomType, LOS, RateDate, Guests, OnsiteRate, NetRate, OnsiteRate, Curr, RateDescription, url, url, url, RoomAmenity_Type, MealInclusion_Type, MaxOccupancy, isPromotionalRate, Closed, 30, StartDate , EndDate, intime, isAvailable, Taxtype, TaxAmount, includedtype_comment, None, Ratetype, NetRate, Promotion_Name, region, statuscode, israteperstay))
					
			else:
				statuscode = 2
				Closed = 'Y'
				array.append(aws_insert.insert(id_update, inputid , Domainname, Websitecode, StartDate, RoomType, LOS, RateDate, Guests, OnsiteRate, NetRate, OnsiteRate, Curr, RateDescription, url, url, url, RoomAmenity_Type, MealInclusion_Type, MaxOccupancy, isPromotionalRate, Closed, 30, StartDate , EndDate, intime, isAvailable, Taxtype, TaxAmount, includedtype_comment, None, Ratetype, NetRate, Promotion_Name, region, statuscode, israteperstay))
		else:
			statuscode = 2
			Closed = 'Y'
			array.append(aws_insert.insert(id_update, inputid , Domainname, Websitecode, StartDate, RoomType, LOS, RateDate, Guests, OnsiteRate, NetRate, OnsiteRate, Curr, RateDescription, url, url, url, RoomAmenity_Type, MealInclusion_Type, MaxOccupancy, isPromotionalRate, Closed, 30, StartDate , EndDate, intime, isAvailable, Taxtype, TaxAmount, includedtype_comment, None, Ratetype, NetRate, Promotion_Name, region, statuscode, israteperstay))
		#print "completed"
		Rtdate = re.sub(r'-|\-', '', str(Ratedate))
		keyvalue = "ondemand/{}/{:%Y%m%d}/delivery/{}.json".format(Websitecode, datetime.datetime.now(), str(inputid) + '_' + str(Rtdate) + '_' + id_update)
		key = bucket.new_key(keyvalue)
		key.set_contents_from_string(json.dumps(array))
		return json.dumps(array)
	except Exception as e:
		#print "error =", e
		value_error = str(re.sub(r"'", '"', str(e)))
		stacktrace = sys.exc_traceback.tb_lineno
		insert_value_error = str(value_error) + 'Where line number ' + str(stacktrace) + str(proxyip)
		statuscode = '4'
		print insert_value_error
		keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(Websitecode, datetime.datetime.now(), id_update)
		#print keyvalue
		key = bucket.new_key(keyvalue)
		key.set_contents_from_string(insert_value_error)
		Guests = '1'
		array.append(aws_insert.insert(id_update, inputid , functionname, Websitecode, "", "", "", "", Guests, "", "", "", "", "", url_db, url_db, url_db, "", "", "", "", "", "", StartDate, EndDate , "", "", "", "", "", "", "", "", "", region, statuscode, israteperstay))
		return json.dumps(array)	
