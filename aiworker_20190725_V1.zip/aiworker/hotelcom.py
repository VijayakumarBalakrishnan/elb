# -*- coding: utf-8 -*-
import re
import requests
import datetime
import json
import boto
import gc
import sys
import aws_insert

# url       = 'https://www.hotels.com/ho270919/monte-santo-resort-carvoeiro-portugal/?MGT=1&SYE=3&WOD=2&WOE=3&YGF=14&ZSX=0&q-localised-check-in=2019-04-03&q-localised-check-out=2019-04-04&q-room-0-adults=1&q-room-0-children=0&tab=description&currency=BRL'
# inputid   = 'test'            
# id_update = '22'    
# proxyip   = 'media:M3diAproxy@171.22.121.164:80'
# pos = '0'

def fetchrates(url ,inputid, id_update, proxyip,pos):
# 	print "pos =",pos   
	#print url
	array = []
	intime=re.sub(r'\s','T',str(datetime.datetime.now()))
	functionname='Hotelcom'
	israteperstay = ''
	try:
		conn = boto.connect_s3(aws_access_key_id= 'AKIAIXEGZVXCWE2FV3SQ',aws_secret_access_key = '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') 
		bucket = conn.get_bucket("rmapi")

		StartDate = datetime.date.today()
		EndDate  = datetime.date.today() + datetime.timedelta(days=29)
		delta = datetime.datetime.strptime(re.search(r"check-out=(.*?)&", url).group(1), "%Y-%m-%d") - datetime.datetime.strptime(re.search(r"check-in=(.*?)&", url).group(1), "%Y-%m-%d")
		LOS = delta.days
		Domainname="Hotelcom"
		functionname = Domainname
		Websitecode = '12'
		Roomtype = ""
		Ratetype=''
		OnsiteRate = 0
		Closed_up = 'N'
		Mealtype = ""
		NetRate = 0
		RateDescription = ""
		RoomAmenity_Type = ""
		GrossRate=0
		currency=''
		Roomavilable=''
		Promotion_Name=''
		MaxOccupancy=''
		ispromupdate = 'N'
		Taxtype = ''
		Taxamount = ''
		statuscode = ''
		RateDate = ''
		Tax_status=''
		region=''
		currency = 'USD'
		if re.search(r'check-in=(.*?)&', url):
			RateDate = re.search(r'check-in=(.*?)&', url).group(1)
		if re.search(r'&currency=(.*?)$', url):
			currency = re.search(r'&currency=(.*?)$', url).group(1)
		#print "currency"
		#print currency
		adult=re.search(r'adults=(\d+)&',url)
		if adult:
			adults1=adult.group(1)
		Guests =adults1
		url =  re.sub(r"(\d+)-(\d+)-(\d+)", r"\1/\2/\3",url)
		#print url
		#url = 'https://www.hotels.com/ho'+hotelid_info+'/michigan-inn-lodge-petoskey-united-states-of-america/?MGT=1&SYE=3&WOD=2&WOE=3&YGF=14&ZSX=0&q-localised-check-in='+chk_in+'&q-localised-check-out='+chk_out+'&q-room-0-adults='+adults1+'&q-room-0-children=0&tab=description'
		proxies = {"https": "http://{}".format(proxyip)}
		head={'User-Agent':'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:12.0) Gecko/20100101 Firefox/31.0'}
		sr = requests.session();
		
		if '222' in str(pos):
			sr.get("https://de.hotels.com/?pos=HCOM_DE&locale=de_DE", proxies=proxies, verify = False);
			urlreplacekeyword = "https://de.hotels.com/"
			url = re.sub(r"https://www.hotels.com/", urlreplacekeyword,url)
		
			if 'ZAR' in currency:
				sr.get("https://za.hotels.com/?pos=HCOM_ZA&locale=en_ZA", proxies=proxies, verify = False);
				urlreplacekeyword = "https://za.hotels.com/"
		else:
			if 'ZAR' in currency:
				sr.get("https://za.hotels.com/?pos=HCOM_ZA&locale=en_ZA", proxies=proxies, verify = False);
				urlreplacekeyword = "https://za.hotels.com/"
			else:
# 				print 'else'
				sr.get("https://www.hotels.com/?pos=HCOM_US&locale=en_US", proxies=proxies, verify = False);
			
		sr.get("https://www.hotels.com/change_currency.html?currency={}".format(currency), proxies=proxies, verify = False);
		try:    
			htm = sr.get(url, headers=head,proxies=proxies,timeout=15, verify = False)
			#print htm.status_code
		except Exception,e:
			value_error=str(re.sub("'",'"',str(e)))
			#value_error=str(es).encode('ascii','ignore')
			stacktrace=sys.exc_traceback.tb_lineno
			try:
				htm = sr.get(url, headers=head,proxies=proxies,timeout=20, verify = False)
			except Exception,e:
				value_error=str(e)
				stacktrace=sys.exc_traceback.tb_lineno
				keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(Websitecode,datetime.datetime.now(),id_update)
				#print keyvalue
				key = bucket.new_key(keyvalue)
				key.set_contents_from_string(str(e))
				region=''
				ip=re.sub(r"\{'.*?@|'\}|:\d+","",str(proxies))
				try:
					try:
						r = requests.get('http://freegeoip.net/json/'+ip,timeout=30)
					except Exception,e:
						r = requests.get('http://freegeoip.net/json/'+ip,timeout=30)
					js = r.json()
					region=js['country_name']
				except Exception,e:
					region=''
				statuscode=5
				Guests='1'
				array.append(aws_insert.insert(id_update, inputid ,functionname,Websitecode, "", "", "", "", Guests, "", "", "", "", "",url, url, url, "", "", "", "", "", "",StartDate, EndDate , "", "", "", "", "", "",  "", "", "",region,statuscode, israteperstay ))
				return json.dumps(array)
		if (htm.status_code <> 200):
			htm = sr.get(url, headers=head,proxies=proxies, verify = False)
		if (htm.status_code == 403 or htm.status_code == 407):
			e = 'Due to the status_code error. Please following the status_code '+str(htm.status_code)+'.'
			keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(Websitecode,datetime.datetime.now(),id_update)
			#print keyvalue
			key = bucket.new_key(keyvalue)
			key.set_contents_from_string(str(e))
			region=''
			ip=re.sub(r"\{'.*?@|'\}|:\d+","",str(proxies))
			try:
				try:
					r = requests.get('http://freegeoip.net/json/'+ip,timeout=30)
				except Exception,e:
					r = requests.get('http://freegeoip.net/json/'+ip,timeout=30)
				js = r.json()
				region=js['country_name']
			except Exception,e:
				region=''
			statuscode=5
			Guests='1'
			array.append(aws_insert.insert(id_update, inputid ,functionname,Websitecode, "", "", "", "", Guests, "", "", "", "", "",url, url, url, "", "", "", "", "", "",StartDate, EndDate , "", "", "", "", "", "",  "", "", "",region,statuscode, israteperstay ))
			return json.dumps(array)
				
		html = htm.text
		html = html.encode('ascii', 'ignore')
		if 'ZAR' in currency:
			url = re.sub(r"https://www.hotels.com/", urlreplacekeyword,url)
			
		Rtdate=re.sub(r'-|\-','',str(RateDate))
		keyvalue = "ondemand/{}/{:%Y%m%d}/source/{}.html".format(Websitecode,datetime.datetime.now(),str(inputid)+'_'+str(Rtdate)+'_'+id_update)
		key = bucket.new_key(keyvalue)
		key.set_contents_from_string(html)
		region=''
		ip=re.sub(r"\{'.*?@|'\}|:\d+","",str(proxies))
		try:
			try:
				r = requests.get('http://freegeoip.net/json/'+ip,timeout=30)
			except Exception,e:
				r = requests.get('http://freegeoip.net/json/'+ip,timeout=30)
			js = r.json()
			region=js['country_name']
		except Exception,e:
			region=''
		#print "BLOCK Entering..."
		json_html = ''
		reg_blo1 = re.compile('"pda.roomsAndRates.rooms":(.*?\[\]}}\]}\])', re.DOTALL).findall(html)
		if reg_blo1:
			json_html_reg = re.search('"pda.roomsAndRates.rooms":(.*?\[\]}}\]}\])',html,re.DOTALL)
			if json_html_reg:
				json_html = json.loads(json_html_reg.group(1))
		else:
			reg_blo1 = re.compile('"pda.roomsAndRates.rooms":(.*?\]}}\]}\])', re.DOTALL).findall(html)
			if reg_blo1:
				json_html_reg = re.search('"pda.roomsAndRates.rooms":(.*?\]}}\]}\])',html,re.DOTALL)
				if json_html_reg:
					json_html = json.loads(json_html_reg.group(1))
			else:
				reg_blo1 = re.compile('"pda.roomsAndRates.rooms":(.*?\[\]}\]}\])', re.DOTALL).findall(html)
				if reg_blo1:
					json_html_reg = re.search('"pda.roomsAndRates.rooms":(.*?\[\]}\]}\])',html,re.DOTALL)
					if json_html_reg:
						json_html = json.loads(json_html_reg.group(1))
				else:
					reg_blo1 = re.compile('"pda.roomsAndRates.rooms":(.*?\]}\]}\])', re.DOTALL).findall(html)
					if reg_blo1:
						json_html_reg = re.search('"pda.roomsAndRates.rooms":(.*?\]}\]}\])',html,re.DOTALL)
						if json_html_reg:
							json_html = json.loads(json_html_reg.group(1))
		if json_html:
			for json_block in json_html:
				RateDescription = ''
				Roomtype = re.sub(r"'","''",re.sub(r"&amp;","&",str(json_block['name']))).strip()
# 				print 'RoomType:',Roomtype
				MaxOccupancy_des = ''
				MaxOccupancy_des1 = ''
				if json_block.has_key('maxOccupancy'):
					MaxOccupancy_block = json_block['maxOccupancy']
					if MaxOccupancy_block.has_key('messageTotal'):
						MaxOccupancy = re.sub(r"[A-Z|a-z]","",str(MaxOccupancy_block['messageTotal']).strip())
						MaxOccupancy_des = str(MaxOccupancy_block['messageTotal'])
					else:
						MaxOccupancy = ''
					if MaxOccupancy_block.has_key('messageChildren'):
						MaxOccupancy_des1 = str(MaxOccupancy_block['messageChildren'])
				else:
					MaxOccupancy = ''
					
				if json_block.has_key('bedTypeAndOccupancy'):
					bedTypeAndOccupancy_block = json_block['bedTypeAndOccupancy']
					if bedTypeAndOccupancy_block.has_key('bedTypes'):
						if bedTypeAndOccupancy_block['bedTypes']:
							RateDescription = 'Bed choices: '+re.sub(r"'","''",re.sub(r"u'|\[|'\s*\]","",re.sub(r"&amp;","&",re.sub(r"'\s*,",",",str(bedTypeAndOccupancy_block['bedTypes'])))))
						
					if bedTypeAndOccupancy_block.has_key('extraBeds'):
						if bedTypeAndOccupancy_block['extraBeds']:
							RateDescription += ', Extra beds available: '+re.sub(r"'","''",re.sub(r"u'|\[|'\s*\]","",re.sub(r"&amp;","&",re.sub(r"'\s*,",",",str(bedTypeAndOccupancy_block['extraBeds'])))))
					
				if json_block.has_key('additionalInfo'):
					additionalInfo_block = json_block['additionalInfo']
					if additionalInfo_block.has_key('description'):
						RateDescription += ', '+re.sub(r"'","''",re.sub(r"&.*?;|<.*?>","",re.sub(r"&amp;","&",re.sub(r"<b>","; ",str(additionalInfo_block['description'])))))
					
				RateDescription = re.sub(r"^,","",RateDescription.strip())
				RateDescription = MaxOccupancy_des+MaxOccupancy_des1+', '+str(RateDescription)
				RateDescription = re.sub(r"^,","",RateDescription.strip())
				#print 'RateDescription:',RateDescription
				
				if json_block.has_key('ratePlans'):
					if json_block['ratePlans']:
						for second_block in json_block['ratePlans']:
							RoomAmenity_Type  = ''
							
							if json_block.has_key('additionalInfo'):
								
								if  additionalInfo_block.has_key('details'):
									additionalInfo_details_block = additionalInfo_block['details']
									if additionalInfo_details_block.has_key('amenities'):
										RoomAmenity_Type =  re.sub(r"'","''",re.sub(r"u'|\[|'\s*\]","",re.sub(r"&amp;","&",re.sub(r"'\s*,",",",str(additionalInfo_details_block['amenities'])))))
										#print 'RoomAmenity_Type:',RoomAmenity_Type
							
							if second_block.has_key('cancellation'):
								if second_block['cancellation'].has_key('title'):
									Ratetype = re.sub(r"'","''",re.sub(r"&amp;","&",str(second_block['cancellation']['title'])))
									#print 'Ratetype:',Ratetype
								else:
									Ratetype = ''
							else:
								Ratetype = ''
						
							if second_block.has_key('features'):
								for features_block in second_block['features']:
									
									if features_block.has_key('featureType'):
										if str(features_block['featureType']) == 'breakfast':
											Mealtype = re.sub(r"'","''",re.sub(r"&amp;","&",str(features_block['title'])))
											#print 'Mealtype:',Mealtype
										else:
											Mealtype = ''
											
										if str(features_block['featureType']) == 'parking':
											RoomAmenity_Type += ','+re.sub(r"'","''",re.sub(r"&amp;","&",str(features_block['title'])))
											#print 'RoomAmenity_Type:',RoomAmenity_Type
											
									else:
										Mealtype = ''
							else:
								Mealtype = ''
							
							if second_block.has_key('price'):
								if second_block['price'].has_key('current'):
									OnsiteRate = re.sub(r"(?!\d|\.).","",second_block['price']['current'])
# 									print 'OnsiteRate:',OnsiteRate
									Closed_up="N"
# 									includedtype_comment = 2
									if second_block.has_key('payment'):
										if second_block['payment'].has_key('book'):
											payment_book_block = second_block['payment']['book']
											if payment_book_block.has_key('bookingParamsMixedRatePlan'):
												if payment_book_block['bookingParamsMixedRatePlan'].has_key('currency'):
													currency = payment_book_block['bookingParamsMixedRatePlan']['currency']
													#print 'currency:',currency
												else:
													currency = ''
											elif payment_book_block.has_key('bookingParams'):
												if payment_book_block['bookingParams'].has_key('currency'):
													currency = payment_book_block['bookingParams']['currency']
													#print 'currency:',currency
												else:
													currency = ''
											else:
												currency = ''
										else:
											currency = ''
									else:
										currency = ''
									
								else:
									OnsiteRate = 0
									Closed_up = 'Y'
# 									includedtype_comment = -1
									
								if second_block['price'].has_key('old'):
									NetRate = re.sub(r"(?!\d|\.).","",second_block['price']['old'])
# 									print 'NetRate:',NetRate
									ispromupdate = 'Y'
								else:
									NetRate = 0
									ispromupdate = 'N'
								
							else:
								OnsiteRate = 0
								NetRate = 0
								ispromupdate = 'N'
								Closed_up = 'Y'
# 								includedtype_comment = -1
							
							if second_block.has_key('payment'):
								if second_block['payment'].has_key('book'):
									if second_block['payment']['book'].has_key('bookingParamsMixedRatePlan'):
										if second_block['payment']['book']['bookingParamsMixedRatePlan'].has_key('priceConfiguration'):
											tax_text = second_block['payment']['book']['bookingParamsMixedRatePlan']['priceConfiguration']
											if 'included' in str(tax_text).lower():
												includedtype_comment = 1
											elif 'excluded' in str(tax_text).lower():
												includedtype_comment = 2
											else:
												includedtype_comment = -1
										else:
											includedtype_comment = -1
# 										print 'includedtype_comment:',includedtype_comment
										if second_block['payment']['book']['bookingParamsMixedRatePlan'].has_key('orderItems'):
											for tax_status_block in second_block['payment']['book']['bookingParamsMixedRatePlan']['orderItems']:
												if tax_status_block.has_key('roomTypeCode'):
													roomtype_code = tax_status_block['roomTypeCode']
												else:
													roomtype_code = ''
												
												if tax_status_block.has_key('rateCode'):
													rate_code = tax_status_block['rateCode']
												else:
													rate_code = ''
													
												if re.search('"roomType":"'+str(roomtype_code)+'","ratePlanIds":\["'+str(rate_code)+'"\].*?additionalFees":\{"tax":\s*(.*?)\s*,"cityTax":\s*(.*?)\s*,', html):
													site_taxamount =re.search('"roomType":"'+str(roomtype_code)+'","ratePlanIds":\["'+str(rate_code)+'"\].*?additionalFees":\{"tax":\s*(.*?)\s*,"cityTax":\s*(.*?)\s*,', html).group(1)
													site_city_taxamount =re.search('"roomType":"'+str(roomtype_code)+'","ratePlanIds":\["'+str(rate_code)+'"\].*?additionalFees":\{"tax":\s*(.*?)\s*,"cityTax":\s*(.*?)\s*,', html).group(2)
													if site_taxamount:
														if float(site_taxamount) == 0 and float(site_city_taxamount) == 0:
															includedtype_comment = 1
														elif float(site_taxamount) != 0 or float(site_city_taxamount) != 0:
															includedtype_comment = 2
												break
# 										print 'includedtype_comment:',includedtype_comment
												
									elif second_block['payment']['book'].has_key('bookingParams'):
										if second_block['payment']['book']['bookingParams'].has_key('priceConfiguration'):
											tax_text = second_block['payment']['book']['bookingParams']['priceConfiguration']
											if 'included' in str(tax_text).lower():
												includedtype_comment = 1
											elif 'excluded' in str(tax_text).lower():
												includedtype_comment = 2
											else:
												includedtype_comment = -1
										else:
											includedtype_comment = -1
										
										if second_block['payment']['book']['bookingParams'].has_key('roomTypeCode'):
											roomtype_code = second_block['payment']['book']['bookingParams']['roomTypeCode']
										else:
											roomtype_code = ''
										
										if second_block['payment']['book']['bookingParams'].has_key('rateCode'):
											rate_code = second_block['payment']['book']['bookingParams']['rateCode']
										else:
											rate_code = ''	
										
										if re.search('"roomType":"'+str(roomtype_code)+'","ratePlanIds":\["'+str(rate_code)+'"\].*?additionalFees":\{"tax":\s*(.*?)\s*,"cityTax":\s*(.*?)\s*,', html):
											site_taxamount =re.search('"roomType":"'+str(roomtype_code)+'","ratePlanIds":\["'+str(rate_code)+'"\].*?additionalFees":\{"tax":\s*(.*?)\s*,"cityTax":\s*(.*?)\s*,', html).group(1)
											site_city_taxamount =re.search('"roomType":"'+str(roomtype_code)+'","ratePlanIds":\["'+str(rate_code)+'"\].*?additionalFees":\{"tax":\s*(.*?)\s*,"cityTax":\s*(.*?)\s*,', html).group(2)
											if site_taxamount:
												if float(site_taxamount) == 0 and float(site_city_taxamount) == 0:
													includedtype_comment = 1
												elif float(site_taxamount) != 0 or float(site_city_taxamount) != 0:
													includedtype_comment = 2
										
									else:
										includedtype_comment = -1
								else:
									includedtype_comment = -1
							else:
								includedtype_comment = -1
							
							if second_block.has_key('roomsLeft'):
								Roomavilable = second_block['roomsLeft']
								#print 'Roomavilable:',Roomavilable
							else:
								Roomavilable = ''
								
							if second_block.has_key('offers'):
								if second_block['offers'].has_key('offer'):
									if second_block['offers']['offer'].has_key('text'):
										Promotion_Name = re.sub(r"'","''",re.sub(r"&amp;","&",str(second_block['offers']['offer']['text'])))
										#print 'Promotion_Name:',Promotion_Name
										ispromupdate = 'Y'
									else:
										Promotion_Name =  ''
										ispromupdate = 'N'
								else:
									Promotion_Name =  ''
									ispromupdate = 'N'
							else:
								Promotion_Name =  ''
								ispromupdate = 'N'
							
							#Discount = NetRate
							if 'pen' in currency.lower():
								OnsiteRate = re.sub(r"^\.(\d+)", r"\1",str(OnsiteRate))
								NetRate = re.sub(r"^\.(\d+)", r"\1",str(NetRate))
							if 'brl' in currency.lower():
								OnsiteRate = re.sub(r"\.", r"",str(OnsiteRate))
								NetRate = re.sub(r"\.", r"",str(NetRate))
							if 'dkk' in currency.lower() or 'vnd' in currency.lower() or 'eur' in currency.lower() or 'idr' in currency.lower():
								'''if re.search('\.\d\d\d+',str(OnsiteRate)):
									OnsiteRate = format_decimal(OnsiteRate, locale='da_DK')
								if re.search('\.\d\d\d+',str(NetRate)):
									NetRate = format_decimal(NetRate, locale='da_DK')'''
								OnsiteRate = re.sub(r".(\d{3})", r"\1",str(OnsiteRate))
								NetRate = re.sub(r".(\d{3})", r"\1",str(NetRate))
								OnsiteRate = re.sub(r',','',str(OnsiteRate))
								NetRate = re.sub(r',','',str(NetRate))
							Tax_status = includedtype_comment
							GrossRate = OnsiteRate
							
							if OnsiteRate==0 or str(OnsiteRate)=='0':
								statuscode=1
								Closed_up = 'Y'
								Tax_status ='-1'
							else:
								Closed_up = 'N'
# 								Tax_status = '2'
							if LOS >1:
								israteperstay = 'N'
							else:
								israteperstay = 'Y'
								
							if '222' in str(pos):
								israteperstay = 'Y'
								
# 							if 'ZAR' in currency:
# 								Tax_status = '1'
							if (NetRate == 0 or NetRate == '') and (Promotion_Name == 0 or Promotion_Name == ''):
								ispromupdate = 'N'
							
# 							print israteperstay
# 							print (id_update, inputid , Domainname, Websitecode, StartDate, Roomtype, LOS, RateDate, Guests, OnsiteRate, NetRate, GrossRate, currency, RateDescription, url, url, url, RoomAmenity_Type, Mealtype, MaxOccupancy, ispromupdate, Closed_up, 30, StartDate , EndDate, intime, Roomavilable, Taxtype, Taxamount, Tax_status, None, Ratetype, NetRate,Promotion_Name,region,statuscode, israteperstay )
							array.append(aws_insert.insert(id_update, inputid , Domainname, Websitecode, StartDate, Roomtype, LOS, RateDate, Guests, OnsiteRate, NetRate, GrossRate, currency, RateDescription, url, url, url, RoomAmenity_Type, Mealtype, MaxOccupancy, ispromupdate, Closed_up, 30, StartDate , EndDate, intime, Roomavilable, Taxtype, Taxamount, Tax_status, None, Ratetype, NetRate,Promotion_Name,region,statuscode, israteperstay ))
		else:
			##print "else"
	#             print (id_update, inputid , Domainname, Websitecode, StartDate, Roomtype, LOS, RateDate, Guests, OnsiteRate, NetRate, GrossRate, currency, RateDescription, url, url, url, RoomAmenity_Type, Mealtype, MaxOccupancy, ispromupdate, Closed_up, 30, StartDate , EndDate, intime, Roomavilable, Taxtype, Taxamount, Tax_status, None, Ratetype, NetRate,Promotion_Name,region,statuscode, israteperstay )
			HotelBlock = 'Rooms are Not Avilable Hotel CLosed'
			Closed_up = "Y"
			statuscode=2
			##print "Rooms are Not Avilable Hotel CLosed"
			array.append(aws_insert.insert(id_update, inputid , Domainname, Websitecode, StartDate, Roomtype, LOS, RateDate, Guests, OnsiteRate, NetRate, GrossRate, currency, RateDescription, url, url, url, RoomAmenity_Type, Mealtype, MaxOccupancy, ispromupdate, Closed_up, 30, StartDate , EndDate, intime, Roomavilable, Taxtype, Taxamount, Tax_status, None, Ratetype, NetRate,Promotion_Name,region,statuscode, israteperstay ))
		Rtdate=re.sub(r'-|\-','',str(RateDate))
		keyvalue = "ondemand/{}/{:%Y%m%d}/delivery/{}.json".format(Websitecode,datetime.datetime.now(),str(inputid)+'_'+str(Rtdate)+'_'+id_update)
		key = bucket.new_key(keyvalue)
		key.set_contents_from_string(json.dumps(array))
		return json.dumps(array)
		gc.collect()
	except Exception,e:
		print e
		value_error=str(re.sub(r"'",'"',str(e)))
		stacktrace=sys.exc_traceback.tb_lineno
		insert_value_error=str(value_error)+'Where line number '+str(stacktrace)+str(proxyip)
		print insert_value_error
		statuscode='4'
		Websitecode='12'
		keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(Websitecode,datetime.datetime.now(),id_update)
		key = bucket.new_key(keyvalue)
		key.set_contents_from_string(insert_value_error)
		Guests='1'
		array.append(aws_insert.insert(id_update, inputid ,functionname,Websitecode, "", "", "", "", Guests, "", "", "", "", "",url, url, url, "", "", "", "", "", "",StartDate, EndDate , "", "", "", "", "", "",  "", "", "",region,statuscode, israteperstay ))
		return json.dumps(array)
# fetchrates(url ,inputid, id_update, proxyip,pos)
