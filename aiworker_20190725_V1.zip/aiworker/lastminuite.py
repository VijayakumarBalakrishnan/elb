# -*- coding: utf-8 -*-
import re
import requests
import datetime
import json
import sys 
import boto

import aws_insert
from unidecode import unidecode
import random


'''
url = 'https://trips.lastminute.com/hotel/route/product-details/321991?search.destinationCities=154933&search.departureIntervals=20171026-20171027&bfSubsource=S01HPV10S10RR01&search.rooms[0].adults=1&search.type=OSE&search.accomodationOnly=true&noCache=1505809861545&searchId=35496&checkin=2018-08-23&checkout=2018-08-24#'
inputid = 'LastCheck'
id_update ='LastCheck'
proxyip = '62.210.169.27:4627'
'''
def fetchrates(url, inputid, id_update, proxyip):
	##print url
	israteperstay = ''
	array = []
	intime=re.sub(r'\s','T',str(datetime.datetime.now()))
	Domainname='lastminute'
	Websitecode = 296
	main_url=''
	try:
		StartDate = datetime.date.today()
		EndDate  = datetime.date.today()+datetime.timedelta(days=29)
		conn = boto.connect_s3(aws_access_key_id= 'AKIAIXEGZVXCWE2FV3SQ',aws_secret_access_key = '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') 
		bucket = conn.get_bucket("rmapi")
		region=''
		Websitecode =296
		RoomType = ""
		RateType=''
		OnsiteRate = 0
		Closed_up = 'N'
		MealInclusion_Type = " "
		RateDescription = " "
		LOS=1
		RoomAmenity_Type = ""
		NetRate=0
		GrossRate=0
		Curr=re.sub(r"http:/.*?curr=|#", "", url)
		Tax_status=''
		listcodes = []
		TaxType=''
		TaxAmount=''
		isAvailable=''
		MaxOccupancy=''
		ispromupdate = 'N'
		statuscode=''
		RateDate=''
		ispromupdate='N'
		promotion=''
		product_id=''
		if re.search(r'adults=(\d+)&',url):
			adults=re.search(r'adults=(\d+)&',url).group(1)
		elif re.search(r'a(\d+)&multi',url):
			adults=re.search(r'a(\d+)&multi',url).group(1)
		Guests = adults
		proxies = {"http": "http://{}".format(proxyip)}
		region=''
		ip=re.sub(r"\{'.*?@|'\}|:\d+","",str(proxies))
		try:
			try:
				r = requests.get('http://freegeoip.net/json/'+ip,timeout=30)
			except Exception,e:
				r = requests.get('http://freegeoip.net/json/'+ip,timeout=30)
			js = r.json()
			region=js['country_name']
		except Exception,e:
			region=''
		head = {'User-Agent':'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:12.0) Gecko/100101 Firefox/31.0'}
		if "www.lastminute.com.au" in url:
			#print ".com"
			if re.search(r'h(\d+).Hotel-Info',url):
				hotelcode=re.search(r'h(\d+).Hotel-Info',url).group(1)
			delta = datetime.datetime.strptime(re.search(r'chkin=(.*?)&chkout=(.*?)&',url,re.DOTALL).group(2), "%Y-%m-%d") - datetime.datetime.strptime(re.search(r'chkin=(.*?)&chkout=(.*?)&',url,re.DOTALL).group(1), "%Y-%m-%d")
			LOS = delta.days
			if re.search(r'chkin=.*?&chkout=.*?&',url):
				checkin=datetime.datetime.strptime(re.search(r'chkin=(.*?)&chkout=(.*?)&',url,re.DOTALL).group(1), "%Y-%m-%d").strftime("%d/%m/%Y")
				checkout=datetime.datetime.strptime(re.search(r'chkin=(.*?)&chkout=(.*?)&',url,re.DOTALL).group(2), "%Y-%m-%d").strftime("%d/%m/%Y")
				RateDate=re.search(r'chkin=(.*?)&chkout=.*?&',url).group(1)
			form_url='chkin='+checkin+'&chkout='+checkout+'&'
			url_insert=re.sub(r'chkin=.*?&chkout=.*?&',form_url,url)
			#=#print     checkin,  checkout,  RateDate
			##print LOS
			sr = requests.session()
			load_url =  url  #+"?hwrqCacheKey=e1816bb7-7c05-46c4-b369-be4934dfdcd2HWRQ1465108597457&c=866788f1-cb72-4a0d-a447-a518ab63ad0a&"
			try:
				##print "try"
				hml1 = sr.get(load_url, headers=head,proxies=proxies,timeout=50)
				##print hml1.status_code
			except Exception,e:
				#print "except"
				value_error=str(e)
				stacktrace=sys.exc_traceback.tb_lineno
				#arora_insert.Errorlog(id_update,Domainname,value_error,stacktrace,intime,url_insert,proxy_arora)
				try:
					hml1 = sr.get(load_url, headers=head,proxies=proxies,timeout=50)
				except Exception,e:
					value_error=str(e)
					stacktrace=sys.exc_traceback.tb_lineno
					insert_value_error=str(value_error)+'Where line number '+str(stacktrace)
					keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(Websitecode,datetime.datetime.now(),id_update)
					##print keyvalue , insert_value_error
					key = bucket.new_key(keyvalue)
					key.set_contents_from_string(insert_value_error)
					statuscode=5
					array.append(aws_insert.insert(id_update, inputid ,Domainname,Websitecode, "", "", "", "", Guests, "", "", "", "", "",url_insert, url_insert, url_insert, "", "", "", "", "", "",StartDate, EndDate , "", "", "", "", "", "", "", "", "",region,statuscode, israteperstay))
					return json.dumps(array)
			if hml1.status_code!=200:
				hml1 = sr.get(load_url,proxies=proxies, headers=head)
			if (hml1.status_code == 403 or hml1.status_code == 407):
				try:
					hml1 = sr.get(load_url, headers=head, proxies = proxies)
					if (hml1.status_code != 200):
						hml1 = sr.get(load_url, headers=head)
				except Exception,e:
					value_error=str(re.sub("'",'"',str(e)))
					stacktrace=sys.exc_traceback.tb_lineno
					insert_value_error=str(value_error)+'Where line number '+str(stacktrace)
					statuscode=5
					keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(Websitecode,datetime.datetime.now(),id_update)
					##print keyvalue
					key = bucket.new_key(keyvalue)
					key.set_contents_from_string(insert_value_error)
					array.append(aws_insert.insert(id_update, inputid ,Domainname,Websitecode, "", "", "", "", Guests, "", "", "", "", "",url_insert, url_insert, url_insert, "", "", "", "", "", "",StartDate, EndDate , "", "", "", "", "", "", "", "", "",region,statuscode, israteperstay))
					return json.dumps(array)
			htm_ec= hml1.text
			htm = htm_ec.encode('ascii', 'ignore')
			Main_block_reg = re.compile (r'(roomTypeCode":.*?maxGuests":\d+,)')
			##print htm
			chkin_re = re.search(r"chkin=(.*?)&", url)
			if chkin_re:
				chkin_grp = chkin_re.group(1)
				chkin = re.sub("/", "%2F", chkin_grp)
			chkin=re.sub("/", "%2F", checkin)
			chkot=re.sub("/", "%2F", checkout)
			#print "#printing  ....."
			tok_reg = re.search(r"infosite.token = '(.*?)'", htm)
			if tok_reg:
				tok_reg_1 = tok_reg.group(1)
				#print "tok_reg_1 =",tok_reg_1
			else:
				tok_reg_1 = ''
			ts_reg_ = re.search(r'utcTimestamp":(.*?),', htm)
			if ts_reg_:
				ts_reg_1 = ts_reg_.group(1)
				#print "ts_reg_1=",ts_reg_1
			else:
				ts_reg_1 = ''
			hbid_ = re.search(r"infosite.hotelBrandId = '(.*?)'", htm)
			if hbid_:
				hbid_1 = hbid_.group(1)
				#print "hbid_1=",hbid_1
			else:
				hbid_1 = ''
			togle_reg_ = re.search(r"infosite.swpToggleOn =\s*(.*?);", htm)
			if togle_reg_:
				togle_reg_1 = togle_reg_.group(1)
				#print "togle_reg_1=",togle_reg_1
			else:
				togle_reg_1 = ''
			Sitehotel_reg = re.search(r"infosite.hotelId = '(.*?)'", htm)
			if Sitehotel_reg:
				SitehotelID = Sitehotel_reg.group(1)
				#print "SitehotelID=",SitehotelID
			else:
				SitehotelID = ''
			#RateDate = chekn
			Rtdate=re.sub(r'-|\-','',str(RateDate))
			keyvalue = "ondemand/{}/{:%Y%m%d}/source/{}.txt".format(Websitecode,datetime.datetime.now(),str(inputid)+'_'+str(Rtdate)+'_'+id_update)
			#print keyvalue
			key = bucket.new_key(keyvalue)
			key.set_contents_from_string(htm)    
			#chkin=datetime.datetime.strptime(chk_re_in,str('%m/%d/%Y')).strftime('%d/%m/%Y')
			#chkot=datetime.datetime.strptime(chk_re_out,str('%m/%d/%Y')).strftime('%d/%m/%Y')
			#j_url = "https://www.expedia.com/api/infosite/"+SitehotelID+"/getOffers?token="+tok_reg_1+"&brandId="+hbid_1+"&isVip=false&chid=&chkin="+chkin+"&chkout="+chkot+"&adults="+str(guest_add)+"&children=0&swpToggleOn="+togle_reg_1+"&ts="+ts_reg_1    
			j_url= "https://www.lastminute.com.au/api/infosite/"+SitehotelID+"/getOffers?token="+tok_reg_1+"&brandId="+hbid_1+"&isVip=false&chid=&chkin="+chkin+"&chkout="+chkot+"&adults="+Guests+"&children=0&swpToggleOn="+togle_reg_1+"&ts="+ts_reg_1
			head = {'User-Agent':'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:12.0) Gecko/100101 Firefox/31.0', 'referer': str(load_url), 'DNT':str(1), 'host': 'www.lastminute.com.au'}
			#print "j_url =",j_url
			try:
				#print "try1"
				hmlj = sr.get(j_url, headers=head,proxies=proxies, timeout=50)
			except Exception,e:
				value_error=str(re.sub(r"'",'',str(e)))
				stacktrace=sys.exc_traceback.tb_lineno
				#arora_insert.Errorlog(id_update,Domainname,value_error,stacktrace,intime,url_insert,proxy_arora)
				try:
					hmlj = sr.get(j_url, headers=head,proxies=proxies, timeout=50)
				except Exception,e:
					value_error=str(re.sub(r"'",'',str(e)))
					stacktrace=sys.exc_traceback.tb_lineno
					keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(Websitecode,datetime.datetime.now(),id_update)
					#print keyvalue,  value_error,   stacktrace
					key = bucket.new_key(keyvalue)
					key.set_contents_from_string(str(e))
					statuscode=5
					Guests='1'
					array.append(aws_insert.insert(id_update, inputid ,Domainname,Websitecode, "", "", "", "", Guests, "", "", "", "", "",url_insert, url_insert, url_insert, "", "", "", "", "", "",StartDate, EndDate , "", "", "", "", "", "", "", "", "",region,statuscode, israteperstay))
					return json.dumps(array)
			if hmlj.status_code <> 200:
				hmlj = sr.get(j_url, headers=head, proxies = proxies)
			if (hmlj.status_code == 403 or hmlj.status_code == 407):
				hmlj = sr.get(j_url, headers=head, proxies = proxies)
				if hmlj.status_code <> 200:
					hmlj = sr.get(j_url, headers=head)
			html = hmlj.text
			html = html.encode('ascii', 'ignore')
			keyvalue = "ondemand/{}/{:%Y%m%d}/json_source/{}.txt".format(Websitecode,datetime.datetime.now(),str(inputid)+'_'+str(Rtdate)+'_'+id_update)
			##print keyvalue
			key = bucket.new_key(keyvalue)
			key.set_contents_from_string(hmlj.text)
			
			jsonvalue = json.loads(hmlj.text)
			html2 = str(jsonvalue)
			if 'offers' in jsonvalue:
					Closed_up = 'N'
					for roomvalue in jsonvalue['offers']:
						if 'exceedsMaxGuests' not in roomvalue or 'exceedsMaxAdults' not in roomvalue:
							Rmtypcode = roomvalue['roomTypeCode']                   
							Roomtype_reg_form = 'roomTypeCode":"' + Rmtypcode + '.*?name":"(.*?)",'
							Roomtype_reg = re.search(Roomtype_reg_form, htm)
							if Roomtype_reg:
								Roomtype_clean = Roomtype_reg.group(1)            
								Roomtype = re.sub("'", "''", Roomtype_clean).encode('utf-8')
								if Roomtype == '':
									Roomtype_clean = roomvalue['roomName']
									Roomtype = re.sub("'", "''", Roomtype_clean).encode('utf-8')
							else:
								Roomtype_clean = roomvalue['roomName']
								Roomtype = re.sub("'", "''", Roomtype_clean).encode('utf-8')
							ratePlanCode = roomvalue['ratePlanCode']
							checklist = str(Rmtypcode) + ' ' + str(Roomtype) + ' ' + str(ratePlanCode)
							if checklist in listcodes:
								continue
							else:
								listcodes.append(checklist)
							if roomvalue['price'] != None:
								onsite_rate_clean = roomvalue['price']['displayPrice']
								if onsite_rate_clean != None:
									onsite_rate_encode = onsite_rate_clean.encode('ascii', 'ignore')
									onsite_rate_Str = str (onsite_rate_encode)
									OnsiteRate = re.sub(r'[A-Z|a-z]', '', re.sub(r'(\D)', '', re.sub(r"\\u20b9|\$|,|[A-Za-z]+\.|Rs.", r"", onsite_rate_Str)))
									# Spaceblock_concat  = roomvalue['price']
									# Spaceblocks         = str(Spaceblock)+' '+str(Spaceblock_concat)+' '+str(offerType)
									# Spaceblock         = ''
								else:
									OnsiteRate = 0
								net_reg = roomvalue['price']['crossOutPrice']
								if net_reg != None:
									net_encode = net_reg.encode('ascii', 'ignore')
									net_clean = str(net_encode)
									net_rate = re.sub(r'[A-Z|a-z]', '', re.sub(r'(\D)', '', re.sub(r"\\u20b9|\$|,|[A-Za-z]+\.|Rs.", r"", net_clean)))
									ispromupdate = 'Y'
								else:
									net_rate = '0'
									ispromupdate = 'N'
							else:
								net_rate = 0
								ispromupdate = 'N'
								OnsiteRate = 0
							if roomvalue["price"] != None:
								Curr = roomvalue["price"]['priceObject']["currencyCode"]
								if Curr != None:
									Currencycode = Curr
							if Currencycode == '':
								if roomvalue['feePenalty'] != None:
									Curr = roomvalue["feePenalty"]["currencyCode"]
									if Curr != None:
										Currencycode = Curr
								else:
									Currencycode = ''
							'''if  LOS>1:
								NightlyRates = roomvalue['nightlyRates'][0]
								i=0
								for Price in NightlyRates:
									OnsiteRate = Price['price']
									OnsiteRate = float(OnsiteRate)+float(i)
									i=OnsiteRate
									OnsiteRate = float(OnsiteRate)/float(len(NightlyRates))'''
							isavlble = roomvalue['numberOfRoomsLeft']
							if isavlble != None:
								roomavlb = isavlble
							else:
								roomavlb = ''
								
							Maxoccp = re.search(r'"roomTypeCode":"' + Rmtypcode + '".*?maxGuests[\'|\"]:(\d+)', htm)
							if Maxoccp:
								Maxoccp = Maxoccp.group(1)
								Maxocp = re.sub("'", "''", Maxoccp)
							else:
								Maxoccp = roomvalue['maxGuests']
								if Maxoccp != None:
									Maxocp = Maxoccp
								else:
									Maxocp = 0
							Room_AMt_reg = '"roomTypeCode":"' + Rmtypcode + '".*?<b>(.*?)\]'
							# #print Room_AMt_reg
							Room_Else = re.search(Room_AMt_reg, htm)
							if Room_Else:
								Room_Amt1 = re.sub(r"'", "''", str(Room_Else.group(1)))
								Room_Amt_coma = re.sub("<b>", ", ", Room_Amt1)
								Room_Amt_tag = re.sub("<.*?>|'", "", Room_Amt_coma)
								Room_Amt = Room_Amt_tag
							else:
								Room_Amt = ''
								
							Room_Dec_reg = r'roomTypeCode":"' + Rmtypcode + '".*?name":"(.*?)<b>'
							# #print Room_Dec_reg
							Room_E_Desc = re.search(Room_Dec_reg, htm)
							if Room_E_Desc:
								Room_Decs_group = re.sub(r"'", "''", str(Room_E_Desc.group(1).encode('ascii', 'ignore')))
								Room_Desc_coma = re.sub("<b>" , ", ", Room_Decs_group)
								Room_Desc_tag = re.sub("\s+|</strong>", " ", Room_Desc_coma)
								Room_Desc = re.sub("<.*?>|'|^.*?\[", "", Room_Desc_tag.replace('"', ''))
							else:
								Room_Desc = ''           
							if re.search(r'"roomTypeCode":"' + str(Rmtypcode) + '".*?"361":"(.*?)"', htm):
								Meal_NotJs = re.sub(r'(?sim)Surcharge', 'Cost', re.search(r'"roomTypeCode":"' + str(Rmtypcode) + '".*?"361":"(.*?)"', htm).group(1))
							else:
								Meal_NotJs = '' 
							Mealtype = roomvalue['amenities']
							Meal = str(Mealtype) + ' ' + str(Room_Desc)+' '+str(Meal_NotJs)
							if "refundable" in roomvalue:
								Ratetype = 'Free Cancellation'
							else:
								Ratetype = 'Non-Refundable'
								
							if OnsiteRate == 0:
								Closed_up = 'Y'
								statuscode = '1'
							else:
								Closed_up = 'N'
								israteperstay = 'Y'
								if roomvalue['price'] != None:
									taxonsite_clean = roomvalue['price']['displayPrice']
									if taxonsite_clean != None:
										taxonsite_clean = taxonsite_clean.encode('ascii', 'ignore')
										taxonsite = re.sub(r'[A-Z|a-z]', '', re.sub(r'(\D)', '', re.sub(r"\\u20b9|\$|,|[A-Za-z]+\.|Rs.", r"", taxonsite_clean)))
								if roomvalue['totalPriceWithTaxesAndFees']:
									taxamount_clean = roomvalue['totalPriceWithTaxesAndFees']['amount']
									if taxamount_clean != None:
										taxamount = taxamount_clean
									if taxonsite and taxamount:
										if int(taxonsite) == int(round(taxamount)):
											Tax_status = '1'
										else:
											Tax_status = '2'
									else:
										Tax_status = '2'
							##print id_update, inputid , Domainname, Websitecode, StartDate, Roomtype, LOS, RateDate, Guests, OnsiteRate, net_rate, OnsiteRate, Currencycode, Room_Desc, url_insert, url_insert, url_insert, Room_Amt, Meal, Maxocp, ispromupdate, Closed_up, 30, StartDate , EndDate, intime, roomavlb, None, None, Tax_status, None, Ratetype, net_rate,promotion,region,statuscode
							# #print Roomtype, LOS, RateDate,OnsiteRate, net_rate,Currencycode, Room_Desc,statuscode
							array.append(aws_insert.insert(id_update, inputid , Domainname, Websitecode, StartDate, Roomtype, LOS, RateDate, Guests, OnsiteRate, net_rate, OnsiteRate, Currencycode, Room_Desc, url_insert, url_insert, url_insert, Room_Amt, Meal, Maxocp, ispromupdate, Closed_up, 30, StartDate , EndDate, intime, roomavlb, None, None, Tax_status, None, Ratetype, net_rate, promotion, region, statuscode, israteperstay))
			else:
				Closed_up = 'Y'
				ispromupdate = 'N'
				LOS = 1
				Guests = 1
				Currencycode = ''
				OnsiteRate = 0
				Room_Desc = ''
				roomavlb = ''
				MaxOccupancy = ''
				Websitecode = 296
				GrossRate = 0
				discount_rate = 0
				statuscode='2'
				No_room = re.search(r'"numberOfRoomsAvailable":0', htm)
				if No_room:
					#Spaceblock = re.sub("'", "''", Spaceblock_all)
					statuscode='2'
				else:
					#Spaceblock = ''  
					statuscode='2'
				da_time = datetime.datetime.now()
				intime = re.sub(r'\s','T',str(da_time))
				array.append(aws_insert.insert(id_update,inputid ,Domainname,Websitecode,StartDate,RoomType,LOS,RateDate,Guests,OnsiteRate,NetRate,GrossRate,Currencycode,Room_Desc,url_insert,url_insert,url_insert,RoomAmenity_Type,MealInclusion_Type,MaxOccupancy,ispromupdate,Closed_up,30,StartDate ,EndDate,intime,roomavlb,TaxType,TaxAmount,Tax_status,None,RateType,discount_rate,promotion,region,statuscode, israteperstay))
			
		else:                
			head = {'User-Agent':'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:12.0) Gecko/20100101 Firefox/31.0'}
			proxies = {"http": "http://{}".format(proxyip)}
			sr = requests.Session()
			adults=re.search(r'adults=(\d+)&',url).group(1)
			if re.search(r'details/(\d+)\?',url):
				hotelcode=re.search(r'details/(\d+)\?',url).group(1)
			if re.search(r'details/(\d+)\?business',url):
				hotelcode=re.search(r'details/(\d+)\?business',url).group(1)
			if re.search(r'searchId=(\d+)&',url):
				sid=re.search(r'searchId=(\d+)&',url).group(1)
			if re.search(r'checkin=.*?&checkout=.*?#',url,re.DOTALL):
				cin=re.search(r'checkin=(.*?)&checkout=(.*?)#',url,re.DOTALL).group(1)
				checkin=datetime.datetime.strptime(cin, str("%Y-%m-%d")).strftime("%Y%m%d")
				RateDate=datetime.datetime.strptime(re.search(r'checkin=(.*?)&checkout=(.*?)#',url,re.DOTALL).group(1),str('%Y-%m-%d')).strftime('%Y-%m-%d')
				cout=re.search(r'checkin=(.*?)&checkout=(.*?)#',url,re.DOTALL).group(2)
				checkout=datetime.datetime.strptime(cout, str("%Y-%m-%d")).strftime("%Y%m%d")
			checkins=datetime.datetime.strptime(cin, str("%Y-%m-%d")).strftime("%Y, %m, %d")
			checkouts=datetime.datetime.strptime(cout, str("%Y-%m-%d")).strftime("%Y, %m, %d")
			ccin = datetime.datetime.strptime(checkins,'%Y, %m, %d')
			ccout = datetime.datetime.strptime(checkouts,'%Y, %m, %d')
			LOS = ccout - ccin
			LOS = LOS.days
				
			main_url1=re.sub(r'departureIntervals=.*?-.*?&','departureIntervals='+str(checkin)+'-'+str(checkout)+'&',re.sub(r'&checkin=.*?&checkout=.*?#','&checkin='+str(checkin)+'&checkout='+str(checkout),url))
			main_url=re.sub(r'searchId=\d+&','searchId='+str(sid)+'&',main_url1)
			destination_tag=''
			if re.search(r'destinationCities=(\d+)&',main_url):
				destination_code=re.search(r'destinationCities=(\d+)&',main_url).group(1)
			elif re.search(r'destinationCity=(\d+)&',main_url):
				destination_code=re.search(r'destinationCity=(\d+)&',main_url).group(1)
			else:
				destination_code=""
			if re.search(r'destinationTag=(.*?)&',main_url):
				destination_tag=re.search(r'destinationTag=(.*?)&',main_url).group(1)
			elif re.search(r'destinationTags=(.*?)&',main_url):
				destination_tag=re.search(r'destinationTags=(.*?)&',main_url).group(1)
			else:
				destination_tag=""
			domain = re.sub(r"/hotel.*|/viajes/route.*", r"",main_url)
			#head = {'User-Agent':'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:12.0) Gecko/20100101 Firefox/31.0'}    
			head= {'Content-Type': "application/json" }    
			#print main_url
			if 'http://trips.lastminute.com' in domain or 'https://trips.lastminute.com' in domain:
				businessProfileId = 'HOLIDAYSLASTMINUTECOUK'
				#print "yes"
			elif 'http://reservation.lastminute.com' in domain or 'https://reservation.lastminute.com' in domain:
				businessProfileId = 'HOLIDAYSLASTMINUTEFR'
			elif 'http://viajes.es.lastminute.com' in domain or 'https://viajes.es.lastminute.com' in domain:
				businessProfileId = ''
			else:
				businessProfileId = ''
			data={"domain":re.sub("http.*?://","",domain),"businessProfileId":businessProfileId,"landingUrl":main_url,"version":"1.78.5"}
			#print data
			if 'http://trips.lastminute.com' in domain or 'https://trips.lastminute.com' in domain:
				Curr = 'GBP'
			else:
				Curr = 'EUR'
			#print data
			#print str(domain)+'/ose/handshake'
			handshkae=sr.post(str(domain)+'/ose/handshake',json=data,headers=head)
			print handshkae.status_code
			sess_id= json.loads(handshkae.text)
			#print "sess_id ---",sess_id
			session_id=sess_id['sessionId']
			print session_id
			randomdigit = random.randint(111111,999999)
			##print checkin, checkout
			#raw_input("Press any key to continue");
			#data1={"activeViews":["LIST","CARDS","MAP"],"searchParameters":{"checkIn":checkin,"checkOut":checkout,"departureAirport":"","destinationAirport":"","destinationCity":"137381","destinationTag":"Calpe","onlyHotel":"true","roomConfiguration":[{"adults":"1"}],"recHotels":["3811511","3811511"],"destinationLocIds":[]},"sessionId":"409c5f9c-0587-4cd1-b15c-2c3b71acec89","subSource":"S03SAV10S10PS01","newTabRequest":"false","searchId":"123456"}
			data={"activeViews":["LIST","CARDS","MAP"],"searchParameters":{"checkIn":checkin,"checkOut":checkout,"departureAirport":"","destinationAirport":"","destinationCity":destination_code,"destinationTag":destination_tag,"onlyHotel":"true","roomConfiguration":[{"adults":adults}],"recHotels":[hotelcode,hotelcode],"destinationLocIds":[]},"sessionId":session_id,"subSource":"S10RRES0S10RR01","newTabRequest":"false","searchId":randomdigit}
			##print "_"*50
			##print data
			search=sr.post(str(domain)+'/ose/'+str(session_id)+'/search',json=data,headers=head)
			##print search

			#print "++++++++++++++++++++++++++++++++++++++"
			search_responce = json.loads(search.text)
			##print search_responce
			search_id=search_responce['searchId']
			
			
			if search_id == None or search_id == '':
				##print search_id
				statuscode='3'
				keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(Websitecode,datetime.datetime.now(),id_update)
				key = bucket.new_key(keyvalue)
				key.set_contents_from_string(search.text)
				array.append(aws_insert.insert(id_update, inputid ,Domainname,Websitecode, "", "", "", "", Guests, "", "", "", "", "",main_url, main_url, main_url, "", "", "", "", "", "",StartDate, EndDate , "", "", "", "", "", "", "", "", "",region,statuscode, israteperstay))
				return json.dumps(array)    
			##print hotelcode
			hoturl = str(domain)+'/ose/'+session_id+'/search/'+search_id+'/map'
			
			#print hoturl
			searching =sr.get(hoturl,headers=head)
			search_response = json.loads(searching.text)
			hotid=[]
			#print "Hotelcode ==",hotelcode
			for i in search_response:
				pid = json.dumps(i)
				ihid = json.loads(pid)
				hcode = ihid['internalHotelId']
				#print "got hcode ==",hcode
				hotid.append(hcode)
				if hotelcode in str(ihid):
					product_id=ihid['productId']
					break
		
			#print "+++++++++++++++++++++++++++++++++++++++++"

			hotelcode=int(hotelcode)
			if hotelcode not in hotid:
				randomdigit = random.randint(111111,999999)
				data={"activeViews":["LIST","CARDS","MAP"],"searchParameters":{"checkIn":checkin,"checkOut":checkout,"departureAirport":"","destinationAirport":"","destinationCity":destination_code,"destinationTag":destination_tag,"onlyHotel":"true","roomConfiguration":[{"adults":adults}],"recHotels":[hotelcode,hotelcode],"destinationLocIds":[]},"sessionId":session_id,"subSource":"S03SAV10S10PS01","newTabRequest":"false","searchId":randomdigit}
				search=sr.post(str(domain)+'/ose/'+str(session_id)+'/search',json=data,headers=head)
			##print search
				#print "++++++++++2nd Check+++++++++++++++++++"
				search_responce = json.loads(search.text)
				##print search_responce
				search_id=search_responce['searchId']
				if search_id == None or search_id == '':
					##print search_id
					statuscode='3'
					keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(Websitecode,datetime.datetime.now(),id_update)
					key = bucket.new_key(keyvalue)
					key.set_contents_from_string(search.text)
					array.append(aws_insert.insert(id_update, inputid ,Domainname,Websitecode, "", "", "", "", Guests, "", "", "", "", "",main_url, main_url, main_url, "", "", "", "", "", "",StartDate, EndDate , "", "", "", "", "", "", "", "", "",region,statuscode, israteperstay))
					return json.dumps(array)    
				##print hotelcode
				hoturl = str(domain)+'/ose/'+session_id+'/search/'+search_id+'/map'
				searching =sr.get(hoturl,headers=head)
				search_response = json.loads(searching.text)
				
				hotid=[]
				#print "Hotelcode ==",hotelcode
				for i in search_response:
					pid = json.dumps(i)
					##print pid
					ihid = json.loads(pid)
					##print ihid
					hcode = ihid['internalHotelId']
					#print "got hcode ==",hcode
					hotid.append(hcode)
					if str(hotelcode) in str(ihid):
						#print "yes"
						product_id=ihid['productId']
						break
				#print "+++++++++++++++++++++++++++++++++++++++++"
				hotelcode=int(hotelcode)
				if hotelcode not in hotid:
					#print "noo"
					statuscode='2'
					keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(Websitecode,datetime.datetime.now(),id_update)
					key = bucket.new_key(keyvalue)
					key.set_contents_from_string(search.text)
					#print main_url
					array.append(aws_insert.insert(id_update, inputid ,Domainname,Websitecode, "", "", "", "", Guests, "", "", "", "", "",main_url, main_url, main_url, "", "", "", "", "", "",StartDate, EndDate , "", "", "", "", "", "", "", "", "",region,statuscode, israteperstay))
					return json.dumps(array)
			try:
				jsonlink =  str(domain)+'/ose/'+str(session_id)+'/search/'+str(search_id)+'/product/'+str(product_id)+'/rooms'
				##print {"sessionId":session_id,"searchId":search_id,"productId":product_id,"referenceEventId":"785538#3cnc76ll9lo","msTracking":{"msCurrency":"","msTotalPrice":"","msMealPlan":"","msRoomIndex":""}}
				#print jsonlink
				result_request = requests.get(jsonlink, headers = head,timeout=50)
				#print result_request.status_code
				print result_request.status_code
			except Exception,e:
				print e
				try:
					result_request = requests.get(jsonlink, headers = head,timeout=50)
				except Exception,e:
					insert_value_error=str(str(re.sub(r"'",'"',str(e))))+'Where line number '+str(sys.exc_traceback.tb_lineno)
					statuscode='5'
					keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(Websitecode,datetime.datetime.now(),id_update)
					key = bucket.new_key(keyvalue)
					key.set_contents_from_string(insert_value_error)
					Guests='1'
					array.append(aws_insert.insert(id_update, inputid ,Domainname,Websitecode, "", "", "", "", Guests, "", "", "", "", "",main_url, main_url, main_url, "", "", "", "", "", "",StartDate, EndDate , "", "", "", "", "", "", "", "", "",region,statuscode, israteperstay))
					return json.dumps(array)            
			Rtdate=re.sub(r'-|\-','',RateDate)
			keyvalue = "ondemand/{}/{:%Y%m%d}/source/{}.json".format(Websitecode,datetime.datetime.now(),str(inputid)+'_'+str(Rtdate)+'_'+id_update)
			key = bucket.new_key(keyvalue)
			key.set_contents_from_string(result_request.text)
			result_responce = json.loads(result_request.text)
			#print "result_responce", result_responce
			if result_responce.has_key('selectedHotel'):
				hotel_info=result_responce['selectedHotel']
			else:
				hotel_info=''
			if result_responce.has_key('dictionary'):
				vat=result_responce['dictionary']['translations']['vacation.select.details.product.tab.rooms.vat.included'] #":"VAT included"
				##print "vat==",vat
				if vat == "VAT included":
					TaxType=vat
					Tax_status=1
				else:
					Tax_status=2
			if hotel_info['rooms']:
				Closed_up='N'
				statuscode=''
				for rooms in hotel_info['rooms']:
					amenties=[]
					RoomType=unidecode(rooms['name']).encode('ascii')
					if rooms.has_key('configurations'):
						room_info=rooms['configurations']
					else:
						room_info=''
					if rooms.has_key('descriptions'):
						for descrip in rooms['descriptions']:
							if descrip.has_key('text'):
								RateDescription=unidecode(descrip['text']).encode('ascii')
							else:
								RateDescription=''
					#RateDescription=rooms['descriptions'][0]['text']
					for room_information in room_info:
						if room_information.has_key('cancellationPolicy'):
							RateType=room_information['cancellationPolicy']['type']
							if RateType=="UNKNOWN":
								RateType="Cancellation Policy"
						else:
							RateType=''
						if room_information.has_key('price'):
							OnsiteRate=room_information['price']
							OnsiteRate=OnsiteRate
							israteperstay = 'Y'
						else:
							OnsiteRate=''
						if room_information.has_key('priceWithoutDiscount'):
							NetRate=room_information['priceWithoutDiscount']
							NetRate=NetRate
							ispromupdate='Y'
						else:
							NetRate=''
						if room_information.has_key('mealPlanName'):
							MealInclusion_Type=unidecode(room_information['mealPlanName']).encode('ascii')
						else:
							MealInclusion_Type=''
						if room_information.has_key('roomsLeft'):
							isAvailable=room_information['roomsLeft']
						else:
							isAvailable=''
						if rooms.has_key('amenities'):
							for ament in rooms['amenities']:
								Room_amenity=unidecode(ament['description']).encode('ascii')
								amenties.append(Room_amenity)
							RoomAmenity_Type=re.sub(r"\[|\]|u|'",'',str(amenties))
						else:
							RoomAmenity_Type=''
						if OnsiteRate=='' or OnsiteRate ==0:
							statuscode=1
						if NetRate=='' or NetRate ==0 or NetRate =='0':
							ispromupdate='N'
						if OnsiteRate == None:
							OnsiteRate = 0
						if NetRate==None:
							NetRate = 0
						Tax_status='-1'
						#print RoomType, OnsiteRate, NetRate
						##print (id_update, inputid , Domainname, Websitecode, StartDate, RoomType, LOS, RateDate, Guests, OnsiteRate, NetRate, OnsiteRate, Curr, RateDescription, main_url, main_url, main_url, RoomAmenity_Type, MealInclusion_Type, MaxOccupancy, ispromupdate, Closed_up, 30, StartDate , EndDate, intime, isAvailable, TaxType,TaxAmount, Tax_status, None, RateType, NetRate,promotion,region,statuscode)
						array.append(aws_insert.insert(id_update, inputid , Domainname, Websitecode, StartDate, RoomType, LOS, RateDate, Guests, OnsiteRate, NetRate, OnsiteRate, Curr, RateDescription, main_url, main_url, main_url, RoomAmenity_Type, MealInclusion_Type, MaxOccupancy, ispromupdate, Closed_up, 30, StartDate , EndDate, intime, isAvailable, TaxType,TaxAmount, Tax_status, None, RateType, NetRate,promotion,region,statuscode, israteperstay))
			else:
				#print "Else..."
				statuscode=2
				Closed_up='Y'
				array.append(aws_insert.insert(id_update, inputid , Domainname, Websitecode, StartDate, RoomType, LOS, RateDate, Guests, OnsiteRate, NetRate, OnsiteRate, Curr, RateDescription, main_url, main_url, main_url, RoomAmenity_Type, MealInclusion_Type, MaxOccupancy, ispromupdate, Closed_up, 30, StartDate , EndDate, intime, isAvailable, TaxType,TaxAmount, Tax_status, None, RateType, NetRate,promotion,region,statuscode, israteperstay))
		keyvalue = "ondemand/{}/{:%Y%m%d}/delivery/{}.json".format(Websitecode,datetime.datetime.now(),str(inputid)+'_'+str(re.sub(r'-|\-','',RateDate))+'_'+id_update)
		key = bucket.new_key(keyvalue)
		key.set_contents_from_string(json.dumps(array))
		return json.dumps(array)
	except Exception,e:
		value_error=str(re.sub(r"'",'"',str(e)))
		stacktrace=sys.exc_traceback.tb_lineno
		insert_value_error=str(value_error)+'Where line number '+str(stacktrace)+str(proxyip)
		print insert_value_error
		statuscode='4'
		Websitecode='296'
		keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(Websitecode,datetime.datetime.now(),id_update)
		key = bucket.new_key(keyvalue)
		key.set_contents_from_string(insert_value_error)
		Guests='1'
		array.append(aws_insert.insert(id_update, inputid ,Domainname,Websitecode, "", "", "", "", Guests, "", "", "", "", "",main_url, main_url, main_url, "", "", "", "", "", "",StartDate, EndDate , "", "", "", "", "", "", "", "", "",region,statuscode, israteperstay))
		return json.dumps(array)

#fetchrates(url, inputid, id_update, proxyip)
