# -*- coding: utf-8 -*-
import re
import requests
import datetime
import json
import boto

import aws_insert
import sys 
import gc
def fetchrates(url ,inputid, id_update, proxyip):
    array      = []
    israteperstay=''
    proxies    = {"http": "http://{}".format(proxyip)}
    intime     = re.sub(r'\s','T',str(datetime.datetime.now()))
    Domainname = 'montreal.gouverneur.com'
    Websitecode= '353'
    region     = ''
    statuscode = ''
    Mealtype   = ''
    conn   = boto.connect_s3(aws_access_key_id= 'AKIAIXEGZVXCWE2FV3SQ',aws_secret_access_key = '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') 
    bucket = conn.get_bucket("rmapi")
    StartDate= datetime.date.today()
    EndDate  = datetime.date.today() + datetime.timedelta(days=29)
    try:
        CheckIn_Check_OT_re = re.search(r'#Checkin=(.*?)&Checkout=(.*?)&',url)
        if CheckIn_Check_OT_re:
            Checkin = CheckIn_Check_OT_re.group(1)
            CheckOT = CheckIn_Check_OT_re.group(2)
        else:
            Checkin = ''
            CheckOT = ''
        RateDate = Checkin
        delta    = datetime.datetime.strptime(str(CheckOT), "%Y-%m-%d") - datetime.datetime.strptime(Checkin, "%Y-%m-%d")
        LOS      = delta.days
        RoomType = ''
        Guests   = re.search(r'Adults=(\d+)', url).group(1)
        Ratetype = ''
        RateDescription = ''
        Meal     = ''
        Taxtype  = ''
        Curr     = ''
        MaxOccupancy = None
        isPromotionalRate  = 'N'
        Closed   = 'Y'
        NetRate  = 0
        Taxstatus= -1
        TaxAmount= 0
        Discount = 0
        GrossRate= 0
        OnsiteRate = 0
        Promotion_Name= ''
        isAvailable = ''
        RoomAmenity_Type = ''
        inMonth_re = re.search(r'Checkin=(\d+)-(\d+)-(\d+)&Checkout=(\d+)-(\d+)-(\d+)&',url)
        if inMonth_re:
            inYear  = inMonth_re.group(1)            
            inMonth = inMonth_re.group(2)
            inDay   = inMonth_re.group(3)
            OTYear  = inMonth_re.group(4)  
            OTMonth = inMonth_re.group(5)
            OTDay   = inMonth_re.group(6)
        else:
            inMonth = ""
            inDay   = ''
            inYear  = '' 
            OTMonth = ''
            OTDay   = ''
            OTYear  = ''
        url = re.sub('#.*$','',str(url))
        date_str   = 'checkinMonth='+str(inMonth)+'&checkinDay='+str(inDay)+'&checkinYear='+str(inYear)+'&checkoutMonth='+str(OTMonth)+'&checkoutDay='+str(OTDay)+'&checkoutYear='+str(OTYear)+'&'
        url        = re.sub(r"checkinMonth=\d+&checkinDay=\d+&checkinYear=\d+&checkoutMonth=\d+&checkoutDay=\d+&checkoutYear=\d+&",date_str, url)
        url_insert = url
        proxyip    = re.sub(r':.*','',str(proxyip))
        headers    = {'User-Agent':'Mozilla/5.0 (X11; Linux i686; rv:45.0) Gecko/20100101 Firefox/45.0'}
        try:
            try:
                r = requests.get('http://freegeoip.net/json/' + proxyip, timeout=30)
            except Exception, e:
                r = requests.get('http://freegeoip.net/json/' + proxyip, timeout=30)
            js = r.json()
            region = js['country_name']
        except Exception, e:
            region = ''
        try:
            hml = requests.get(url,headers=headers,proxies=proxies,timeout=50)
        except Exception, e:
            value_error = str(re.sub("'", '', str(e)))
            stacktrace = sys.exc_traceback.tb_lineno
            try:
                hml = requests.get(url,headers=headers,proxies=proxies,timeout=50)
            except Exception, e:
                value_error = str(re.sub("'", '', str(e)))
                stacktrace = sys.exc_traceback.tb_lineno
                keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(Websitecode, datetime.datetime.now(), id_update)
                key = bucket.new_key(keyvalue)
                key.set_contents_from_string(str(e) + 'Where Line number' + str(stacktrace) + str(proxies))
                statuscode = 5
                Guests = ''
                array.append(aws_insert.insert(id_update, inputid , Domainname, Websitecode, "", "", "", "", Guests, "", "", "", "", "", url, url, url, "", "", "", "", "", "", StartDate, EndDate , "", "", "", "", "", "", "", "", "", region, statuscode,israteperstay))
                return json.dumps(array)
        if hml.status_code <> 200:
            hml = requests.get(url,headers=headers,proxies=proxies,timeout=50)
        if (hml.status_code == 403 or hml.status_code == 407) or hml.status_code <> 200:
            try:
                if hml.status_code <> 200:
                    hml = requests.get(url,headers=headers,timeout=50)
            except Exception, e:
                print e
                value_error = str(re.sub("'", '', str(e)))
                stacktrace = sys.exc_traceback.tb_lineno
                keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(Websitecode, datetime.datetime.now(), id_update)
                key = bucket.new_key(keyvalue)
                key.set_contents_from_string(str(e) + 'Where Line number' + str(stacktrace) + str(proxies))
                statuscode = 5
                Guests = ''
                array.append(aws_insert.insert(id_update, inputid , Domainname, Websitecode, "", "", "", "", Guests, "", "", "", "", "", url, url, url, "", "", "", "", "", "", StartDate, EndDate , "", "", "", "", "", "", "", "", "", region, statuscode,israteperstay))
                return json.dumps(array) 
        json_data = re.sub(r'amp;','',hml.text.encode('utf-8'))
        Rtdate=re.sub(r'-|\-','',str(RateDate))
        keyvalue = "ondemand/{}/{:%Y%m%d}/source{}.html".format(Websitecode,datetime.datetime.now(),str(inputid)+'_'+str(Rtdate)+'_'+id_update)
        key = bucket.new_key(keyvalue)
        key.set_contents_from_string(json_data)
        ##print json_data
        if re.compile(r'class="first_level_li".*?</section>\s*</li>', re.DOTALL).findall(json_data):
            #print "IFFFF"
            for block in re.compile(r'class="first_level_li".*?</section>\s*</li>', re.DOTALL).findall(json_data):
                for block2 in re.compile(r'<li class="">.*?</div>\s*</li>',re.DOTALL).findall(block):
                    RoomType_re_re = re.search(r'room" data-tag="wh-quick-view-click" title="(.*?)"\s*href=', block)
                    if RoomType_re_re:
                        Ratetype = re.sub(r"'","''",re.sub(r'<.*?>','',RoomType_re_re.group(1))).decode('unicode_escape').encode('ascii','ignore')
                    else:
                        Ratetype = ""
                    RoomType_re = re.search(r'<span class="toggle-arrow toggle-closed">.*?</span> (.*?)</a>', block2)
                    if RoomType_re:
                        RoomType = re.sub(r"'","''",re.sub(r'<.*?>','',RoomType_re.group(1))).decode('unicode_escape').encode('ascii','ignore')
                    else:
                        RoomType = ""
                    OnsiteRate_re = re.search(r'<span class="average_room_rate">.*?\s*<span class="converted_currency_amount">\s*(.*?)</span>', block2, re.DOTALL)
                    if OnsiteRate_re:
                        OnsiteRate = OnsiteRate_re.group(1)
                    else:
                        OnsiteRate = 0            
                    Curr_re = re.search(r'"converted_currency_code">\s*(.*?)\s*<', block2)
                    if Curr_re:
                        Curr = Curr_re.group(1)
                    else:
                        Curr = ""    
                    isAvailable_re = re.search(r'<p class="inventor.*?">.*?(\d+).*?</p>', block2)
                    if isAvailable_re:
                        isAvailable = isAvailable_re.group(1)
                    else:
                        isAvailable = ''  
                    RateDescrip_re = re.search(r'"rate-descr">\s*(.*?)\s*</div', block2, re.DOTALL)
                    if RateDescrip_re:
                        RateDescription = re.sub(r"\s\s\s*","",re.sub(r"'","''",str(re.sub(r'<.*?>','',str(RateDescrip_re.group(1)))))).decode('unicode_escape').encode('ascii','ignore')
                    else:
                        RateDescription  = ""
                    #print "RoomType :",RoomType
                    #print "Ratetype :",Ratetype
                    #print "Currency :",Curr
                    #print "Available:",isAvailable
                    #print "OnsiteRat:",OnsiteRate
                    #print "Amenities:",RoomAmenity_Type
                    #print "Descript :",RateDescription
                    #print "__"*30
                    if OnsiteRate==0:
                        statuscode = 1
                        Closed='Y'
                    else:
                        statuscode = ''
                        Closed='N'
                    if TaxAmount!=0:
                        Taxstatus = 1
                    Mealtypes = str(RateDescription)+' '+str(RoomType)
                    if Mealtypes !=None:
                        Mealtype_str = str(Mealtypes)
                        if 'breakfast' in Mealtype_str.lower() and 'dinner' in Mealtype_str.lower()  and 'lunch' in Mealtype_str.lower():
                            Meal = 'Breakfast, Lunch and Dinner'
                        elif 'breakfast' in Mealtype_str.lower() and 'dinner' in Mealtype_str.lower():
                            Meal = 'Breakfast and dinner'
                        elif 'breakfast included' in Mealtype_str.lower():
                            Meal = 'Breakfast included'
                        elif 'BREAKFAST' in Mealtype_str:
                            Meal = 'Breakfast'
                        elif 'breakfast' in Mealtype_str.lower() and 'lunch' in Mealtype_str.lower():
                            Meal = 'Breakfast and Lunch'
                        elif 'Lunch' in Mealtype_str and 'Dinner' in Mealtype_str :
                            Meal = "Lunch and Dinner"
                        elif 'breakfast' in Mealtype_str.lower() and 'lunch' in Mealtype_str.lower() and 'dinner' in Mealtype_str.lower():
                            Meal = 'Breakfast, Lunch and dinner'
                        elif 'Break fast' in Mealtype_str:
                            Meal = 'BreakFast' 
                        elif 'breakfast' in Mealtype_str.lower():
                            Meal = 'BreakFast' 
                        elif 'halfboard' in Mealtype_str.lower():
                            Meal = 'Halfboard'
                        elif 'half board' in Mealtype_str.lower():
                            Meal = 'Half board' 
                        elif 'full board' in Mealtype_str.lower():
                            Meal = 'Full Board'
                        elif 'fullboard' in Mealtype_str.lower():
                            Meal = 'FullBoard'
                        elif 'All-Inclusive' in Mealtype_str:
                            Meal = 'All-Inclusive'
                        elif 'All Inclusive' in Mealtype_str:
                            Meal = 'All Inclusive'
                        elif 'All Meals' in Mealtype_str:
                            Meal = 'All Meals'
                        elif 'All Meal' in Mealtype_str:
                            Meal = 'All Meal'
                        else:
                            Meal = ''
                    else:
                        Meal = ''                             
                    GrossRate = OnsiteRate
                    Mealtype  = Meal
                    RateDate  = Checkin
                    if int(LOS)>1:
                        israteperstay = "N"
                    else:
                        israteperstay = "Y"
                    ##print (id_update, inputid , Domainname, Websitecode, StartDate, RoomType, LOS, RateDate, Guests, OnsiteRate, NetRate, GrossRate, Curr, RateDescription, url_insert, url_insert, url_insert, RoomAmenity_Type, Mealtype, MaxOccupancy, isPromotionalRate, Closed, 30, StartDate , EndDate, intime, isAvailable, Taxtype, TaxAmount, Taxstatus, None, Ratetype, Discount,Promotion_Name,region,statuscode,israteperstay)
                    array.append(aws_insert.insert(id_update, inputid , Domainname, Websitecode, StartDate, RoomType, LOS, RateDate, Guests, OnsiteRate, NetRate, GrossRate, Curr, RateDescription, url_insert, url_insert, url_insert, RoomAmenity_Type, Mealtype, MaxOccupancy, isPromotionalRate, Closed, 30, StartDate , EndDate, intime, isAvailable, Taxtype, TaxAmount, Taxstatus, None, Ratetype, Discount,Promotion_Name,region,statuscode,israteperstay))
        else:
            Closed     = 'Y'
            statuscode ='2'
            array.append(aws_insert.insert(id_update, inputid , Domainname, Websitecode, StartDate, RoomType, LOS, RateDate, Guests, OnsiteRate, NetRate, GrossRate, Curr, RateDescription, url_insert, url_insert, url_insert, RoomAmenity_Type, Mealtype, MaxOccupancy, isPromotionalRate, Closed, 30, StartDate , EndDate, intime, isAvailable, Taxtype, TaxAmount, Taxstatus, None, Ratetype, Discount,Promotion_Name,region,statuscode,israteperstay))
        Rtdate = re.sub(r'-|\-', '', str(RateDate))
        keyvalue = "ondemand/{}/{:%Y%m%d}/delivery/{}.json".format(Websitecode,datetime.datetime.now(),str(inputid)+'_'+str(Rtdate)+'_'+id_update)
        key = bucket.new_key(keyvalue)
        key.set_contents_from_string(json.dumps(array))
        return json.dumps(array)
        gc.collect()
    except Exception as e:
        print e
        value_error = str(re.sub(r"'", '"', str(e)))
        stacktrace = sys.exc_traceback.tb_lineno
        Guests = ''
        region = ''
        insert_value_error = str(value_error) + 'Where line number ' + str(stacktrace) + str(proxyip)
        statuscode = '4'
        keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(Websitecode, datetime.datetime.now(), id_update)
        key = bucket.new_key(keyvalue)
        key.set_contents_from_string(insert_value_error)
        array.append(aws_insert.insert(id_update, inputid , Domainname, Websitecode, "", "", "", "", Guests, "", "", "", "", "", url, url, url, "", "", "", "", "", "", StartDate, EndDate , "", "", "", "", "", "", "", "", "", region, statuscode,israteperstay))
        return json.dumps(array)
        
'''url       = 'https://ushgp.webhotel.microsdc.us/bp/search_rooms.cmd?checkinMonth=10&checkinDay=15&checkinYear=2017&checkoutMonth=10&checkoutDay=16&checkoutYear=2017&numberOfRooms=1&numberOfAdults=1&numberOfChildren=0&#Checkin=2017-11-16&Checkout=2017-11-17&'
inputid   = 'Test'            
id_update = ''
proxyip   = '62.210.106.225:3710'                
fetchrates(url ,inputid, id_update, proxyip)'''
    
    
    
    
    
