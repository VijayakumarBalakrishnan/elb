# -*- coding: utf-8 -*-
import re
import requests
import datetime
import json
import sys 
import boto
import gc

import aws_insert

#url        ='https://www.orbitz.com/Dubai-Hotels-Winchester-Hotel-Apartments.h2919333.Hotel-Information?chkin=2018-04-22&chkout=2018-04-25&rm1=a2&multiCurrencyCode=USD#rooms-and-rates'
#inputid  ='Testing'
#id_update='12345'
#proxyip  ='user-34068:214859b73da0e174@45.64.106.45:1212'

def fetchrates(url ,inputid, id_update, proxyip):
    israteperstay = ''
    try:
        array = []
        intime=re.sub(r'\s','T',str(datetime.datetime.now()))
        functionname='Orbitz'
        conn = boto.connect_s3(aws_access_key_id= 'AKIAIXEGZVXCWE2FV3SQ',aws_secret_access_key = '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') 
        bucket = conn.get_bucket("rmapi")
        WebSiteName="Orbitz"
        No_of_day=30
        region=''
        
        websitecode = 35
        StartDate = datetime.date.today()
        EndDate = datetime.date.today()+datetime.timedelta(days=29)
        url_insert = re.search(r"chkin=(.*?)&chkout=(.*?)&",url)
        if url_insert:
            group1=url_insert.group(1)
            RateDate= group1
            group2=url_insert.group(2)
            chkot_res1=datetime.datetime.strftime(datetime.datetime.strptime(str(group1),"%Y-%m-%d"), "%m/%d/%Y")
            chkot_res=datetime.datetime.strftime(datetime.datetime.strptime(str(group2),"%Y-%m-%d"), "%m/%d/%Y")
        sam_url='chkin='+chkot_res1+'&chkout='+chkot_res+'&'
        url_search=re.sub(r'chkin=.*?&chkout=.*?&',sam_url,url)
        delta = datetime.datetime.strptime(re.search(r"chkout=(.*?)&", url).group(1), "%Y-%m-%d") - datetime.datetime.strptime(re.search(r"chkin=(.*?)&", url).group(1), "%Y-%m-%d")
        LOS = delta.days
        #print url
        def Extraction(jsonvalue,htm,url,id_update,inputid,RateDate,totaldays, LOS):
            parsed_htm_re = re.search(r'({"propertyData":.*?}};)', htm,re.DOTALL)
            if parsed_htm_re:
                parsed_htm = parsed_htm_re.group(1)
            else:
                parsed_htm = "" 
            listcodes      = []
            OnsiteRate     = 0
            roomavlb       = 0
            Taxtype        = ''
            websitecode    = 35
            Maxocp         = None
            Room_Desc      = ''
            israteperstay = ''
            Meal_NotJs     = ''
            Currencycode   = ''
            Closed_up      = 'N'
            ispromupdate   = 'N'
            Roomtype       = " "
            Room_Amt_tag   = ''
            Ratetype       = ''
            Meal           = ''
            net_rate       = 0
            Room_Amt       = ''
            TaxAmount      = 0
            Tax_status     = ''
            statuscode     =''
            Promotion_Name =''
            
            if 'offers' in jsonvalue:
                Closed_up = 'N'
                for roomvalue in jsonvalue['offers']:
                    Tax_and_Fees = 0
                    OnsiteRate_c = 0
                    Rmtypcode = roomvalue['roomTypeCode']
                    Rmtypcode = re.sub(r'\.','\.',re.sub(r'\|','\|',str(Rmtypcode)))
                    Roomtype_reg_form = 'roomTypeCode":"'+Rmtypcode+'".*?"name":"(.*?)",'
                    Roomtype_reg = re.search(Roomtype_reg_form, parsed_htm, re.IGNORECASE)
                    if Roomtype_reg:
                        Roomtype_clean = Roomtype_reg.group(1)            
                        Roomtype = re.sub("'", "''", str(Roomtype_clean))
                        if Roomtype == '' or Roomtype == None:
                            if 'roomName' in roomvalue:
                                Roomtype_clean = roomvalue['roomName']
                                Roomtype = re.sub("'", "''", str(Roomtype_clean))
                            else:
                                Roomtype = ''
                    else:
                        if 'roomName' in roomvalue:
                            Roomtype_clean = roomvalue['roomName']
                            Roomtype = re.sub("'", "''", str(Roomtype_clean))
                        else:
                            Roomtype = ''
                    if 'valueAdd' in roomvalue:
                        if 'text' in roomvalue['valueAdd']:
                            promo_namchek = roomvalue['valueAdd']['text']
                            if '% off' in promo_namchek.lower():
                                Promotion_Name = promo_namchek
                                ispromupdate = 'Y'
                            else:
                                ispromupdate = 'N'
                                Promotion_Name = '' 
                        else:
                            ispromupdate = 'N'
                            Promotion_Name = '' 
                    else:
                        Promotion_Name = '' 
                    ratePlanCode = roomvalue['ratePlanCode']
                    checklist = str(Rmtypcode) + ' ' + str(Roomtype) + ' ' + str(ratePlanCode)
                    if checklist in listcodes:
                        continue
                    else:
                        listcodes.append(checklist)
                    if roomvalue['price'] != None:
                        onsite_rate_clean = roomvalue['price']['displayPrice']
                        if 'formattedTotalPriceWithTaxesAndFees' in roomvalue['price']:
                            Tax_and_Fees  = re.sub(r"\\u20b9|\$|,|[A-Za-z]+\.|Rs.", r"",str(roomvalue['price']['formattedTotalPriceWithTaxesAndFees'].encode('ascii', 'ignore')))
                        else:
                            Tax_and_Fees  = 0
                        if onsite_rate_clean != None:
                            onsite_rate_encode = onsite_rate_clean.encode('ascii', 'ignore')
                            onsite_rate_Str = str (onsite_rate_encode)
                            OnsiteRate = re.sub(r'[A-Z|a-z]', '', re.sub(r'(\D)', '', re.sub(r"\\u20b9|\$|,|[A-Za-z]+\.|Rs.", r"", onsite_rate_Str)))
                        else:
                            OnsiteRate = 0
                        net_reg = roomvalue['price']['crossOutPrice']
                        if net_reg != None:
                            net_encode = net_reg.encode('ascii', 'ignore')
                            net_clean = str(net_encode)
                            net_rate = re.sub(r'[A-Z|a-z]', '', re.sub(r'(\D)', '', re.sub(r"\\u20b9|\$|,|[A-Za-z]+\.|Rs.", r"", net_clean)))
                            ispromupdate = 'Y'
                        else:
                            net_rate = 0
                            ispromupdate = 'N'
                    else:
                        net_rate = 0
                        ispromupdate = 'N'
                        OnsiteRate = 0
                    if roomvalue["price"] != None:
                        Curr = roomvalue["price"]['priceObject']["currencyCode"]
                        if Curr != None:
                            Currencycode = Curr
                    if Currencycode == '':
                        if roomvalue['feePenalty'] != None:
                            Curr = roomvalue["feePenalty"]["currencyCode"]
                            if Curr != None:
                                Currencycode = Curr
                        else:
                            Currencycode = ''
                    isavlble = roomvalue['numberOfRoomsLeft']
                    if isavlble != None:
                        roomavlb = isavlble
                    else:
                        roomavlb = ''
                    Maxoccp =  re.search(r'"roomTypeCode":"' + Rmtypcode + '".*?maxGuests[\'|\"]:(\d+)', parsed_htm)
                    if Maxoccp:
                        Maxoccp = Maxoccp.group(1)
                        Maxocp = re.sub("'", "''", str(Maxoccp))
                        if Maxocp == '0' or Maxocp=='' or Maxocp==None:
                            Maxoccp = re.search(r'"roomTypeCode":"' + Rmtypcode + '".*?total[\'|\"]:(\d+)', parsed_htm)
                            if Maxoccp:
                                Maxoccp = Maxoccp.group(1)
                                Maxocp = re.sub("'", "''", str(Maxoccp))
                    else:
                        Maxoccp = re.search(r'"roomTypeCode":"' + Rmtypcode + '".*?total[\'|\"]:(\d+)', parsed_htm)
                        if Maxoccp:
                            Maxoccp = Maxoccp.group(1)
                            Maxocp = re.sub("'", "''", str(Maxoccp))
                        else:
                            Maxoccp = roomvalue['maxGuests']
                            if Maxoccp != None:
                                Maxocp = Maxoccp
                            else:
                                Maxocp = None
                    if Maxoccp==None or Maxoccp=='0' or Maxoccp==0:
                        Maxocp = None
                    Room_AMt_reg = '"roomTypeCode":"' + Rmtypcode + '".*?<b>(.*?)\]'
                    # ##print Room_AMt_reg
                    Room_Else = re.search(Room_AMt_reg, parsed_htm)
                    if Room_Else:
                        Room_Amt1 = re.sub(r"'", "''", str(Room_Else.group(1)))
                        Room_Amt_coma = re.sub("<b>", ", ", str(Room_Amt1))
                        Room_Amt_tag = re.sub("<.*?>|'", "", str(Room_Amt_coma))
                        Room_Amt = Room_Amt_tag
                    else:
                        Room_Amt = ''
                        
                    Room_Dec_reg = r'roomTypeCode":"'+Rmtypcode+'".*?name":".*?"description":\[(.*?)\]'
                    # ##print Room_Dec_reg
                    Room_E_Desc = re.search(Room_Dec_reg, parsed_htm)
                    if Room_E_Desc:
                        if Room_E_Desc.group(1)!=None:
                            Room_Decs_group = re.sub(r"'", "''", str(Room_E_Desc.group(1).encode('ascii', 'ignore')))
                            Room_Desc_coma = re.sub("<b>" , ", ", str(Room_Decs_group))
                            Room_Desc_tag = re.sub("\s+|</strong>", " ", str(Room_Desc_coma))
                            Room_Desc = re.sub("<.*?>|'|^.*?\[", "", Room_Desc_tag.replace('"', ''))
                    else:
                        Room_Desc = Roomtype           
                    if re.search(r'"roomTypeCode":"' + str(Rmtypcode) + '".*?"361":"(.*?)"', parsed_htm):
                        Meal_NotJs = re.sub(r'(?sim)Surcharge', 'Cost', str(re.search(r'"roomTypeCode":"' + str(Rmtypcode) + '".*?"361":"(.*?)"', parsed_htm).group(1)))
                    else:
                        Meal_NotJs = '' 
                    Mealtype = roomvalue['amenities']
                    Meal = str(Mealtype) + ' ' + str(Room_Desc)+' '+str(Meal_NotJs)
                    if "refundable" in roomvalue:
                        Ratetype = 'Free Cancellation'
                    else:
                        Ratetype = 'Non-Refundable'

                    OnsiteRate_c  = OnsiteRate
                    if Currencycode=='IDR':
                        OnsiteRate_c = re.sub(r"\.","",str(OnsiteRate_c))
                        Tax_and_Fees = re.sub(r"\.","",str(Tax_and_Fees))
                    OnsiteRate_c  = re.sub(r'[A-Z|a-z]','',re.sub(r'(\D)','',str(OnsiteRate_c)))
                    Tax_and_Fees  = re.sub(r'[A-Z|a-z]','',re.sub(r'(\D)','',str(Tax_and_Fees)))
                    if OnsiteRate == 0:
                        Closed_up = 'Y'
                        statuscode = '1'
                    else:
                        if float(Tax_and_Fees)==float(OnsiteRate):
                            Tax_status = '1'
                        else:
                            Tax_status = '2'
                        Closed_up = 'N'
                    if LOS> 1 and Currencycode in ('AUD', 'CHF', 'DKK', 'EUR', 'GBP', 'NOK', 'NZD', 'SEK') or LOS ==1:
                        israteperstay = 'Y'
                    else:
                        israteperstay = 'N'
                    if net_rate <> 0:
                        ispromupdate = 'Y'
                    else:
                        ispromupdate = 'N'
                    if Roomtype=='':
                        Roomtype_reg_form = 'roomTypeCode":"'+Rmtypcode+'".*?name":"(.*?)",'
                        Roomtype_reg = re.search(Roomtype_reg_form, parsed_htm)
                        if Roomtype_reg:
                            Roomtype_clean = Roomtype_reg.group(1)            
                            Roomtype = re.sub("'", "''", str(Roomtype_clean))
                            if Roomtype == '' or Roomtype == None:
                                if 'roomName' in roomvalue:
                                    Roomtype_clean = roomvalue['roomName']
                                    Roomtype = re.sub("'", "''", str(Roomtype_clean))
                                else:
                                    Roomtype = ''
                        else:
                            if 'roomName' in roomvalue:
                                Roomtype_clean = roomvalue['roomName']
                                Roomtype = re.sub("'", "''", str(Roomtype_clean))
                            else:
                                Roomtype = ''
                    if 'exceedsMaxGuests'  in roomvalue or 'exceedsMaxAdults' in roomvalue:
                        statuscode = 1
                        OnsiteRate = 0
                        net_rate   = 0
                    if (net_rate == 0 or net_rate == '') and (Promotion_Name == 0 or Promotion_Name == ''):
                        ispromupdate = 'N'
                    da_time     = datetime.datetime.now()
                    intime      = re.sub(r'\s','T',str(da_time))
                    #print Roomtype
                    array.append(aws_insert.insert(id_update, inputid, WebSiteName, websitecode, StartDate, Roomtype,LOS, RateDate, Guests, OnsiteRate, net_rate, OnsiteRate, Currencycode, Room_Desc, url_search, url_search, url_search, Room_Amt, Meal,Maxocp, ispromupdate, Closed_up, 30, StartDate, EndDate, intime,roomavlb,Taxtype,TaxAmount,Tax_status,None,Ratetype,net_rate,Promotion_Name,region,statuscode, israteperstay))
            else:
                Closed_up       = 'Y'
                ispromupdate    = 'N'
                #Spaceblock      = 'No rooms available for the selected dates'
                LOS             = LOS
                OnsiteRate      = 0
                Room_Desc       = ''
                roomavlb        = 0
                Maxocp          = None
                websitecode     = 35
                statuscode=2
                da_time     = datetime.datetime.now()
                intime      = re.sub(r'\s','T',str(da_time))
                ##print (id_update, inputid, WebSiteName, websitecode, StartDate, Roomtype,LOS, RateDate, Guests, OnsiteRate, net_rate, OnsiteRate, Currencycode, Room_Desc, url_search, url_search, url_search, Room_Amt, Meal,Maxocp, ispromupdate, Closed_up, 30, StartDate, EndDate, intime,roomavlb,Taxtype,TaxAmount,Tax_status,None,Ratetype,net_rate,Promotion_Name,region,statuscode, israteperstay)
                array.append(aws_insert.insert(id_update, inputid, WebSiteName, websitecode, StartDate, Roomtype,LOS, RateDate, Guests, OnsiteRate, net_rate, OnsiteRate, Currencycode, Room_Desc, url_search, url_search, url_search, Room_Amt, Meal,Maxocp, ispromupdate, Closed_up, 30, StartDate, EndDate, intime,roomavlb,Taxtype,TaxAmount,Tax_status,None,Ratetype,net_rate,Promotion_Name,region,statuscode, israteperstay))
                #insert(inputid , Domainname, websitecode, ReportDate, Roomtype, LOS, RateDate, Guests, OnsiteRate, net_rate, GrossRate, Currencycode, Maxocp, urlRate, urlInclusions, urlAmenities, Room_Amt,roomavlb, Room_Desc, ispromupdate, Closed_up, totaldays, Meal, Ratetype, StartDate , EndDate, intime, Spaceblock, discount_rate,Taxtype)



        if re.search(r'=[a|A](\d+)[&|#]', str(url)):
            Guests = re.search(r'=[a|A](\d+)[&|#]', str(url)).group(1)
        elif re.search(r'[a|A]dults=(\d+)&', str(url)):
            Guests = re.search(r'[a|A]dults=(\d+)&', str(url)).group(1)
        elif re.search(r'[a|A]dult=(\d+)&', str(url)):
            Guests = re.search(r'[a|A]dult=(\d+)&', str(url)).group(1)
        else:
            Guests = re.search(r'=[a|A](\d+)&', str(url)).group(1)  
              
        sr=requests.session()
        proxies = {"https": "http://{}".format(proxyip)}
        Hrkey       = "?hwrqCacheKey=e1816bb7-7c05-46c4-b369-be4934dfdcd2HWRQ1465108597457&c=866788f1-cb72-4a0d-a447-a518ab63ad0a&"
        load_url= url+Hrkey
        head    = {'User-Agent':'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:12.0) Gecko/20100101 Firefox/31.0'}
        region=''
        ip=re.sub(r"\{'.*?@|'\}|:\d+","",str(proxies))
        try:
            try:
                r = requests.get('http://freegeoip.net/json/'+ip,timeout=30)
            except Exception,e:
                r = requests.get('http://freegeoip.net/json/'+ip,timeout=30)
            js = r.json()
            region=js['country_name']
        except Exception,e:
            region=''
        try:
            hml = sr.get(load_url, headers=head,proxies = proxies,timeout=50)
        except Exception,e:
            try:
                hml = sr.get(load_url, headers=head,proxies = proxies)
            except Exception,e:
                value_error=str(re.sub(r"'",'',str(e)))
                stacktrace=sys.exc_traceback.tb_lineno
                keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(websitecode,datetime.datetime.now(),id_update)
                key = bucket.new_key(keyvalue)
                key.set_contents_from_string(str(e))
                statuscode=5
                Guests=''
                if re.search(r'=[a|A](\d+)[&|#]', str(url)):
                    Guests = re.search(r'=[a|A](\d+)[&|#]', str(url)).group(1)
                elif re.search(r'[a|A]dults=(\d+)&', str(url)):
                    Guests = re.search(r'[a|A]dults=(\d+)&', str(url)).group(1)
                elif re.search(r'[a|A]dult=(\d+)&', str(url)):
                    Guests = re.search(r'[a|A]dult=(\d+)&', str(url)).group(1)
                else:
                    Guests = re.search(r'=[a|A](\d+)&', str(url)).group(1)
                
                array.append(aws_insert.insert(id_update, inputid ,functionname,websitecode, "", "", "", "", Guests, "", "", "", "", "",url, url, url, "", "", "", "", "", "",StartDate, EndDate , "", "", "", "", "", "", "", "", "",region,statuscode, israteperstay))
                return json.dumps(array)                    
        if hml.status_code <> 200:
            hml = sr.get(load_url, headers=head,proxies = proxies)
        if hml.status_code == 403 or hml.status_code == 407:
            try:
                hml = sr.get(load_url, headers=head)
            except Exception,e:
                value_error=str(re.sub(r"'",'',str(e)))
                stacktrace=sys.exc_traceback.tb_lineno
                keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(websitecode,datetime.datetime.now(),id_update)
                key = bucket.new_key(keyvalue)
                key.set_contents_from_string(str(e))
                statuscode=5
                Guests=''
                if re.search(r'=[a|A](\d+)[&|#]', str(url)):
                    Guests = re.search(r'=[a|A](\d+)[&|#]', str(url)).group(1)
                elif re.search(r'[a|A]dults=(\d+)&', str(url)):
                    Guests = re.search(r'[a|A]dults=(\d+)&', str(url)).group(1)
                elif re.search(r'[a|A]dult=(\d+)&', str(url)):
                    Guests = re.search(r'[a|A]dult=(\d+)&', str(url)).group(1)
                else:
                    Guests = re.search(r'=[a|A](\d+)&', str(url)).group(1)
                array.append(aws_insert.insert(id_update, inputid ,functionname,websitecode, "", "", "", "", Guests, "", "", "", "", "",url, url, url, "", "", "", "", "", "",StartDate, EndDate , "", "", "", "", "", "", "", "", "",region,statuscode, israteperstay))
                return json.dumps(array)    
            
        htm_ec= hml.text
        htm = htm_ec.encode('ascii', 'ignore')
        Rtdate=re.sub(r'-|\-','',str(RateDate))
        keyvalue = "ondemand/{}/{:%Y%m%d}/source/{}.html".format(websitecode,datetime.datetime.now(),str(inputid)+'_'+str(Rtdate)+'_'+id_update)
        #print "keyvalue =",keyvalue
        key = bucket.new_key(keyvalue)
        key.set_contents_from_string(htm)
        ##print htm
        #regexes
        token_reg = r"infosite.token = '(.*?)'"
        ts_reg    = r'utcTimestamp":(.*?),'
        hbid      = r"infosite.hotelBrandId = '(.*?)'"
        togle_reg = r"infosite.swpToggleOn =\s*(.*?);"
        Sitehotel = r"infosite.hotelId = '(.*?)'"
        tok_reg = re.search(token_reg, htm)
        if tok_reg:
            tok_reg_1 = tok_reg.group(1)
        else:
            tok_reg_1 = ''
        ts_reg_ = re.search(ts_reg, htm)
        if ts_reg_:
            ts_reg_1 = ts_reg_.group(1)
        else:
            ts_reg_1 = ''
        hbid_ = re.search(hbid, htm)
        if hbid_:
            hbid_1 = hbid_.group(1)
        else:
            hbid_1 = ''
        togle_reg_ = re.search(togle_reg, htm)
        if togle_reg_:
            togle_reg_1 = togle_reg_.group(1)
        else:
            togle_reg_1 = ''
        Sitehotel_reg = re.search(Sitehotel, htm)
        if Sitehotel_reg:
            SitehotelID = Sitehotel_reg.group(1)
        else:
            SitehotelID = ''

        chkin_re = re.search(r"chkin=(.*?)&", url)
        if chkin_re:
            chkin_grp = chkin_re.group(1)
            chkin=datetime.datetime.strptime(chkin_grp,str('%Y-%m-%d')).strftime('%m-%d-%Y')
            #print "chkin =",chkin
            chkin     = re.sub("-", "%2F", chkin)
        chkot_re = re.search(r"chkout=(.*?)&", url)
        if chkot_re:
            chkot_grp = chkot_re.group(1)
            chkot=datetime.datetime.strptime(chkot_grp,str('%Y-%m-%d')).strftime('%m-%d-%Y')
            chkot = re.sub("-", "%2F", chkot)        
        #print chkin, chkot
        #RateDate = datetime.datetime.strftime(datetime.datetime.strptime(chkin_grp, "%m/%d/%Y"), "%Y-%m-%d")
        htm_ec   = hml.text
        htm      = htm_ec.encode('ascii', 'ignore')
        #Jsonvalues
        #print SitehotelID,  tok_reg_1,  hbid_1,   chkin,   chkot,   togle_reg_1,   ts_reg_1
        j_url = "https://www.orbitz.com/api/infosite/"+SitehotelID+"/getOffers?token="+tok_reg_1+"&brandId="+hbid_1+"&isVip=false&chid=&chkin="+chkin+"&chkout="+chkot+"&adults="+str(Guests)+"&children=0&swpToggleOn="+togle_reg_1+"&ts="+ts_reg_1        
        #print j_url
        head    = {'User-Agent':'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:12.0) Gecko/20100101 Firefox/31.0', 'referer': load_url, 'DNT':'1', 'host': 'www.orbitz.com'}
        try:    
            hmlj    = sr.get(j_url, headers=head, proxies = proxies)
            #print hmlj.status_code
        except Exception,e:
            try:
                hmlj    = sr.get(j_url, headers=head, proxies = proxies)
            except Exception,e:
                value_error=str(re.sub(r"'",'',str(e)))
                stacktrace=sys.exc_traceback.tb_lineno
                keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(websitecode,datetime.datetime.now(),id_update)
                key = bucket.new_key(keyvalue)
                key.set_contents_from_string(str(e))
                statuscode=5
                Guests=''
                if re.search(r'=[a|A](\d+)[&|#]', str(url)):
                    Guests = re.search(r'=[a|A](\d+)[&|#]', str(url)).group(1)
                elif re.search(r'[a|A]dults=(\d+)&', str(url)):
                    Guests = re.search(r'[a|A]dults=(\d+)&', str(url)).group(1)
                elif re.search(r'[a|A]dult=(\d+)&', str(url)):
                    Guests = re.search(r'[a|A]dult=(\d+)&', str(url)).group(1)
                else:
                    Guests = re.search(r'=[a|A](\d+)&', str(url)).group(1)
                array.append(aws_insert.insert(id_update, inputid ,functionname,websitecode, "", "", "", "", Guests, "", "", "", "", "",url, url, url, "", "", "", "", "", "",StartDate, EndDate , "", "", "", "", "", "", "", "", "",region,statuscode, israteperstay))
                return json.dumps(array)                    
        if hmlj.status_code <> 200:
            hmlj   = sr.get(j_url, headers=head, proxies = proxies)
        if hmlj.status_code == 403 or hmlj.status_code == 407:
            try:
                hmlj    = sr.get(j_url, headers=head)
            except Exception,e:
                value_error=str(re.sub(r"'",'',str(e)))
                stacktrace=sys.exc_traceback.tb_lineno
                keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(websitecode,datetime.datetime.now(),id_update)
                key = bucket.new_key(keyvalue)
                key.set_contents_from_string(str(e))
                statuscode=5
                Guests=''
                if re.search(r'=[a|A](\d+)[&|#]', str(url)):
                    Guests = re.search(r'=[a|A](\d+)[&|#]', str(url)).group(1)
                elif re.search(r'[a|A]dults=(\d+)&', str(url)):
                    Guests = re.search(r'[a|A]dults=(\d+)&', str(url)).group(1)
                elif re.search(r'[a|A]dult=(\d+)&', str(url)):
                    Guests = re.search(r'[a|A]dult=(\d+)&', str(url)).group(1)
                else:
                    Guests = re.search(r'=[a|A](\d+)&', str(url)).group(1)                
                array.append(aws_insert.insert(id_update, inputid ,functionname,websitecode, "", "", "", "", Guests, "", "", "", "", "",url, url, url, "", "", "", "", "", "",StartDate, EndDate , "", "", "", "", "", "", "", "", "",region,statuscode, israteperstay))
                return json.dumps(array)  
        try:
            try:
                hmtl = hmlj.text.encode('ascii','ignore')
            except:
                hmtl = hmlj.text.decode('ascii','ignore')
            Json_V = json.loads(hmtl)
            keyvalue = "ondemand/{}/{:%Y%m%d}/source/{}.json".format(websitecode,datetime.datetime.now(),str(inputid)+'_'+str(Rtdate)+'_'+id_update)
            #print "keyvalue =",keyvalue
            key = bucket.new_key(keyvalue)
            key.set_contents_from_string(hmlj.text)
            Extraction(Json_V,htm,url,id_update,inputid,RateDate,No_of_day, LOS)
        except Exception,e:
            print e
            value_error=str(re.sub(r"'",'"',str(e)))
            stacktrace=sys.exc_traceback.tb_lineno
            insert_value_error=str(value_error)+'Where line number '+str(stacktrace)
            print insert_value_error
            websitecode='35'
            if hmlj.status_code==429:
                statuscode=9
            else:
                statuscode='4'
            keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(websitecode,datetime.datetime.now(),id_update)
            key = bucket.new_key(keyvalue)
            key.set_contents_from_string(insert_value_error)
            array.append(aws_insert.insert(id_update, inputid ,functionname,websitecode, "", "", "", "", Guests, "", "", "", "", "",url, url, url, "", "", "", "", "", "",StartDate, EndDate , "", "", "", "", "", "", "", "", "",region,statuscode, israteperstay))
            return json.dumps(array)
        keyvalue = "ondemand/{}/{:%Y%m%d}/delivery/{}.json".format(websitecode,datetime.datetime.now(),str(inputid)+'_'+str(Rtdate)+'_'+id_update)
        #print keyvalue
        key = bucket.new_key(keyvalue)
        key.set_contents_from_string(json.dumps(array))
        return json.dumps(array)
        gc.collect()
    except Exception as e:
        value_error=str(re.sub(r"'",'"',str(e)))
        stacktrace=sys.exc_traceback.tb_lineno
        insert_value_error=str(value_error)+'Where line number '+str(stacktrace)+str(proxyip)
        print insert_value_error
        statuscode='4'
        websitecode='35'
        keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(websitecode,datetime.datetime.now(),id_update)
        key = bucket.new_key(keyvalue)
        key.set_contents_from_string(insert_value_error)
        Guests=''
        if re.search(r'=[a|A](\d+)[&|#]', str(url)):
            Guests = re.search(r'=[a|A](\d+)[&|#]', str(url)).group(1)
        elif re.search(r'[a|A]dults=(\d+)&', str(url)):
            Guests = re.search(r'[a|A]dults=(\d+)&', str(url)).group(1)
        elif re.search(r'[a|A]dult=(\d+)&', str(url)):
            Guests = re.search(r'[a|A]dult=(\d+)&', str(url)).group(1)
        else:
            Guests = re.search(r'=[a|A](\d+)&', str(url)).group(1)
        ##print (id_update, inputid ,functionname,websitecode, "", "", "", "", Guests, "", "", "", "", "",url_search, url_search, url_search, "", "", "", "", "", "",StartDate, EndDate , "", "", "", "", "",  "", "", "",statuscode)
        array.append(aws_insert.insert(id_update, inputid ,functionname,websitecode, "", "", "", "", Guests, "", "", "", "", "",url_search, url_search, url_search, "", "", "", "", "", "",StartDate, EndDate , "", "", "", "", "","", "", "", "",region,statuscode, israteperstay))
        return json.dumps(array)

#fetchrates(url ,inputid, id_update, proxyip)
