# -*- coding: utf-8 -*-
import re
import requests
import datetime
import json
import sys 
import operator
import boto
import gc

import aws_insert

def fetchrates(url ,inputid, id_update, proxyip):
    array      = []
    sr  = requests.session()
    proxies    = {"https": "http://{}".format(proxyip)}
    intime     = re.sub(r'\s','T',str(datetime.datetime.now()))
    Domainname = '320ranch.com'
    Websitecode= '357'
    region     = ''
    statuscode = ''
    Mealtype   = ''
    israteperstay = ''
    try:
        conn   = boto.connect_s3(aws_access_key_id= 'AKIAIXEGZVXCWE2FV3SQ',aws_secret_access_key = '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') 
        bucket = conn.get_bucket("rmapi")
        StartDate = datetime.date.today()
        EndDate   = datetime.date.today() + datetime.timedelta(days=29)
        CheckIn_Check_OT_re = re.search(r'arrivalDate=(.*?)&.*?departureDate=(.*?)&',url)
        if CheckIn_Check_OT_re:
            Checkin  = CheckIn_Check_OT_re.group(1)
            Checkout = CheckIn_Check_OT_re.group(2)
        else:
            Checkin  = ''
            Checkout = ''
        #print Checkin,Checkout
        RateDate = Checkin
        delta    = datetime.datetime.strptime(Checkout, "%Y-%m-%d") - datetime.datetime.strptime(Checkin, "%Y-%m-%d")
        LOS      = delta.days
        RoomType = ''
        #Guests   = 1
        Guests   = re.search(r'adultsCount.*?:(.*?),', url).group(1)
        Ratetype = ''
        RateDescription = ''
        Taxtype  = ''
        Curr     = ''
        MaxOccupancy = None
        isPromotionalRate  = 'N'
        Closed   = 'Y'
        NetRate  = 0
        Taxstatus= -1
        TaxAmount= 0
        Discount = 0
        GrossRate= 0
        OnsiteRate = 0
        Curr     = ''
        Promotion_Name= ''
        isAvailable = ''
        RoomAmenity_Type = ''
        url_insert = 'https://us01.iqwebbook.com/3RMT348/'
        ip = re.sub(r"\{'.*?@|'\}|:\d+", "", str(proxies))
        head = {'User-Agent':'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36'}
        try:
            try:
                r = requests.get('http://freegeoip.net/json/' + ip, timeout=30)
            except Exception, e:
                r = requests.get('http://freegeoip.net/json/' + ip, timeout=30)
            js = r.json()
            region = js['country_name']
        except Exception, e:
            region = ''
        try:
            htm = requests.get(url,headers = head,proxies = proxies , timeout=50)
        except Exception, e:
            value_error = str(re.sub("'", '', str(e)))
            stacktrace = sys.exc_traceback.tb_lineno
            try:
                htm = requests.get(url,headers = head,proxies = proxies , timeout=50)
            except Exception, e:
                value_error = str(re.sub("'", '', str(e)))
                stacktrace = sys.exc_traceback.tb_lineno
                keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(Websitecode, datetime.datetime.now(), id_update)
                key = bucket.new_key(keyvalue)
                key.set_contents_from_string(str(e) + 'Where Line number' + str(stacktrace) + str(proxies))
                statuscode = 5
                Guests = ''
                array.append(aws_insert.insert(id_update, inputid , Domainname, Websitecode, "", "", "", "", Guests, "", "", "", "", "", url, url, url, "", "", "", "", "", "", StartDate, EndDate , "", "", "", "", "", "", "", "", "", region, statuscode, israteperstay))
                return json.dumps(array)
        if htm.status_code <> 200:
            htm = requests.get(url,headers = head,proxies = proxies)
        if (htm.status_code == 403 or htm.status_code == 407) or htm.status_code <> 200:
            try:
                if htm.status_code <> 200:
                    htm = requests.get(url,headers = head)
            except Exception, e:
                Closed    = 'Y'
                value_error = str(re.sub("'", '', str(e)))
                stacktrace = sys.exc_traceback.tb_lineno
                keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(Websitecode, datetime.datetime.now(), id_update)
                key = bucket.new_key(keyvalue)
                key.set_contents_from_string(str(e) + 'Where Line number' + str(stacktrace) + str(proxies))
                statuscode = 5
                Guests = ''
                array.append(aws_insert.insert(id_update, inputid , Domainname, Websitecode, "", "", "", "", Guests, "", "", "", "", "", url, url, url, "", "", "", "", "", "", StartDate, EndDate , "", "", "", "", "", "", "", "", "", region, statuscode, israteperstay))
                return json.dumps(array)
        source = htm.text.encode('ascii','ignore')
        html  = json.loads(source)
        
        Rtdate=re.sub(r'-|\-','',str(RateDate))
        keyvalue = "ondemand/{}/{:%Y%m%d}/source{}.json".format(Websitecode,datetime.datetime.now(),str(inputid)+'_'+str(Rtdate)+'_'+id_update)
        key = bucket.new_key(keyvalue)
        key.set_contents_from_string(json.dumps(html))
        if 'data' in html:
            block1 = html['data']
            for blocks in block1['roomTypeResults']:
                RoomType = ''
                if blocks['name']:
                    RoomType  = blocks['name']
                for block1 in blocks['rooms']:
                    sold_out  = blocks['isSoldOut']
                    #print sold_out
                    for rate_blk in block1['rateTypes']:
                        OnsiteRate = 0
                        GrossRate  = 0
                        Ratetype   = ''
                        RateDescription = ''
                        isAvailable = ''
                        Curr        = ''
                        Closed      ='N'
                        block_isavail = rate_blk['isSelfAvailable']
                        if "True" not in str(sold_out):
                            if "False" not in str(block_isavail):
                                if rate_blk['averageNightlyRate']:
                                    OnsiteRate = rate_blk['averageNightlyRate']
                                    if OnsiteRate ==None:
                                        OnsiteRate = 0
                                GrossRate = OnsiteRate
                                if rate_blk['name']:
                                    Ratetype   = rate_blk['name']
                                if rate_blk['description']:
                                    RateDescription = rate_blk['description']
                                if rate_blk['isAvailable']:
                                    isAvailable = rate_blk['isAvailable']
                                    if 'True' in str(isAvailable):
                                        Closed   = 'N'
                                    else:
                                        Closed   = 'Y'
                                if OnsiteRate==0 or  'True' in str(sold_out):
                                    statuscode = 1
                                    Closed='Y'
                                else:
                                    statuscode = ''
                                    Closed='N'
                                LOS = int(LOS)
                                if int(LOS) >1:
                                    israteperstay = 'N'
                                else:
                                    israteperstay = 'Y'   
                                     
                                '''#print "RoomType         :",RoomType          
                                #print "Ratetype         :",Ratetype          
                                #print "price            :",OnsiteRate             
                                #print "RateDescription  :",RateDescription
                                #print "closed           :",Closed
                                #print "isAvailable      :",isAvailable,statuscode'''
                                isAvailable = ''
                                #print (id_update, inputid , Domainname, Websitecode, StartDate, RoomType, LOS, RateDate, Guests, OnsiteRate, NetRate, GrossRate, Curr, RateDescription, url_insert, url_insert, url_insert, RoomAmenity_Type, Mealtype, MaxOccupancy, isPromotionalRate, Closed, 30, StartDate , EndDate, intime, isAvailable, Taxtype, TaxAmount, Taxstatus, None, Ratetype, Discount,Promotion_Name,region,statuscode, israteperstay)
                                array.append(aws_insert.insert(id_update, inputid , Domainname, Websitecode, StartDate, RoomType, LOS, RateDate, Guests, OnsiteRate, NetRate, GrossRate, Curr, RateDescription, url_insert, url_insert, url_insert, RoomAmenity_Type, Mealtype, MaxOccupancy, isPromotionalRate, Closed, 30, StartDate , EndDate, intime, isAvailable, Taxtype, TaxAmount, Taxstatus, None, Ratetype, Discount,Promotion_Name,region,statuscode, israteperstay))
        else:
            Closed     = 'Y'
            statuscode = '2'
            #print (id_update, inputid , Domainname, Websitecode, StartDate, RoomType, LOS, RateDate, Guests, OnsiteRate, NetRate, GrossRate, Curr, RateDescription, url_insert, url_insert, url_insert, RoomAmenity_Type, Mealtype, MaxOccupancy, isPromotionalRate, Closed, 30, StartDate , EndDate, intime, isAvailable, Taxtype, TaxAmount, Taxstatus, None, Ratetype, Discount,Promotion_Name,region,statuscode, israteperstay)
            array.append(aws_insert.insert(id_update, inputid , Domainname, Websitecode, StartDate, RoomType, LOS, RateDate, Guests, OnsiteRate, NetRate, GrossRate, Curr, RateDescription, url_insert, url_insert, url_insert, RoomAmenity_Type, Mealtype, MaxOccupancy, isPromotionalRate, Closed, 30, StartDate , EndDate, intime, isAvailable, Taxtype, TaxAmount, Taxstatus, None, Ratetype, Discount,Promotion_Name,region,statuscode, israteperstay))
        Rtdate = re.sub(r'-|\-', '', str(RateDate))
        keyvalue = "ondemand/{}/{:%Y%m%d}/delivery/{}.json".format(Websitecode,datetime.datetime.now(),str(inputid)+'_'+str(Rtdate)+'_'+id_update)
        key = bucket.new_key(keyvalue)
        key.set_contents_from_string(json.dumps(array))
        return json.dumps(array)
        gc.collect()
    except Exception as e:
        print e
        value_error = str(re.sub(r"'", '"', str(e)))
        stacktrace = sys.exc_traceback.tb_lineno
        Guests = ''
        region = ''
        statuscode = '4'
        array.append(aws_insert.insert(id_update, inputid , Domainname, Websitecode, "", "", "", "", Guests, "", "", "", "", "", url, url, url, "", "", "", "", "", "", StartDate, EndDate , "", "", "", "", "", "", "", "", "", region, statuscode, israteperstay))
        keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(Websitecode,datetime.datetime.now(),id_update)
        key = bucket.new_key(keyvalue)
        key.set_contents_from_string(json.dumps(value_error))
        return json.dumps(array)
        
