# -*- coding: utf-8 -*-
import re
import requests
import datetime
import json
import time 
import boto
import gc
from mtranslate import translate
from unidecode import unidecode
import sys
import aws_insert

def fetchrates(url ,inputid, id_update, proxyip):
	israteperstay = ''
	try:
		array = []	
		url_concat=''
		sr = requests.Session()
		##print url	
		intime=re.sub(r'\s','T',str(datetime.datetime.now()))
		functionname='Ticket.com'
		Websitecode='311'	
		region=''
		conn = boto.connect_s3(aws_access_key_id= 'AKIAIXEGZVXCWE2FV3SQ',aws_secret_access_key = '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') 
		bucket = conn.get_bucket("rmapi")
		StartDate = datetime.date.today()
		EndDate  = datetime.date.today() + datetime.timedelta(days=29)
		if re.search(r"startdate=(.*?)&", url):
			RateDate = re.search(r"startdate=(.*?)&", url).group(1)
		if re.search(r'&enddate=(.*?)&',url):
			chkout_date=re.search(r'&enddate=(.*?)&',url).group(1)
		delta = datetime.datetime.strptime(chkout_date, "%Y-%m-%d") - datetime.datetime.strptime(RateDate, "%Y-%m-%d")
		LOS=delta.days
		url_concat = re.sub(r'&night=\d+&room=1&','&night='+str(LOS)+'&room=1&',re.sub(r'enddate=.*?&','',url))
		url1       = 'https://en.tiket.com/currency/doChangeCurrency?ref='+re.sub("startdate.*?enddate.*?&", "", str(url_concat))
		##print url1
		url = re.sub('night=1', 'night='+str(LOS), url)
		##print url
		def trans(to_translate):
			try:
				Translated = (translate(to_translate,'en'))
				return Translated
			except:
				return to_translate  
		proxies = {"https": "http://{}".format(proxyip)}
		ip      = re.sub(r"\{'.*?@|'\}|:\d+","",str(proxies))
		try:
			try:
				r = requests.get('http://freegeoip.net/json/'+ip,timeout=30)
			except Exception,e:
				r = requests.get('http://freegeoip.net/json/'+ip,timeout=30)
			js = r.json()
			region=js['country_name']
		except Exception,e:
			region=''
		try:
			sr.get(re.sub("#", "", url1), proxies = proxies,timeout=50,verify=False)
			hml =  sr.get(re.sub("#", "", url), proxies = proxies,timeout=50,verify=False)
			##print "ssdsdsd", hml.url
		except Exception,e:
			##print "Second_time",e
			try:
				sr.get(re.sub("#", "", url1), proxies = proxies,timeout=50,verify=False)
				hml =  sr.get(re.sub("#", "", url), proxies = proxies,timeout=50,verify=False)
			except Exception,e:
				value_error=str(re.sub("'",'"',str(e)))
				stacktrace=sys.exc_traceback.tb_lineno
				keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(Websitecode,datetime.datetime.now(),id_update)
				key = bucket.new_key(keyvalue)
				key.set_contents_from_string(str(e))
				statuscode=5
				if re.search(r'adult=(\d+)&',url,re.DOTALL):
					Guests=re.search(r'adult=(\d+)&',url,re.DOTALL).group(1)
				else:
					Guests=''
				array.append(aws_insert.insert(id_update, inputid ,functionname,Websitecode, "","", "", "", Guests, "", "", "", "", "",url_concat,url_concat,url_concat, "", "", "", "", "", "",StartDate, EndDate , "", "", "", "", "", "",  "", "", "",region,statuscode, israteperstay))
				return json.dumps(array)

		if (hml.status_code <> 200):
			sr.get(re.sub("#", "", url1), proxies = proxies,verify=False)
			hml =  sr.get(re.sub("#", "", url), proxies = proxies,verify=False)
		if (hml.status_code == 403 or hml.status_code == 407 or hml.status_code <> 200):
			try:	
				sr.get(re.sub("#", "", url1),proxies = proxies,verify=False)
				hml =  sr.get(re.sub("#", "", url),proxies = proxies,verify=False)
			except Exception,e:
				value_error=str(re.sub("'",'"',str(e)))		
				stacktrace=sys.exc_traceback.tb_lineno
				region=''
				ip=re.sub(r"\{'.*?@|'\}|:\d+","",str(proxies))
				try:
					try:
						r = requests.get('http://freegeoip.net/json/'+ip,timeout=30)
					except Exception,e:
						r = requests.get('http://freegeoip.net/json/'+ip,timeout=30)
					js = r.json()
					region=js['country_name']
				except Exception,e:
					region=''
				keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(Websitecode,datetime.datetime.now(),id_update)
				key = bucket.new_key(keyvalue)
				key.set_contents_from_string(str(e))
				statuscode=5
				if re.search(r'adult=(\d+)&',url,re.DOTALL):
					Guests=re.search(r'adult=(\d+)&',url,re.DOTALL).group(1)
				else:
					Guests=''
				array.append(aws_insert.insert(id_update, inputid ,functionname,Websitecode, "","", "", "", Guests, "", "", "", "", "",url_concat,url_concat,url_concat, "", "", "", "", "", "",StartDate, EndDate , "", "", "", "", "", "",  "", "", "",region,statuscode, israteperstay))
				return json.dumps(array)
		time.sleep(2)
		html         = unidecode(hml.text).encode('ascii')
		Rtdate=re.sub(r'-|\-','',str(RateDate))	
		keyvalue = "ondemand/{}/{:%Y%m%d}/source/{}.html".format(Websitecode,datetime.datetime.now(),str(inputid)+'_'+str(Rtdate)+'_'+id_update)
		key = bucket.new_key(keyvalue)
		key.set_contents_from_string(html)
		if re.search(r'adult=(\d+)&',url,re.DOTALL):
			Guests=re.search(r'adult=(\d+)&',url,re.DOTALL).group(1)
		else:
			Guests=''
		Taxtype=''
		Tax_status=''
		Spaceblock=''
		Roomtype=''
		OnsiteRate=''
		net_rate=0
		Curr=''
		RoomDescp=''
		RoomAmenity_Type=''
		Meal=''
		MaxOccupancy=''
		isPromotionalRate=''
		Closed_up='N'
		isAvailable=''
		Taxamount=0
		Ratetype=''
		Promotion_Name=''
		Tax_status = -1
		statuscode=''
		###print html
		#fo = open('data.html', 'w')
		#fo.write(html.encode('utf-8'))
		block1  = re.compile(r'class="show_room title-room".*?<div class="hotel-',re.DOTALL)
		##print "block"
		if block1.findall(html):
			for blck1 in block1.findall(html):
				##print "here"
				if re.search(r'class="show_room title-room.*?href="#" room_id=".*?">\s*(.*?)\s*</',blck1):
					Roomtype = re.sub(r"'","''",re.search(r'class="show_room title-room.*?href="#" room_id=".*?">\s*(.*?)\s*</',blck1).group(1))
					
				if re.search(r'<h4>Kebijakan Refund</h4>\s*(.*?)\s*</',blck1,re.DOTALL):
					Ratetype = re.sub(r"'","''",re.sub(r'\s\s+','; ',re.sub(r'(?s)<.*?>|^\s+','',re.search(r'<h4>Kebijakan Refund</h4>\s*(.*?)\s*</',blck1,re.DOTALL).group(1))))

				if re.search(r'class="show_room title-room.*?href="#" room_id="(.*?)">',blck1):
					ROOM_IDs = re.search(r'class="show_room title-room.*?href="#" room_id="(.*?)">',blck1).group(1)
				else:
					ROOM_IDs = ''
					
				if re.search(r'<span class="currency.*?>\s*[A-z].*?\s*(\d.*?)\s*<',blck1):
					OnsiteRate = re.sub(r",|'",'',re.search(r'<span class="currency.*?>\s*[A-z].*?\s*(\d.*?)\s*<',blck1).group(1))
					
				if re.search(r'<p class="base-price hasPromotion">(\d.*?) [A-z].*?<',blck1):
					net_rate = re.sub(r"'|,","",re.search(r'<p class="base-price hasPromotion">(\d.*?) [A-z].*?<',blck1).group(1))
					if net_rate:
						isPromotionalRate="Y"
					else:
						isPromotionalRate="N"
				else:
					net_rate = 0
					isPromotionalRate="N"
				if re.search(r'<strong><span>([A-z].*?)\s*\d.*?<',blck1):
					Curr = re.sub(r"'","''",re.search(r'<strong><span>([A-z].*?)\s*\d.*?<',blck1).group(1))

				if re.search(r'<h5>Surcharge .*?<strong><span>[A-z].*? (\d.*?)<',blck1):
					Taxamount = re.sub(r"'","''",re.search(r'<h5>Surcharge .*?<strong><span>[A-z].*? (\d.*?)<',blck1).group(1))            

				if re.search(r'class="info-detail">\s*<p>(.*?)\s*</p>', blck1):
					Amenity2 = re.sub(r"'","''",re.search(r'class="info-detail">\s*<p>(.*?)\s*</p>', blck1).group(1))
				else:
					Amenity2 = ""
				Amenity2 = trans(Amenity2)
				if re.search(r"class='promoWhat'>\s*(.*?)\s*<",blck1):
					Promotion_Name = re.sub(r"'","",re.search(r"class='promoWhat'>\s*(.*?)\s*<",blck1).group(1))
					if Promotion_Name:
						isPromotionalRate="Y"
					else:
						isPromotionalRate="N"
				else:
					Promotion_Name = ''
				if re.search(r'class="room-type-available">\s*.*?(\d+).*?\s*<',blck1):
					isAvailable = re.search(r'class="room-type-available">\s*.*?(\d+).*?\s*<',blck1).group(1)
				
				head    = {'Host':'www.tiket.com', 'User-Agent':'Mozilla/5.0 (X11; Linux i686; rv:40.0) Gecko/20100101 Firefox/40.0', 'Accept':'*/*', 'Accept-Language':'en-US,en;q=0.5', 'Accept-Encoding':'gzip, deflate', 'X-NewRelic-ID':'UQIGUlJXGwACUFZaAAM=', 'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8', 'X-Requested-With':'XMLHttpRequest', 'Pragma':'no-cache', 'Cache-Control':'no-cache', 'Referer':url}
				payload = {"newlayout":"1"}
				
				if re.search(r'var.*?url.*?=.*?"/(.*?)/room', html):
					Hotel = re.search(r'var.*?url.*?=.*?"/(.*?)/room', html).group(1)
				else:
					Hotel = ''
				###print Hotel
				Descurl = 'https://www.tiket.com/'+str(Hotel)+'/room/'+str(ROOM_IDs)+'/total_price/'+str(Curr)+' '+str(OnsiteRate)
				Desc_htm= requests.post(Descurl,data=payload,headers=head,proxies=proxies,verify=False).text.encode('ascii','ignore')
				if re.search(r'<p>(.*?)</p>',Desc_htm):
					RoomDescp = re.sub(r'<.*?>','',re.sub(r"'",'',re.search(r'<p>(.*?)</p>',Desc_htm).group(1)))
					
				if re.search(r'<ul>\s*(.*?)\s*</ul',Desc_htm,re.DOTALL):
					RoomAmenity_Type = re.search(r'<ul>\s*(.*?)\s*</ul',Desc_htm,re.DOTALL).group(1)
					RoomAmenity_Type = re.sub('\n',',',re.sub('<.*?>','',RoomAmenity_Type))
				if re.search(r'class="occupancybungkus">\s*(.*?)\s*</sp',blck1):
					MaxOccupanc = re.findall(r'(<i class="icon-user">)', blck1)
					MaxOccupancy=len(MaxOccupanc)
				else:
					MaxOccupancy = None
				##print MaxOccupancy
				Roomtype  = unidecode(trans(Roomtype)).encode('ascii')
				Ratetype  = unidecode(trans(Ratetype)).encode('ascii')
				Promotion_Name  = unidecode(trans(Promotion_Name)).encode('ascii')
				RoomDescp = unidecode(trans(RoomDescp)).encode('ascii')
				RoomAmenity_Type = unidecode(trans(RoomAmenity_Type)).encode('ascii')
				RoomAmenity_Type = RoomAmenity_Type.encode('utf-8')
				Amenity2         = Amenity2.encode('utf-8')
				RoomAmenity_Type = str(RoomAmenity_Type)+' '+str(Amenity2)
				Meal          = str(RoomDescp)+' '+str(RoomAmenity_Type)+' '+str(Roomtype)+' '+str(Ratetype)
				#OnsiteRate = re.sub(r',','',str(OnsiteRate))
				#OnsiteRate=OnsiteRate
				if Curr=='IDR':
					OnsiteRate = re.sub(r"^(\d+)\.", r"\1",str(OnsiteRate))
					net_rate    = re.sub(r"^(\d+)\.", r"\1",str(net_rate))
					Taxamount  = re.sub(r"^(\d+)\.", r"\1",str(Taxamount))
				else:        
					OnsiteRate = re.sub(r",(\d{3})", r"\1",str(OnsiteRate))
					net_rate    = re.sub(r",(\d{3})", r"\1",str(net_rate))
					Taxamount  = re.sub(r",(\d{3})", r"\1",str(Taxamount))
				Taxamount = re.sub(r',','',str(Taxamount))
				Roomtype  = re.sub(r'&.*?;','',str(Roomtype))
				if Taxamount!=0:
					Tax_status = 1
					Taxtype  = 'Included'
				else:
					Tax_status = 2
					Taxtype  = 'Not Included'  
				#RoomAmenity_Type=RoomAmenity_Type.decode('utf-8')  
				RoomAmenity_Type  = unicode(RoomAmenity_Type,errors='ignore') 
				RoomAmenity_Type  = re.sub("\\r|\\n", "", str(RoomAmenity_Type))
				if Curr=='IDR':
					OnsiteRate = re.sub(r",\d+|\.", r"",str(OnsiteRate))
					net_rate    = re.sub(r",\d+|\.", r"",str(net_rate))
					Taxamount  = re.sub(r",\d+|\.", r"",str(Taxamount))
				else:        
					OnsiteRate = re.sub(r",(\d{3})", r"\1",str(OnsiteRate))
					net_rate    = re.sub(r",(\d{3})", r"\1",str(net_rate))
					Taxamount  = re.sub(r",(\d{3})", r"\1",str(Taxamount))                
				nights_re = re.search(r"night=(\d+)&", url)
				if nights_re:
					nights = nights_re.group(1)
				else:
					nights = 1
				Taxamount = round(float(Taxamount)/float(nights),2) 			
				if OnsiteRate == 0 or str(OnsiteRate)=='0':
					statuscode=1
				if LOS>1:
					israteperstay = 'N'
				else:
					israteperstay = 'Y'
				if (net_rate == 0 or net_rate == '') and (Promotion_Name == 0 or Promotion_Name == ''):
					isPromotionalRate = 'N'
				##print OnsiteRate, net_rate
# 				print (id_update, inputid , functionname, Websitecode, StartDate, Roomtype, LOS, RateDate, Guests, OnsiteRate, net_rate, OnsiteRate, Curr, RoomDescp, url_concat,url_concat,url_concat, RoomAmenity_Type, Meal, MaxOccupancy, isPromotionalRate, Closed_up,30, StartDate , EndDate, intime, isAvailable, Taxtype, Taxamount, Tax_status, Spaceblock, Ratetype, net_rate,Promotion_Name,region,statuscode, israteperstay)
				###print "______________________________________________________________"
				array.append(aws_insert.insert(id_update, inputid , functionname, Websitecode, StartDate, Roomtype, LOS, RateDate, Guests, OnsiteRate, net_rate, OnsiteRate, Curr, RoomDescp, url_concat,url_concat,url_concat, RoomAmenity_Type, Meal, MaxOccupancy, isPromotionalRate, Closed_up,30, StartDate , EndDate, intime, isAvailable, Taxtype, Taxamount, Tax_status, Spaceblock, Ratetype, net_rate,Promotion_Name,region,statuscode, israteperstay))
		else:
			##print "Else"
			Closed_up = 'Y'
			statuscode = '2'
			array.append(aws_insert.insert(id_update, inputid , functionname, Websitecode, StartDate, Roomtype, LOS, RateDate, Guests, OnsiteRate, net_rate, OnsiteRate, Curr, RoomDescp, url_concat,url_concat,url_concat, RoomAmenity_Type, Meal, MaxOccupancy, isPromotionalRate, Closed_up,30, StartDate , EndDate, intime, isAvailable, Taxtype, Taxamount, Tax_status, Spaceblock, Ratetype, net_rate,Promotion_Name,region,statuscode, israteperstay))
# 			print (id_update, inputid , functionname, Websitecode, StartDate, Roomtype, LOS, RateDate, Guests, OnsiteRate, net_rate, OnsiteRate, Curr, RoomDescp, url_concat,url_concat,url_concat, RoomAmenity_Type, Meal, MaxOccupancy, isPromotionalRate, Closed_up,30, StartDate , EndDate, intime, isAvailable, Taxtype, Taxamount, Tax_status, Spaceblock, Ratetype, net_rate,Promotion_Name,region,statuscode)
			###print "______________________________________________________________"
		Rtdate=re.sub(r'-|\-','',str(RateDate))	
		keyvalue = "ondemand/{}/{:%Y%m%d}/delivery/{}.json".format(Websitecode,datetime.datetime.now(),str(inputid)+'_'+str(Rtdate)+'_'+id_update)
		key = bucket.new_key(keyvalue)
		key.set_contents_from_string(json.dumps(array))
		gc.collect()
		##print " returning.... "
		return json.dumps(array)
	except Exception as e:
		value_error=str(re.sub(r"'",'"',str(e)))
		stacktrace=sys.exc_traceback.tb_lineno
		if re.search(r'adult=(\d+)&',url,re.DOTALL):
			Guests=re.search(r'adult=(\d+)&',url,re.DOTALL).group(1)
		else:
			Guests=''
		insert_value_error=str(value_error)+'Where line number '+str(stacktrace)+str(proxyip)
		statuscode='4'
		Websitecode='311'
		print insert_value_error
		keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(Websitecode,datetime.datetime.now(),id_update)
		key = bucket.new_key(keyvalue)
		key.set_contents_from_string(insert_value_error)
		array.append(aws_insert.insert(id_update, inputid ,functionname,Websitecode, insert_value_error,"", "", "", Guests, "", "", "", "", "",url_concat,url_concat,url_concat, "", "", "", "", "", "",StartDate, EndDate , "", "", "", "","", "",  "", "", "",region,statuscode, israteperstay))
		return json.dumps(array)

# url       = 'https://www.tiket.com/hotel/india/rishikesh/rishikesh/dewa-retreat-a-himalayan-boutique-hotel-1?startdate=2018-08-25&night=1&room=1&adult=1&child=0&enddate=2018-08-26&curr=USD&'
# inputid	  = ''
# id_update = ''
# proxyip   = 'user-34068:214859b73da0e174@45.64.106.45:1212'
# 
# 
# fetchrates(url ,inputid, id_update, proxyip)
