# -*- coding: utf-8 -*-
import re
import requests
import datetime
import json
import boto
import sys
import meta_insert
from unidecode import unidecode


# url = 'https://www.google.com/async/hotelRoomPrices?async=async_id:luhrp-rTC5WKK3FYqd8QXaqpW4BQ,chd:2018-09-18,hid:3986590320063672972,itinerary_type:0,los:{los},lqt:3,lqtkn:,rlst:,rqt:1,_id:luhrp-rTC5WKK3FYqd8QXaqpW4BQ,_pms:s,_fmt:pc&ved=1t:17330#checkout=2018-09-19'
# inputid = 123
# id_update = 23
# proxyip = 'user-34068:214859b73da0e174@103.250.184.252:1212'



def fetchrates(url ,inputid, id_update, proxyip):    
    try:
        array = []
        csv=[]
        Provider = ''
        Rank = 0
        functionname='Google'
        conn = boto.connect_s3(aws_access_key_id= 'AKIAIXEGZVXCWE2FV3SQ',aws_secret_access_key = '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') 
        bucket = conn.get_bucket("rmapi")
        StartDate = datetime.date.today()
        Hotelcode = inputid
        websitecode=283
        Reportdate=datetime.datetime.strptime(str(StartDate),'%Y-%m-%d').strftime('%Y-%m-%d')    
        cin=re.search(r'chd:(.*?),h',url).group(1)
        cout=re.search(r'checkout=(.*?$)',url).group(1)
        delta = datetime.datetime.strptime(re.search(r"checkout=(.*?$)", url).group(1), "%Y-%m-%d") - datetime.datetime.strptime(re.search(r"chd:(.*?),h", url).group(1), "%Y-%m-%d")
        LOS = delta.days
        Ratedate=cin
        los=LOS       
        url_db = re.sub(r"chd:(.*?),", r"chd:"+str(cin)+",", url)
        url = re.sub(r"los:(.*?),", r"los:"+str(los)+",", url_db)
        head = {'User-Agent':'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:12.0) Gecko/20100101 Firefox/48.0'}
        proxies = {"http": "http://{}".format(proxyip)}
        Los = los
        url = re.sub(r"\#.*",r"",url)
        Provider_url = "https://www.google.com/async/updateHotelBookingModule?vet=10ahUKEwjs1s_nh6LVAhUDp5QKHc-mBEQQmmQIsQEoADAS..i&ei=-_p1WaztLYPO0gTPzZKgBA&noj=1&yv=2&start&tbs=lrf:,lf:1&async=chd:"+str(cin)+",los:"+str(los)+",itinerary_type:1,idc:true,async_id:mhbbn--_p1WaztLYPO0gTPzZKgBA1,dlms:750,hid:"+str(re.search(r"hid:(.*?),", url).group(1))+",lqt:1,lsi:-8664662052454373721,mdtp:1,rlst:,rqt:2,srnr:178,srv:4.5,_id:mhbbn--_p1WaztLYPO0gTPzZKgBA1,_pms:s,_fmt:pc"
        try:
            hml = requests.get(url, headers=head, proxies = proxies,verify = False,timeout=50)
            providerhtml = requests.get(Provider_url, headers=head, proxies = proxies,verify = False,timeout=50)
        except Exception,e:
            #print e
            try:
                hml = requests.get(url, headers=head, proxies = proxies,verify = False)
                providerhtml = requests.get(Provider_url, headers=head, proxies = proxies,verify = False,timeout=50)
            except Exception,e:
                #print e
                value_error=str(re.sub("'",'"',str(e)))
                stacktrace=sys.exc_traceback.tb_lineno
                insert_value_error=str(value_error)+'Where line number '+str(stacktrace)+str(proxyip)
                keyvalue = "metasearch/{}/{:%Y%m%d}/Error/{}.txt".format(websitecode,datetime.datetime.now(),str(inputid)+'_'+str(id_update))
                key = bucket.new_key(keyvalue)
                key.set_contents_from_string(str(insert_value_error))
                statuscode=5
                array.append(meta_insert.insert(Provider,Rank,"","",None,None,None,"",Ratedate,Los,Reportdate,Hotelcode,websitecode,url,"",Ratedate,statuscode))
                return json.dumps(array)
        if (hml.status_code <> 200):
            hml = requests.get(url, headers=head, proxies = proxies,verify = False,timeout=50)
            providerhtml = requests.get(Provider_url, headers=head, proxies = proxies,verify = False,timeout=50)
        if (hml.status_code == 403 or hml.status_code == 407 or hml.status_code <> 200):
            try:
                hml = requests.get(url, headers=head, proxies = proxies,verify = False)
                if (hml.status_code <> 200):
                    hml = requests.get(url, headers=head,  proxies = proxies, verify = False)
                    providerhtml = requests.get(Provider_url, headers=head, proxies = proxies,verify = False)
            except Exception,e:
                value_error=str(re.sub("'",'"',str(e)))        
                stacktrace=sys.exc_traceback.tb_lineno
                insert_value_error=str(value_error)+'Where line number '+str(stacktrace)+str(proxyip)
                keyvalue = "metasearch/{}/{:%Y%m%d}/Error/{}.txt".format(websitecode,datetime.datetime.now(),str(inputid)+'_'+str(id_update))
                key = bucket.new_key(keyvalue)
                key.set_contents_from_string(str(insert_value_error))
                statuscode=5
                array.append(meta_insert.insert(Provider,Rank,"","",None,None,None,"",Ratedate,Los,Reportdate,Hotelcode,websitecode,url,"",Ratedate,statuscode))
                return json.dumps(array)
#         html = re.sub("\\u003.|u002.", "", hml.text.replace("\\", ""))
#         html2 = html.encode('ascii','ignore')
#         providerhtml = re.sub("\\u003.|u002.", "",providerhtml.text.replace("\\", "")).encode('ascii','ignore')
        html2 = re.sub("\\/", "/", unidecode(hml.text).decode("unicode-escape"))
        providerhtml = re.sub("\\/", "/", unidecode(providerhtml.text).decode("unicode-escape"))
        #html = json.loads(hml.text.encode('utf-8'))
        keyvalue = "metasearch/{}/{:%Y%m%d}/source/{}.html".format(websitecode,datetime.datetime.now(),str(inputid)+'_'+str(id_update))
        key = bucket.new_key(keyvalue)
        key.set_contents_from_string(hml.text+'---------'+providerhtml)    
        Provider =None
        Rank = ''
        RoomName = ''
        RoomFacilities = ''
        OnsiteRate = 0
        NetRate = 0
        Pricepernight = 0
        providername = ''
        Curr = 'USD'
        Los ='1'
        statuscode=''
        provider_dict = {}
        provider_list = []
        prank = 1
        mainblockrange = 0
        #print "Loaded"
#             open(str(hotelcode)+str(Ratedate)+'Overall.html', 'w').write(unidecode(html2).encode('ascii'))
#             open(str(hotelcode)+str(Ratedate)+'Provider.html', 'w').write(unidecode(providerhtml).encode('ascii'))
        provider_dict = {}
        provider_list = []
        pid_list = []
        pid_list2 = []
        if re.compile(r'<div class="B4MzEf">.*?</div></div>').findall(providerhtml):
            for prank, providerdata in enumerate(re.compile(r'<div class="B4MzEf">.*?</div></div>').findall(providerhtml), start=1):
                providername_reg = re.search(r'<span class="XmKKw">(.*?)<', providerdata)
                if providername_reg:
                    providername = providername_reg.group(1)
                pid_reg = re.search(r'data-pid="(.*?)"', providerdata)
                if pid_reg:
                    pid = pid_reg.group(1)
                display_price_reg = re.search(r'data-dp=".*?(\d.*?)"', providerdata)
                if display_price_reg:
                    display_price = display_price_reg.group(1)
                provider_dict = {"Providername": providername, "Rank":prank, "Pid": pid, 'display_price' : display_price}
                provider_list.append(provider_dict)
                pid_list.append(pid)
            #print provider_list
            check_pid = re.compile(r'pid="(.*?)"').findall(html2)
            if not check_pid:
                for rooms in provider_list:
                    RoomFacilities = ''
                    HotelBlock = re.sub(r"'", "''", str(rooms))
                    RoomName = 'Lowest Available Rate'
                    if rooms.has_key('display_price'):
                        OnsiteRate = re.sub(r',|\z|\$|$', '', rooms['display_price'])
                    if OnsiteRate:
                        Curr = ''
                    Provider = rooms['Providername']
                    Rank = rooms['Rank']
                    statuscode = ''
                    if int(OnsiteRate)  == 0:
                        statuscode = 1
                    Los_reg = re.search("los:(\d+)", url)
                    if Los_reg:
                        Los = Los_reg.group(1)
                    Los=int(Los)
                    RoomFacilities=re.sub(r',',' - ',RoomFacilities)
                    RoomName=re.sub(r',',' - ',RoomName)
                    OnsiteRate=int(OnsiteRate)
                    valu=Provider,Rank,RoomName,RoomFacilities,OnsiteRate,NetRate,Pricepernight,Curr,Ratedate,Los,Reportdate,Hotelcode,websitecode,url,HotelBlock,Ratedate,statuscode
                    vals=str(valu)
                    csv.append(vals)
                    array.append(meta_insert.insert(Provider,Rank,RoomName,RoomFacilities,OnsiteRate,NetRate,Pricepernight,Curr,Ratedate,Los,Reportdate,Hotelcode,websitecode,url,HotelBlock,Ratedate,statuscode))
                return json.dumps(array)
            #print len(pid_list), len(check_pid)
            if list(set(check_pid).difference(set(pid_list))):
                print "Re-run due list miss matched"
                keyvalue = "metasearch/{}/{:%Y%m%d}/Error/{}.txt".format(websitecode,datetime.datetime.now(),str(inputid)+'_'+str(id_update))
                key = bucket.new_key(keyvalue)
                key.set_contents_from_string("Re-run due list miss matched")
                statuscode=5
                array.append(meta_insert.insert(Provider,Rank,"","",None,None,None,"",Ratedate,Los,Reportdate,Hotelcode,websitecode,url,"",Ratedate,statuscode))
                return json.dumps(array)
            if '["dom",""]]' not in html2:
                for mainblock in re.compile(r"<div data-pid.*?</g-expandable-container>").findall(html2):
                    Provider = ''
                    Rank = 0
                    RoomFacilities = ''
                    sec_pid_reg = re.search(r'data-pid="(.*?)"', mainblock)
                    if sec_pid_reg:
                        sec_pid = sec_pid_reg.group(1)
                        pid_list2.append(sec_pid)
                    for data in provider_list:
                        #print data['Pid'],sec_pid
                        if data['Pid'] == sec_pid:
                            Provider = data['Providername']
                            Rank = data['Rank']
                            break
                    for block in re.compile(r'<div class="RreVXb">.*?</g-expandable-content>').findall(mainblock):
                        RoomName = 'Lowest Available Rate'
                        HotelBlock = re.sub(r"'", "''", block)
                        RoomFacilities = ''
                        Los = 0
                        NetRate = 0
                        websitecode = 283
                        if re.search(r'<div class="SJ3DTe">(.*?)<', block):
                            RoomName = re.search(r'<div class="SJ3DTe">(.*?)<', block).group(1)
                            if len(RoomName) <= 0 or not RoomName :
                                RoomName = 'Lowest Available Rate'
                        if re.search(r'<div class="TfzBfc">.*?(\d.*?)<', block):
                            OnsiteRate = re.sub(r',|\z|\$|$', '', re.search(r'<div class="TfzBfc">.*?(\d.*?)<', block).group(1))
                        if OnsiteRate:
                            Curr = Curr
                        if re.search(r'<div class="Qk4syb">(.*?)<', block):
                            RoomFacilities = re.sub("&nbsp;|&middot;", ", ", re.search(r'<div class="Qk4syb">(.*?)<', block).group(1))
                        if  re.search(r"<span>Total:.*?(\d.*?)\\/", block):
                            NetRate = re.sub(r',|\z|\$|$', '', re.search(r"<span>Total:.*?(\d.*?)\\/", block).group(1))
                        statuscode = ''
                        if int(OnsiteRate) == 0:
                            statuscode = 1
                        Los_reg = re.search("los:(\d+)", url)
                        if Los_reg:
                            Los = Los_reg.group(1)
                        Los=int(Los)
                        RoomFacilities=re.sub(r',',' - ',RoomFacilities)
                        RoomName=re.sub(r',',' - ',RoomName)
                        OnsiteRate=int(OnsiteRate)
                        valu=Provider,Rank,RoomName,RoomFacilities,OnsiteRate,NetRate,Pricepernight,Curr,Ratedate,Los,Reportdate,Hotelcode,websitecode,url,HotelBlock,Ratedate,statuscode
                        vals=str(valu)
                        csv.append(vals)
                        array.append(meta_insert.insert(Provider,Rank,RoomName,RoomFacilities,OnsiteRate,NetRate,Pricepernight,Curr,Ratedate,Los,Reportdate,Hotelcode,websitecode,url,HotelBlock,Ratedate,statuscode))
                pending_list = list(set(pid_list).difference(set(pid_list2)))
                if pending_list:
                    for pending in pending_list:
                        HotelBlock = re.sub(r"'", "''", str(pending))
                        RoomFacilities = ''
                        RoomName = 'Lowest Available Rate'
                        NetRate = 0
                        for data in provider_list:
                            if data['Pid'] == pending:
                                Provider = data['Providername']
                                Rank = data['Rank']
                                OnsiteRate = re.sub(r',|\z|\$|$', '', data['display_price'])
                                break
                        statuscode = ''
                        if int(OnsiteRate) == 0:
                            statuscode = 1
                        Los_reg = re.search("los:(\d+)", url)
                        if Los_reg:
                            Los = Los_reg.group(1)
                        Los=int(Los)
                        RoomFacilities=re.sub(r',',' - ',RoomFacilities)
                        RoomName=re.sub(r',',' - ',RoomName)
                        OnsiteRate=int(OnsiteRate)
                        valu=Provider,Rank,RoomName,RoomFacilities,OnsiteRate,NetRate,Pricepernight,Curr,Ratedate,Los,Reportdate,Hotelcode,websitecode,url,HotelBlock,Ratedate,statuscode
                        vals=str(valu)
                        csv.append(vals)
                        array.append(meta_insert.insert(Provider,Rank,RoomName,RoomFacilities,OnsiteRate,NetRate,Pricepernight,Curr,Ratedate,Los,Reportdate,Hotelcode,websitecode,url,HotelBlock,Ratedate,statuscode))
            elif provider_list:
                # print "Came"
                for rooms in provider_list:
                    HotelBlock = re.sub(r"'", "''", str(rooms))
                    RoomFacilities = ''
                    RoomName = 'Lowest Available Rate'
                    if rooms.has_key('display_price'):
                        OnsiteRate = re.sub(r',|\z|\$|$', '', rooms['display_price'])
                    if OnsiteRate:
                        Curr = Curr
                    Provider = rooms['Providername']
                    Rank = rooms['Rank']
                    Los_reg = re.search("los:(\d+)", url)
                    if Los_reg:
                        Los = Los_reg.group(1)
                    Los = int(Los)
                    statuscode = ''
                    RoomFacilities = re.sub(r',', ' - ', RoomFacilities)
                    RoomName = re.sub(r',', ' - ', RoomName)
                    if int(OnsiteRate)  == 0:
                        statuscode = 1
                    Los_reg = re.search("los:(\d+)", url)
                    if Los_reg:
                        Los = Los_reg.group(1)
                    Los=int(Los)
                    RoomFacilities=re.sub(r',',' - ',RoomFacilities)
                    RoomName=re.sub(r',',' - ',RoomName)
                    OnsiteRate=int(OnsiteRate)
                    valu=Provider,Rank,RoomName,RoomFacilities,OnsiteRate,NetRate,Pricepernight,Curr,Ratedate,Los,Reportdate,Hotelcode,websitecode,url,HotelBlock,Ratedate,statuscode
                    vals=str(valu)
                    csv.append(vals)
                    array.append(meta_insert.insert(Provider,Rank,RoomName,RoomFacilities,OnsiteRate,NetRate,Pricepernight,Curr,Ratedate,Los,Reportdate,Hotelcode,websitecode,url,HotelBlock,Ratedate,statuscode))
            else:
                statuscode=2
                HotelBlock = 'Check website for rates and availability'
                valu=Provider,Rank,RoomName,RoomFacilities,OnsiteRate,NetRate,Pricepernight,Curr,Ratedate,Los,Reportdate,Hotelcode,websitecode,url,HotelBlock,Ratedate,statuscode
                vals=str(valu)
                csv.append(vals)
                array.append(meta_insert.insert(Provider,Rank,RoomName,RoomFacilities,OnsiteRate,NetRate,Pricepernight,Curr,Ratedate,Los,Reportdate,Hotelcode,websitecode,url,HotelBlock,Ratedate,statuscode))
                
        else:
            statuscode=2
            HotelBlock = 'Check website for rates and availability'
            valu=Provider,Rank,RoomName,RoomFacilities,OnsiteRate,NetRate,Pricepernight,Curr,Ratedate,Los,Reportdate,Hotelcode,websitecode,url,HotelBlock,Ratedate,statuscode
            vals=str(valu)
            csv.append(vals)
            array.append(meta_insert.insert(Provider,Rank,RoomName,RoomFacilities,OnsiteRate,NetRate,Pricepernight,Curr,Ratedate,Los,Reportdate,Hotelcode,websitecode,url,HotelBlock,Ratedate,statuscode))
        newline="\n".join(csv)
        arrayclean1=re.sub(r'\[|\(|\)|\]','',str(newline))
        arrayclean2=re.sub(r"'",'"',arrayclean1)
        arrayclean=re.sub(r'u"','"',arrayclean2)
        Ratedates=re.sub(r'-','',str(Ratedate))
        date_time=datetime.datetime.now().strftime('%Y%m%d_%I%M')
        keyvalue = "metasearch/metaresults/{}.txt".format(str(date_time)+'_'+str(websitecode)+'_'+str(Hotelcode)+'_'+str(Ratedates))
        key = bucket.new_key(keyvalue)
        key.set_contents_from_string(arrayclean)
        return json.dumps(array)
    except Exception as e:
        value_error=str(re.sub(r"'",'"',str(e)))
        stacktrace=sys.exc_traceback.tb_lineno
        insert_value_error=str(value_error)+'Where line number '+str(stacktrace)+str(proxyip)
        print insert_value_error
        statuscode=4
        keyvalue = "metasearch/{}/{:%Y%m%d}/Error/{}.txt".format(websitecode,datetime.datetime.now(),str(inputid)+'_'+str(id_update))
        key = bucket.new_key(keyvalue)
        key.set_contents_from_string(insert_value_error)
        array.append(meta_insert.insert(functionname,Rank,"","",OnsiteRate,NetRate,Pricepernight,"",Ratedate,Los,Reportdate,Hotelcode,websitecode,url,"",Ratedate,statuscode))
        return HttpResponse(json.dumps(array),content_type="application/json")
# fetchrates(url ,inputid, id_update, proxyip)
