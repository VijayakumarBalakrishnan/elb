# -*- coding: utf-8 -*-
import re
import requests
import datetime
import json
import gc
import boto
import sys
from unidecode import unidecode

import aws_insert
def fetchrates(url ,inputid, id_update, proxyip):
    array      = []
    israteperstay=''
    proxies    = {"http": "http://{}".format(proxyip)}
    intime     = re.sub(r'\s','T',str(datetime.datetime.now()))
    Domainname ='rixos.com'
    Websitecode='336'
    region     =''
    statuscode =''
    Mealtype   = ''
    conn   = boto.connect_s3(aws_access_key_id= 'AKIAIXEGZVXCWE2FV3SQ',aws_secret_access_key = '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') 
    bucket = conn.get_bucket("rmapi")
    StartDate= datetime.date.today()
    EndDate  = datetime.date.today() + datetime.timedelta(days=29)
    try:
        CheckIn_Check_OT_re = re.search(r'&dateIn=(.*?)&dateOut=(.*?)&',url)
        if CheckIn_Check_OT_re:
            Checkin = CheckIn_Check_OT_re.group(1)
            CheckOT = CheckIn_Check_OT_re.group(2)
        else:
            Checkin = ''
            CheckOT = ''
        RateDate = Checkin
        delta    = datetime.datetime.strptime(str(CheckOT), "%Y-%m-%d") - datetime.datetime.strptime(Checkin, "%Y-%m-%d")
        LOS      = delta.days
        RoomType = ''
        Guests   = re.search(r'adults=(\d+)',url).group(1)
        Ratetype = ''
        RateDescription = ''
        Meal     = ''
        Taxtype  = ''
        Curr     = ''
        MaxOccupancy = None
        isPromotionalRate  = 'N'
        Closed   = 'Y'
        NetRate  = 0
        Taxstatus= -1
        TaxAmount= 0
        Discount = 0
        GrossRate= 0
        OnsiteRate = 0
        Promotion_Name= ''
        isAvailable = ''
        RoomAmenity_Type = ''
        url_insert = 'https://reservations.travelclick.com/72850?hotelId=72850'
        proxyip = re.sub(r':.*','',str(proxyip))
        headers = {'Host':'api.travelclick.com', 'User-Agent':'Mozilla/5.0 (X11; Linux i686; rv:45.0) Gecko/20100101 Firefox/45.0', 'Accept':'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8', 'Accept-Language':'en-US,en;q=0.5', 'Accept-Encoding':'gzip, deflate, br', }
        try:
            try:
                r = requests.get('http://freegeoip.net/json/' + proxyip, timeout=30)
            except Exception, e:
                r = requests.get('http://freegeoip.net/json/' + proxyip, timeout=30)
            js = r.json()
            region = js['country_name']
        except Exception, e:
            region = ''
        try:
            hml = requests.get(url,headers=headers,proxies=proxies,timeout=50)
        except Exception, e:
            value_error = str(re.sub("'", '', str(e)))
            stacktrace = sys.exc_traceback.tb_lineno
            try:
                hml = requests.get(url,headers=headers,proxies=proxies,timeout=50)
            except Exception, e:
                value_error = str(re.sub("'", '', str(e)))
                stacktrace = sys.exc_traceback.tb_lineno
                keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(Websitecode, datetime.datetime.now(), id_update)
                key = bucket.new_key(keyvalue)
                key.set_contents_from_string(str(e) + 'Where Line number' + str(stacktrace) + str(proxies))
                statuscode = 5
                Guests = ''
                array.append(aws_insert.insert(id_update, inputid , Domainname, Websitecode, "", "", "", "", Guests, "", "", "", "", "", url, url, url, "", "", "", "", "", "", StartDate, EndDate , "", "", "", "", "", "", "", "", "", region, statuscode,israteperstay))
                return json.dumps(array)
        if hml.status_code <> 200:
            hml = requests.get(url,headers=headers,proxies=proxies,timeout=50)
        if (hml.status_code == 403 or hml.status_code == 407) or hml.status_code <> 200:
            try:
                if hml.status_code <> 200:
                    hml = requests.get(url,headers=headers,timeout=50)
            except Exception, e:
                print e
                value_error = str(re.sub("'", '', str(e)))
                stacktrace = sys.exc_traceback.tb_lineno
                keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(Websitecode, datetime.datetime.now(), id_update)
                key = bucket.new_key(keyvalue)
                key.set_contents_from_string(str(e) + 'Where Line number' + str(stacktrace) + str(proxies))
                statuscode = 5
                Guests = ''
                array.append(aws_insert.insert(id_update, inputid , Domainname, Websitecode, "", "", "", "", Guests, "", "", "", "", "", url, url, url, "", "", "", "", "", "", StartDate, EndDate , "", "", "", "", "", "", "", "", "", region, statuscode,israteperstay))
                return json.dumps(array) 
        Data_Htm  = re.sub('amp;','',unidecode(hml.text).encode('ascii'))
        json_data = json.loads(Data_Htm)
        Rtdate=re.sub(r'-|\-','',str(RateDate))
        keyvalue = "ondemand/{}/{:%Y%m%d}/source{}.json".format(Websitecode,datetime.datetime.now(),str(inputid)+'_'+str(Rtdate)+'_'+id_update)
        key = bucket.new_key(keyvalue)
        key.set_contents_from_string(hml.text.encode('utf-8'))
        if 'roomStays' in json_data:
            for var in json_data['roomStays']:
                if re.search(r"currencyCode': u'(.*?)'", str(json_data)):
                    Curr      = re.search(r"currencyCode': u'(.*?)'", str(json_data)).group(1)
                for blocks in var['roomTypes']:
                    if "roomTypeName" in blocks:
                        RoomType = blocks['roomTypeName']
                    else:
                        RoomType = ''
                    if 'description' in blocks:
                        RateDescription = blocks['description']
                    else:
                        RateDescription = ''
                    for rates in blocks['averageRates']:
                        Ratetype_re = re.search(r'"ratePlanCode":"'+str(rates['ratePlanCode'])+'","ratePlanType":"\w+","ratePlanName":"(.*?)"', Data_Htm)
                        if Ratetype_re:
                            Ratetype = Ratetype_re.group(1)
                        else:
                            Ratetype = ""
                        if Ratetype!='':
                            if rates['rate']:
                                OnsiteRate = rates['rate']
                            else:
                                OnsiteRate = 0
                            if 'discount' in rates:
                                discount = rates['discount']
                            else:
                                discount = 0
                            if int(discount)!=0:
                                NetRate    = OnsiteRate
                                OnsiteRate = OnsiteRate-discount
                            else:
                                NetRate    = 0
                                OnsiteRate = OnsiteRate
                            i=0
                            list_v = []
                            for amn in blocks['amenities']:
                                amts = blocks['amenities'][i]['amenityName']
                                list_v.append(amts)
                                ameints = list_v
                                i=i+1
                            j=0
                            list_v = []
                            for Fetr in blocks['roomFeatures']:
                                Fetrs  = blocks['roomFeatures'][j]['amenityName']
                                descps = blocks['roomFeatures'][j]['quantity']
                                Fetrsss = str(Fetrs)+' '+str(descps)
                                list_v.append(Fetrsss)
                                Features = list_v
                                j=j+1
                            Features         = re.sub(r"\[|\]",'',str(Features))
                            RoomAmenity_Type = re.sub(r"'",'"',re.sub(r"u|\[|\]|amp;",'',str(ameints))) 
                            RateDescription  = RateDescription.encode('ascii','ignore')
                            RateDescription  = str(RateDescription) +' '+str(Features)
                            RateDescription  = re.sub(r"'",'"',RateDescription)
                            if OnsiteRate==0:
                                statuscode = 1
                                Closed='Y'
                            else:
                                statuscode = ''
                                Closed='N'
                            if TaxAmount!=0:
                                Taxstatus = 1
            
                            Mealtypes = str(RateDescription)+' '+str(RoomType)
                            if Mealtypes !=None:
                                Mealtype_str = str(Mealtypes)
                                if 'breakfast' in Mealtype_str.lower() and 'dinner' in Mealtype_str.lower()  and 'lunch' in Mealtype_str.lower():
                                    Meal = 'Breakfast, Lunch and Dinner'
                                elif 'breakfast' in Mealtype_str.lower() and 'dinner' in Mealtype_str.lower():
                                    Meal = 'Breakfast and dinner'
                                elif 'breakfast included' in Mealtype_str.lower():
                                    Meal = 'Breakfast included'
                                elif 'BREAKFAST' in Mealtype_str:
                                    Meal = 'Breakfast'
                                elif 'breakfast' in Mealtype_str.lower() and 'lunch' in Mealtype_str.lower():
                                    Meal = 'Breakfast and Lunch'
                                elif 'Lunch' in Mealtype_str and 'Dinner' in Mealtype_str :
                                    Meal = "Lunch and Dinner"
                                elif 'breakfast' in Mealtype_str.lower() and 'lunch' in Mealtype_str.lower() and 'dinner' in Mealtype_str.lower():
                                    Meal = 'Breakfast, Lunch and dinner'
                                elif 'Break fast' in Mealtype_str:
                                    Meal = 'BreakFast' 
                                elif 'breakfast' in Mealtype_str.lower():
                                    Meal = 'BreakFast' 
                                elif 'halfboard' in Mealtype_str.lower():
                                    Meal = 'Halfboard'
                                elif 'half board' in Mealtype_str.lower():
                                    Meal = 'Half board' 
                                elif 'full board' in Mealtype_str.lower():
                                    Meal = 'Full Board'
                                elif 'fullboard' in Mealtype_str.lower():
                                    Meal = 'FullBoard'
                                elif 'All-Inclusive' in Mealtype_str:
                                    Meal = 'All-Inclusive'
                                elif 'All Inclusive' in Mealtype_str:
                                    Meal = 'All Inclusive'
                                elif 'All Meals' in Mealtype_str:
                                    Meal = 'All Meals'
                                elif 'All Meal' in Mealtype_str:
                                    Meal = 'All Meal'
                                else:
                                    Meal = ''
                            else:
                                Meal = ''  
                            MaxOccupancy_re = re.search(r'People (\d+)',RateDescription)
                            if MaxOccupancy_re:
                                MaxOccupancy = MaxOccupancy_re.group(1)
                            else:
                                MaxOccupancy = ''                    
                            #print "RoomType :-",RoomType
                            #print "Ratetype :-",Ratetype
                            #print "RateDescription :-",RateDescription
                            #print "Amount   :-",OnsiteRate
                            #print "Prmotion :-",Promotion_Name
                            #print "isPromotionalRate  :-",isPromotionalRate
                            #print "NetRate  :-",NetRate
                            #print "Currency :-",Curr
                            #print "Discount :-",Discount
                            #print "MealType :-",Meal
                            #print "Closed   :-",Closed
                            #print "Taxstatus:-",Taxstatus
                            #print "status_cd:-",statuscode
                            #print "_"*30
                            GrossRate = OnsiteRate
                            Mealtype  = Meal
                            RateDate  = Checkin
                            LOS = int(LOS)
                            if int(LOS) >1:
                                israteperstay = 'N'
                            else:
                                israteperstay ='Y'
                            ##print (id_update, inputid , Domainname, Websitecode, StartDate, RoomType, LOS, RateDate, Guests, OnsiteRate, NetRate, GrossRate, Curr, RateDescription, url_insert, url_insert, url_insert, RoomAmenity_Type, Mealtype, MaxOccupancy, isPromotionalRate, Closed, 30, StartDate , EndDate, intime, isAvailable, Taxtype, TaxAmount, Taxstatus, None, Ratetype, Discount,Promotion_Name,region,statuscode,israteperstay)
                            array.append(aws_insert.insert(id_update, inputid , Domainname, Websitecode, StartDate, RoomType, LOS, RateDate, Guests, OnsiteRate, NetRate, GrossRate, Curr, RateDescription, url_insert, url_insert, url_insert, RoomAmenity_Type, Mealtype, MaxOccupancy, isPromotionalRate, Closed, 30, StartDate , EndDate, intime, isAvailable, Taxtype, TaxAmount, Taxstatus, None, Ratetype, Discount,Promotion_Name,region,statuscode,israteperstay))
        else:
            Closed     = 'Y'
            statuscode ='2'
            array.append(aws_insert.insert(id_update, inputid , Domainname, Websitecode, StartDate, RoomType, LOS, RateDate, Guests, OnsiteRate, NetRate, GrossRate, Curr, RateDescription, url_insert, url_insert, url_insert, RoomAmenity_Type, Mealtype, MaxOccupancy, isPromotionalRate, Closed, 30, StartDate , EndDate, intime, isAvailable, Taxtype, TaxAmount, Taxstatus, None, Ratetype, Discount,Promotion_Name,region,statuscode,israteperstay))
        Rtdate = re.sub(r'-|\-', '', str(RateDate))
        keyvalue = "ondemand/{}/{:%Y%m%d}/delivery/{}.json".format(Websitecode,datetime.datetime.now(),str(inputid)+'_'+str(Rtdate)+'_'+id_update)
        key = bucket.new_key(keyvalue)
        key.set_contents_from_string(json.dumps(array))
        return json.dumps(array)
        gc.collect()
    except Exception as e:
        print e
        value_error = str(re.sub(r"'", '"', str(e)))
        stacktrace = sys.exc_traceback.tb_lineno
        Guests = ''
        region = ''
        insert_value_error = str(value_error) + 'Where line number ' + str(stacktrace) + str(proxyip)
        statuscode = '4'
        keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(Websitecode, datetime.datetime.now(), id_update)
        key = bucket.new_key(keyvalue)
        key.set_contents_from_string(insert_value_error)
        array.append(aws_insert.insert(id_update, inputid , Domainname, Websitecode, "", "", "", "", Guests, "", "", "", "", "", url, url, url, "", "", "", "", "", "", StartDate, EndDate , "", "", "", "", "", "", "", "", "", region, statuscode,israteperstay))
        return json.dumps(array)
        
'''url       = 'https://api.travelclick.com/ibe/v1/hotel/72850/avail?lang=EN_US&adults=1&infants=0&currency=EUR&rooms=1&dateIn=2017-11-18&dateOut=2017-11-19&'
inputid   = 'Test'            
id_update = ''
proxyip   = ''
fetchrates(url ,inputid, id_update, proxyip)'''
