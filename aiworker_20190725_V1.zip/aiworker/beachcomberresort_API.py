# -*- coding: utf-8 -*-
import re
import requests
import datetime
import json
import sys 
import boto
import gc

import aws_insert


def fetchrates(url,inputid,id_update,proxyip):
    array      = []
    sr  = requests.session()
    proxies    = {"https": "http://{}".format(proxyip)}
    intime     = re.sub(r'\s','T',str(datetime.datetime.now()))
    Domainname = 'beachcomberresort.com'
    Websitecode= '358'
    region     = ''
    statuscode = ''
    Mealtype   = ''
    israteperstay = ''
    try:
        conn   = boto.connect_s3(aws_access_key_id= 'AKIAIXEGZVXCWE2FV3SQ',aws_secret_access_key = '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') 
        bucket = conn.get_bucket("rmapi")
        StartDate = datetime.date.today()
        EndDate   = datetime.date.today() + datetime.timedelta(days=29)
        CheckIn_Check_OT_re = re.search(r'arrive=(.*?)&depart=(.*?)&',url)
        if CheckIn_Check_OT_re:
            Checkin  = CheckIn_Check_OT_re.group(1)
            Checkout = CheckIn_Check_OT_re.group(2)
        else:
            Checkin  = ''
            Checkout = ''
        #print Checkin,Checkout
        RateDate = Checkin
        delta    = datetime.datetime.strptime(Checkout, "%Y-%m-%d") - datetime.datetime.strptime(Checkin, "%Y-%m-%d")
        LOS      = delta.days
        RoomType = ''
        Guests   = re.search(r'Adult=(\d)&', url).group(1)
        Ratetype = ''
        RateDescription = ''
        Taxtype  = ''
        Curr     = ''
        MaxOccupancy = None
        isPromotionalRate  = 'N'
        Closed   = 'Y'
        NetRate  = 0
        Taxstatus= -1
        TaxAmount= 0
        Discount = 0
        GrossRate= 0
        OnsiteRate = 0
        Curr     = ''
        Promotion_Name= ''
        isAvailable = ''
        RoomAmenity_Type = ''
        url_insert = url
        head = {'Host':'gc.synxis.com','Connection':'keep-alive','Cache-Control':'max-age=0','Upgrade-Insecure-Requests':'1','User-Agent':'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36','Accept':'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8','Accept-Encoding':'gzip, deflate, br','Accept-Language':'en-GB,en-US;q=0.8,en;q=0.6'}
        ip = re.sub(r"\{'.*?@|'\}|:\d+", "", str(proxies))
        try:
            try:
                r = requests.get('http://freegeoip.net/json/' + ip, timeout=30)
            except Exception, e:
                r = requests.get('http://freegeoip.net/json/' + ip, timeout=30)
            js = r.json()
            region = js['country_name']
        except Exception, e:
            region = ''
        try:
            htm = requests.get(url,headers = head,proxies = proxies,timeout=50)
        except Exception, e:
            value_error = str(re.sub("'", '', str(e)))
            stacktrace = sys.exc_traceback.tb_lineno
            try:
                htm = requests.get(url,headers = head,proxies = proxies , timeout=50)
            except Exception, e:
                value_error = str(re.sub("'", '', str(e)))
                stacktrace = sys.exc_traceback.tb_lineno
                keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(Websitecode, datetime.datetime.now(), id_update)
                key = bucket.new_key(keyvalue)
                key.set_contents_from_string(str(e) + 'Where Line number' + str(stacktrace) + str(proxies))
                statuscode = 5
                Guests = ''
                array.append(aws_insert.insert(id_update, inputid , Domainname, Websitecode, "", "", "", "", Guests, "", "", "", "", "", url, url, url, "", "", "", "", "", "", StartDate, EndDate , "", "", "", "", "", "", "", "", "", region, statuscode, israteperstay))
                return json.dumps(array)
                    
            
        if htm.status_code <> 200:
            htm = requests.get(url,headers = head,proxies = proxies)
           
        if (htm.status_code == 403 or htm.status_code == 407) or htm.status_code <> 200:
            try:
                if htm.status_code <> 200:
                    htm = requests.get(url,headers = head)
            except Exception, e:
                Closed    = 'Y'
                value_error = str(re.sub("'", '', str(e)))
                stacktrace = sys.exc_traceback.tb_lineno
                
                keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(Websitecode, datetime.datetime.now(), id_update)
                key = bucket.new_key(keyvalue)
                key.set_contents_from_string(str(e) + 'Where Line number' + str(stacktrace) + str(proxies))
                statuscode = 5
                Guests = ''
                array.append(aws_insert.insert(id_update, inputid , Domainname, Websitecode, "", "", "", "", Guests, "", "", "", "", "", url, url, url, "", "", "", "", "", "", StartDate, EndDate , "", "", "", "", "", "", "", "", "", region, statuscode, israteperstay))
                return json.dumps(array)
        
        html = htm.text.encode('ascii','ignore')
        Rtdate=re.sub(r'-|\-','',str(RateDate))
        keyvalue = "ondemand/{}/{:%Y%m%d}/source{}.html".format(Websitecode,datetime.datetime.now(),str(inputid)+'_'+str(Rtdate)+'_'+id_update)
        key = bucket.new_key(keyvalue)
        key.set_contents_from_string(json.dumps(html))
        if re.search(r'(<div class="ProductInfo">.*?</tfoot>)',html,re.DOTALL):
            for block in re.compile(r'<div class="ProductInfo">.*?</tfoot>',re.DOTALL).findall(html):
                RoomType      = ''
                Ratetype      = ''
                OnsiteRate    = 0
                RoomAmenity_Type = ''
                RateDescription  = ''
                Mealtype         = ''
                Curr             = ''
                Closed           = 'N'
                GrossRate        = 0
                isAvailable      = ''
                TaxAmount        = 0
                Taxstatus        = -1
                roomtype_re = re.search(r'TitleSz2">(.*?)<', block,re.DOTALL)            
                if roomtype_re:
                    RomeType1 = re.sub(r"'","''", roomtype_re.group(1))
                    RoomType  = re.sub('\s\s+','',re.sub(r'&.*?;','',RomeType1))
                    
                desc1_re    = re.search(r'<div class="CluetipDescription">(.*?)</div>', block,re.DOTALL)
                if desc1_re:
                    RateDescription = re.sub(r"'","''",re.sub(r"\s\s+","",desc1_re.group(1)))
                    
                ratetype_re     = re.search(r'RateValue">(.*?)</span>', block,re.DOTALL)
                if ratetype_re:
                    Ratetype = re.sub(r"<.*?>|\s\s+",'',re.sub(r"'","''",ratetype_re.group(1)))
                    
                price_re    = re.search(r'TotalChargeValueRate BigTxt1">(.*?)</span>', block,re.DOTALL)
                if price_re:
                    OnsiteRate = re.sub('\$|,|[A-Za-z]','',price_re.group(1)).strip()
                GrossRate  = OnsiteRate 
                
                curr_re =  re.search(r'ProductPrice BigTxt1">(.*?)\d', block,re.DOTALL)
                if curr_re:
                    Curr = curr_re.group(1).strip()
                    if "$" in Curr:
                        Curr = 'USD'
                    elif 'USD' in Curr:
                        Curr = 'USD'
                #print Curr
                TaxAmount_re = re.search(r'>Tax</span>.*?(\d.*?)</span>', block,re.DOTALL)
                if TaxAmount_re:
                    TaxAmount = TaxAmount_re.group(1).strip()
                    Taxstatus  = 1
                
                #print "TaxAmount    :",TaxAmount
                #print "OnsiteRate    :",OnsiteRate
                Mealtypes          = str(RateDescription)+' '+str(RoomType)+' '+str(Ratetype)
                if Mealtypes !=None:
                    Mealtype_str = str(Mealtypes)
                    if 'breakfast' in Mealtype_str.lower() and 'dinner' in Mealtype_str.lower()  and 'lunch' in Mealtype_str.lower():
                        Meal = 'Breakfast, Lunch and Dinner'
                    elif 'breakfast' in Mealtype_str.lower() and 'dinner' in Mealtype_str.lower():
                        Meal = 'Breakfast and dinner'
                    elif 'breakfast included' in Mealtype_str.lower():
                        Meal = 'Breakfast included'
                    elif 'BREAKFAST' in Mealtype_str:
                        Meal = 'Breakfast'
                    elif 'breakfast' in Mealtype_str.lower() and 'lunch' in Mealtype_str.lower():
                        Meal = 'Breakfast and Lunch'
                    elif 'Lunch' in Mealtype_str and 'Dinner' in Mealtype_str :
                        Meal = "Lunch and Dinner"
                    elif 'breakfast' in Mealtype_str.lower() and 'lunch' in Mealtype_str.lower() and 'dinner' in Mealtype_str.lower():
                        Meal = 'Breakfast, Lunch and dinner'
                    elif 'Break fast' in Mealtype_str:
                        Meal = 'BreakFast' 
                    elif 'breakfast' in Mealtype_str.lower():
                        Meal = 'BreakFast' 
                    elif 'halfboard' in Mealtype_str.lower():
                        Meal = 'Halfboard'
                    elif 'half board' in Mealtype_str.lower():
                        Meal = 'Half board' 
                    elif 'full board' in Mealtype_str.lower():
                        Meal = 'Full Board'
                    elif 'fullboard' in Mealtype_str.lower():
                        Meal = 'FullBoard'
                    elif 'All-Inclusive' in Mealtype_str:
                        Meal = 'All-Inclusive'
                    elif 'All Inclusive' in Mealtype_str:
                        Meal = 'All Inclusive'
                    elif 'All Meals' in Mealtype_str:
                        Meal = 'All Meals'
                    elif 'All Meal' in Mealtype_str:
                        Meal = 'All Meal'
                    else:
                        Meal = ''
                else:
                    Meal = ''   
                Mealtype = Meal
                if OnsiteRate==0:
                    statuscode = 1
                    Closed='Y'
                else:
                    statuscode = ''
                    Closed='N'
                LOS = int(LOS)
                '''if int(LOS) >1:
                    israteperstay = 'N'
                else:'''
                israteperstay ='Y'
                #print RoomAmenity_Type
                
                #print (id_update, inputid , Domainname, Websitecode, StartDate, RoomType, LOS, RateDate, Guests, OnsiteRate, NetRate, GrossRate, Curr, RateDescription, url_insert, url_insert, url_insert, RoomAmenity_Type, Mealtype, MaxOccupancy, isPromotionalRate, Closed, 30, StartDate , EndDate, intime, isAvailable, Taxtype, TaxAmount, Taxstatus, None, Ratetype, Discount,Promotion_Name,region,statuscode, israteperstay)
                array.append(aws_insert.insert(id_update, inputid , Domainname, Websitecode, StartDate, RoomType, LOS, RateDate, Guests, OnsiteRate, NetRate, GrossRate, Curr, RateDescription, url_insert, url_insert, url_insert, RoomAmenity_Type, Mealtype, MaxOccupancy, isPromotionalRate, Closed, 30, StartDate , EndDate, intime, isAvailable, Taxtype, TaxAmount, Taxstatus, None, Ratetype, Discount,Promotion_Name,region,statuscode, israteperstay))
        else:
            Closed     = 'Y'
            statuscode = '2'
            #print "else"
            #print (id_update, inputid , Domainname, Websitecode, StartDate, RoomType, LOS, RateDate, Guests, OnsiteRate, NetRate, GrossRate, Curr, RateDescription, url_insert, url_insert, url_insert, RoomAmenity_Type, Mealtype, MaxOccupancy, isPromotionalRate, Closed, 30, StartDate , EndDate, intime, isAvailable, Taxtype, TaxAmount, Taxstatus, None, Ratetype, Discount,Promotion_Name,region,statuscode, israteperstay)
            array.append(aws_insert.insert(id_update, inputid , Domainname, Websitecode, StartDate, RoomType, LOS, RateDate, Guests, OnsiteRate, NetRate, GrossRate, Curr, RateDescription, url_insert, url_insert, url_insert, RoomAmenity_Type, Mealtype, MaxOccupancy, isPromotionalRate, Closed, 30, StartDate , EndDate, intime, isAvailable, Taxtype, TaxAmount, Taxstatus, None, Ratetype, Discount,Promotion_Name,region,statuscode, israteperstay))
        Rtdate = re.sub(r'-|\-', '', str(RateDate))
        keyvalue = "ondemand/{}/{:%Y%m%d}/delivery/{}.json".format(Websitecode,datetime.datetime.now(),str(inputid)+'_'+str(Rtdate)+'_'+id_update)
        key = bucket.new_key(keyvalue)
        key.set_contents_from_string(json.dumps(array))
        return json.dumps(array)
        gc.collect()
    except Exception as e:
       print e
       value_error = str(re.sub(r"'", '"', str(e)))
       stacktrace = sys.exc_traceback.tb_lineno
       Guests = ''
       region = ''
       statuscode = '4'
       array.append(aws_insert.insert(id_update, inputid , Domainname, Websitecode, "", "", "", "", Guests, "", "", "", "", "", url, url, url, "", "", "", "", "", "", StartDate, EndDate , "", "", "", "", "", "", "", "", "", region, statuscode, israteperstay))
       keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(Websitecode,datetime.datetime.now(),id_update)
       key = bucket.new_key(keyvalue)
       key.set_contents_from_string(json.dumps(value_error))
       return json.dumps(array)
   
  



