# -*- coding: utf-8 -*-
import re
import requests
import operator
import json
import time 
import urllib2
 
import sys 
import boto
import random
import gc



def insert(qid, HotelCode, WebSiteName, Websitecode, ReportDate, RoomType, Los, RateDate, Guests, OnsiteRate, Netrate, GrossRate, Curr, RoomDescription, urlRate, urlInclusions, urlAmenities, RoomAmenity_Type, MealInclusion_Type, MaxOcp, Isprom, Closed_up, NumberOfDays, StartDate, EndDate, intime, RoomAvilable, TaxType, TaxAmount,Tax_status, HotelBlock, RateType, Discount,promotion,region, statuscode, israteperstay):
	global array    
	if (Websitecode == "0"):
		return
	else:
		Output_url = "https://www.ratemetrics.com/hotels/api/reznext/rateupdate"
		roomtypemapped = ""    
		ratetypemapped = ""
		complete = ""
		disc = 0
		if (Closed_up == "Y"):
			OnsiteRate = 0
			Netrate = 0
			GrossDate = 0
		
		else:  
			if re.search(r"special|studio|bungalow|cottage|bdrm ste", RateType, re.IGNORECASE):
				roomtypemapped = "Suite"
			elif re.search(r"Business|Deluxe|Superior|Executive|Hypo|Premium|Concierge|Supreme|Luxury|Premier|Classic|", RateType, re.IGNORECASE):
				roomtypemapped = "Premium"
			elif re.search(r"suite|studio|bungalow|cottage|bdrm ste|en suit|en-suit|ensuit", RoomDescription, re.IGNORECASE):
				roomtypemapped = "Suite"
			elif re.search(r"Deluxe|Business|Superior|Executive|Hypo|Premium|Concierge|Supreme|premier|Luxury|Classic", RoomDescription, re.IGNORECASE):
				roomtypemapped = "Premium"
			else:
				roomtypemapped = "Standard"
			
			if re.search(r"special|discount|Advance Purchase|Government|Military|AAA|AARP|Double Your Points", RateType, re.IGNORECASE):
				ratetypemapped = "Qualified"
			elif re.search(r"package|PKG|rewards|bonus point|save|AAA|AARP|Double Your Points", RateType, re.IGNORECASE):
				ratetypemapped = "UnQualified"
			else:
				ratetypemapped = "Unrestricted"            
	
			if (OnsiteRate <> ""): 
				OnsiteRate = re.sub(r'Rs\.|[A-Za-z]\.|\$\.|\$', "", str(OnsiteRate))
			else:
				OnsiteRate = 0

			if Netrate == '' or Netrate == '0':
				Netrate = 0
			if (Netrate <> 0):
				Netrate = re.sub(r'Rs\.|[A-Za-z]\.|\$\.|\$', "", str(Netrate))
				Isprom = 'Y'
			else:
				Netrate = 0
				Isprom = 'N'
				
			if (GrossRate <> ""):
				GrossRate = re.sub(r'Rs\.|[A-Za-z]\.|\$\.|\$', "", str(GrossRate))
			else:
				GrossRate = 0
				
			if (float(Netrate) > 0):
				disc = 100 - (float(OnsiteRate) / float(Netrate) * 100)
			if (disc < 0 and float(Netrate) > 0):
				disc = 100 - (float(Netrate) / float(OnsiteRate) * 100)
	
		if (OnsiteRate == 0 and Netrate == 0 and GrossRate == 0):
			Closed_up = "Y"
		if MaxOcp ==0 or MaxOcp =='' or MaxOcp =='0' or MaxOcp =='null':
			MaxOcp = None
			
		disc = round(disc, 2)
		if TaxAmount=="" or str(TaxAmount)=="" or str(TaxAmount)=='null'  or TaxAmount== None:
			TaxAmount='0'
		#if Tax_status==-1 or str(Tax_status)=="-1":
		#	Tax_status=''
		if Tax_status==-1 or str(Tax_status)=="-1" or Tax_status==0 or str(Tax_status)=="0":
			Tax_status=None
		vdata = '"{}"^"{}"^"{}"^"{}"^"{}"^"{}"^"{}"^"{}"^"{}"^"{}"^"{}"^"{}"^"{}"^"{}"^"{}"^"{}"^"{}"^"{}"^"{}"^"{}"^"{}"^"{}"^"{}"^"{}"^"{}"^"{}"^"{}"^"{}"^"{}"^"{}"^"{}'.format(qid, HotelCode,Websitecode,StartDate,RoomType,Los,RateDate,Guests,OnsiteRate,Netrate,GrossRate,Curr,RoomDescription,urlRate,RoomAmenity_Type,MealInclusion_Type,MaxOcp,Isprom,Closed_up,NumberOfDays,EndDate,intime,RoomAvilable,TaxType,TaxAmount,RateType,disc, roomtypemapped, ratetypemapped,promotion, statuscode, israteperstay)
		json = {"hotelcode": HotelCode, "websitecode": Websitecode, "roomtype": RoomType, "ratetype": RateType, "guests":Guests, "onsiterate":OnsiteRate, "netrate":Netrate, "curr":Curr, "roomdescription":RoomDescription, "url":urlRate,"roomamenity":RoomAmenity_Type, "mealinclusion":MealInclusion_Type, "maxocp":MaxOcp, "isprom":Isprom, "closed_up":Closed_up, "disc":disc, "taxtype":TaxType, "taxamount":TaxAmount,"taxstatus":Tax_status,"promotion":promotion,"region":region, "statuscode":statuscode, "israteperstay": israteperstay}
		##print "json =",json
	return json 








