# -*- coding: utf-8 -*-
import re
import requests
import datetime
import json
import sys 
import boto
import gc

import aws_insert

def fetchrates(url,inputid,id_update,proxyip):
    array      = []
    sr  = requests.session()
    intime     = re.sub(r'\s','T',str(datetime.datetime.now()))
    Domainname = 'thepodhotel.com'
    Websitecode= '287'
    region     = ''
    #proxies    = {"https": "http://media:M3diAproxy@%s"% proxyip}
    proxies   = {"https": "http://{}".format(proxyip)}
    statuscode = ''
    israteperstay = ''
    try:
        conn   = boto.connect_s3(aws_access_key_id= 'AKIAIXEGZVXCWE2FV3SQ',aws_secret_access_key = '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') 
        bucket = conn.get_bucket("rmapi")
        StartDate = datetime.date.today()
        EndDate   = datetime.date.today() + datetime.timedelta(days=29)
        CheckIn_Check_OT_re = re.search(r'checkin=(.*?)&checkout=(.*)',url)
        if CheckIn_Check_OT_re:
            Checkin  = CheckIn_Check_OT_re.group(1)
            Checkout = CheckIn_Check_OT_re.group(2)
            y1 = datetime.datetime.strptime(str(Checkin),'%Y-%m-%d').strftime('%Y')
            m1 = datetime.datetime.strptime(str(Checkin),'%Y-%m-%d').strftime('%m')
            d1 = datetime.datetime.strptime(str(Checkin),'%Y-%m-%d').strftime('%d')
            y2 = datetime.datetime.strptime(str(Checkout),'%Y-%m-%d').strftime('%Y')
            m2 = datetime.datetime.strptime(str(Checkout),'%Y-%m-%d').strftime('%m')
            d2 = datetime.datetime.strptime(str(Checkout),'%Y-%m-%d').strftime('%d')
        #print Checkin,Checkout
        RateDate = Checkin
        delta    = datetime.datetime.strptime(Checkout, "%Y-%m-%d") - datetime.datetime.strptime(Checkin, "%Y-%m-%d")
        LOS      = delta.days
        Checkinout_URL = 'gg='+d1+'&mm='+m1+'&aa='+y1+'&ggf='+d2+'&mmf='+m2+'&aaf='+y2+'&notti_1='+str(LOS)+'&'
        url1 = re.sub(r"gg=.*?ggf.*?notti_1=.*?&",Checkinout_URL,url)
        url  = re.sub(r"\#.*",'',url1)
        #print url
        RoomType = ''
        Guests   = re.search(r'tot_adulti=(\d+)&', url).group(1)
        #print Guests,LOS
        Ratetype = ''
        Mealtype = ''
        RateDescription = ''
        Taxtype  = ''
        Curr     = ''
        MaxOccupancy = None
        isPromotionalRate  = 'N'
        Closed   = 'Y'
        NetRate  = 0
        Taxstatus= -1
        TaxAmount= 0
        Discount = 0
        GrossRate= 0
        OnsiteRate = 0
        Curr     = ''
        Promotion_Name= ''
        isAvailable = ''
        RoomAmenity_Type = ''
        url_insert = url
        head={'User-Agent':'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/56.0.2924.87 Safari/537.36','Host':'www.webervations.com'}
        ip = re.sub(r"\{'.*?@|'\}|:\d+", "", str(proxies))
        try:
            try:
                r = requests.get('http://freegeoip.net/json/' + ip, timeout=30)
            except Exception, e:
                r = requests.get('http://freegeoip.net/json/' + ip, timeout=30)
            js = r.json()
            region = js['country_name']
        except Exception, e:
            region = ''
        try:
            htm = requests.get(url,headers = head,proxies = proxies,timeout=100)
        except Exception, e:
            #print "error",e
            value_error = str(re.sub("'", '', str(e)))
            stacktrace = sys.exc_traceback.tb_lineno
            try:
                htm = requests.get(url,headers = head,proxies = proxies,timeout=120)
            except Exception, e:
                try:
                    htm = requests.get(url,headers = head,proxies = proxies,timeout=150)
                except Exception, e:
                    value_error = str(re.sub("'", '', str(e)))
                    stacktrace = sys.exc_traceback.tb_lineno
                    keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(Websitecode, datetime.datetime.now(), id_update)
                    key = bucket.new_key(keyvalue)
                    key.set_contents_from_string(str(e) + 'Where Line number' + str(stacktrace) + str(proxies))
                    statuscode = 5
                    Guests = ''
                    array.append(aws_insert.insert(id_update, inputid , Domainname, Websitecode, "", "", "", "", Guests, "", "", "", "", "", url, url, url, "", "", "", "", "", "", StartDate, EndDate , "", "", "", "", "", "", "", "", "", region, statuscode, israteperstay))
                    return json.dumps(array)
        if htm.status_code <> 200:
            htm = requests.get(url,headers = head,proxies = proxies)
        if (htm.status_code == 403 or htm.status_code == 407) or htm.status_code <> 200:
            try:
                if htm.status_code <> 200:
                    htm = requests.get(url,headers = head)
            except Exception, e:
                Closed    = 'Y'
                value_error = str(re.sub("'", '', str(e)))
                stacktrace = sys.exc_traceback.tb_lineno
                keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(Websitecode, datetime.datetime.now(), id_update)
                key = bucket.new_key(keyvalue)
                key.set_contents_from_string(str(e) + 'Where Line number' + str(stacktrace) + str(proxies))
                statuscode = 5
                Guests = ''
                array.append(aws_insert.insert(id_update, inputid , Domainname, Websitecode, "", "", "", "", Guests, "", "", "", "", "", url, url, url, "", "", "", "", "", "", StartDate, EndDate , "", "", "", "", "", "", "", "", "", region, statuscode, israteperstay))
                return json.dumps(array)
        html = htm.text.encode('ascii','ignore')
        Rtdate=re.sub(r'-|\-','',str(RateDate))
        keyvalue = "ondemand/{}/{:%Y%m%d}/source{}.html".format(Websitecode,datetime.datetime.now(),str(inputid)+'_'+str(Rtdate)+'_'+id_update)
        key = bucket.new_key(keyvalue)
        key.set_contents_from_string(json.dumps(html))
            
        if re.compile(r'<div class="room-name">.*?<span\s+class="close">',re.DOTALL).findall(html):
            for block in re.compile(r'<div class="room-name">.*?<span\s+class="close">',re.DOTALL).findall(html):
                RoomType   = ''
                Ratetype   = ''
                GrossRate  = 0
                OnsiteRate = 0
                NetRate    = 0
                MaxOccupancy = None
                Taxstatus    = -1
                isPromotionalRate = 'N'
                RoomAmenity_Type  = ''
                RateDescription   = ''
                Taxtype = ''
                Roomtype_re = re.search(r'<div class="room-name">(.*?)</div>', block)
                if Roomtype_re:
                    RomType = Roomtype_re.group(1)
                    RoomType = re.sub("\s\s+","",re.sub(r"'","''",re.sub(r'&.*?;',' ',RomType).strip()))
                else:
                    RoomType = ''
                price2=re.search(r'pricesloaded="no">.*?price">(.*?)<',block,re.DOTALL)
                if price2:
                    rate1=price2.group(1)
                    OnsiteRate=re.sub("\,","",rate1)
                else:
                    OnsiteRate='0'
                Currency_Code=re.search(r'pricesloaded="no">.*?valuta">(.*?)<',block,re.DOTALL)
                if Currency_Code:
                    Currency1=Currency_Code.group(1)
                    Curr=re.sub(r'\d+|\s+|,','',Currency1)
                    if 'USD' in Curr:
                        Curr = 'USD'
                else:
                    Curr=''
                ratetype1=re.search(r'short-desc"></div>.*?class="label">(.*?)</div>',block,re.DOTALL)
                if ratetype1:
                    Ratetype_grp = ratetype1.group(1)
                    Ratetype_1 = re.sub(r'\s\s+|-|Details','',re.sub(r'<.*?>','',Ratetype_grp))
                    Ratetype = re.sub(r"'","",Ratetype_1).strip()
                roomdescription=re.search(r'room-name">.*?decrBreveCamera">(.*?)[\!|\.|\s+]</div>',block,re.DOTALL)
                if roomdescription:
                    roomdescription1 = roomdescription.group(1)
                    RateDescription1 = re.sub(r"'","",roomdescription1)
                    RateDescription2 = re.sub(r"<.*?>","",RateDescription1)
                    RateDescription  = re.sub(r"\+|Details|\s\s+","",RateDescription2)
                '''taxtype=re.search(r'<div class="cancellation.*?<div class="text">(.*?)\s+\(',block) 
                if taxtype:
                    Taxtype=taxtype.group(1)
                taxamount=re.search(r'<div class="cancellation.*?:\s+(\d+.\d+)',block) 
                if taxamount:
                    TaxAmount=taxamount.group(1)'''
                amenties=re.search(r'class="blugray">IN ROOM</h6>(.*?)</ul></div>',block,re.DOTALL)
                if amenties:
                    amenties1=amenties.group(1)
                    amenties2 = re.sub(r'<.*?>','',re.sub(r'<br />',',',amenties1))
                    amen1=re.sub(r'\s\s+','',amenties2)
                    RoomAmenity_Type1=re.sub(r',$','',amen1)
                    RoomAmenity_Type=re.sub(r"'","",RoomAmenity_Type1)
                RateDescription = re.sub(r"'","''",RateDescription)
                Mealtypes = str(RateDescription)+' '+str(RoomAmenity_Type)+' '+str(RoomType)+''+str(Ratetype)
                if Mealtypes !=None:
                    Mealtype_str = str(Mealtypes)
                    if 'breakfast' in Mealtype_str.lower() and 'dinner' in Mealtype_str.lower()  and 'lunch' in Mealtype_str.lower():
                        Meal = 'Breakfast, Lunch and Dinner'
                    elif 'breakfast' in Mealtype_str.lower() and 'dinner' in Mealtype_str.lower():
                        Meal = 'Breakfast and dinner'
                    elif 'breakfast included' in Mealtype_str.lower():
                        Meal = 'Breakfast included'
                    elif 'BREAKFAST' in Mealtype_str:
                        Meal = 'Breakfast'
                    elif 'breakfast' in Mealtype_str.lower() and 'lunch' in Mealtype_str.lower():
                        Meal = 'Breakfast and Lunch'
                    elif 'Lunch' in Mealtype_str and 'Dinner' in Mealtype_str :
                        Meal = "Lunch and Dinner"
                    elif 'breakfast' in Mealtype_str.lower() and 'lunch' in Mealtype_str.lower() and 'dinner' in Mealtype_str.lower():
                        Meal = 'Breakfast, Lunch and dinner'
                    elif 'Break fast' in Mealtype_str:
                        Meal = 'BreakFast' 
                    elif 'breakfast' in Mealtype_str.lower():
                        Meal = 'BreakFast' 
                    elif 'halfboard' in Mealtype_str.lower():
                        Meal = 'Halfboard'
                    elif 'half board' in Mealtype_str.lower():
                        Meal = 'Half board' 
                    elif 'full board' in Mealtype_str.lower():
                        Meal = 'Full Board'
                    elif 'fullboard' in Mealtype_str.lower():
                        Meal = 'FullBoard'
                    elif 'All-Inclusive' in Mealtype_str:
                        Meal = 'All-Inclusive'
                    elif 'All Inclusive' in Mealtype_str:
                        Meal = 'All Inclusive'
                    elif 'All Meals' in Mealtype_str:
                        Meal = 'All Meals'
                    elif 'All Meal' in Mealtype_str:
                        Meal = 'All Meal'
                    else:
                        Meal = ''
                else:
                    Meal = ''    
                Mealtype = Meal
                taxtype_re = re.search(r'city tax tcm.*?>\s*(.*?)\s*</small>', block)
                if taxtype_re:
                    Taxtype   = re.sub(r"'","''",taxtype_re.group(1))
                else:
                    Taxtype = ''
                if OnsiteRate==0:
                    statuscode = 1
                    Closed='Y'
                else:
                    statuscode = ''
                    Closed='N'
                LOS = int(LOS)
                if int(LOS) >1:
                    israteperstay = 'N'
                else:
                    israteperstay = 'Y'
                Taxstatus = 2
                #print "RoomType         :",RoomType          
                #print "Ratetype         :",Ratetype          
                #print "price            :",OnsiteRate  
                #print "NetRate          :",NetRate           
                #print "RateDescription  :",RateDescription  
                #print "Currency         :",Curr
                #print "RoomAmenity_Type :",RoomAmenity_Type
                #print "MaxOccupancy     :",MaxOccupancy
                #print "Taxtype          :",Taxtype
                #print"$"*40
                #print (id_update, inputid , Domainname, Websitecode, StartDate, RoomType, LOS, RateDate, Guests, OnsiteRate, NetRate, GrossRate, Curr, RateDescription, url_insert, url_insert, url_insert, RoomAmenity_Type, Mealtype, MaxOccupancy, isPromotionalRate, Closed, 30, StartDate , EndDate, intime, isAvailable, Taxtype, TaxAmount, Taxstatus, None, Ratetype, Discount,Promotion_Name,region,statuscode, israteperstay)
                array.append(aws_insert.insert(id_update, inputid , Domainname, Websitecode, StartDate, RoomType, LOS, RateDate, Guests, OnsiteRate, NetRate, GrossRate, Curr, RateDescription, url_insert, url_insert, url_insert, RoomAmenity_Type, Mealtype, MaxOccupancy, isPromotionalRate, Closed, 30, StartDate , EndDate, intime, isAvailable, Taxtype, TaxAmount, Taxstatus, None, Ratetype, Discount,Promotion_Name,region,statuscode, israteperstay))
        else:
            Closed     = 'Y'
            statuscode = '2'
            Taxstatus  =  0
            #print "else"
            #print (id_update, inputid , Domainname, Websitecode, StartDate, RoomType, LOS, RateDate, Guests, OnsiteRate, NetRate, GrossRate, Curr, RateDescription, url_insert, url_insert, url_insert, RoomAmenity_Type, Mealtype, MaxOccupancy, isPromotionalRate, Closed, 30, StartDate , EndDate, intime, isAvailable, Taxtype, TaxAmount, Taxstatus, None, Ratetype, Discount,Promotion_Name,region,statuscode, israteperstay)
            array.append(aws_insert.insert(id_update, inputid , Domainname, Websitecode, StartDate, RoomType, LOS, RateDate, Guests, OnsiteRate, NetRate, GrossRate, Curr, RateDescription, url_insert, url_insert, url_insert, RoomAmenity_Type, Mealtype, MaxOccupancy, isPromotionalRate, Closed, 30, StartDate , EndDate, intime, isAvailable, Taxtype, TaxAmount, Taxstatus, None, Ratetype, Discount,Promotion_Name,region,statuscode, israteperstay))
        Rtdate = re.sub(r'-|\-', '', str(RateDate))
        keyvalue = "ondemand/{}/{:%Y%m%d}/delivery/{}.json".format(Websitecode,datetime.datetime.now(),str(inputid)+'_'+str(Rtdate)+'_'+id_update)
        key = bucket.new_key(keyvalue)
        key.set_contents_from_string(json.dumps(array))
        return json.dumps(array)
        gc.collect()
    except Exception as e:
        print e
        value_error = str(re.sub(r"'", '"', str(e)))
        stacktrace = sys.exc_traceback.tb_lineno
        Guests = ''
        region = ''
        statuscode = '4'
        array.append(aws_insert.insert(id_update, inputid , Domainname, Websitecode, "", "", "", "", Guests, "", "", "", "", "", url, url, url, "", "", "", "", "", "", StartDate, EndDate , "", "", "", "", "", "", "", "", "", region, statuscode, israteperstay))
        keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(Websitecode,datetime.datetime.now(),id_update)
        key = bucket.new_key(keyvalue)
        key.set_contents_from_string(json.dumps(value_error))
        return json.dumps(array)
