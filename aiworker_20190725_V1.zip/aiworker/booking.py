# -*- coding: utf-8 -*-
import re
import requests
import datetime
import operator
import json
import boto
import gc
import sys
import aws_insert
import random
from unidecode import unidecode

# url = 'https://www.booking.com/hotel/gb/the-point-apartments-sheffield.en-gb.html?checkin=2019-06-02;checkout=2019-06-03;group_adults=1;lang=en-us;selected_currency=AUD;changed_currency=1;hotelid=882577'
# inputid = '12werwe32452'
# id_update = '2345'
# proxyip = 'aggregate:39cxjGYByv@154.13.77.4:60000'

def fetchrates(url , inputid, id_update, proxyip):
	sr = requests.Session()	
	if "http:" in str(url):
		url = re.sub(r'http:', 'https:', url)
	array = []
	intime = re.sub(r'\s', 'T', str(datetime.datetime.now()))
	functionname = 'Booking'
	israteperstay = ''
	region = ''
	hid = re.sub(r'http.*?hotelid=', '', url)
	conn = boto.connect_s3(aws_access_key_id='AKIAIXEGZVXCWE2FV3SQ', aws_secret_access_key='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') 
	bucket = conn.get_bucket("rmapi")
	StartDate = datetime.date.today()
	EndDate = datetime.date.today() + datetime.timedelta(days=29)
	adult = re.search(r'group_adults=(\d+);', url)
	if adult:
		adults1 = adult.group(1)
		Guests = adults1
	proxies = {"https": "http://{}".format(proxyip), "http": "http://{}".format(proxyip)}
	Websitecode = '2'
	Mtrdivsib = 10.764
# 	print url
	try:	
		MainBlock_regex = re.compile(r'<div class="hprt-block"\s*data-et-view=" goal:hp_sold_out_rooms_viewed">.*?</td>\s*</tr>|<tr data-block-id=.*?hprt-table-last-row.*?</div>\s*</td>\s*</tr>', re.DOTALL)
		Room1_block_regex = re.compile(r'<tr data-block-id.*?</div>\s*</td>\s*</tr>|<div class="hprt-block"\s*data-et-view=" goal:hp_sold_out_rooms_viewed">.*?</td>\s*</tr>', re.DOTALL)
		Ft_regex = re.compile(r'Size:\s*.*?\s*(\d+)\s*ft', re.IGNORECASE)
		Websitecode = 2
		statuscode = ''
		Domainname = 'Booking.com'
		RateDate = ''
		Rtdate = ''
		RateDate_reg = re.search(r"checkin=(.*?);", url)
		if RateDate_reg:
			RateDate = RateDate_reg.group(1)
			Rtdate = re.sub(r'-|\-', '', str(RateDate))
		delta = datetime.datetime.strptime(re.search(r"checkout=(.*?);", url).group(1), "%Y-%m-%d") - datetime.datetime.strptime(re.search(r"checkin=(.*?);", url).group(1), "%Y-%m-%d")
		LOS = delta.days 

		def Ft_reg_check(RoomDescp):
			Ft_regex = re.compile(r'Size:\s*.*?\s*(\d+)\s*ft', re.IGNORECASE)
			if Ft_regex.findall(RoomDescp):
				Ft_reg = re.search(Ft_regex, RoomDescp)
				if Ft_reg:
					Ft_reg_group = Ft_reg.group(1)
					Ft_reg_Int = int(Ft_reg_group)
					Mtsqr_con = Ft_reg_Int / Mtrdivsib
					Mtsqr_round = round(Mtsqr_con)
					Mtsqr_int = int(Mtsqr_round)
					Mtsqr = str(Mtsqr_int) + ' ' + "m2"
					return Mtsqr
		
		inpl = ['user-37082:a7d2c0d3ace90f48@45.64.105.154:1212','user-37082:a7d2c0d3ace90f48@103.250.184.172:1212','user-37082:a7d2c0d3ace90f48@103.12.211.82:1212','user-37082:a7d2c0d3ace90f48@45.64.106.37:1212','user-37082:a7d2c0d3ace90f48@45.64.106.5:1212','user-37082:a7d2c0d3ace90f48@45.64.106.27:1212','user-37082:a7d2c0d3ace90f48@103.250.184.229:1212','user-37082:a7d2c0d3ace90f48@45.64.106.62:1212','user-37082:a7d2c0d3ace90f48@45.64.106.41:1212','user-37082:a7d2c0d3ace90f48@103.250.184.252:1212']
		head = {'User-Agent':'Mozilla/5.0 (X11; Linux x86_64; rv:64.0) Gecko/20100101 Firefox/64.0'}
		try:
			hml = requests.get(url, headers=head, proxies=proxies, timeout=50)
		except Exception as e:
			#print e
			try:
				prox = random.choice(inpl)
				proxies      = {"https": "http://{}".format(prox)}
				hml = requests.get(url, headers=head, proxies=proxies, timeout=50)
			except Exception as e:
				value_error = str(re.sub("'", '"', str(e)))
				stacktrace = sys.exc_traceback.tb_lineno
				insert_value_error = str(value_error) + 'Where line number ' + str(stacktrace) + str(proxyip)+ ' Hotelcode in:' + str(inputid)
				region = ''
				keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(Websitecode, datetime.datetime.now(), id_update)
				key = bucket.new_key(keyvalue)
				key.set_contents_from_string(str(insert_value_error))
				statuscode = 5
				Guests = '1'
				array.append(aws_insert.insert(id_update, inputid , functionname, Websitecode, "", "", "", "", Guests, "", "", "", "", "", url, url, url, "", "", "", "", "", "", StartDate, EndDate , "", "", "", "", "", "", "", "", "", region, statuscode, israteperstay))
				return json.dumps(array)
		if (hml.status_code <> 200):
			hml = requests.get(url, headers=head, proxies=proxies)
		if (hml.status_code == 403 or hml.status_code == 407 or hml.status_code <> 200):
			#print "hml.status_code == 403 or hml.status_code == 407 or hml.status_code <> 200"
			try:	
				hml = requests.get(url, headers=head)
			except Exception, e:
				value_error = str(re.sub("'", '"', str(e)))		
				stacktrace = sys.exc_traceback.tb_lineno
				insert_value_error = str(value_error) + 'Where line number ' + str(stacktrace) + str(proxyip)+ ' Hotelcode in:' + str(inputid)
				region = ''
				keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(Websitecode, datetime.datetime.now(), id_update)
				key = bucket.new_key(keyvalue)
				key.set_contents_from_string(str(insert_value_error))
				statuscode = 5
				Guests = '1'
				array.append(aws_insert.insert(id_update, inputid , functionname, Websitecode, "", "", "", "", Guests, "", "", "", "", "", url, url, url, "", "", "", "", "", "", StartDate, EndDate , "", "", "", "", "", "", "", "", "", region, statuscode, israteperstay))
				   		
				
		html = hml.text
		html = unidecode(html).encode('ascii')		
		if 'searchresults' in hml.url:
			url_check = url
			label_reg = re.search(r'b_go_to_hp_by_hid.*?\?.*?label=(.*?);', html)
			if label_reg:
				label = label_reg.group(1)
				label = 'label=' + str(label) + ';'
			else:
				label_reg = re.search(r"b_label: '(.*?)'", html)
				if label_reg:
					label = label_reg.group(1)
					label = 'label=' + str(label) + ';'
				else:
					label = ''
			sid_reg = re.search(r'b_go_to_hp_by_hid.*?\?.*?sid=(.*?);', html)
			if sid_reg:
				sid = sid_reg.group(1)
				sid = 'sid=' + str(sid) + ';'
			else:
				sid = ''
			all_sr_blocks_reg = re.search(r'b_go_to_hp_by_hid.*?\?.*?all_sr_blocks=(.*?);', html)
			if all_sr_blocks_reg:
				all_sr_blocks = all_sr_blocks_reg.group(1)
				all_sr_blocks = 'all_sr_blocks=' + str(all_sr_blocks) + ';'
			else:
				all_sr_blocks = ''
			highlighted_blocks_reg = re.search(r'b_go_to_hp_by_hid.*?\?.*?highlighted_blocks=(.*?);', html)
			if highlighted_blocks_reg:
				highlighted_blocks = highlighted_blocks_reg.group(1)
				highlighted_blocks = 'highlighted_blocks=' + str(highlighted_blocks) + ';'
			else:
				highlighted_blocks = ''
			dest_id_reg = re.search(r'b_go_to_hp_by_hid.*?\?.*?dest_id=(.*?);', html)
			if dest_id_reg:
				dest_id = dest_id_reg.group(1)
				dest_id = 'dest_id=' + str(dest_id) + ';'
			else:
				dest_id = ''
			hpos_reg = re.search(r'b_go_to_hp_by_hid.*?\?.*?hpos=(.*?);', html)
			if hpos_reg:
				hpos = hpos_reg.group(1)
				hpos = 'hpos=' + str(hpos) + ';'
			else:
				hpos = ''
			ucfs_reg = re.search(r'b_go_to_hp_by_hid.*?\?.*?ucfs=(.*?);', html)
			if ucfs_reg:
				ucfs = ucfs_reg.group(1)
				ucfs = 'ucfs=' + str(ucfs) + ';'
			else:
				ucfs = ''
			dest_type_reg = re.search(r'b_go_to_hp_by_hid.*?\?.*?dest_type=(.*?);', html)
			if dest_type_reg:
				dest_type = dest_type_reg.group(1)
				dest_type = 'dest_type=' + str(dest_type) + ';'
			else:
				dest_type = ''
			room1_reg = re.search(r'b_go_to_hp_by_hid.*?\?.*?room1=(.*?);', html)
			if room1_reg:
				room1 = room1_reg.group(1)
				room1 = 'room1=' + str(room1) + ';'
			else:
				room1 = ''
			url = re.sub(r'\?', '?' + str(label) + str(sid) + str(all_sr_blocks) + str(highlighted_blocks) + str(dest_id) + str(hpos) + str(ucfs) + str(dest_type) + str(room1), url_check)
			hml = sr.get(url, headers=head, proxies=proxies)
				
			i = 0
			while 'searchresults' in hml.url:
				hml = sr.get(url, headers=head, proxies=proxies)
				i = i + 1
				if i == 7:
					break
			keyvalue = "ondemand/{}/{:%Y%m%d}/source/{}.html".format(Websitecode, datetime.datetime.now(), str(inputid) + '_' + str(Rtdate) + '_' + id_update + '_searchresults')
			key = bucket.new_key(keyvalue)
			key.set_contents_from_string(unidecode(hml.text).encode('ascii'))
		html = hml.text
		html = unidecode(html).encode('ascii')
		
		hotel_name_url_reg = re.search(r'/hotel/.*?/(.*?)\.', hml.url)
		if hotel_name_url_reg:
			hotel_name_url = hotel_name_url_reg.group(1)
		else:
			hotel_name_url = ''
		
		if not re.search("hotel_id:\s*'"+str(hid)+"',", html):
			inpl = ['user-37082:a7d2c0d3ace90f48@45.64.106.63:1212','user-37082:a7d2c0d3ace90f48@45.64.106.30:1212','user-37082:a7d2c0d3ace90f48@45.64.106.33:1212','user-37082:a7d2c0d3ace90f48@45.64.106.67:1212','user-37082:a7d2c0d3ace90f48@45.64.106.46:1212','user-37082:a7d2c0d3ace90f48@45.64.106.56:1212','user-37082:a7d2c0d3ace90f48@45.64.106.28:1212','user-37082:a7d2c0d3ace90f48@45.64.106.55:1212']
			prox = random.choice(inpl)
			proxies      = {"https": "http://{}".format(prox)}
			try:
				hml = requests.get(url, headers=head, proxies=proxies, timeout=50)
			except Exception as e:
				print e
				value_error = str(re.sub("'", '"', str(e)))
				stacktrace = sys.exc_traceback.tb_lineno
				insert_value_error = str(value_error) + 'Where line number ' + str(stacktrace) + str(proxyip)+ ' Hotelcode in:' + str(inputid)
				region = ''
				keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(Websitecode, datetime.datetime.now(), id_update)
				key = bucket.new_key(keyvalue)
				key.set_contents_from_string(str(insert_value_error))
				statuscode = 5
				Guests = '1'
				array.append(aws_insert.insert(id_update, inputid , functionname, Websitecode, "", "", "", "", Guests, "", "", "", "", "", url, url, url, "", "", "", "", "", "", StartDate, EndDate , "", "", "", "", "", "", "", "", "", region, statuscode, israteperstay))
				return json.dumps(array)
			
			html = hml.text
			html = unidecode(html).encode('ascii')
			
			if not re.search("hotel_id:\s*'"+str(hid)+"',", html):
				if hml.history:
					if (str(hml.history[0]) == '<Response [301]>' or str(hml.history[0]) == '<Response [302]>') and 'searchresults' in hml.url:
						Closed_up = 'Y'
						statuscode = '3'
						array.append(aws_insert.insert(id_update, inputid , functionname, Websitecode, "", "", "", "", Guests, "", "", "", "", "", url, url, url, "", "", "", "", Closed_up, "", StartDate, EndDate , "", "", "", "", "", "", "", "", "", region, statuscode, israteperstay))				
						keyvalue = "ondemand/{}/{:%Y%m%d}/source/{}.html".format(Websitecode, datetime.datetime.now(), str(inputid) + '_' + str(Rtdate) + '_' + id_update)
						key = bucket.new_key(keyvalue)
						key.set_contents_from_string(html)
						return json.dumps(array)
					else:
						value_error = 'Hotel redirect to another hotel'
						stacktrace = ''
						insert_value_error = str(value_error) + str(proxyip)+ ' Hotelcode in:' + str(inputid)
						region = ''
						keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(Websitecode, datetime.datetime.now(), id_update)
						key = bucket.new_key(keyvalue)
						key.set_contents_from_string(str(insert_value_error))
						statuscode = 5
						Guests = '1'
						array.append(aws_insert.insert(id_update, inputid , functionname, Websitecode, "", "", "", "", Guests, "", "", "", "", "", url, url, url, "", "", "", "", "", "", StartDate, EndDate , "", "", "", "", "", "", "", "", "", region, statuscode, israteperstay))
						return json.dumps(array)
				else:
					value_error = 'Hotel redirect to another hotel'
					stacktrace = ''
					insert_value_error = str(value_error) + str(proxyip)+ ' Hotelcode in:' + str(inputid)
					region = ''
					keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(Websitecode, datetime.datetime.now(), id_update)
					key = bucket.new_key(keyvalue)
					key.set_contents_from_string(str(insert_value_error))
					statuscode = 5
					Guests = '1'
					array.append(aws_insert.insert(id_update, inputid , functionname, Websitecode, "", "", "", "", Guests, "", "", "", "", "", url, url, url, "", "", "", "", "", "", StartDate, EndDate , "", "", "", "", "", "", "", "", "", region, statuscode, israteperstay))
					return json.dumps(array)
			
		if "This property isn't taking reservations on our site right now" in html  or 'temporarily unavailable on our site, but we found' in html or 'There are no rooms available at this property' in html or 'isnt bookable on our site anymore, but we found some great alternatives for you' in html or "Unfortunately it's not possible to make reservations for this hotel at this time" in html:
			Closed_up = 'Y'
			statuscode = '3'
			array.append(aws_insert.insert(id_update, inputid , functionname, Websitecode, "", "", "", "", Guests, "", "", "", "", "", url, url, url, "", "", "", "", Closed_up, "", StartDate, EndDate , "", "", "", "", "", "", "", "", "", region, statuscode, israteperstay))				
			keyvalue = "ondemand/{}/{:%Y%m%d}/source/{}.html".format(Websitecode, datetime.datetime.now(), str(inputid) + '_' + str(Rtdate) + '_' + id_update)
			key = bucket.new_key(keyvalue)
			key.set_contents_from_string(html)
			return json.dumps(array)
		if 'searchresults' in hml.url:	
			Closed_up = 'Y'
			statuscode = '6'
			array.append(aws_insert.insert(id_update, inputid , functionname, Websitecode, "", "", "", "", Guests, "", "", "", "", "", hml.url, hml.url, hml.url, "", "", "", "", Closed_up, "", StartDate, EndDate , "", "", "", "", "", "", "", "", "", region, statuscode, israteperstay))				
			keyvalue = "ondemand/{}/{:%Y%m%d}/source/{}.html".format(Websitecode, datetime.datetime.now(), str(inputid) + '_' + str(Rtdate) + '_' + id_update)
			key = bucket.new_key(keyvalue)
			key.set_contents_from_string(html)
			reference = url + '\n' + '\n' + str(proxyip)
			keyvalue = "ondemand/{}/{:%Y%m%d}/source/{}.txt".format(Websitecode, datetime.datetime.now(), id_update + '-info')
			key = bucket.new_key(keyvalue)
			key.set_contents_from_string(reference)
			keyvalue = "ondemand/{}/{:%Y%m%d}/delivery/{}.json".format(Websitecode, datetime.datetime.now(), str(inputid) + '_' + str(Rtdate) + '_' + id_update)
			key = bucket.new_key(keyvalue)
			key.set_contents_from_string(json.dumps(array))
			return json.dumps(array)
		
		if hml.history:
			if str(hml.history[0]) == '<Response [301]>':
				keyvalue = "ondemand/{}/{:%Y%m%d}/source/{}.html".format(Websitecode, datetime.datetime.now(), str(inputid) + '_' + str(Rtdate) + '_' + id_update + '_history')
				key = bucket.new_key(keyvalue)
				key.set_contents_from_string(html)
				inpl = ['user-34068:214859b73da0e174@103.250.184.172:1212','user-34068:214859b73da0e174@103.250.184.229:1212','user-34068:214859b73da0e174@103.250.184.252:1212','user-34068:214859b73da0e174@45.64.106.29:1212','user-34068:214859b73da0e174@45.64.106.38:1212','user-34068:214859b73da0e174@103.12.211.82:1212','user-34068:214859b73da0e174@45.64.106.31:1212','user-34068:214859b73da0e174@45.64.105.154:1212','user-34068:214859b73da0e174@45.64.106.24:1212','user-34068:214859b73da0e174@45.64.106.41:1212']
				prox = random.choice(inpl)
				proxies      = {"https": "http://{}".format(prox)}
				hml = sr.get(url, headers=head, proxies=proxies)
				
				
			html = hml.text
			html = unidecode(html).encode('ascii')
			if hml.history:
				if str(hml.history[0]) == '<Response [301]>':
					region = ''
					keyvalue = "ondemand/{}/{:%Y%m%d}/source/{}.html".format(Websitecode, datetime.datetime.now(), str(inputid) + '_' + str(Rtdate) + '_' + id_update)
					key = bucket.new_key(keyvalue)
					key.set_contents_from_string(html)
					statuscode = 5
					Guests = '1'
					array.append(aws_insert.insert(id_update, inputid , functionname, Websitecode, "", "", "", "", Guests, "", "", "", "", "", url, url, url, "", "", "", "", "", "", StartDate, EndDate , "", "", "", "", "", "", "", "", "", region, statuscode, israteperstay))
					return json.dumps(array)
		keyvalue = "ondemand/{}/{:%Y%m%d}/source/{}.html".format(Websitecode, datetime.datetime.now(), str(inputid) + '_' + str(Rtdate) + '_' + id_update)
		key = bucket.new_key(keyvalue)
		key.set_contents_from_string(html)
		region = ''
		Rtdate = re.sub(r'-|\-', '', str(RateDate))				
		if "We have no availability" in html:
			#print "no availablity"
			Closed_up = 'Y'
			statuscode = '2'
			israteperstay = ''
			array.append(aws_insert.insert(id_update, inputid , functionname, Websitecode, "", "", "", "", Guests, "", "", "", "", "", url, url, url, "", "", "", "", Closed_up, "", StartDate, EndDate , "", "", "", "", "", "", "", "", "", region, statuscode, israteperstay))
			keyvalue = "ondemand/{}/{:%Y%m%d}/delivery/{}.json".format(Websitecode, datetime.datetime.now(), str(inputid) + '_' + str(Rtdate) + '_' + id_update)
			key = bucket.new_key(keyvalue)
			key.set_contents_from_string(json.dumps(array))			
			return json.dumps(array)
# 		else:
# 			print "Rooms Available"
		Taxtype_reg_2_remove = ''
		Roomtype = ""
		OnsiteRate = 0
		GrossRate = 0
		Currencycode = " "
		Closed_up = 'N'
		Mealtype = " "
		RoomAmenityType = ""
		discount_rate = 0
		net_rate = 0
		RoomDescp = ''
		Maxocp = ''
		ispromupdate = 'N'
		promotion = ''
		Roomavilable = ''
		Taxtype = ''
		Taxamount = 0
		Ratetype = ''
		Tax_status = '-1'
		RoomDescp = ''
		if MainBlock_regex.findall(html):
			#print 'Price Available'
			for mainblock in MainBlock_regex.findall(html):
				RoomDescp = ''
				if re.search(r'data-room-id="(.*?)"', mainblock):
					Rmid = re.search(r'data-room-id="(.*?)"', mainblock).group(1)
					Roomtype = ""
					OnsiteRate = 0
					GrossRate = 0
					Currencycode = " "
					Closed_up = 'N'
					Mealtype = " "
					RoomAmenityType = ""
					discount_rate = 0
					net_rate = 0
					RoomDescp = ''
					Maxocp = ''
					ispromupdate = 'N'
					promotion = ''
					Roomavilable = ''
					Taxtype = ''
					Taxamount = 0
					Ratetype = ''
					Tax_status = '-1'
				else:
					Rmid = '0'
					Roomtype = ""
					OnsiteRate = 0
					GrossRate = 0
					Currencycode = " "
					Closed_up = 'N'
					Mealtype = " "
					RoomAmenityType = ""
					discount_rate = 0
					net_rate = 0
					RoomDescp = ''
					Maxocp = ''
					ispromupdate = 'N'
					promotion = ''
					Roomavilable = ''
					Taxtype = ''
					Taxamount = 0
					Ratetype = ''
					Tax_status = '-1'
					
				Rmdespblock_formation = '(<div class="hprt-lightbox js_hp_rt_lightbox_facilities.*?data-room-id="%s.*?class="feedback-loop feedback)' %Rmid 
				Rmdespblock_reg = re.search(Rmdespblock_formation, html, re.DOTALL)
				if Rmdespblock_reg:
					Rmdespblock = Rmdespblock_reg.group(1)
					match = re.search(r"sold out|You missed it! Sold", Rmdespblock, re.IGNORECASE)
					if match:
						RoomDescp = ''
					else:
						RoomDescp_reg_check = re.search(r'<div class="hprt-lightbox-right-container.*?>(.*?)<p class="hprt-lightbox-title">',Rmdespblock, re.DOTALL)
						if RoomDescp_reg_check:
							RoomDescp = RoomDescp_reg_check.group(1)
							RoomDescp = re.sub(r"<.*?>|\\\n", "", re.sub("'", "''", re.sub("\s+", " ",re.sub("(?sim)<.*?>", " ", re.sub(r"<.*?>|&.*?;", r" ", re.sub(r"</p>", r", ", RoomDescp))))))
							Ft_reg = Ft_reg_check(RoomDescp)
							if Ft_reg:
								RoomDescp = re.sub("\d+\s*ft|'", Ft_reg, RoomDescp)
							else:
								RoomDescp = ''
						else:
							RoomDescp = ''
				else:
					RoomDescp = ''
				RoomDescp_reg2 = re.compile('<ul\s*class="rt-bed-types"\s*>\s*(.*?)\s*</ul>', re.DOTALL).findall(mainblock)
				if RoomDescp_reg2:
					RoomDescp_first = ''
					RoomDescp_first = re.sub(r"\[|\]|\\n'|'\\n", "", str(RoomDescp_reg2))
					#RoomDescp_first = ratedescription_first_replace(RoomDescp_first)
					RoomDescp_first = re.sub("'", "''", re.sub("\s+", " ",re.sub("(?sim)<.*?>", " ", re.sub(r"<.*?>|&.*?;", r" ", re.sub(r"</p>", r", ", RoomDescp_first)))))
					Ft_reg = Ft_reg_check(RoomDescp_first)
					if Ft_reg:
						RoomDescp_first = re.sub("\d+\s*ft|'", Ft_reg, RoomDescp_first)
				
				else:
					RoomDescp_reg2_else = re.compile('<ul\s*class="room-config".*?>\s*(.*?)\s*</ul>', re.DOTALL).findall(mainblock)
					if RoomDescp_reg2_else:
						RoomDescp_first = ''
						RoomDescp_first = re.sub(r"\[|\]|\\n'|'\\n", "", str(RoomDescp_reg2_else))
						#RoomDescp_first = ratedescription_first_replace(RoomDescp_first)
						RoomDescp_first = re.sub("'", "''", re.sub("\s+", " ",re.sub("(?sim)<.*?>", " ", re.sub(r"<.*?>|&.*?;", r" ", re.sub(r"</p>", r", ", RoomDescp_first)))))
						Ft_reg = Ft_reg_check(RoomDescp_first)
						if Ft_reg:
							RoomDescp_first = re.sub("\d+\s*ft|'", Ft_reg, RoomDescp_first)
					else:
						RoomDescp_first = ''
				RoomDescp = re.sub(r"<.*?>|\\n|\\", "",(str(RoomDescp) + ' ' + str(RoomDescp_first)).strip())
				RoomDescp = re.sub(r"\s+"," ",RoomDescp).strip()
# 				print 'frist_Tax_status:',Tax_status
				Taxtype_reg_block = re.search('class="\s*hptr-taxinfo-.*?>(.*?\s*</div>\s*</div>)', mainblock, re.DOTALL)
				if Taxtype_reg_block:
					Taxtype_reg = Taxtype_reg_block.group(1)
					Tax_reg = re.findall(re.compile(r'class=[\'|\"]hptr-taxinfo-label[\'|\"]\s*>\s*(.*?)\s*</div>', re.DOTALL), Taxtype_reg)
					if Tax_reg:
						Taxtype = re.sub("\[|\]|u'|(?s)\\n", "", str(Tax_reg))
				else:
					Taxtype_reg_block = re.search('class="\s*small\s.*?>(.*?)\s*</div>\s*<!-- end', mainblock, re.DOTALL)
					if Taxtype_reg_block:
						Taxtype_reg = Taxtype_reg_block.group(1)
						Tax_reg = re.findall(re.compile('incExcEmphasize">(.*?)</div>', re.DOTALL), Taxtype_reg)
						if Tax_reg:
							Taxtype = re.sub("\[|\]|u'|(?s)\\n", "", str(Tax_reg))
						else:
							Tax_reg = re.findall(re.compile('incExc.*?</div>(.*?)</div>', re.DOTALL), Taxtype_reg)
							if Tax_reg:
								Taxtype = re.sub("\[|\]|u'|(?s)\\n", "", str(Tax_reg))
				Taxtype = re.sub ("'", "''", Taxtype)
				Taxtype = re.sub ("'+", "''", Taxtype)
				Taxtype = re.sub("&.*?;", "&", Taxtype).strip()
				Taxtype = re.sub("^,", "", Taxtype)
				Taxtype = re.sub(r"(?s)\\n|(?s)<.*?>", r"", Taxtype)
				Taxtype = re.sub("\s+", " ", Taxtype).strip()
				includedtype_reg = re.findall(r'class=[\'|\"]incExcEmphasize[\'|\"]\s*>\s*(.*?)\s*</', mainblock)
				if includedtype_reg:
				    for includedtype_check in includedtype_reg:
				        includedtype_remove = includedtype_check
				        includedtype_check2 = re.sub(r"\d+\.\d+\s*\%\s*Property\s*service\s*charge|\d+\s*\%\s*Property\s*service\s*charge","",re.sub(r'(?i)Included\s*Breakfast|Included\s*Dinner|Included\s*Lunch|Excluded\s*Breakfast|Excluded\s*Dinner|Excluded\s*Lunch|Included\s*in.*?price\s*Breakfast|Included\s*All-Inclusive|Included\s*Half\s*board|Included\s*in.*?price\s*Full\s*board|Included\s*in.*?price\s*Half\s*board|Included\s*in.*?price\s*All-Inclusive|Included\s*Full\s*board|Excluded\s*\d+\.\d+\s*\%\s*Property\s*service\s*charge\s*,\s*Breakfast|Excluded\s*\d+\s*\%\s*Property\s*service\s*charge\s*,\s*Breakfast|Included\s*\d+\.\d+\s*\%\s*Property\s*service\s*charge\s*,\s*Breakfast|Included\s*\d+\s*\%\s*Property\s*service\s*charge\s*,\s*Breakfast|Included\s*in.*?price\s*\d+\.\d+\s*\%\s*Property\s*service\s*charge\s*,\s*Breakfast|Included\s*in.*?price\s*\d+\s*\%\s*Property\s*service\s*charge\s*,\s*Breakfast|Excluded\s*\d+\.\d+\s*\%\s*Property\s*service\s*charge|Excluded\s*\d+\s*\%\s*Property\s*service\s*charge|Included\s*\d+\.\d+\s*\%\s*Property\s*service\s*charge|Included\s*\d+\s*\%\s*Property\s*service\s*charge|Included\s*in.*?price\s*\d+\.\d+\s*\%\s*Property\s*service\s*charge|Included\s*in.*?price\s*\d+\s*\%\s*Property\s*service\s*charge|Not\s*included\s*credit\s*card\s*fee|Not\s*included\s*in\s*apartment\s*price\s*credit\s*card\s*fee|Excluded\s*credit\s*card\s*fee|Included\s*in.*?price\s*[A-Z][A-Z][A-Z]\s*\d+\.\d+\s*Property\s*service\s*charge\s*per\s*night|Included\s*in.*?price\s*[A-Z][A-Z][A-Z]\s*\d+\s*Property\s*service\s*charge\s*per\s*night|Included\s*in.*?price\s*[A-Z][A-Z][A-Z]\s*\d+\.\d+\s*Property\s*service\s*charge|Included\s*in.*?price\s*[A-Z][A-Z][A-Z]\s*\d+\s*Property\s*service\s*charge|Excluded\s*[A-Z][A-Z][A-Z]\s*\d+\.\d+\s*Property\s*service\s*charge\s*per\s*night|Excluded\s*[A-Z][A-Z][A-Z]\s*\d+\s*Property\s*service\s*charge\s*per\s*night|Excluded\s*[A-Z][A-Z][A-Z]\s*\d+\.\d+\s*Property\s*service\s*charge|Excluded\s*[A-Z][A-Z][A-Z]\s*\d+\s*Property\s*service\s*charge', '', str(includedtype_check))).strip()
				        if 'tax' not in includedtype_check2.lower() and 'vat' not in includedtype_check2.lower() and '%' not in includedtype_check2.lower():
				            if 'fee' in includedtype_check2.lower():
				                includedtype_reg.remove(includedtype_remove)
				    if includedtype_reg:
				        includedtype = re.sub("\s+", " ", re.sub("'", "''", re.sub(r"<.*?>|\:", r"", reduce(operator.add, includedtype_reg))))
				    else:
				        includedtype = ''
				else:
				    includedtype_reg = re.findall(r'class=[\'|\"]hptr-taxinfo-label[\'|\"]\s*>\s*(.*?)\s*</div', mainblock, re.DOTALL)
				    if includedtype_reg:
				        for includedtype_check in includedtype_reg:
				            includedtype_remove = includedtype_check
				            includedtype_check2 = re.sub(r"\d+\.\d+\s*\%\s*Property\s*service\s*charge|\d+\s*\%\s*Property\s*service\s*charge","",re.sub(r'(?i)Included\s*Breakfast|Included\s*Dinner|Included\s*Lunch|Excluded\s*Breakfast|Excluded\s*Dinner|Excluded\s*Lunch|Included\s*in.*?price\s*Breakfast|Included\s*All-Inclusive|Included\s*Half\s*board|Included\s*in.*?price\s*Full\s*board|Included\s*in.*?price\s*Half\s*board|Included\s*in.*?price\s*All-Inclusive|Included\s*Full\s*board|Excluded\s*\d+\.\d+\s*\%\s*Property\s*service\s*charge\s*,\s*Breakfast|Excluded\s*\d+\s*\%\s*Property\s*service\s*charge\s*,\s*Breakfast|Included\s*\d+\.\d+\s*\%\s*Property\s*service\s*charge\s*,\s*Breakfast|Included\s*\d+\s*\%\s*Property\s*service\s*charge\s*,\s*Breakfast|Included\s*in.*?price\s*\d+\.\d+\s*\%\s*Property\s*service\s*charge\s*,\s*Breakfast|Included\s*in.*?price\s*\d+\s*\%\s*Property\s*service\s*charge\s*,\s*Breakfast|Excluded\s*\d+\.\d+\s*\%\s*Property\s*service\s*charge|Excluded\s*\d+\s*\%\s*Property\s*service\s*charge|Included\s*\d+\.\d+\s*\%\s*Property\s*service\s*charge|Included\s*\d+\s*\%\s*Property\s*service\s*charge|Included\s*in.*?price\s*\d+\.\d+\s*\%\s*Property\s*service\s*charge|Included\s*in.*?price\s*\d+\s*\%\s*Property\s*service\s*charge|Not\s*included\s*credit\s*card\s*fee|Not\s*included\s*in\s*apartment\s*price\s*credit\s*card\s*fee|Excluded\s*credit\s*card\s*fee|Included\s*in.*?price\s*[A-Z][A-Z][A-Z]\s*\d+\.\d+\s*Property\s*service\s*charge\s*per\s*night|Included\s*in.*?price\s*[A-Z][A-Z][A-Z]\s*\d+\s*Property\s*service\s*charge\s*per\s*night|Included\s*in.*?price\s*[A-Z][A-Z][A-Z]\s*\d+\.\d+\s*Property\s*service\s*charge|Included\s*in.*?price\s*[A-Z][A-Z][A-Z]\s*\d+\s*Property\s*service\s*charge|Excluded\s*[A-Z][A-Z][A-Z]\s*\d+\.\d+\s*Property\s*service\s*charge\s*per\s*night|Excluded\s*[A-Z][A-Z][A-Z]\s*\d+\s*Property\s*service\s*charge\s*per\s*night|Excluded\s*[A-Z][A-Z][A-Z]\s*\d+\.\d+\s*Property\s*service\s*charge|Excluded\s*[A-Z][A-Z][A-Z]\s*\d+\s*Property\s*service\s*charge', '', str(includedtype_check))).strip()
				            if 'tax' not in includedtype_check2.lower() and 'vat' not in includedtype_check2.lower() and '%' not in includedtype_check2.lower():
				                if 'fee' in includedtype_check2.lower():
				                    includedtype_reg.remove(includedtype_remove)
				        if includedtype_reg:
				            includedtype = re.sub("\s+", " ", re.sub("'", "''", re.sub(r"<.*?>|\:", r"", reduce(operator.add, includedtype_reg))))
				        else:
				            includedtype = ''
				    else:
				        includedtype = ''
				# 				print "before", includedtype
				includedtype = re.sub(r"\d+\.\d+\s*\%\s*Property\s*service\s*charge|\d+\s*\%\s*Property\s*service\s*charge","",re.sub(r'(?i)Included\s*Breakfast|Included\s*Dinner|Included\s*Lunch|Excluded\s*Breakfast|Excluded\s*Dinner|Excluded\s*Lunch|Included\s*in.*?price\s*Breakfast|Included\s*All-Inclusive|Included\s*Half\s*board|Included\s*in.*?price\s*Full\s*board|Included\s*in.*?price\s*Half\s*board|Included\s*in.*?price\s*All-Inclusive|Included\s*Full\s*board|Excluded\s*\d+\.\d+\s*\%\s*Property\s*service\s*charge\s*,\s*Breakfast|Excluded\s*\d+\s*\%\s*Property\s*service\s*charge\s*,\s*Breakfast|Included\s*\d+\.\d+\s*\%\s*Property\s*service\s*charge\s*,\s*Breakfast|Included\s*\d+\s*\%\s*Property\s*service\s*charge\s*,\s*Breakfast|Included\s*in.*?price\s*\d+\.\d+\s*\%\s*Property\s*service\s*charge\s*,\s*Breakfast|Included\s*in.*?price\s*\d+\s*\%\s*Property\s*service\s*charge\s*,\s*Breakfast|Excluded\s*\d+\.\d+\s*\%\s*Property\s*service\s*charge|Excluded\s*\d+\s*\%\s*Property\s*service\s*charge|Included\s*\d+\.\d+\s*\%\s*Property\s*service\s*charge|Included\s*\d+\s*\%\s*Property\s*service\s*charge|Included\s*in.*?price\s*\d+\.\d+\s*\%\s*Property\s*service\s*charge|Included\s*in.*?price\s*\d+\s*\%\s*Property\s*service\s*charge|Not\s*included\s*credit\s*card\s*fee|Not\s*included\s*in\s*apartment\s*price\s*credit\s*card\s*fee|Excluded\s*credit\s*card\s*fee|Included\s*in.*?price\s*[A-Z][A-Z][A-Z]\s*\d+\.\d+\s*Property\s*service\s*charge\s*per\s*night|Included\s*in.*?price\s*[A-Z][A-Z][A-Z]\s*\d+\s*Property\s*service\s*charge\s*per\s*night|Included\s*in.*?price\s*[A-Z][A-Z][A-Z]\s*\d+\.\d+\s*Property\s*service\s*charge|Included\s*in.*?price\s*[A-Z][A-Z][A-Z]\s*\d+\s*Property\s*service\s*charge|Excluded\s*[A-Z][A-Z][A-Z]\s*\d+\.\d+\s*Property\s*service\s*charge\s*per\s*night|Excluded\s*[A-Z][A-Z][A-Z]\s*\d+\s*Property\s*service\s*charge\s*per\s*night|Excluded\s*[A-Z][A-Z][A-Z]\s*\d+\.\d+\s*Property\s*service\s*charge|Excluded\s*[A-Z][A-Z][A-Z]\s*\d+\s*Property\s*service\s*charge', '', str(includedtype))).strip()
				if 'tax' not in includedtype.lower() and 'vat' not in includedtype.lower() and '%' not in includedtype.lower():
					if 'fee' in includedtype.lower():
						includedtype = ''
				# 				includedtype = re.sub(r'(?i)Included\s*Breakfast|Included\s*Dinner|Included\s*Lunch|Excluded\s*Breakfast|Excluded\s*Dinner|Excluded\s*Lunch|Included\s*in.*?price\s*Breakfast|Included\s*All-Inclusive|Included\s*Half\s*board', '', str(includedtype)).strip()
				# 				print len(includedtype)
				# 				print "before", includedtype
				if includedtype:
					included_match_first = re.search('^included.*?not included', includedtype.lower())
					included_match_first_else = re.search('^included.*?exclude', includedtype.lower())
					included_match = re.search('^includednot included', includedtype.lower())
					included_match_else = re.search('^includedexclude', includedtype.lower())
					if included_match_first:
						Tax_status = '3'
					elif included_match:
						Tax_status = '3'
					elif included_match_else:
						Tax_status = '3'
					elif included_match_first_else:
						Tax_status = '3'
					elif 'not included' in includedtype.lower() or 'exclude' in includedtype.lower():
						Tax_status = '2'
					else:
						Tax_status = '1'
				elif 'incExcEmphasize">Not included</span>' in mainblock:
					Tax_status = '3'
# 				print 'Tax_status:',Tax_status
				amenites_regex = re.search(r'<ul class="hprt-lightbox-list"\s*data-nr-of-facilities="\d+"\s*>(.*?)</ul>', mainblock, re.DOTALL)
				if amenites_regex:
					amenites_dedupe = amenites_regex.group(1)
					RoomAmenityType = re.sub("&bull;", ", ", amenites_dedupe)
				else:
					amenites_regex = re.search(r'<div class="hprt-facilities-block" data-component=".*?">(.*?)</ul>\s*</div>\s*</div>\s*</div>\s*</div>', mainblock, re.DOTALL)
					if amenites_regex:
						amenites_dedupe = amenites_regex.group(1)
						RoomAmenityType = re.sub(r"Disabilities</span>","Disabilities :",re.sub(r"</ul>",";",re.sub("See the accommodations", "", re.sub('</i>|&bull;', ", ", amenites_dedupe))))
					else:
						amenites_regex = re.search(r'<div class="hprt-facilities-block" data-component=".*?">(.*?)</ul>', mainblock, re.DOTALL)
						if amenites_regex:
							amenites_dedupe = amenites_regex.group(1)
							RoomAmenityType = re.sub("See the accommodations", "", re.sub('</i>|&bull;', ", ", amenites_dedupe))
						else:
							amenites_regex = re.search(r'<div class="hprt-facilities-block" data-component=".*?">(.*?)</div>', mainblock, re.DOTALL)
							if amenites_regex:
								amenites_dedupe = amenites_regex.group(1)
								RoomAmenityType = re.sub("See the accommodations", "", re.sub('</i>|&bull;', ", ", amenites_dedupe))
							else:
								RoomAmenityType = ''
				#print '\n\nRoomAmenityType:',RoomAmenityType
				RoomAmenityType = re.sub('<span class="jq_tooltip hp_rt_rs_ds" title="" >|\'|eatures a|More|Room Amenities|nbsp;|^:|Type|&bull;|(?sim)<.*?>', "", RoomAmenityType)
				RoomAmenityType = re.sub(r"\s+", r" ", RoomAmenityType)
				#print '\n\nRoomAmenityType:',RoomAmenityType
				RoomAmenityType = re.sub(r"Can you tell us what youd like to see here\? \(Well use your feedback to improve the information in this section\)\;|<.*|-.*?\">|^,", "", RoomAmenityType.strip()).strip()
				if len(RoomAmenityType) > 4000:
					RoomAmenityType = str(RoomAmenityType)[:3999]
				includedtype_1 = ''
				for spaceblock in Room1_block_regex.findall(mainblock):
					da_time = datetime.datetime.now()
					intime = re.sub(r'\s', 'T', str(da_time))
					RoomType_reg = re.search(r'hprt-roomtype-name-arrow"></span>\s*(.*?)\s*</a>', spaceblock , re.DOTALL)
					if RoomType_reg:
						Roomtype = RoomType_reg.group(1)
					else:
						RoomType_reg = re.search(r'class="hprt-roomtype-link.*?>\s*(.*?)\s*</', spaceblock, re.DOTALL)
						if RoomType_reg:
							Roomtype = RoomType_reg.group(1)
						else:
							RoomType_reg = re.search(r'class="hprt-roomtype-icon-link__photo-icon">\s*(.*?)\s*</a>', spaceblock, re.DOTALL)
							if RoomType_reg:
								Roomtype = RoomType_reg.group(1)
					Roomtype = re.sub(r"<.*?>|Special Conditions|Non-Ref.*|Non-ref.*|Refundable|refundable", r"", Roomtype)
					Roomtype = re.sub("'", "''", Roomtype)
					Roomtype = re.sub("&.*?;", "", Roomtype)
					Roomtype = re.sub("\s+", " ", Roomtype).strip()
					Roomavilable_reg = re.search(r'[o|O]nly\s*(.*?)\s*room', spaceblock)
					if Roomavilable_reg:
						Roomavilable = Roomavilable_reg.group(1)
					else:
						Roomavilable_reg = re.search(r'[o|O]nly\s*(.*?)\s*room', mainblock)
						if Roomavilable_reg:
							Roomavilable = Roomavilable_reg.group(1)
						else:
							Roomavilable = ''
					Taxtype_reg_block = re.search('class="\s*hptr-taxinfo-.*?>(.*?\s*</div>\s*</div>)', spaceblock, re.DOTALL)
					if Taxtype_reg_block:
						Taxtype_reg = Taxtype_reg_block.group(1)
						_reg = re.findall(re.compile(r'class=\s*[\'|\"]\s*hptr-taxinfo-label.*?[\'|\"]\s*>\s*(.*?)\s*</div>', re.DOTALL), Taxtype_reg)
						if Tax_reg:
							Taxtype = re.sub("\[|\]|u'|(?s)\\n", "", str(Tax_reg))
					else:
						Taxtype_reg_block = re.search('class="\s*small\s.*?>(.*?)\s*</div>\s*<!-- end',spaceblock,re.DOTALL)
						if Taxtype_reg_block:
							Taxtype_reg = Taxtype_reg_block.group(1)
							Tax_reg =  re.findall(re.compile('incExcEmphasize">(.*?)</div>', re.DOTALL), Taxtype_reg)
							if Tax_reg:
								Taxtype = re.sub("\[|\]|u'|(?s)\\n", "", str(Tax_reg))
							else:
								Tax_reg =  re.findall(re.compile('incExc.*?</div>(.*?)</div>', re.DOTALL), Taxtype_reg)
								if Tax_reg:
									Taxtype = re.sub("\[|\]|u'|(?s)\\n", "", str(Tax_reg))
# 					print 'Taxtype:',Taxtype
					Taxtype_reg_block2 = re.search('class=[\'|\"]prd-taxes-and-fees-under-price .*?-hpage blockuid-\d+.*?\s*>\s*(.*?)\s*</div',spaceblock)
					if Taxtype_reg_block2:
						Taxtype = re.sub(str(Taxtype_reg_2_remove).strip(),"",str(Taxtype))
						Taxtype_reg_2 = re.sub(r"\+","exclude ",Taxtype_reg_block2.group(1))   
						Taxtype = str(Taxtype)+', '+str(Taxtype_reg_2) 
						Taxtype_reg_2_remove = re.sub(r"\.","\.",re.sub(r"\$","\$",Taxtype_reg_2))       
# 					print 'Taxtype:',Taxtype
					Taxtype = re.sub ("'", "''", Taxtype)
					Taxtype = re.sub ("'+", "''", Taxtype)
					Taxtype = re.sub("&.*?;", "&", Taxtype).strip()
					Taxtype = re.sub("^,", "", Taxtype)
					Taxtype = re.sub(", ,", ",", Taxtype)
					Taxtype = re.sub(r"(?s)\\n|(?s)<.*?>", r"", Taxtype)
					Taxtype = re.sub("\s+", " ", Taxtype).strip()
					includedtype_reg = re.findall(r'class=[\'|\"]incExcEmphasize[\'|\"]\s*>\s*(.*?)\s*</', spaceblock)
					if includedtype_reg:
					    for includedtype_check in includedtype_reg:
					        includedtype_remove = includedtype_check
					        includedtype_check2 = re.sub(r"\d+\.\d+\s*\%\s*Property\s*service\s*charge|\d+\s*\%\s*Property\s*service\s*charge","",re.sub(r'(?i)Included\s*Breakfast|Included\s*Dinner|Included\s*Lunch|Excluded\s*Breakfast|Excluded\s*Dinner|Excluded\s*Lunch|Included\s*in.*?price\s*Breakfast|Included\s*All-Inclusive|Included\s*Half\s*board|Included\s*in.*?price\s*Full\s*board|Included\s*in.*?price\s*Half\s*board|Included\s*in.*?price\s*All-Inclusive|Included\s*Full\s*board|Excluded\s*\d+\.\d+\s*\%\s*Property\s*service\s*charge\s*,\s*Breakfast|Excluded\s*\d+\s*\%\s*Property\s*service\s*charge\s*,\s*Breakfast|Included\s*\d+\.\d+\s*\%\s*Property\s*service\s*charge\s*,\s*Breakfast|Included\s*\d+\s*\%\s*Property\s*service\s*charge\s*,\s*Breakfast|Included\s*in.*?price\s*\d+\.\d+\s*\%\s*Property\s*service\s*charge\s*,\s*Breakfast|Included\s*in.*?price\s*\d+\s*\%\s*Property\s*service\s*charge\s*,\s*Breakfast|Excluded\s*\d+\.\d+\s*\%\s*Property\s*service\s*charge|Excluded\s*\d+\s*\%\s*Property\s*service\s*charge|Included\s*\d+\.\d+\s*\%\s*Property\s*service\s*charge|Included\s*\d+\s*\%\s*Property\s*service\s*charge|Included\s*in.*?price\s*\d+\.\d+\s*\%\s*Property\s*service\s*charge|Included\s*in.*?price\s*\d+\s*\%\s*Property\s*service\s*charge|Not\s*included\s*credit\s*card\s*fee|Not\s*included\s*in\s*apartment\s*price\s*credit\s*card\s*fee|Excluded\s*credit\s*card\s*fee|Included\s*in.*?price\s*[A-Z][A-Z][A-Z]\s*\d+\.\d+\s*Property\s*service\s*charge\s*per\s*night|Included\s*in.*?price\s*[A-Z][A-Z][A-Z]\s*\d+\s*Property\s*service\s*charge\s*per\s*night|Included\s*in.*?price\s*[A-Z][A-Z][A-Z]\s*\d+\.\d+\s*Property\s*service\s*charge|Included\s*in.*?price\s*[A-Z][A-Z][A-Z]\s*\d+\s*Property\s*service\s*charge|Excluded\s*[A-Z][A-Z][A-Z]\s*\d+\.\d+\s*Property\s*service\s*charge\s*per\s*night|Excluded\s*[A-Z][A-Z][A-Z]\s*\d+\s*Property\s*service\s*charge\s*per\s*night|Excluded\s*[A-Z][A-Z][A-Z]\s*\d+\.\d+\s*Property\s*service\s*charge|Excluded\s*[A-Z][A-Z][A-Z]\s*\d+\s*Property\s*service\s*charge', '', str(includedtype_check))).strip()
					        if 'tax' not in includedtype_check2.lower() and 'vat' not in includedtype_check2.lower() and '%' not in includedtype_check2.lower():
					            if 'fee' in includedtype_check2.lower():
					                includedtype_reg.remove(includedtype_remove)
					    if includedtype_reg:
					        includedtype = re.sub("\s+", " ", re.sub("'", "''", re.sub(r"<.*?>|\:", r"", reduce(operator.add, includedtype_reg))))
					    else:
					        includedtype = ''
					else:
					    includedtype_reg = re.findall(r'class=[\'|\"]prd-taxes-and-fees-under-price .*?-hpage blockuid-\d+.*?\s*>\s*(.*?)\s*</div', spaceblock)
					    if includedtype_reg:
					        for includedtype_check in includedtype_reg:
					            includedtype_remove = includedtype_check
					            includedtype_check2 = re.sub(r"\d+\.\d+\s*\%\s*Property\s*service\s*charge|\d+\s*\%\s*Property\s*service\s*charge","",re.sub(r'(?i)Included\s*Breakfast|Included\s*Dinner|Included\s*Lunch|Excluded\s*Breakfast|Excluded\s*Dinner|Excluded\s*Lunch|Included\s*in.*?price\s*Breakfast|Included\s*All-Inclusive|Included\s*Half\s*board|Included\s*in.*?price\s*Full\s*board|Included\s*in.*?price\s*Half\s*board|Included\s*in.*?price\s*All-Inclusive|Included\s*Full\s*board|Excluded\s*\d+\.\d+\s*\%\s*Property\s*service\s*charge\s*,\s*Breakfast|Excluded\s*\d+\s*\%\s*Property\s*service\s*charge\s*,\s*Breakfast|Included\s*\d+\.\d+\s*\%\s*Property\s*service\s*charge\s*,\s*Breakfast|Included\s*\d+\s*\%\s*Property\s*service\s*charge\s*,\s*Breakfast|Included\s*in.*?price\s*\d+\.\d+\s*\%\s*Property\s*service\s*charge\s*,\s*Breakfast|Included\s*in.*?price\s*\d+\s*\%\s*Property\s*service\s*charge\s*,\s*Breakfast|Excluded\s*\d+\.\d+\s*\%\s*Property\s*service\s*charge|Excluded\s*\d+\s*\%\s*Property\s*service\s*charge|Included\s*\d+\.\d+\s*\%\s*Property\s*service\s*charge|Included\s*\d+\s*\%\s*Property\s*service\s*charge|Included\s*in.*?price\s*\d+\.\d+\s*\%\s*Property\s*service\s*charge|Included\s*in.*?price\s*\d+\s*\%\s*Property\s*service\s*charge|Not\s*included\s*credit\s*card\s*fee|Not\s*included\s*in\s*apartment\s*price\s*credit\s*card\s*fee|Excluded\s*credit\s*card\s*fee|Included\s*in.*?price\s*[A-Z][A-Z][A-Z]\s*\d+\.\d+\s*Property\s*service\s*charge\s*per\s*night|Included\s*in.*?price\s*[A-Z][A-Z][A-Z]\s*\d+\s*Property\s*service\s*charge\s*per\s*night|Included\s*in.*?price\s*[A-Z][A-Z][A-Z]\s*\d+\.\d+\s*Property\s*service\s*charge|Included\s*in.*?price\s*[A-Z][A-Z][A-Z]\s*\d+\s*Property\s*service\s*charge|Excluded\s*[A-Z][A-Z][A-Z]\s*\d+\.\d+\s*Property\s*service\s*charge\s*per\s*night|Excluded\s*[A-Z][A-Z][A-Z]\s*\d+\s*Property\s*service\s*charge\s*per\s*night|Excluded\s*[A-Z][A-Z][A-Z]\s*\d+\.\d+\s*Property\s*service\s*charge|Excluded\s*[A-Z][A-Z][A-Z]\s*\d+\s*Property\s*service\s*charge', '', str(includedtype_check))).strip()
					            if 'tax' not in includedtype_check2.lower() and 'vat' not in includedtype_check2.lower() and '%' not in includedtype_check2.lower():
					                if 'fee' in includedtype_check2.lower():
					                    includedtype_reg.remove(includedtype_remove)
					        if includedtype_reg:
					            includedtype = re.sub("\s+", " ", re.sub("'", "''", re.sub(r"<.*?>|\:", r"", reduce(operator.add, includedtype_reg))))
					        else:
					            includedtype = ''
					    else:
					        includedtype = ''
					includedtype_1_reg = re.findall(r'class=[\'|\"]hptr-taxinfo-label[\'|\"]\s*>\s*(.*?)\s*</div', spaceblock, re.DOTALL)
					if includedtype_1_reg:
					    for includedtype_check in includedtype_1_reg:
					        includedtype_remove = includedtype_check
					        includedtype_check2 = re.sub(r"\d+\.\d+\s*\%\s*Property\s*service\s*charge|\d+\s*\%\s*Property\s*service\s*charge","",re.sub(r'(?i)Included\s*Breakfast|Included\s*Dinner|Included\s*Lunch|Excluded\s*Breakfast|Excluded\s*Dinner|Excluded\s*Lunch|Included\s*in.*?price\s*Breakfast|Included\s*All-Inclusive|Included\s*Half\s*board|Included\s*in.*?price\s*Full\s*board|Included\s*in.*?price\s*Half\s*board|Included\s*in.*?price\s*All-Inclusive|Included\s*Full\s*board|Excluded\s*\d+\.\d+\s*\%\s*Property\s*service\s*charge\s*,\s*Breakfast|Excluded\s*\d+\s*\%\s*Property\s*service\s*charge\s*,\s*Breakfast|Included\s*\d+\.\d+\s*\%\s*Property\s*service\s*charge\s*,\s*Breakfast|Included\s*\d+\s*\%\s*Property\s*service\s*charge\s*,\s*Breakfast|Included\s*in.*?price\s*\d+\.\d+\s*\%\s*Property\s*service\s*charge\s*,\s*Breakfast|Included\s*in.*?price\s*\d+\s*\%\s*Property\s*service\s*charge\s*,\s*Breakfast|Excluded\s*\d+\.\d+\s*\%\s*Property\s*service\s*charge|Excluded\s*\d+\s*\%\s*Property\s*service\s*charge|Included\s*\d+\.\d+\s*\%\s*Property\s*service\s*charge|Included\s*\d+\s*\%\s*Property\s*service\s*charge|Included\s*in.*?price\s*\d+\.\d+\s*\%\s*Property\s*service\s*charge|Included\s*in.*?price\s*\d+\s*\%\s*Property\s*service\s*charge|Not\s*included\s*credit\s*card\s*fee|Not\s*included\s*in\s*apartment\s*price\s*credit\s*card\s*fee|Excluded\s*credit\s*card\s*fee|Included\s*in.*?price\s*[A-Z][A-Z][A-Z]\s*\d+\.\d+\s*Property\s*service\s*charge\s*per\s*night|Included\s*in.*?price\s*[A-Z][A-Z][A-Z]\s*\d+\s*Property\s*service\s*charge\s*per\s*night|Included\s*in.*?price\s*[A-Z][A-Z][A-Z]\s*\d+\.\d+\s*Property\s*service\s*charge|Included\s*in.*?price\s*[A-Z][A-Z][A-Z]\s*\d+\s*Property\s*service\s*charge|Excluded\s*[A-Z][A-Z][A-Z]\s*\d+\.\d+\s*Property\s*service\s*charge\s*per\s*night|Excluded\s*[A-Z][A-Z][A-Z]\s*\d+\s*Property\s*service\s*charge\s*per\s*night|Excluded\s*[A-Z][A-Z][A-Z]\s*\d+\.\d+\s*Property\s*service\s*charge|Excluded\s*[A-Z][A-Z][A-Z]\s*\d+\s*Property\s*service\s*charge', '', str(includedtype_check))).strip()
					        if 'tax' not in includedtype_check2.lower() and 'vat' not in includedtype_check2.lower() and '%' not in includedtype_check2.lower():
					            if 'fee' in includedtype_check2.lower():
					                includedtype_1_reg.remove(includedtype_remove)
					    if includedtype_1_reg:
					        includedtype_1 = re.sub("\s+", " ", re.sub("'", "''", re.sub(r"<.*?>|\:", r"", reduce(operator.add, includedtype_1_reg))))
					    else:
					        includedtype_1 = ''
					includedtype = includedtype_1+' '+includedtype
					includedtype = re.sub(r"\+","exclude ",str(includedtype))
# 					print "before1", includedtype
					includedtype = re.sub(r"\d+\.\d+\s*\%\s*Property\s*service\s*charge|\d+\s*\%\s*Property\s*service\s*charge","",re.sub(r'(?i)Included\s*Breakfast|Included\s*Dinner|Included\s*Lunch|Excluded\s*Breakfast|Excluded\s*Dinner|Excluded\s*Lunch|Included\s*in.*?price\s*Breakfast|Included\s*All-Inclusive|Included\s*Half\s*board|Included\s*in.*?price\s*Full\s*board|Included\s*in.*?price\s*Half\s*board|Included\s*in.*?price\s*All-Inclusive|Included\s*Full\s*board|Excluded\s*\d+\.\d+\s*\%\s*Property\s*service\s*charge\s*,\s*Breakfast|Excluded\s*\d+\s*\%\s*Property\s*service\s*charge\s*,\s*Breakfast|Included\s*\d+\.\d+\s*\%\s*Property\s*service\s*charge\s*,\s*Breakfast|Included\s*\d+\s*\%\s*Property\s*service\s*charge\s*,\s*Breakfast|Included\s*in.*?price\s*\d+\.\d+\s*\%\s*Property\s*service\s*charge\s*,\s*Breakfast|Included\s*in.*?price\s*\d+\s*\%\s*Property\s*service\s*charge\s*,\s*Breakfast|Excluded\s*\d+\.\d+\s*\%\s*Property\s*service\s*charge|Excluded\s*\d+\s*\%\s*Property\s*service\s*charge|Included\s*\d+\.\d+\s*\%\s*Property\s*service\s*charge|Included\s*\d+\s*\%\s*Property\s*service\s*charge|Included\s*in.*?price\s*\d+\.\d+\s*\%\s*Property\s*service\s*charge|Included\s*in.*?price\s*\d+\s*\%\s*Property\s*service\s*charge|Not\s*included\s*credit\s*card\s*fee|Not\s*included\s*in\s*apartment\s*price\s*credit\s*card\s*fee|Excluded\s*credit\s*card\s*fee|Included\s*in.*?price\s*[A-Z][A-Z][A-Z]\s*\d+\.\d+\s*Property\s*service\s*charge\s*per\s*night|Included\s*in.*?price\s*[A-Z][A-Z][A-Z]\s*\d+\s*Property\s*service\s*charge\s*per\s*night|Included\s*in.*?price\s*[A-Z][A-Z][A-Z]\s*\d+\.\d+\s*Property\s*service\s*charge|Included\s*in.*?price\s*[A-Z][A-Z][A-Z]\s*\d+\s*Property\s*service\s*charge|Excluded\s*[A-Z][A-Z][A-Z]\s*\d+\.\d+\s*Property\s*service\s*charge\s*per\s*night|Excluded\s*[A-Z][A-Z][A-Z]\s*\d+\s*Property\s*service\s*charge\s*per\s*night|Excluded\s*[A-Z][A-Z][A-Z]\s*\d+\.\d+\s*Property\s*service\s*charge|Excluded\s*[A-Z][A-Z][A-Z]\s*\d+\s*Property\s*service\s*charge', '', str(includedtype))).strip()
					if 'tax' not in includedtype.lower() and 'vat' not in includedtype.lower() and '%' not in includedtype.lower():
						if 'fee' in includedtype.lower():
							includedtype = ''
# 					print len(includedtype)
# 					print "before1", includedtype
					if includedtype:
						included_match_first = re.search('^included.*?not included', includedtype.lower())
						included_match_first_else = re.search('^included.*?exclude', includedtype.lower())
						included_match = re.search('^includednot included', includedtype.lower())
						included_match_else = re.search('^includedexclude', includedtype.lower())
						if included_match_first:
							Tax_status = '3'
						elif included_match:
							Tax_status = '3'
						elif included_match_else:
							Tax_status = '3'
						elif included_match_first_else:
							Tax_status = '3'
						elif 'not included' in includedtype.lower() or 'exclude' in includedtype.lower():
							Tax_status = '2'
						else:
							Tax_status = '1'
					elif 'incExcEmphasize">Not included</span>' in spaceblock:
						Tax_status = '3'
# 					print 'Tax_status:',Tax_status
					onsite_rate_regex = re.search('rooms-table-room-price.*?"\s*t.*?"\s*>\s*.*?(\d.*?)\s*<', spaceblock, re.DOTALL)
					if onsite_rate_regex:
						OnsiteRate = onsite_rate_regex.group(1)
					else:
						onsite_rate_regex = re.search(r'helper prco-font16-helper">\s*(.*?)\s*</',  spaceblock)
						if onsite_rate_regex:
						    OnsiteRate = onsite_rate_regex.group(1)
						else:
						    onsite_rate_regex = re.search(r'<span class="hprt-price.*?>\s*(.*?)\s*</sp', spaceblock)
						    if onsite_rate_regex:
						        OnsiteRate = re.sub(r"(?s)<.*?>", r"", re.sub("Rs\.|USD\.|Usd\.|z&#x0142;|163;|20AC;|[A-Za-z]|&nbsp;|,|\$|'|&#269;|165;", "", str(onsite_rate_regex.group(1)))).strip()
						        if OnsiteRate == '':
						            onsite_rate_regex = re.search(r"hprt-price-price-(actual|standard).*?>\s*(.*?)\s*</", spaceblock, re.DOTALL)
						            if onsite_rate_regex:
						                OnsiteRate = onsite_rate_regex.group(2)
						    else:
						        onsite_rate_regex = re.search(r"hprt-price-price-(actual|standard).*?>\s*(.*?)\s*</", spaceblock, re.DOTALL)
						        if onsite_rate_regex:
						            OnsiteRate = onsite_rate_regex.group(2)
						        else:
						            onsite_rate_regex = re.search(r'&lt;&#47;ul&gt; &lt;&#47;div&gt; &lt;&#47;div&gt; ">\s*(.*?)\s*</', spaceblock)
						            if onsite_rate_regex:
						                OnsiteRate = onsite_rate_regex.group(1)
						            else:
						                onsite_rate_regex = re.search(r'hp_rt_hovering_price.*?<span.*?>\s*(.*?)\s*</', spaceblock, re.DOTALL)
						                if onsite_rate_regex:
						                    OnsiteRate = onsite_rate_regex.group(1)
						                else:
						                    onsite_rate_regex = re.search(r'class="bui-price-display__value prco-ltr-center-align-helper">\s*(.*?)\s*</', spaceblock,re.DOTALL)
						                    if onsite_rate_regex:
						                        OnsiteRate = onsite_rate_regex.group(1)
						                    else:
						                        onsite_rate_regex = re.search(r'class="prco-valign-middle-helper"\s*>\s*(.*?)\s*</', spaceblock)
						                        if onsite_rate_regex:
						                            OnsiteRate = onsite_rate_regex.group(1)
						                        else:
						                            OnsiteRate = 0
						                            statuscode = '1'
					OnsiteRate = re.sub(r"(?s)<.*?>|=", r"", re.sub("Rs\.|USD\.|Usd\.|z&#x0142;|163;|20AC;|[A-Za-z]|&nbsp;|,|\$|'|&#269;|165;", "", str(OnsiteRate))).strip()
					ect_tax_reg = re.search('class="prd-taxes-and-fees-under-price.*?\s*>\s*\+\s*(.*?\s*\d.*?)\s*</', spaceblock)
					if ect_tax_reg:
						if Tax_status == '-1':
							Taxtype = Taxtype+', '+ect_tax_reg.group(1)
							Tax_status = 2
							Taxtype = re.sub ("'", "''", Taxtype)
							Taxtype = re.sub ("'+", "''", Taxtype)
							Taxtype = re.sub("&.*?;", "&", Taxtype).strip()
							Taxtype = re.sub("^,", "", Taxtype)
							Taxtype = re.sub(r"(?s)\\n|(?s)<.*?>", r"", Taxtype)
							Taxtype = re.sub("\s+", " ", Taxtype).strip()
					
					if Tax_status == '1':
					    if re.search(r"taxes and charges may vary$", Taxtype) and (re.search(r"(?i)Included.*?:\s*\d+.*?\%\s*TAX",Taxtype) or re.search(r"(?i)Included.*?:\s*\d+.*?\%\s*vat",Taxtype)):
					        Tax_status = '3'
					    elif re.search(r"taxes and charges may vary$", Taxtype):
					        Tax_status = '2'		
					
					Curr_reg = re.search("b_selected_currency:\s*'(.*?)'", html)
					if Curr_reg:
						Currencycode = re.sub("'", "''", Curr_reg.group(1))
					else:
						currency_reg = re.search(r'hidden" name="selected_currency" value="(.*?)" />', html)
						if currency_reg:
							Currencycode = currency_reg.group(1)
						else:
							Currencycode = ''
					net_reg = re.search('blue-sans-rack-rate\s*"\s*>\s*.*?(\d.*?)\s*<', spaceblock)
					if net_reg:
						net_clean = net_reg.group(1)
						net_rate = re.sub("Rs.|USD.|Usd.|z&#x0142;|163;|20AC;|[A-Za-z]|&nbsp;|,|\$|'|&#269;|165;", "", net_clean)
						ispromupdate = 'Y'
					else:
						net_reg = re.search('class="bui-price-display__original prco-ltr-center-align-helper.*?>\s*(.*?)\s*</', spaceblock,re.DOTALL)
						if net_reg:
							net_clean = net_reg.group(1)
							net_rate = re.sub("Rs.|USD.|Usd.|z&#x0142;|163;|20AC;|[A-Za-z]|&nbsp;|,|\$|'|&#269;|165;", "", net_clean)
							ispromupdate = 'Y'
						else:
							net_rate = 0
							ispromupdate = 'N'
					mealplan_regex = re.search(r'<span class="bicon-coffee mp-icon meal-plan-icon".*?>(.*?)</li>', spaceblock, re.DOTALL)
					if mealplan_regex:
						Mealtype = re.sub("\s+", " ", re.sub("<.*?>","", mealplan_regex.group(1)))
					else:
						mealplan_regex = re.search('Meals:&.*?;&.*?;strong&.*?;\s*(.*?)\s*&lt;', spaceblock, re.DOTALL)
						if mealplan_regex:
							Mealtype = mealplan_regex.group(1)
						else:
							Mealtype = ''
					
					ratetype_regex_new = re.search(r'<ul\s*class="hprt-conditions".*?>\s*<li.*?data-et-mouseenter="\s*goal:\s*goal:hp_rt_.*?\s*>\s*<\s*span\s*>\s*(.*?)\s*</ul>', spaceblock, re.DOTALL)
					if ratetype_regex_new:
						reatetpye_dedupe_rate = ratetype_regex_new.group(1)
						reatetpye_reduce = re.sub('\s+', " ",  re.sub('<.*?>', "",  re.sub('</span>', ", ", reatetpye_dedupe_rate)))
					else:
						ratetype_regex_new = re.search(r'<ul\s*class="hprt-conditions".*?>\s*<li.*?data-et-mouseenter="\s*goal:hp_rt_hovering_.*?\s*>\s*<\s*span\s*>\s*(.*?)\s*</ul>', spaceblock, re.DOTALL)
						if ratetype_regex_new:
							reatetpye_dedupe_rate = ratetype_regex_new.group(1)
							reatetpye_reduce = re.sub('\s+', " ",  re.sub('<.*?>', "",  re.sub('</span>', ", ", reatetpye_dedupe_rate)))
						else:
							ratetype_regex_new = re.search(r'class="hprt-checkmark-condition.*?>(.*?)</div>', spaceblock, re.DOTALL)
							if ratetype_regex_new:
								reatetpye_dedupe_rate = ratetype_regex_new.group(1)
								reatetpye_reduce = re.sub('\s+', " ",  re.sub('<.*?>', "",  re.sub('</span>', ", ", reatetpye_dedupe_rate)))
							else:
								reatetpye_reduce = ''
					reatetpye_clean = re.sub(r"(?sim)<.*?>|CHF40|CHF 40|\(CHF 40\)|\(CHF40\)|" + str(Currencycode), r"", reatetpye_reduce)
					reatetpye_clean = re.sub(r"\s+", r" ", reatetpye_clean)
					Ratetype_quotes = re.sub("'", "''", reatetpye_clean.strip())
					Ratetype = re.sub (",$", "", Ratetype_quotes)
					if Mealtype == '' :
						if "breakfast" in Ratetype.lower():
							Mealtype = re.sub("costs  Cost", "costs ", re.sub("z&#x0142;|&#163;|&#x20AC;|NZD|Rs|RS|USD", " Cost", Ratetype.replace('&nbsp;', ''))) 
						if "dinner" in Ratetype.lower():
							Mealtype = re.sub("costs  Cost", "costs ", re.sub("z&#x0142;|&#163;|&#x20AC;|NZD|Rs|RS|USD", " Cost", Ratetype.replace('&nbsp;', ''))) 
						if "lunch" in Ratetype.lower():
							Mealtype = re.sub("costs  Cost", "costs ", re.sub("z&#x0142;|&#163;|&#x20AC;|NZD|Rs|RS|USD", " Cost", Ratetype.replace('&nbsp;', '')))
					Mealtype = re.sub("costs  Cost", "costs ", re.sub("PS|z&#x0142;|&#163;|&#x20AC;|NZD|Rs|RS|USD|K&#269;|&#165;|\$|" + str(Currencycode), " Cost", Mealtype))
					Mealtype = re.sub(r"<.*?>|'|&.*?;|CHF40|CHF 40|\(CHF 40\)|\(CHF40\)", r"", Mealtype)
					Mealtype = re.sub(r"&nbsp;|(?sim)<.*?>", "", Mealtype.strip())
					Mealtype = re.sub(r"\(optional\)", "Cost (optional)", Mealtype)
					Mealtype = re.sub(r"\s+", " ", Mealtype.strip())
					clean = re.sub(r"\(\)","",re.sub(r'[A-z]|\d|\,|\.|\-|\:|\'|\"', '',Mealtype).strip())
					if clean:
						Mealtype = re.sub(str(clean), 'Cost',Mealtype)
					if re.search('(?i)breakfast\s*\d', Mealtype) or re.search('(?i)lunch\s*\d', Mealtype) or re.search('(?i)dinner\s*\d', Mealtype):
						Mealtype = str(Mealtype)+' Cost'
					Ratetype = re.sub ("&.*?;|>", " ", Ratetype) 
					Ratetype = re.sub("Special cancellation conditions", "Special Conditions", Ratetype).strip()
					Maxocp_reg = re.search(r'data-title="\s*Sleeps:\s*.*?-\s*(\d+)', spaceblock)
					if Maxocp_reg:
						maxocp_clean = Maxocp_reg.group(1)
						Maxocp = re.sub(r"'|\.|max.*|[A-Z].*|[a-z].*", r"", maxocp_clean)
					else:
						Maxocp_reg = re.search(r'data-title="\s*This option is suitable for.*?(up to|or)\s*(\d+)', spaceblock)
						if Maxocp_reg:
							maxocp_clean = Maxocp_reg.group(2)
							Maxocp = re.sub(r"'|\.|max.*|[A-Z].*|[a-z].*", r"", maxocp_clean)
						else:
							Maxocp_reg = re.search(r'data-title="\s*Max people:\s*(\d+)', spaceblock)
							if Maxocp_reg:
								maxocp_clean = Maxocp_reg.group(1)
								Maxocp = re.sub(r"'|\.|max.*|[A-Z].*|[a-z].*", r"", maxocp_clean)
							else:
								Maxocp_reg = re.search(r'data-et-mouseenter=" goal:hp_rt_hovering_occupancy.*?data-title="\s*.*?(\d)', spaceblock, re.DOTALL)
								if Maxocp_reg:
									maxocp_clean = Maxocp_reg.group(1)
									Maxocp = re.sub(r"\.|max.*|[A-Z].*|[a-z].*", r"", maxocp_clean.lower()).strip()
								else:
									Maxocp_reg = re.search(r'class="c-occupancy-icons__adults\s*".*?>.*?Max\s*people:\s*(\d+)\s*<', spaceblock, re.DOTALL)
									if Maxocp_reg:
										maxocp_clean = Maxocp_reg.group(1)
										Maxocp = re.sub(r"\.|max.*|[A-Z].*|[a-z].*", r"", maxocp_clean.lower()).strip()
									else:
										Maxocp = ''
					GrossRate = OnsiteRate
					discount_rate = net_rate
					if str(OnsiteRate) == 0 or str(OnsiteRate) == '0':
						statuscode = '1'
						Closed_up = 'Y'
					else:
						statuscode = ''
						Closed_up = 'N'
						israteperstay = 'Y'
					Spaceblock = ''	
					if (net_rate == 0 or net_rate == '') and (promotion == 0 or promotion == ''):
						ispromupdate = 'N'
					#print id_update, inputid , Domainname, Websitecode, StartDate, Roomtype, LOS, RateDate, Guests, OnsiteRate, net_rate, GrossRate, Currencycode, RoomDescp, url, url, url, 'RoomAmenityType:',RoomAmenityType, Mealtype, Maxocp, ispromupdate, Closed_up, 30, StartDate , EndDate, intime, Roomavilable, Taxtype, Taxamount, Tax_status, Spaceblock, Ratetype, discount_rate, promotion, region, statuscode, israteperstay
					OnsiteRate =  re.sub(" |\s|=", "", str(OnsiteRate).strip())
					net_rate   = re.sub(" |\s|=", "", str(net_rate).strip())
					#print OnsiteRate, net_rate
# 					print (id_update, inputid , Domainname, Websitecode, StartDate, Roomtype, LOS, RateDate, Guests, OnsiteRate, net_rate, GrossRate, Currencycode, RoomDescp, url, url, url, RoomAmenityType, Mealtype, Maxocp, ispromupdate, Closed_up, 30, StartDate , EndDate, intime, Roomavilable, Taxtype, Taxamount, Tax_status, Spaceblock, Ratetype, discount_rate, promotion, region, statuscode, israteperstay)
					array.append(aws_insert.insert(id_update, inputid , Domainname, Websitecode, StartDate, Roomtype, LOS, RateDate, Guests, OnsiteRate, net_rate, GrossRate, Currencycode, RoomDescp, url, url, url, RoomAmenityType, Mealtype, Maxocp, ispromupdate, Closed_up, 30, StartDate , EndDate, intime, Roomavilable, Taxtype, Taxamount, Tax_status, Spaceblock, Ratetype, discount_rate, promotion, region, statuscode, israteperstay))
		elif re.compile(r'<tr data-block-id=.*?hprt-table-last-row.*?</tr>', re.DOTALL).findall(html):
			#print 'Price Available'
			MainBlock_regex = re.compile(r'<tr data-block-id=.*?hprt-table-last-row.*?</tr>', re.DOTALL)
			Room1_block_regex = re.compile(r'<tr data-block-id.*?</td>\s*</tr>', re.DOTALL)
			for mainblock in MainBlock_regex.findall(html):
				RoomDescp = ''
				if re.search(r'data-room-id="(.*?)"', mainblock):
					Rmid = re.search(r'data-room-id="(.*?)"', mainblock).group(1)
					Roomtype = ""
					OnsiteRate = 0
					GrossRate = 0
					Currencycode = " "
					Closed_up = 'N'
					Mealtype = " "
					RoomAmenityType = ""
					discount_rate = 0
					net_rate = 0
					RoomDescp = ''
					Maxocp = ''
					ispromupdate = 'N'
					promotion = ''
					Roomavilable = ''
					Taxtype = ''
					Taxamount = 0
					Ratetype = ''
					Tax_status = '-1'
				else:
					Rmid = '0'
					Roomtype = ""
					OnsiteRate = 0
					GrossRate = 0
					Currencycode = " "
					Closed_up = 'N'
					Mealtype = " "
					RoomAmenityType = ""
					discount_rate = 0
					net_rate = 0
					RoomDescp = ''
					Maxocp = ''
					ispromupdate = 'N'
					promotion = ''
					Roomavilable = ''
					Taxtype = ''
					Taxamount = 0
					Ratetype = ''
					Tax_status = '-1'
					
				Rmdespblock_formation = '(<div class="hprt-lightbox js_hp_rt_lightbox_facilities.*?data-room-id="%s.*?class="feedback-loop feedback)' %Rmid 
				Rmdespblock_reg = re.search(Rmdespblock_formation, html, re.DOTALL)
				if Rmdespblock_reg:
					Rmdespblock = Rmdespblock_reg.group(1)
					match = re.search(r"sold out|You missed it! Sold", Rmdespblock, re.IGNORECASE)
					if match:
						RoomDescp = ''
					else:
						RoomDescp_reg_check = re.search(r'<div class="hprt-lightbox-right-container.*?>(.*?)<p class="hprt-lightbox-title">',Rmdespblock, re.DOTALL)
						if RoomDescp_reg_check:
							RoomDescp = RoomDescp_reg_check.group(1)
							RoomDescp = re.sub(r"<.*?>|\\\n", "", re.sub("'", "''", re.sub("\s+", " ",re.sub("(?sim)<.*?>", " ", re.sub(r"<.*?>|&.*?;", r" ", re.sub(r"</p>", r", ", RoomDescp))))))
							Ft_reg = Ft_reg_check(RoomDescp)
							if Ft_reg:
								RoomDescp = re.sub("\d+\s*ft|'", Ft_reg, RoomDescp)
							else:
								RoomDescp = ''
						else:
							RoomDescp = ''
				else:
					RoomDescp = ''
				RoomDescp_reg2 = re.compile('<ul\s*class="rt-bed-types"\s*>\s*(.*?)\s*</ul>', re.DOTALL).findall(mainblock)
				if RoomDescp_reg2:
					RoomDescp_first = ''
					RoomDescp_first = re.sub(r"\[|\]|\\n'|'\\n", "", str(RoomDescp_reg2))
					#RoomDescp_first = ratedescription_first_replace(RoomDescp_first)
					RoomDescp_first = re.sub("'", "''", re.sub("\s+", " ",re.sub("(?sim)<.*?>", " ", re.sub(r"<.*?>|&.*?;", r" ", re.sub(r"</p>", r", ", RoomDescp_first)))))
					Ft_reg = Ft_reg_check(RoomDescp_first)
					if Ft_reg:
						RoomDescp_first = re.sub("\d+\s*ft|'", Ft_reg, RoomDescp_first)
				
				else:
					RoomDescp_reg2_else = re.compile('<ul\s*class="room-config".*?>\s*(.*?)\s*</ul>', re.DOTALL).findall(mainblock)
					if RoomDescp_reg2_else:
						RoomDescp_first = ''
						RoomDescp_first = re.sub(r"\[|\]|\\n'|'\\n", "", str(RoomDescp_reg2_else))
						#RoomDescp_first = ratedescription_first_replace(RoomDescp_first)
						RoomDescp_first = re.sub("'", "''", re.sub("\s+", " ",re.sub("(?sim)<.*?>", " ", re.sub(r"<.*?>|&.*?;", r" ", re.sub(r"</p>", r", ", RoomDescp_first)))))
						Ft_reg = Ft_reg_check(RoomDescp_first)
						if Ft_reg:
							RoomDescp_first = re.sub("\d+\s*ft|'", Ft_reg, RoomDescp_first)
					else:
						RoomDescp_first = ''
				RoomDescp = re.sub(r"<.*?>|\\n|\\", "",(str(RoomDescp) + ' ' + str(RoomDescp_first)).strip())
				RoomDescp = re.sub(r"\s+"," ",RoomDescp).strip()
# 				print 'frist_Tax_status:',Tax_status
				Taxtype_reg_block = re.search('class="\s*hptr-taxinfo-.*?>(.*?\s*</div>\s*</div>)', mainblock, re.DOTALL)
				if Taxtype_reg_block:
					Taxtype_reg = Taxtype_reg_block.group(1)
					Tax_reg = re.findall(re.compile(r'class=[\'|\"]hptr-taxinfo-label[\'|\"]\s*>\s*(.*?)\s*</div>', re.DOTALL), Taxtype_reg)
					if Tax_reg:
						Taxtype = re.sub("\[|\]|u'|(?s)\\n", "", str(Tax_reg))
				else:
					Taxtype_reg_block = re.search('class="\s*small\s.*?>(.*?)\s*</div>\s*<!-- end', mainblock, re.DOTALL)
					if Taxtype_reg_block:
						Taxtype_reg = Taxtype_reg_block.group(1)
						Tax_reg = re.findall(re.compile('incExcEmphasize">(.*?)</div>', re.DOTALL), Taxtype_reg)
						if Tax_reg:
							Taxtype = re.sub("\[|\]|u'|(?s)\\n", "", str(Tax_reg))
						else:
							Tax_reg = re.findall(re.compile('incExc.*?</div>(.*?)</div>', re.DOTALL), Taxtype_reg)
							if Tax_reg:
								Taxtype = re.sub("\[|\]|u'|(?s)\\n", "", str(Tax_reg))
				Taxtype = re.sub ("'", "''", Taxtype)
				Taxtype = re.sub ("'+", "''", Taxtype)
				Taxtype = re.sub("&.*?;", "&", Taxtype).strip()
				Taxtype = re.sub("^,", "", Taxtype)
				Taxtype = re.sub(r"(?s)\\n|(?s)<.*?>", r"", Taxtype)
				Taxtype = re.sub("\s+", " ", Taxtype).strip()
				includedtype_reg = re.findall(r'class=[\'|\"]incExcEmphasize[\'|\"]\s*>\s*(.*?)\s*</', mainblock)
				if includedtype_reg:
				    for includedtype_check in includedtype_reg:
				        includedtype_remove = includedtype_check
				        includedtype_check2 = re.sub(r"\d+\.\d+\s*\%\s*Property\s*service\s*charge|\d+\s*\%\s*Property\s*service\s*charge","",re.sub(r'(?i)Included\s*Breakfast|Included\s*Dinner|Included\s*Lunch|Excluded\s*Breakfast|Excluded\s*Dinner|Excluded\s*Lunch|Included\s*in.*?price\s*Breakfast|Included\s*All-Inclusive|Included\s*Half\s*board|Included\s*in.*?price\s*Full\s*board|Included\s*in.*?price\s*Half\s*board|Included\s*in.*?price\s*All-Inclusive|Included\s*Full\s*board|Excluded\s*\d+\.\d+\s*\%\s*Property\s*service\s*charge\s*,\s*Breakfast|Excluded\s*\d+\s*\%\s*Property\s*service\s*charge\s*,\s*Breakfast|Included\s*\d+\.\d+\s*\%\s*Property\s*service\s*charge\s*,\s*Breakfast|Included\s*\d+\s*\%\s*Property\s*service\s*charge\s*,\s*Breakfast|Included\s*in.*?price\s*\d+\.\d+\s*\%\s*Property\s*service\s*charge\s*,\s*Breakfast|Included\s*in.*?price\s*\d+\s*\%\s*Property\s*service\s*charge\s*,\s*Breakfast|Excluded\s*\d+\.\d+\s*\%\s*Property\s*service\s*charge|Excluded\s*\d+\s*\%\s*Property\s*service\s*charge|Included\s*\d+\.\d+\s*\%\s*Property\s*service\s*charge|Included\s*\d+\s*\%\s*Property\s*service\s*charge|Included\s*in.*?price\s*\d+\.\d+\s*\%\s*Property\s*service\s*charge|Included\s*in.*?price\s*\d+\s*\%\s*Property\s*service\s*charge|Not\s*included\s*credit\s*card\s*fee|Not\s*included\s*in\s*apartment\s*price\s*credit\s*card\s*fee|Excluded\s*credit\s*card\s*fee|Included\s*in.*?price\s*[A-Z][A-Z][A-Z]\s*\d+\.\d+\s*Property\s*service\s*charge\s*per\s*night|Included\s*in.*?price\s*[A-Z][A-Z][A-Z]\s*\d+\s*Property\s*service\s*charge\s*per\s*night|Included\s*in.*?price\s*[A-Z][A-Z][A-Z]\s*\d+\.\d+\s*Property\s*service\s*charge|Included\s*in.*?price\s*[A-Z][A-Z][A-Z]\s*\d+\s*Property\s*service\s*charge|Excluded\s*[A-Z][A-Z][A-Z]\s*\d+\.\d+\s*Property\s*service\s*charge\s*per\s*night|Excluded\s*[A-Z][A-Z][A-Z]\s*\d+\s*Property\s*service\s*charge\s*per\s*night|Excluded\s*[A-Z][A-Z][A-Z]\s*\d+\.\d+\s*Property\s*service\s*charge|Excluded\s*[A-Z][A-Z][A-Z]\s*\d+\s*Property\s*service\s*charge', '', str(includedtype_check))).strip()
				        if 'tax' not in includedtype_check2.lower() and 'vat' not in includedtype_check2.lower() and '%' not in includedtype_check2.lower():
				            if 'fee' in includedtype_check2.lower():
				                includedtype_reg.remove(includedtype_remove)
				    if includedtype_reg:
				        includedtype = re.sub("\s+", " ", re.sub("'", "''", re.sub(r"<.*?>|\:", r"", reduce(operator.add, includedtype_reg))))
				    else:
				        includedtype = ''
				else:
				    includedtype_reg = re.findall(r'class=[\'|\"]hptr-taxinfo-label[\'|\"]\s*>\s*(.*?)\s*</div', mainblock, re.DOTALL)
				    if includedtype_reg:
				        for includedtype_check in includedtype_reg:
				            includedtype_remove = includedtype_check
				            includedtype_check2 = re.sub(r"\d+\.\d+\s*\%\s*Property\s*service\s*charge|\d+\s*\%\s*Property\s*service\s*charge","",re.sub(r'(?i)Included\s*Breakfast|Included\s*Dinner|Included\s*Lunch|Excluded\s*Breakfast|Excluded\s*Dinner|Excluded\s*Lunch|Included\s*in.*?price\s*Breakfast|Included\s*All-Inclusive|Included\s*Half\s*board|Included\s*in.*?price\s*Full\s*board|Included\s*in.*?price\s*Half\s*board|Included\s*in.*?price\s*All-Inclusive|Included\s*Full\s*board|Excluded\s*\d+\.\d+\s*\%\s*Property\s*service\s*charge\s*,\s*Breakfast|Excluded\s*\d+\s*\%\s*Property\s*service\s*charge\s*,\s*Breakfast|Included\s*\d+\.\d+\s*\%\s*Property\s*service\s*charge\s*,\s*Breakfast|Included\s*\d+\s*\%\s*Property\s*service\s*charge\s*,\s*Breakfast|Included\s*in.*?price\s*\d+\.\d+\s*\%\s*Property\s*service\s*charge\s*,\s*Breakfast|Included\s*in.*?price\s*\d+\s*\%\s*Property\s*service\s*charge\s*,\s*Breakfast|Excluded\s*\d+\.\d+\s*\%\s*Property\s*service\s*charge|Excluded\s*\d+\s*\%\s*Property\s*service\s*charge|Included\s*\d+\.\d+\s*\%\s*Property\s*service\s*charge|Included\s*\d+\s*\%\s*Property\s*service\s*charge|Included\s*in.*?price\s*\d+\.\d+\s*\%\s*Property\s*service\s*charge|Included\s*in.*?price\s*\d+\s*\%\s*Property\s*service\s*charge|Not\s*included\s*credit\s*card\s*fee|Not\s*included\s*in\s*apartment\s*price\s*credit\s*card\s*fee|Excluded\s*credit\s*card\s*fee|Included\s*in.*?price\s*[A-Z][A-Z][A-Z]\s*\d+\.\d+\s*Property\s*service\s*charge\s*per\s*night|Included\s*in.*?price\s*[A-Z][A-Z][A-Z]\s*\d+\s*Property\s*service\s*charge\s*per\s*night|Included\s*in.*?price\s*[A-Z][A-Z][A-Z]\s*\d+\.\d+\s*Property\s*service\s*charge|Included\s*in.*?price\s*[A-Z][A-Z][A-Z]\s*\d+\s*Property\s*service\s*charge|Excluded\s*[A-Z][A-Z][A-Z]\s*\d+\.\d+\s*Property\s*service\s*charge\s*per\s*night|Excluded\s*[A-Z][A-Z][A-Z]\s*\d+\s*Property\s*service\s*charge\s*per\s*night|Excluded\s*[A-Z][A-Z][A-Z]\s*\d+\.\d+\s*Property\s*service\s*charge|Excluded\s*[A-Z][A-Z][A-Z]\s*\d+\s*Property\s*service\s*charge', '', str(includedtype_check))).strip()
				            if 'tax' not in includedtype_check2.lower() and 'vat' not in includedtype_check2.lower() and '%' not in includedtype_check2.lower():
				                if 'fee' in includedtype_check2.lower():
				                    includedtype_reg.remove(includedtype_remove)
				        if includedtype_reg:
				            includedtype = re.sub("\s+", " ", re.sub("'", "''", re.sub(r"<.*?>|\:", r"", reduce(operator.add, includedtype_reg))))
				        else:
				            includedtype = ''
				    else:
				        includedtype = ''
				# 				print "before", includedtype
				includedtype = re.sub(r"\d+\.\d+\s*\%\s*Property\s*service\s*charge|\d+\s*\%\s*Property\s*service\s*charge","",re.sub(r'(?i)Included\s*Breakfast|Included\s*Dinner|Included\s*Lunch|Excluded\s*Breakfast|Excluded\s*Dinner|Excluded\s*Lunch|Included\s*in.*?price\s*Breakfast|Included\s*All-Inclusive|Included\s*Half\s*board|Included\s*in.*?price\s*Full\s*board|Included\s*in.*?price\s*Half\s*board|Included\s*in.*?price\s*All-Inclusive|Included\s*Full\s*board|Excluded\s*\d+\.\d+\s*\%\s*Property\s*service\s*charge\s*,\s*Breakfast|Excluded\s*\d+\s*\%\s*Property\s*service\s*charge\s*,\s*Breakfast|Included\s*\d+\.\d+\s*\%\s*Property\s*service\s*charge\s*,\s*Breakfast|Included\s*\d+\s*\%\s*Property\s*service\s*charge\s*,\s*Breakfast|Included\s*in.*?price\s*\d+\.\d+\s*\%\s*Property\s*service\s*charge\s*,\s*Breakfast|Included\s*in.*?price\s*\d+\s*\%\s*Property\s*service\s*charge\s*,\s*Breakfast|Excluded\s*\d+\.\d+\s*\%\s*Property\s*service\s*charge|Excluded\s*\d+\s*\%\s*Property\s*service\s*charge|Included\s*\d+\.\d+\s*\%\s*Property\s*service\s*charge|Included\s*\d+\s*\%\s*Property\s*service\s*charge|Included\s*in.*?price\s*\d+\.\d+\s*\%\s*Property\s*service\s*charge|Included\s*in.*?price\s*\d+\s*\%\s*Property\s*service\s*charge|Not\s*included\s*credit\s*card\s*fee|Not\s*included\s*in\s*apartment\s*price\s*credit\s*card\s*fee|Excluded\s*credit\s*card\s*fee|Included\s*in.*?price\s*[A-Z][A-Z][A-Z]\s*\d+\.\d+\s*Property\s*service\s*charge\s*per\s*night|Included\s*in.*?price\s*[A-Z][A-Z][A-Z]\s*\d+\s*Property\s*service\s*charge\s*per\s*night|Included\s*in.*?price\s*[A-Z][A-Z][A-Z]\s*\d+\.\d+\s*Property\s*service\s*charge|Included\s*in.*?price\s*[A-Z][A-Z][A-Z]\s*\d+\s*Property\s*service\s*charge|Excluded\s*[A-Z][A-Z][A-Z]\s*\d+\.\d+\s*Property\s*service\s*charge\s*per\s*night|Excluded\s*[A-Z][A-Z][A-Z]\s*\d+\s*Property\s*service\s*charge\s*per\s*night|Excluded\s*[A-Z][A-Z][A-Z]\s*\d+\.\d+\s*Property\s*service\s*charge|Excluded\s*[A-Z][A-Z][A-Z]\s*\d+\s*Property\s*service\s*charge', '', str(includedtype))).strip()
				if 'tax' not in includedtype.lower() and 'vat' not in includedtype.lower() and '%' not in includedtype.lower():
					if 'fee' in includedtype.lower():
						includedtype = ''
				# 				includedtype = re.sub(r'(?i)Included\s*Breakfast|Included\s*Dinner|Included\s*Lunch|Excluded\s*Breakfast|Excluded\s*Dinner|Excluded\s*Lunch|Included\s*in.*?price\s*Breakfast|Included\s*All-Inclusive|Included\s*Half\s*board', '', str(includedtype)).strip()
				# 				print len(includedtype)
				# 				print "before", includedtype
				if includedtype:
					included_match_first = re.search('^included.*?not included', includedtype.lower())
					included_match_first_else = re.search('^included.*?exclude', includedtype.lower())
					included_match = re.search('^includednot included', includedtype.lower())
					included_match_else = re.search('^includedexclude', includedtype.lower())
					if included_match_first:
						Tax_status = '3'
					elif included_match:
						Tax_status = '3'
					elif included_match_else:
						Tax_status = '3'
					elif included_match_first_else:
						Tax_status = '3'
					elif 'not included' in includedtype.lower() or 'exclude' in includedtype.lower():
						Tax_status = '2'
					else:
						Tax_status = '1'
				elif 'incExcEmphasize">Not included</span>' in mainblock:
					Tax_status = '3'
# 				print 'Tax_status:',Tax_status
				amenites_regex = re.search(r'<ul class="hprt-lightbox-list"\s*data-nr-of-facilities="\d+"\s*>(.*?)</ul>', mainblock, re.DOTALL)
				if amenites_regex:
					amenites_dedupe = amenites_regex.group(1)
					RoomAmenityType = re.sub("&bull;", ", ", amenites_dedupe)
				else:
					amenites_regex = re.search(r'<div class="hprt-facilities-block" data-component=".*?">(.*?)</ul>\s*</div>\s*</div>\s*</div>\s*</div>', mainblock, re.DOTALL)
					if amenites_regex:
						amenites_dedupe = amenites_regex.group(1)
						RoomAmenityType = re.sub(r"Disabilities</span>","Disabilities :",re.sub(r"</ul>",";",re.sub("See the accommodations", "", re.sub('</i>|&bull;', ", ", amenites_dedupe))))
					else:
						amenites_regex = re.search(r'<div class="hprt-facilities-block" data-component=".*?">(.*?)</ul>', mainblock, re.DOTALL)
						if amenites_regex:
							amenites_dedupe = amenites_regex.group(1)
							RoomAmenityType = re.sub("See the accommodations", "", re.sub('</i>|&bull;', ", ", amenites_dedupe))
						else:
							amenites_regex = re.search(r'<div class="hprt-facilities-block" data-component=".*?">(.*?)</div>', mainblock, re.DOTALL)
							if amenites_regex:
								amenites_dedupe = amenites_regex.group(1)
								RoomAmenityType = re.sub("See the accommodations", "", re.sub('</i>|&bull;', ", ", amenites_dedupe))
							else:
								RoomAmenityType = ''
				#print '\n\nRoomAmenityType:',RoomAmenityType
				RoomAmenityType = re.sub('<span class="jq_tooltip hp_rt_rs_ds" title="" >|\'|eatures a|More|Room Amenities|nbsp;|^:|Type|&bull;|(?sim)<.*?>', "", RoomAmenityType)
				RoomAmenityType = re.sub(r"\s+", r" ", RoomAmenityType)
				#print '\n\nRoomAmenityType:',RoomAmenityType
				RoomAmenityType = re.sub(r"Can you tell us what youd like to see here\? \(Well use your feedback to improve the information in this section\)\;|<.*|-.*?\">|^,", "", RoomAmenityType.strip()).strip()
				if len(RoomAmenityType) > 4000:
					RoomAmenityType = str(RoomAmenityType)[:3999]
				includedtype_1 = ''
				for spaceblock in Room1_block_regex.findall(mainblock):
					da_time = datetime.datetime.now()
					intime = re.sub(r'\s', 'T', str(da_time))
					RoomType_reg = re.search(r'hprt-roomtype-name-arrow"></span>\s*(.*?)\s*</a>', spaceblock , re.DOTALL)
					if RoomType_reg:
						Roomtype = RoomType_reg.group(1)
					else:
						RoomType_reg = re.search(r'class="hprt-roomtype-link.*?>\s*(.*?)\s*</', spaceblock, re.DOTALL)
						if RoomType_reg:
							Roomtype = RoomType_reg.group(1)
						else:
							RoomType_reg = re.search(r'class="hprt-roomtype-icon-link__photo-icon">\s*(.*?)\s*</a>', spaceblock, re.DOTALL)
							if RoomType_reg:
								Roomtype = RoomType_reg.group(1)
					Roomtype = re.sub(r"<.*?>|Special Conditions|Non-Ref.*|Non-ref.*|Refundable|refundable", r"", Roomtype)
					Roomtype = re.sub("'", "''", Roomtype)
					Roomtype = re.sub("&.*?;", "", Roomtype)
					Roomtype = re.sub("\s+", " ", Roomtype).strip()
					Roomavilable_reg = re.search(r'[o|O]nly\s*(.*?)\s*room', spaceblock)
					if Roomavilable_reg:
						Roomavilable = Roomavilable_reg.group(1)
					else:
						Roomavilable_reg = re.search(r'[o|O]nly\s*(.*?)\s*room', mainblock)
						if Roomavilable_reg:
							Roomavilable = Roomavilable_reg.group(1)
						else:
							Roomavilable = ''
					Taxtype_reg_block = re.search('class="\s*hptr-taxinfo-.*?>(.*?\s*</div>\s*</div>)', spaceblock, re.DOTALL)
					if Taxtype_reg_block:
						Taxtype_reg = Taxtype_reg_block.group(1)
						Tax_reg = re.findall(re.compile(r'class=\s*[\'|\"]\s*hptr-taxinfo-label.*?[\'|\"]\s*>\s*(.*?)\s*</div>', re.DOTALL), Taxtype_reg)
						if Tax_reg:
							Taxtype = re.sub("\[|\]|u'|(?s)\\n", "", str(Tax_reg))
					else:
						Taxtype_reg_block = re.search('class="\s*small\s.*?>(.*?)\s*</div>\s*<!-- end',spaceblock,re.DOTALL)
						if Taxtype_reg_block:
							Taxtype_reg = Taxtype_reg_block.group(1)
							Tax_reg =  re.findall(re.compile('incExcEmphasize">(.*?)</div>', re.DOTALL), Taxtype_reg)
							if Tax_reg:
								Taxtype = re.sub("\[|\]|u'|(?s)\\n", "", str(Tax_reg))
							else:
								Tax_reg =  re.findall(re.compile('incExc.*?</div>(.*?)</div>', re.DOTALL), Taxtype_reg)
								if Tax_reg:
									Taxtype = re.sub("\[|\]|u'|(?s)\\n", "", str(Tax_reg))
					Taxtype_reg_block2 = re.search('class=[\'|\"]prd-taxes-and-fees-under-price .*?-hpage blockuid-\d+.*?\s*>\s*(.*?)\s*</div',spaceblock)
					if Taxtype_reg_block2:
						Taxtype = re.sub(str(Taxtype_reg_2_remove).strip(),"",str(Taxtype))
						Taxtype_reg_2 = re.sub(r"\+","exclude ",Taxtype_reg_block2.group(1))   
						Taxtype = str(Taxtype)+', '+str(Taxtype_reg_2) 
						Taxtype_reg_2_remove = re.sub(r"\.","\.",re.sub(r"\$","\$",Taxtype_reg_2))       
# 					print 'Taxtype:',Taxtype
					Taxtype = re.sub ("'", "''", Taxtype)
					Taxtype = re.sub ("'+", "''", Taxtype)
					Taxtype = re.sub("&.*?;", "&", Taxtype).strip()
					Taxtype = re.sub("^,", "", Taxtype)
					Taxtype = re.sub(", ,", ",", Taxtype)
					Taxtype = re.sub(r"(?s)\\n|(?s)<.*?>", r"", Taxtype)
					Taxtype = re.sub("\s+", " ", Taxtype).strip()
					includedtype_reg = re.findall(r'class=[\'|\"]incExcEmphasize[\'|\"]\s*>\s*(.*?)\s*</', spaceblock)
					if includedtype_reg:
					    for includedtype_check in includedtype_reg:
					        includedtype_remove = includedtype_check
					        includedtype_check2 = re.sub(r"\d+\.\d+\s*\%\s*Property\s*service\s*charge|\d+\s*\%\s*Property\s*service\s*charge","",re.sub(r'(?i)Included\s*Breakfast|Included\s*Dinner|Included\s*Lunch|Excluded\s*Breakfast|Excluded\s*Dinner|Excluded\s*Lunch|Included\s*in.*?price\s*Breakfast|Included\s*All-Inclusive|Included\s*Half\s*board|Included\s*in.*?price\s*Full\s*board|Included\s*in.*?price\s*Half\s*board|Included\s*in.*?price\s*All-Inclusive|Included\s*Full\s*board|Excluded\s*\d+\.\d+\s*\%\s*Property\s*service\s*charge\s*,\s*Breakfast|Excluded\s*\d+\s*\%\s*Property\s*service\s*charge\s*,\s*Breakfast|Included\s*\d+\.\d+\s*\%\s*Property\s*service\s*charge\s*,\s*Breakfast|Included\s*\d+\s*\%\s*Property\s*service\s*charge\s*,\s*Breakfast|Included\s*in.*?price\s*\d+\.\d+\s*\%\s*Property\s*service\s*charge\s*,\s*Breakfast|Included\s*in.*?price\s*\d+\s*\%\s*Property\s*service\s*charge\s*,\s*Breakfast|Excluded\s*\d+\.\d+\s*\%\s*Property\s*service\s*charge|Excluded\s*\d+\s*\%\s*Property\s*service\s*charge|Included\s*\d+\.\d+\s*\%\s*Property\s*service\s*charge|Included\s*\d+\s*\%\s*Property\s*service\s*charge|Included\s*in.*?price\s*\d+\.\d+\s*\%\s*Property\s*service\s*charge|Included\s*in.*?price\s*\d+\s*\%\s*Property\s*service\s*charge|Not\s*included\s*credit\s*card\s*fee|Not\s*included\s*in\s*apartment\s*price\s*credit\s*card\s*fee|Excluded\s*credit\s*card\s*fee|Included\s*in.*?price\s*[A-Z][A-Z][A-Z]\s*\d+\.\d+\s*Property\s*service\s*charge\s*per\s*night|Included\s*in.*?price\s*[A-Z][A-Z][A-Z]\s*\d+\s*Property\s*service\s*charge\s*per\s*night|Included\s*in.*?price\s*[A-Z][A-Z][A-Z]\s*\d+\.\d+\s*Property\s*service\s*charge|Included\s*in.*?price\s*[A-Z][A-Z][A-Z]\s*\d+\s*Property\s*service\s*charge|Excluded\s*[A-Z][A-Z][A-Z]\s*\d+\.\d+\s*Property\s*service\s*charge\s*per\s*night|Excluded\s*[A-Z][A-Z][A-Z]\s*\d+\s*Property\s*service\s*charge\s*per\s*night|Excluded\s*[A-Z][A-Z][A-Z]\s*\d+\.\d+\s*Property\s*service\s*charge|Excluded\s*[A-Z][A-Z][A-Z]\s*\d+\s*Property\s*service\s*charge', '', str(includedtype_check))).strip()
					        if 'tax' not in includedtype_check2.lower() and 'vat' not in includedtype_check2.lower() and '%' not in includedtype_check2.lower():
					            if 'fee' in includedtype_check2.lower():
					                includedtype_reg.remove(includedtype_remove)
					    if includedtype_reg:
					        includedtype = re.sub("\s+", " ", re.sub("'", "''", re.sub(r"<.*?>|\:", r"", reduce(operator.add, includedtype_reg))))
					    else:
					        includedtype = ''
					else:
					    includedtype_reg = re.findall(r'class=[\'|\"]prd-taxes-and-fees-under-price .*?-hpage blockuid-\d+.*?\s*>\s*(.*?)\s*</div', spaceblock)
					    if includedtype_reg:
					        for includedtype_check in includedtype_reg:
					            includedtype_remove = includedtype_check
					            includedtype_check2 = re.sub(r"\d+\.\d+\s*\%\s*Property\s*service\s*charge|\d+\s*\%\s*Property\s*service\s*charge","",re.sub(r'(?i)Included\s*Breakfast|Included\s*Dinner|Included\s*Lunch|Excluded\s*Breakfast|Excluded\s*Dinner|Excluded\s*Lunch|Included\s*in.*?price\s*Breakfast|Included\s*All-Inclusive|Included\s*Half\s*board|Included\s*in.*?price\s*Full\s*board|Included\s*in.*?price\s*Half\s*board|Included\s*in.*?price\s*All-Inclusive|Included\s*Full\s*board|Excluded\s*\d+\.\d+\s*\%\s*Property\s*service\s*charge\s*,\s*Breakfast|Excluded\s*\d+\s*\%\s*Property\s*service\s*charge\s*,\s*Breakfast|Included\s*\d+\.\d+\s*\%\s*Property\s*service\s*charge\s*,\s*Breakfast|Included\s*\d+\s*\%\s*Property\s*service\s*charge\s*,\s*Breakfast|Included\s*in.*?price\s*\d+\.\d+\s*\%\s*Property\s*service\s*charge\s*,\s*Breakfast|Included\s*in.*?price\s*\d+\s*\%\s*Property\s*service\s*charge\s*,\s*Breakfast|Excluded\s*\d+\.\d+\s*\%\s*Property\s*service\s*charge|Excluded\s*\d+\s*\%\s*Property\s*service\s*charge|Included\s*\d+\.\d+\s*\%\s*Property\s*service\s*charge|Included\s*\d+\s*\%\s*Property\s*service\s*charge|Included\s*in.*?price\s*\d+\.\d+\s*\%\s*Property\s*service\s*charge|Included\s*in.*?price\s*\d+\s*\%\s*Property\s*service\s*charge|Not\s*included\s*credit\s*card\s*fee|Not\s*included\s*in\s*apartment\s*price\s*credit\s*card\s*fee|Excluded\s*credit\s*card\s*fee|Included\s*in.*?price\s*[A-Z][A-Z][A-Z]\s*\d+\.\d+\s*Property\s*service\s*charge\s*per\s*night|Included\s*in.*?price\s*[A-Z][A-Z][A-Z]\s*\d+\s*Property\s*service\s*charge\s*per\s*night|Included\s*in.*?price\s*[A-Z][A-Z][A-Z]\s*\d+\.\d+\s*Property\s*service\s*charge|Included\s*in.*?price\s*[A-Z][A-Z][A-Z]\s*\d+\s*Property\s*service\s*charge|Excluded\s*[A-Z][A-Z][A-Z]\s*\d+\.\d+\s*Property\s*service\s*charge\s*per\s*night|Excluded\s*[A-Z][A-Z][A-Z]\s*\d+\s*Property\s*service\s*charge\s*per\s*night|Excluded\s*[A-Z][A-Z][A-Z]\s*\d+\.\d+\s*Property\s*service\s*charge|Excluded\s*[A-Z][A-Z][A-Z]\s*\d+\s*Property\s*service\s*charge', '', str(includedtype_check))).strip()
					            if 'tax' not in includedtype_check2.lower() and 'vat' not in includedtype_check2.lower() and '%' not in includedtype_check2.lower():
					                if 'fee' in includedtype_check2.lower():
					                    includedtype_reg.remove(includedtype_remove)
					        if includedtype_reg:
					            includedtype = re.sub("\s+", " ", re.sub("'", "''", re.sub(r"<.*?>|\:", r"", reduce(operator.add, includedtype_reg))))
					        else:
					            includedtype = ''
					    else:
					        includedtype = ''
					includedtype_1_reg = re.findall(r'class=[\'|\"]hptr-taxinfo-label[\'|\"]\s*>\s*(.*?)\s*</div', spaceblock, re.DOTALL)
					if includedtype_1_reg:
					    for includedtype_check in includedtype_1_reg:
					        includedtype_remove = includedtype_check
					        includedtype_check2 = re.sub(r"\d+\.\d+\s*\%\s*Property\s*service\s*charge|\d+\s*\%\s*Property\s*service\s*charge","",re.sub(r'(?i)Included\s*Breakfast|Included\s*Dinner|Included\s*Lunch|Excluded\s*Breakfast|Excluded\s*Dinner|Excluded\s*Lunch|Included\s*in.*?price\s*Breakfast|Included\s*All-Inclusive|Included\s*Half\s*board|Included\s*in.*?price\s*Full\s*board|Included\s*in.*?price\s*Half\s*board|Included\s*in.*?price\s*All-Inclusive|Included\s*Full\s*board|Excluded\s*\d+\.\d+\s*\%\s*Property\s*service\s*charge\s*,\s*Breakfast|Excluded\s*\d+\s*\%\s*Property\s*service\s*charge\s*,\s*Breakfast|Included\s*\d+\.\d+\s*\%\s*Property\s*service\s*charge\s*,\s*Breakfast|Included\s*\d+\s*\%\s*Property\s*service\s*charge\s*,\s*Breakfast|Included\s*in.*?price\s*\d+\.\d+\s*\%\s*Property\s*service\s*charge\s*,\s*Breakfast|Included\s*in.*?price\s*\d+\s*\%\s*Property\s*service\s*charge\s*,\s*Breakfast|Excluded\s*\d+\.\d+\s*\%\s*Property\s*service\s*charge|Excluded\s*\d+\s*\%\s*Property\s*service\s*charge|Included\s*\d+\.\d+\s*\%\s*Property\s*service\s*charge|Included\s*\d+\s*\%\s*Property\s*service\s*charge|Included\s*in.*?price\s*\d+\.\d+\s*\%\s*Property\s*service\s*charge|Included\s*in.*?price\s*\d+\s*\%\s*Property\s*service\s*charge|Not\s*included\s*credit\s*card\s*fee|Not\s*included\s*in\s*apartment\s*price\s*credit\s*card\s*fee|Excluded\s*credit\s*card\s*fee|Included\s*in.*?price\s*[A-Z][A-Z][A-Z]\s*\d+\.\d+\s*Property\s*service\s*charge\s*per\s*night|Included\s*in.*?price\s*[A-Z][A-Z][A-Z]\s*\d+\s*Property\s*service\s*charge\s*per\s*night|Included\s*in.*?price\s*[A-Z][A-Z][A-Z]\s*\d+\.\d+\s*Property\s*service\s*charge|Included\s*in.*?price\s*[A-Z][A-Z][A-Z]\s*\d+\s*Property\s*service\s*charge|Excluded\s*[A-Z][A-Z][A-Z]\s*\d+\.\d+\s*Property\s*service\s*charge\s*per\s*night|Excluded\s*[A-Z][A-Z][A-Z]\s*\d+\s*Property\s*service\s*charge\s*per\s*night|Excluded\s*[A-Z][A-Z][A-Z]\s*\d+\.\d+\s*Property\s*service\s*charge|Excluded\s*[A-Z][A-Z][A-Z]\s*\d+\s*Property\s*service\s*charge', '', str(includedtype_check))).strip()
					        if 'tax' not in includedtype_check2.lower() and 'vat' not in includedtype_check2.lower() and '%' not in includedtype_check2.lower():
					            if 'fee' in includedtype_check2.lower():
					                includedtype_1_reg.remove(includedtype_remove)
					    if includedtype_1_reg:
					        includedtype_1 = re.sub("\s+", " ", re.sub("'", "''", re.sub(r"<.*?>|\:", r"", reduce(operator.add, includedtype_1_reg))))
					    else:
					        includedtype_1 = ''
					includedtype = includedtype_1+' '+includedtype
					includedtype = re.sub(r"\+","exclude ",str(includedtype))
# 					print "before1", includedtype
					includedtype = re.sub(r"\d+\.\d+\s*\%\s*Property\s*service\s*charge|\d+\s*\%\s*Property\s*service\s*charge","",re.sub(r'(?i)Included\s*Breakfast|Included\s*Dinner|Included\s*Lunch|Excluded\s*Breakfast|Excluded\s*Dinner|Excluded\s*Lunch|Included\s*in.*?price\s*Breakfast|Included\s*All-Inclusive|Included\s*Half\s*board|Included\s*in.*?price\s*Full\s*board|Included\s*in.*?price\s*Half\s*board|Included\s*in.*?price\s*All-Inclusive|Included\s*Full\s*board|Excluded\s*\d+\.\d+\s*\%\s*Property\s*service\s*charge\s*,\s*Breakfast|Excluded\s*\d+\s*\%\s*Property\s*service\s*charge\s*,\s*Breakfast|Included\s*\d+\.\d+\s*\%\s*Property\s*service\s*charge\s*,\s*Breakfast|Included\s*\d+\s*\%\s*Property\s*service\s*charge\s*,\s*Breakfast|Included\s*in.*?price\s*\d+\.\d+\s*\%\s*Property\s*service\s*charge\s*,\s*Breakfast|Included\s*in.*?price\s*\d+\s*\%\s*Property\s*service\s*charge\s*,\s*Breakfast|Excluded\s*\d+\.\d+\s*\%\s*Property\s*service\s*charge|Excluded\s*\d+\s*\%\s*Property\s*service\s*charge|Included\s*\d+\.\d+\s*\%\s*Property\s*service\s*charge|Included\s*\d+\s*\%\s*Property\s*service\s*charge|Included\s*in.*?price\s*\d+\.\d+\s*\%\s*Property\s*service\s*charge|Included\s*in.*?price\s*\d+\s*\%\s*Property\s*service\s*charge|Not\s*included\s*credit\s*card\s*fee|Not\s*included\s*in\s*apartment\s*price\s*credit\s*card\s*fee|Excluded\s*credit\s*card\s*fee|Included\s*in.*?price\s*[A-Z][A-Z][A-Z]\s*\d+\.\d+\s*Property\s*service\s*charge\s*per\s*night|Included\s*in.*?price\s*[A-Z][A-Z][A-Z]\s*\d+\s*Property\s*service\s*charge\s*per\s*night|Included\s*in.*?price\s*[A-Z][A-Z][A-Z]\s*\d+\.\d+\s*Property\s*service\s*charge|Included\s*in.*?price\s*[A-Z][A-Z][A-Z]\s*\d+\s*Property\s*service\s*charge|Excluded\s*[A-Z][A-Z][A-Z]\s*\d+\.\d+\s*Property\s*service\s*charge\s*per\s*night|Excluded\s*[A-Z][A-Z][A-Z]\s*\d+\s*Property\s*service\s*charge\s*per\s*night|Excluded\s*[A-Z][A-Z][A-Z]\s*\d+\.\d+\s*Property\s*service\s*charge|Excluded\s*[A-Z][A-Z][A-Z]\s*\d+\s*Property\s*service\s*charge', '', str(includedtype))).strip()
					if 'tax' not in includedtype.lower() and 'vat' not in includedtype.lower() and '%' not in includedtype.lower():
						if 'fee' in includedtype.lower():
							includedtype = ''
# 					print len(includedtype)
# 					print "before1", includedtype
					if includedtype:
						included_match_first = re.search('^included.*?not included', includedtype.lower())
						included_match_first_else = re.search('^included.*?exclude', includedtype.lower())
						included_match = re.search('^includednot included', includedtype.lower())
						included_match_else = re.search('^includedexclude', includedtype.lower())
						if included_match_first:
							Tax_status = '3'
						elif included_match:
							Tax_status = '3'
						elif included_match_else:
							Tax_status = '3'
						elif included_match_first_else:
							Tax_status = '3'
						elif 'not included' in includedtype.lower() or 'exclude' in includedtype.lower():
							Tax_status = '2'
						else:
							Tax_status = '1'
					elif 'incExcEmphasize">Not included</span>' in spaceblock:
						Tax_status = '3'
# 					print 'Tax_status:',Tax_status
					onsite_rate_regex = re.search('rooms-table-room-price.*?"\s*t.*?"\s*>\s*.*?(\d.*?)\s*<', spaceblock, re.DOTALL)
					if onsite_rate_regex:
					    OnsiteRate = onsite_rate_regex.group(1)
					else:
					    onsite_rate_regex = re.search(r'helper prco-font16-helper">\s*(.*?)\s*</',  spaceblock)
					    if onsite_rate_regex:
					        OnsiteRate = onsite_rate_regex.group(1)
					    else:
					        onsite_rate_regex = re.search(r'<span class="hprt-price.*?>\s*(.*?)\s*</sp', spaceblock)
					        if onsite_rate_regex:
					            OnsiteRate = re.sub(r"(?s)<.*?>", r"", re.sub("Rs\.|USD\.|Usd\.|z&#x0142;|163;|20AC;|[A-Za-z]|&nbsp;|,|\$|'|&#269;|165;", "", str(onsite_rate_regex.group(1)))).strip()
					            if OnsiteRate == '':
					                onsite_rate_regex = re.search(r"hprt-price-price-(actual|standard).*?>\s*(.*?)\s*</", spaceblock, re.DOTALL)
					                if onsite_rate_regex:
					                    OnsiteRate = onsite_rate_regex.group(2)
					        else:
					            onsite_rate_regex = re.search(r"hprt-price-price-(actual|standard).*?>\s*(.*?)\s*</", spaceblock, re.DOTALL)
					            if onsite_rate_regex:
					                OnsiteRate = onsite_rate_regex.group(2)
					            else:
					                onsite_rate_regex = re.search(r'&lt;&#47;ul&gt; &lt;&#47;div&gt; &lt;&#47;div&gt; ">\s*(.*?)\s*</', spaceblock)
					                if onsite_rate_regex:
					                    OnsiteRate = onsite_rate_regex.group(1)
					                else:
					                    onsite_rate_regex = re.search(r'hp_rt_hovering_price.*?<span.*?>\s*(.*?)\s*</', spaceblock, re.DOTALL)
					                    if onsite_rate_regex:
					                        OnsiteRate = onsite_rate_regex.group(1)
					                    else:
					                        onsite_rate_regex = re.search(r'class="bui-price-display__value prco-ltr-center-align-helper">\s*(.*?)\s*</', spaceblock,re.DOTALL)
					                        if onsite_rate_regex:
					                            OnsiteRate = onsite_rate_regex.group(1)
					                        else:
					                            onsite_rate_regex = re.search(r'class="prco-valign-middle-helper"\s*>\s*(.*?)\s*</', spaceblock)
					                            if onsite_rate_regex:
					                                OnsiteRate = onsite_rate_regex.group(1)
					                            else:
					                                OnsiteRate = 0
					                                statuscode = '1'
					OnsiteRate = re.sub(r"(?s)<.*?>|=", r"", re.sub("Rs\.|USD\.|Usd\.|z&#x0142;|163;|20AC;|[A-Za-z]|&nbsp;|,|\$|'|&#269;|165;", "", str(OnsiteRate))).strip()
					ect_tax_reg = re.search('class="prd-taxes-and-fees-under-price.*?\s*>\s*\+\s*(.*?\s*\d.*?)\s*</', spaceblock)
					if ect_tax_reg:
						if Tax_status == '-1':
							Taxtype = Taxtype+', '+ect_tax_reg.group(1)
							Tax_status = 2
							Taxtype = re.sub ("'", "''", Taxtype)
							Taxtype = re.sub ("'+", "''", Taxtype)
							Taxtype = re.sub("&.*?;", "&", Taxtype).strip()
							Taxtype = re.sub("^,", "", Taxtype)
							Taxtype = re.sub(r"(?s)\\n|(?s)<.*?>", r"", Taxtype)
							Taxtype = re.sub("\s+", " ", Taxtype).strip()
							
					if Tax_status == '1':
					    if re.search(r"taxes and charges may vary$", Taxtype) and (re.search(r"(?i)Included.*?:\s*\d+.*?\%\s*TAX",Taxtype) or re.search(r"(?i)Included.*?:\s*\d+.*?\%\s*vat",Taxtype)):
					        Tax_status = '3'
					    elif re.search(r"taxes and charges may vary$", Taxtype):
					        Tax_status = '2'
							
					Curr_reg = re.search("b_selected_currency:\s*'(.*?)'", html)
					if Curr_reg:
						Currencycode = re.sub("'", "''", Curr_reg.group(1))
					else:
						currency_reg = re.search(r'hidden" name="selected_currency" value="(.*?)" />', html)
						if currency_reg:
							Currencycode = currency_reg.group(1)
						else:
							Currencycode = ''
					net_reg = re.search('blue-sans-rack-rate\s*"\s*>\s*.*?(\d.*?)\s*<', spaceblock)
					if net_reg:
						net_clean = net_reg.group(1)
						net_rate = re.sub("Rs.|USD.|Usd.|z&#x0142;|163;|20AC;|[A-Za-z]|&nbsp;|,|\$|'|&#269;|165;", "", net_clean)
						ispromupdate = 'Y'
					else:
						net_reg = re.search('class="bui-price-display__original prco-ltr-center-align-helper.*?>\s*(.*?)\s*</', spaceblock,re.DOTALL)
						if net_reg:
							net_clean = net_reg.group(1)
							net_rate = re.sub("Rs.|USD.|Usd.|z&#x0142;|163;|20AC;|[A-Za-z]|&nbsp;|,|\$|'|&#269;|165;", "", net_clean)
							ispromupdate = 'Y'
						else:
							net_rate = 0
							ispromupdate = 'N'
					mealplan_regex = re.search(r'<span class="bicon-coffee mp-icon meal-plan-icon".*?>(.*?)</li>', spaceblock, re.DOTALL)
					if mealplan_regex:
						Mealtype = re.sub("\s+", " ", re.sub("<.*?>","", mealplan_regex.group(1)))
					else:
						mealplan_regex = re.search('Meals:&.*?;&.*?;strong&.*?;\s*(.*?)\s*&lt;', spaceblock, re.DOTALL)
						if mealplan_regex:
							Mealtype = mealplan_regex.group(1)
						else:
							Mealtype = ''
					
					ratetype_regex_new = re.search(r'<ul\s*class="hprt-conditions".*?>\s*<li.*?data-et-mouseenter="\s*goal:\s*goal:hp_rt_.*?\s*>\s*<\s*span\s*>\s*(.*?)\s*</ul>', spaceblock, re.DOTALL)
					if ratetype_regex_new:
						reatetpye_dedupe_rate = ratetype_regex_new.group(1)
						reatetpye_reduce = re.sub('\s+', " ",  re.sub('<.*?>', "",  re.sub('</span>', ", ", reatetpye_dedupe_rate)))
					else:
						ratetype_regex_new = re.search(r'<ul\s*class="hprt-conditions".*?>\s*<li.*?data-et-mouseenter="\s*goal:hp_rt_hovering_.*?\s*>\s*<\s*span\s*>\s*(.*?)\s*</ul>', spaceblock, re.DOTALL)
						if ratetype_regex_new:
							reatetpye_dedupe_rate = ratetype_regex_new.group(1)
							reatetpye_reduce = re.sub('\s+', " ",  re.sub('<.*?>', "",  re.sub('</span>', ", ", reatetpye_dedupe_rate)))
						else:
							ratetype_regex_new = re.search(r'class="hprt-checkmark-condition.*?>(.*?)</div>', spaceblock, re.DOTALL)
							if ratetype_regex_new:
								reatetpye_dedupe_rate = ratetype_regex_new.group(1)
								reatetpye_reduce = re.sub('\s+', " ",  re.sub('<.*?>', "",  re.sub('</span>', ", ", reatetpye_dedupe_rate)))
							else:
								reatetpye_reduce = ''
					reatetpye_clean = re.sub(r"(?sim)<.*?>|CHF40|CHF 40|\(CHF 40\)|\(CHF40\)|" + str(Currencycode), r"", reatetpye_reduce)
					reatetpye_clean = re.sub(r"\s+", r" ", reatetpye_clean)
					Ratetype_quotes = re.sub("'", "''", reatetpye_clean.strip())
					Ratetype = re.sub (",$", "", Ratetype_quotes)
					if Mealtype == '' :
						if "breakfast" in Ratetype.lower():
							Mealtype = re.sub("costs  Cost", "costs ", re.sub("z&#x0142;|&#163;|&#x20AC;|NZD|Rs|RS|USD", " Cost", Ratetype.replace('&nbsp;', ''))) 
						if "dinner" in Ratetype.lower():
							Mealtype = re.sub("costs  Cost", "costs ", re.sub("z&#x0142;|&#163;|&#x20AC;|NZD|Rs|RS|USD", " Cost", Ratetype.replace('&nbsp;', ''))) 
						if "lunch" in Ratetype.lower():
							Mealtype = re.sub("costs  Cost", "costs ", re.sub("z&#x0142;|&#163;|&#x20AC;|NZD|Rs|RS|USD", " Cost", Ratetype.replace('&nbsp;', '')))
					Mealtype = re.sub("costs  Cost", "costs ", re.sub("PS|z&#x0142;|&#163;|&#x20AC;|NZD|Rs|RS|USD|K&#269;|&#165;|\$|" + str(Currencycode), " Cost", Mealtype))
					Mealtype = re.sub(r"<.*?>|'|&.*?;|CHF40|CHF 40|\(CHF 40\)|\(CHF40\)", r"", Mealtype)
					Mealtype = re.sub(r"&nbsp;|(?sim)<.*?>", "", Mealtype.strip())
					Mealtype = re.sub(r"\(optional\)", "Cost (optional)", Mealtype)
					Mealtype = re.sub(r"\s+", " ", Mealtype.strip())
					clean = re.sub(r'[A-z]|\d|\,|\.|\-|\:|\'|\"', '',Mealtype).strip()
					if clean:
						Mealtype = re.sub(str(clean), 'Cost',Mealtype)
					if re.search('(?i)breakfast\s*\d', Mealtype) or re.search('(?i)lunch\s*\d', Mealtype) or re.search('(?i)dinner\s*\d', Mealtype):
						Mealtype = str(Mealtype)+' Cost'
					Ratetype = re.sub ("&.*?;|>", " ", Ratetype) 
					Ratetype = re.sub("Special cancellation conditions", "Special Conditions", Ratetype).strip()
					Maxocp_reg = re.search(r'data-title="\s*Sleeps:\s*.*?-\s*(\d+)', spaceblock)
					if Maxocp_reg:
						maxocp_clean = Maxocp_reg.group(1)
						Maxocp = re.sub(r"'|\.|max.*|[A-Z].*|[a-z].*", r"", maxocp_clean)
					else:
						Maxocp_reg = re.search(r'data-title="\s*This option is suitable for.*?(up to|or)\s*(\d+)', spaceblock)
						if Maxocp_reg:
							maxocp_clean = Maxocp_reg.group(2)
							Maxocp = re.sub(r"'|\.|max.*|[A-Z].*|[a-z].*", r"", maxocp_clean)
						else:
							Maxocp_reg = re.search(r'data-title="\s*Max people:\s*(\d+)', spaceblock)
							if Maxocp_reg:
								maxocp_clean = Maxocp_reg.group(1)
								Maxocp = re.sub(r"'|\.|max.*|[A-Z].*|[a-z].*", r"", maxocp_clean)
							else:
								Maxocp_reg = re.search(r'data-et-mouseenter=" goal:hp_rt_hovering_occupancy.*?data-title="\s*.*?(\d)', spaceblock, re.DOTALL)
								if Maxocp_reg:
									maxocp_clean = Maxocp_reg.group(1)
									Maxocp = re.sub(r"\.|max.*|[A-Z].*|[a-z].*", r"", maxocp_clean.lower()).strip()
								else:
									Maxocp_reg = re.search(r'class="c-occupancy-icons__adults\s*".*?>.*?Max\s*people:\s*(\d+)\s*<', spaceblock, re.DOTALL)
									if Maxocp_reg:
										maxocp_clean = Maxocp_reg.group(1)
										Maxocp = re.sub(r"\.|max.*|[A-Z].*|[a-z].*", r"", maxocp_clean.lower()).strip()
									else:
										Maxocp = ''
					GrossRate = OnsiteRate
					discount_rate = net_rate
					if str(OnsiteRate) == 0 or str(OnsiteRate) == '0':
						statuscode = '1'
						Closed_up = 'Y'
					else:
						statuscode = ''
						Closed_up = 'N'
						israteperstay = 'Y'
					Spaceblock = ''	
					if (net_rate == 0 or net_rate == '') and (promotion == 0 or promotion == ''):
						ispromupdate = 'N'
					#print id_update, inputid , Domainname, Websitecode, StartDate, Roomtype, LOS, RateDate, Guests, OnsiteRate, net_rate, GrossRate, Currencycode, RoomDescp, url, url, url, 'RoomAmenityType:',RoomAmenityType, Mealtype, Maxocp, ispromupdate, Closed_up, 30, StartDate , EndDate, intime, Roomavilable, Taxtype, Taxamount, Tax_status, Spaceblock, Ratetype, discount_rate, promotion, region, statuscode, israteperstay
					OnsiteRate =  re.sub(" |\s|=", "", str(OnsiteRate).strip())
					net_rate   = re.sub(" |\s|=", "", str(net_rate).strip())
					#print OnsiteRate, net_rate
# 					print (id_update, inputid , Domainname, Websitecode, StartDate, Roomtype, LOS, RateDate, Guests, OnsiteRate, net_rate, GrossRate, Currencycode, RoomDescp, url, url, url, RoomAmenityType, Mealtype, Maxocp, ispromupdate, Closed_up, 30, StartDate , EndDate, intime, Roomavilable, Taxtype, Taxamount, Tax_status, Spaceblock, Ratetype, discount_rate, promotion, region, statuscode, israteperstay)
					array.append(aws_insert.insert(id_update, inputid , Domainname, Websitecode, StartDate, Roomtype, LOS, RateDate, Guests, OnsiteRate, net_rate, GrossRate, Currencycode, RoomDescp, url, url, url, RoomAmenityType, Mealtype, Maxocp, ispromupdate, Closed_up, 30, StartDate , EndDate, intime, Roomavilable, Taxtype, Taxamount, Tax_status, Spaceblock, Ratetype, discount_rate, promotion, region, statuscode, israteperstay))
		else:
			Closed_up = 'Y'
			ispromupdate = 'N'
			statuscode = '2'
			israteperstay = ''
			Spaceblock = ''
			da_time = datetime.datetime.now()
			intime = re.sub(r'\s', 'T', str(da_time))
# 			print (id_update, inputid , Domainname, Websitecode, StartDate, Roomtype, LOS, RateDate, Guests, OnsiteRate, net_rate, GrossRate, Currencycode, RoomDescp, url, url, url, RoomAmenityType, Mealtype, Maxocp, ispromupdate, Closed_up, 30, StartDate , EndDate, intime, Roomavilable, Taxtype, Taxamount, Tax_status, Spaceblock, Ratetype, discount_rate, promotion, region, statuscode, israteperstay)
			array.append(aws_insert.insert(id_update, inputid , Domainname, Websitecode, StartDate, Roomtype, LOS, RateDate, Guests, OnsiteRate, net_rate, GrossRate, Currencycode, RoomDescp, url, url, url, RoomAmenityType, Mealtype, Maxocp, ispromupdate, Closed_up, 30, StartDate , EndDate, intime, Roomavilable, Taxtype, Taxamount, Tax_status, Spaceblock, Ratetype, discount_rate, promotion, region, statuscode, israteperstay))
		keyvalue = "ondemand/{}/{:%Y%m%d}/delivery/{}.json".format(Websitecode, datetime.datetime.now(), str(inputid) + '_' + str(Rtdate) + '_' + id_update)
		key = bucket.new_key(keyvalue)
		key.set_contents_from_string(json.dumps(array))
		gc.collect()
		return json.dumps(array)
	except Exception as e:
		value_error = str(re.sub(r"'", '"', str(e)))
		stacktrace = sys.exc_traceback.tb_lineno
		print 'Error:', stacktrace
		Guests = '1'
		Websitecode = 2
		insert_value_error = str(value_error) + 'Where line number ' + str(stacktrace) + str(proxyip)+ ' Hotelcode in:' + str(inputid)
		print insert_value_error
		statuscode = '4'
		keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(Websitecode, datetime.datetime.now(), id_update)
		key = bucket.new_key(keyvalue)
		key.set_contents_from_string(insert_value_error)
		array.append(aws_insert.insert(id_update, inputid , functionname, Websitecode, insert_value_error, "", "", "", Guests, "", "", "", "", "", url, url, url, "", "", "", "", "", "", StartDate, EndDate , "", "", "", "", "", "", "", "", "", region, statuscode, israteperstay))
		return json.dumps(array)

# fetchrates(url , inputid, id_update, proxyip)
