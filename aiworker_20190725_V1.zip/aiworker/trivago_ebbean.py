# -*- coding: utf-8 -*-
import re
import requests
import datetime
import operator
import json
import time 
import urllib2
 
import sys 
import boto
import random
import gc

import sys
import traceback
import meta_insert

#url='https://www.trivago.com/?cpt=95470102&iRoomType=7&aHotelTestClassifier=&iIncludeAll=0&iGeoDistanceLimit=20000&aPartner=&iPathId=364781&iGeoDistanceItem=954701&aDateRange[arr]=2017-03-18&aDateRange[dep]=2017-03-19&iViewType=0&bIsSeoPage=false&bIsSitemap=false'	
def fetchrates(url ,inputid, id_update, proxyip):
	try:
		array = []
		csv=[]
		url_db=url
		intime=re.sub(r'\s','T',str(datetime.datetime.now()))
		functionname='trivago'
		conn = boto.connect_s3(aws_access_key_id= 'AKIAIXEGZVXCWE2FV3SQ',aws_secret_access_key = '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') 
		bucket = conn.get_bucket("rmapi")
		StartDate = datetime.date.today()
		EndDate  = datetime.date.today() + datetime.timedelta(days=29)
		websitecode = 282
		price_=''
		Provider = ''
		Rank = None
		Hotelcode=inputid
		RoomName = ''
		RoomFacilities = ''
		OnsiteRate = 0
		NetRate = 0
		Pricepernight = 0
		Curr = 'USD'
		statuscode=''
		HotelBlock=''
		Ratedate=''
		Reportdate=''
		Los=None
		if re.search('cpt=(.*?)&',url_db):
			cptid = re.sub(r'\d\d$','',re.search('cpt=(.*?)&',url_db).group(1))

		if re.search('iRoomType=(.*?)&',url_db):
			iRoomTypeid = re.search('iRoomType=(.*?)&',url_db).group(1)

		if re.search('iPathId=(.*?)&',url_db):
			iPathIdid = re.search('iPathId=(.*?)&',url_db).group(1)
		if re.search(r'aDateRange\[arr]=.*?&aDateRange\[dep]=.*?&',url_db):
			checkin_date=re.search(r'aDateRange\[arr]=(.*?)&',url_db).group(1)
			checkout_date=re.search(r'&aDateRange\[dep]=(.*?)&',url_db).group(1)
		if checkin_date:
			check_in_date = datetime.datetime.strptime(datetime.datetime.strptime(str(checkin_date),'%Y-%m-%d').strftime('%Y, %m, %d'),'%Y, %m, %d')
		if checkout_date:
			check_out_date = datetime.datetime.strptime(datetime.datetime.strptime(str(checkout_date),'%Y-%m-%d').strftime('%Y, %m, %d'),'%Y, %m, %d')
		LOS = check_out_date - check_in_date
		Los = LOS.days
		Ratedate=checkin_date
		Reportdate=datetime.datetime.strptime(str(StartDate),'%Y-%m-%d').strftime('%Y-%m-%d')
		url_db = re.sub(r"(?s)&aDateRange\[dep\]=(.*?)&", r"&aDateRange[dep]="+str(checkout_date)+"&", re.sub(r"(?s)&aDateRange\[arr\]=(.*?)&", r"&aDateRange[arr]="+str(checkin_date)+"&", url_db))
		if re.search(r'//(.*?)/', url_db):
			domainname = re.search(r'//(.*?)/', url_db).group(1)
		proxies = {"http": "http://{}".format(proxyip)}
		sr = requests.Session()
		json_url ='https://'+domainname+'/api/v1/accommodation/'+str(cptid)+'/deals.json?iPathId='+str(iPathIdid)+'&iRoomType='+str(iRoomTypeid)+'&aRooms=&aDateRange%5Barr%5D='+str(checkin_date)+'&aDateRange%5Bdep%5D='+str(checkout_date)+'&bSharedRooms=false'
		hml = sr.get(json_url, headers={'User-Agent':'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:12.0) Gecko/100101 Firefox/31.0', 'DNT':str(1), 'host': 'www.trivago.in'}, proxies = proxies, verify = False,timeout=40)
		keyvalue = "metasearch/{}/{:%Y%m%d}/Error_chk/{}.txt".format(websitecode,datetime.datetime.now(),str(inputid)+'_'+str(id_update))
		key = bucket.new_key(keyvalue)
		key.set_contents_from_string(hml.text)
		c=0
		while "Are you a human or a robot?" in hml.text: 
			hml = sr.get(json_url, headers={'User-Agent':'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:12.0) Gecko/20100101 Firefox/31.0'},proxies=proxies, verify = False,timeout=40)
			c=c+1
			if c==100:
				break		
		html = json.loads(hml.text.encode('utf-8'))
		html4 = hml.text.encode('ascii', 'ignore')
		
		jchk ='"deals":[{"id":'
		while jchk not in str(html4):
			try:
				hml = sr.get(json_url, headers={'User-Agent':'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:12.0) Gecko/20100101 Firefox/31.0'}, proxies = proxies, verify = False,timeout=40)
				#print "hml while	:",hml.status_code
			except Exception,e:
				value_error=str(re.sub("'",'"',str(e)))		
				stacktrace=sys.exc_traceback.tb_lineno
				##print stacktrace,   value_error
			html = json.loads(hml.text.encode('utf-8'))
			html4 = hml.text.encode('ascii', 'ignore')
			
		keyvalue = "metasearch/{}/{:%Y%m%d}/source/{}.json".format(websitecode,datetime.datetime.now(),str(inputid)+'_'+str(id_update))
		key = bucket.new_key(keyvalue)
		key.set_contents_from_string(html4)
		deal_check = html['deals']
		if not deal_check:
			hml = sr.get(json_url, headers={'User-Agent':'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:12.0) Gecko/20100101 Firefox/31.0'}, verify = False)
			html = json.loads(hml.text.encode('utf-8'))
		if re.search(r"price':(.*?)',", str(html)):
			price_ = re.sub("u'", "", re.search(r"price':(.*?)',", str(html)).group(1))
		if html['deals']:
			i = 1
			Rank_dict = {}
			for block in html['deals']:
				amnt = ''
				if block.has_key('description'):
					RateDescription = re.sub("'", "''", str(block['description']))
					RoomName = RateDescription
				if re.search(r"Suite|DuplexCottage|bungalow|Villa|domekHostel|Dormitory|Capsule|dormStudio|Apart|Comfort|Honeymoon|Maisonette|Attic|Appartmentdelux|premium|superior|Premier|Executive|Corner|Club|Family|Guest|Loft|Business|Concierge|Diamond|Luxury|Prestige|Privilege|Swiss", RoomName, re.IGNORECASE):
					RoomName = RoomName
				else:
					RoomName = 'Lowest Available Rate'
				if block.has_key('price'):
					OnsiteRate = re.sub("\\$|\$|$", "", re.sub("'", "''", str(block['price'])))
					OnsiteRate=int(OnsiteRate)
				if block.has_key('partnerRatingId'):
					partnerRatingId = re.sub("'", "''", str(block['partnerRatingId']))
				price_check = block['terms']
				if 'list' in price_check:
					for amt in block['terms']['list']:
						amnt +=', '+amt
						RoomFacilities = re.sub("'", "''", re.sub("^, ", "", amnt))
				if 'partners' in html:
					if html['partners'].has_key(str(partnerRatingId)):
						Amnit_check = html['partners'][partnerRatingId]
						if Amnit_check.has_key('name'):
							Provider = re.sub("'", "''", str(Amnit_check['name']))
							#print "Provider	:",Provider
						if Provider not in Rank_dict:
							Rank_dict[Provider] = i
							i = i+1
						Rank = Rank_dict[Provider]
				RoomFacilities=re.sub(r',',' - ',RoomFacilities)
				RoomName=re.sub(r',',' - ',RoomName)
				valu=Provider,Rank,RoomName,RoomFacilities,OnsiteRate,NetRate,Pricepernight,Curr,Ratedate,Los,Reportdate,Hotelcode,websitecode,url_db,HotelBlock,Ratedate,statuscode
				vals=str(valu)
				csv.append(vals)
				array.append(meta_insert.insert(Provider,Rank,RoomName,RoomFacilities,OnsiteRate,NetRate,Pricepernight,Curr,Ratedate,Los,Reportdate,Hotelcode,websitecode,url_db,HotelBlock,Ratedate,statuscode))
		else:
			HotelBlock=''
			statuscode='2'
			valu=Provider,Rank,RoomName,RoomFacilities,OnsiteRate,NetRate,Pricepernight,Curr,Ratedate,Los,Reportdate,Hotelcode,websitecode,url_db,HotelBlock,Ratedate,statuscode
			vals=str(valu)
			csv.append(vals)
			array.append(meta_insert.insert(Provider,Rank,RoomName,RoomFacilities,OnsiteRate,NetRate,Pricepernight,Curr,Ratedate,Los,Reportdate,Hotelcode,websitecode,url_db,HotelBlock,Ratedate,statuscode))
		newline="\n".join(csv)
		arrayclean1=re.sub(r'\[|\(|\)|\]','',str(newline))
		arrayclean2=re.sub(r"'",'"',arrayclean1)
		arrayclean=re.sub(r'u"','"',arrayclean2)
		Ratedates=re.sub(r'-','',str(Ratedate))
		date_time=datetime.datetime.now().strftime('%Y%m%d_%I%M')	
		keyvalue = "metasearch/metaresults/{}.txt".format(str(date_time)+'_'+str(websitecode)+'_'+str(Hotelcode)+'_'+str(Ratedates))
		key = bucket.new_key(keyvalue)
		key.set_contents_from_string(arrayclean)
		return json.dumps(array)				
	except Exception as e:
		insert_value_error=str(str(re.sub(r"'",'"',str(e))))+'Where line number '+str(sys.exc_traceback.tb_lineno)+str(proxyip)
		statuscode=4
		websitecode=282
		print insert_value_error
		keyvalue = "metasearch/{}/{:%Y%m%d}/Error/{}.txt".format(websitecode,datetime.datetime.now(),str(inputid)+'_'+str(id_update))
		key = bucket.new_key(keyvalue)
		key.set_contents_from_string(insert_value_error)
		#print (Provider,Rank,insert_value_error,"","","","","",Ratedate,Los,Reportdate,Hotelcode,websitecode,url_db,"",Ratedate,statuscode)
		array.append(meta_insert.insert(Provider,Rank,RoomName,"",OnsiteRate,NetRate,Pricepernight,"",Ratedate,Los,Reportdate,Hotelcode,websitecode,url_db,"",Ratedate,statuscode))
		return json.dumps(array)				
				
			
			
			

