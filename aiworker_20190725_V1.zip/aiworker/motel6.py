# -*- coding: utf-8 -*-
import re,requests
import datetime
import json
import boto,gc,sys

import aws_insert

def fetchrates(url,inputid,id_update,proxyip):
    array      = []
    sr         = requests.session()
    proxies    = {"https": "http://{}".format(proxyip)}
#     proxies    = {"https": "http://media:M3diAproxy@%s"% proxyip}
    intime     = re.sub(r'\s','T',str(datetime.datetime.now()))
    Domainname = 'MOTEL6'
    Websitecode= '134'
    region     = ''
    statuscode = ''
    Mealtype   = ''
    israteperstay = ''
    try:
        conn   = boto.connect_s3(aws_access_key_id= 'AKIAIXEGZVXCWE2FV3SQ',aws_secret_access_key = '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') 
        bucket = conn.get_bucket("rmapi")
        StartDate = datetime.date.today()
        EndDate   = datetime.date.today() + datetime.timedelta(days=29)
        CheckIn_Check_OT_re = re.search(r'checkin=(.*?)&checkout=(.*?)&',url)
        if CheckIn_Check_OT_re:
            Checkin  = CheckIn_Check_OT_re.group(1)
            Checkout = CheckIn_Check_OT_re.group(2)
            Checkin_URL = datetime.datetime.strptime(str(CheckIn_Check_OT_re.group(1)),'%Y-%m-%d').strftime('%m-%d-%Y')
            CheckOT_URL = datetime.datetime.strptime(str(CheckIn_Check_OT_re.group(2)),'%Y-%m-%d').strftime('%m-%d-%Y')
        else:
            Checkin  = ''
            Checkout = ''
            Checkin_URL = ''
            CheckOT_URL = ''
        #print Checkin,Checkout
        #print url 
        #print Checkin_URL,CheckOT_URL
        RateDate = Checkin
        delta    = datetime.datetime.strptime(Checkout, "%Y-%m-%d") - datetime.datetime.strptime(Checkin, "%Y-%m-%d")
        LOS      = delta.days
        RoomType = ''
        Guests   = re.search(r'Adults=(\d)', url).group(1)
        #print Guests,LOS
        Ratetype = ''
        RateDescription = ''
        Taxtype  = ''
        Curr     = ''
        MaxOccupancy = None
        isPromotionalRate  = 'N'
        Closed   = 'Y'
        NetRate  = 0
        Taxstatus= -1
        TaxAmount= 0
        Discount = 0
        GrossRate= 0
        OnsiteRate = 0
        Curr     = ''
        Promotion_Name= ''
        isAvailable = ''
        RoomAmenity_Type = ''
        url_insert  = re.sub(r'#.*','',url)
        Hotelid     = re.search(r'motel6.com/.*?/.*?\.(\d+).html', url).group(1)
        #print Hotelid,url_insert
        ses1 = sr.get('https://www.motel6.com/#/hotel-search')
        head = {'Host':'svc.prd.motel6.com','Connection':'keep-alive','Accept':'application/json, text/plain, */*','Origin':'https://www.motel6.com','User-Agent':'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36','Referer':url_insert,'Accept-Encoding':'gzip, deflate, br','Accept-Language':'en-GB,en-US;q=0.8,en;q=0.6'}
        urldb = 'https://svc.prd.motel6.com/svs/check-rate-by-id-cp.do?checkInDate='+Checkin_URL+'&checkOutDate='+CheckOT_URL+'&numberOfAdults='+str(Guests)+'&propertyId='+Hotelid
        #print urldb
        ip = re.sub(r"\{'.*?@|'\}|:\d+", "", str(proxies))
        try:
            try:
                r = sr.get('http://freegeoip.net/json/' + ip, timeout=30)
            except Exception, e:
                r = sr.get('http://freegeoip.net/json/' + ip, timeout=30)
            js = r.json()
            region = js['country_name']
        except Exception, e:
            region = ''
        try:
            htm = sr.get(urldb,headers = head,proxies = proxies,timeout=100)
        except Exception, e:
            value_error = str(re.sub("'", '', str(e)))
            stacktrace = sys.exc_traceback.tb_lineno
            try:
                htm = sr.get(urldb,headers = head,proxies = proxies,timeout=120)
            except Exception, e:
                try:
                    htm = sr.get(urldb,headers = head,proxies = proxies,timeout=150)
                except Exception, e:
                    value_error = str(re.sub("'", '', str(e)))
                    stacktrace = sys.exc_traceback.tb_lineno
                    keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(Websitecode, datetime.datetime.now(), id_update)
                    key = bucket.new_key(keyvalue)
                    key.set_contents_from_string(str(e) + 'Where Line number' + str(stacktrace) + str(proxies))
                    statuscode = 5
                    Guests = ''
                    array.append(aws_insert.insert(id_update, inputid , Domainname, Websitecode, "", "", "", "", Guests, "", "", "", "", "", url_insert,url_insert,url_insert, "", "", "", "", "", "", StartDate, EndDate , "", "", "", "", "", "", "", "", "", region, statuscode, israteperstay))
                    return json.dumps(array)
        if htm.status_code <> 200:
            htm = sr.get(urldb,headers = head,proxies = proxies)
        if (htm.status_code == 403 or htm.status_code == 407) or htm.status_code <> 200:
            try:
                if htm.status_code <> 200:
                    htm = sr.get(urldb,headers = head)
            except Exception, e:
                Closed    = 'Y'
                value_error = str(re.sub("'", '', str(e)))
                stacktrace = sys.exc_traceback.tb_lineno
                keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(Websitecode, datetime.datetime.now(), id_update)
                key = bucket.new_key(keyvalue)
                key.set_contents_from_string(str(e) + 'Where Line number' + str(stacktrace) + str(proxies))
                statuscode = 5
                Guests = ''
                array.append(aws_insert.insert(id_update, inputid , Domainname, Websitecode, "", "", "", "", Guests, "", "", "", "", "", url_insert,url_insert,url_insert, "", "", "", "", "", "", StartDate, EndDate , "", "", "", "", "", "", "", "", "", region, statuscode, israteperstay))
                return json.dumps(array)
        html = htm.text.encode('ascii','ignore')
#         fo = open('motel8.html','w').write(str(html))
        json_value = json.loads(html)
        keyvalue = "ondemand/{}/{:%Y%m%d}/source/{}.json".format(Websitecode,datetime.datetime.now(),str(inputid)+'_'+str(Checkin)+'_'+id_update)
        key = bucket.new_key(keyvalue)
        key.set_contents_from_string(json.dumps(json_value))
        if 'data' in json_value:
            Available = json_value['data']['availability']
            #print Available
            if Available.has_key('best_available_rates'):
                for block in Available['best_available_rates']:
                    for block1 in block['rate_by_rooms']:
                        Ratetype    = ''
                        RoomType    = ''
                        OnsiteRate  = 0
                        GrossRate   = 0
                        Curr        = ''
                        isAvailable = ''
                        RateDescription = ''
                        if block1['room_description']:
                            RoomType = block1['room_description']
                            RoomType = re.sub(r"'","''",str(RoomType))
                            RoomType = re.sub(r"(\|)\s*",',',RoomType).rstrip(',')
                        if block1['standard_rate_name']:
                            Ratetype = block1['standard_rate_name']
                            Ratetype = re.sub(r"'","''",str(Ratetype))
                        if block1['average_standard_rate']:
                            OnsiteRate = block1['average_standard_rate']
                        GrossRate  = OnsiteRate
                        if block1['currency_code']:
                            Curr = block1['currency_code']
                        if block1['total_room_available']:
                            isAvailable = block1['total_room_available']
                        if block1['long_description']:
                            RateDescription = block1['long_description']
                            RateDescription = re.sub(r"'","''",str(RateDescription))
                        Mealtypes          = str(RateDescription)+' '+str(RoomType)+' '+str(Ratetype)+' '+str(RoomAmenity_Type)
                        if Mealtypes !=None:
                            Mealtype_str = str(Mealtypes)
                            if 'breakfast' in Mealtype_str.lower() and 'dinner' in Mealtype_str.lower()  and 'lunch' in Mealtype_str.lower():
                                Meal = 'Breakfast, Lunch and Dinner'
                            elif 'breakfast' in Mealtype_str.lower() and 'dinner' in Mealtype_str.lower():
                                Meal = 'Breakfast and dinner'
                            elif 'breakfast included' in Mealtype_str.lower():
                                Meal = 'Breakfast included'
                            elif 'BREAKFAST' in Mealtype_str:
                                Meal = 'Breakfast'
                            elif 'breakfast' in Mealtype_str.lower() and 'lunch' in Mealtype_str.lower():
                                Meal = 'Breakfast and Lunch'
                            elif 'Lunch' in Mealtype_str and 'Dinner' in Mealtype_str :
                                Meal = "Lunch and Dinner"
                            elif 'breakfast' in Mealtype_str.lower() and 'lunch' in Mealtype_str.lower() and 'dinner' in Mealtype_str.lower():
                                Meal = 'Breakfast, Lunch and dinner'
                            elif 'Break fast' in Mealtype_str:
                                Meal = 'BreakFast' 
                            elif 'breakfast' in Mealtype_str.lower():
                                Meal = 'BreakFast' 
                            elif 'halfboard' in Mealtype_str.lower():
                                Meal = 'Halfboard'
                            elif 'half board' in Mealtype_str.lower():
                                Meal = 'Half board' 
                            elif 'full board' in Mealtype_str.lower():
                                Meal = 'Full Board'
                            elif 'fullboard' in Mealtype_str.lower():
                                Meal = 'FullBoard'
                            elif 'All-Inclusive' in Mealtype_str:
                                Meal = 'All-Inclusive'
                            elif 'All Inclusive' in Mealtype_str:
                                Meal = 'All Inclusive'
                            elif 'All Meals' in Mealtype_str:
                                Meal = 'All Meals'
                            elif 'All Meal' in Mealtype_str:
                                Meal = 'All Meal'
                            else:
                                Meal = ''
                        else:
                            Meal = ''   
                        Mealtype = Meal
                        if OnsiteRate==0:
                            statuscode = 1
                            Closed='Y'
                        else:
                            statuscode = ''
                            Closed='N'
                            
                        LOS = int(LOS)
                        if int(LOS) >1:
                            israteperstay = 'N'
                        else:
                            israteperstay = 'Y'
                       
#                         #print "Ratetype          :",Ratetype
#                         #print "RoomType          :",RoomType  
#                         #print "OnsiteRate        :",OnsiteRate
#                         #print "Curr              :",Curr        
#                         #print "isAvailable       :",isAvailable  
#                         #print "RateDescription   :",RateDescription  
#                         #print "="*50
#                         #print (id_update, inputid , Domainname, Websitecode, StartDate, RoomType, LOS, RateDate, Guests, OnsiteRate, NetRate, GrossRate, Curr, RateDescription, url_insert, url_insert, url_insert, RoomAmenity_Type, Mealtype, MaxOccupancy, isPromotionalRate, Closed, 30, StartDate , EndDate, intime, isAvailable, Taxtype, TaxAmount, Taxstatus, None, Ratetype, Discount,Promotion_Name,region,statuscode, israteperstay)
                        array.append(aws_insert.insert(id_update, inputid , Domainname, Websitecode, StartDate, RoomType, LOS, RateDate, Guests, OnsiteRate, NetRate, GrossRate, Curr, RateDescription, url_insert, url_insert, url_insert, RoomAmenity_Type, Mealtype, MaxOccupancy, isPromotionalRate, Closed, 30, StartDate , EndDate, intime, isAvailable, Taxtype, TaxAmount, Taxstatus, None, Ratetype, Discount,Promotion_Name,region,statuscode, israteperstay))
        else:
            Closed     = 'Y'
            statuscode = '2'
            #print (id_update, inputid , Domainname, Websitecode, StartDate, RoomType, LOS, RateDate, Guests, OnsiteRate, NetRate, GrossRate, Curr, RateDescription, url_insert, url_insert, url_insert, RoomAmenity_Type, Mealtype, MaxOccupancy, isPromotionalRate, Closed, 30, StartDate , EndDate, intime, isAvailable, Taxtype, TaxAmount, Taxstatus, None, Ratetype, Discount,Promotion_Name,region,statuscode, israteperstay)
            array.append(aws_insert.insert(id_update, inputid , Domainname, Websitecode, StartDate, RoomType, LOS, RateDate, Guests, OnsiteRate, NetRate, GrossRate, Curr, RateDescription, url_insert, url_insert, url_insert, RoomAmenity_Type, Mealtype, MaxOccupancy, isPromotionalRate, Closed, 30, StartDate , EndDate, intime, isAvailable, Taxtype, TaxAmount, Taxstatus, None, Ratetype, Discount,Promotion_Name,region,statuscode, israteperstay))
        keyvalue = "ondemand/{}/{:%Y%m%d}/delivery/{}.json".format(Websitecode,datetime.datetime.now(),str(inputid)+'_'+str(RateDate)+'_'+id_update)
        key = bucket.new_key(keyvalue)
        key.set_contents_from_string(json.dumps(array))
        return json.dumps(array)
        gc.collect()
    except Exception as e:
       print e
       value_error = str(re.sub(r"'", '"', str(e)))
       stacktrace = sys.exc_traceback.tb_lineno
       Guests = ''
       statuscode = '4'
       region = ''
       array.append(aws_insert.insert(id_update, inputid , Domainname, Websitecode, "", "", "", "", Guests, "", "", "", "", "", url_insert,url_insert,url_insert, "", "", "", "", "", "", StartDate, EndDate , "", "", "", "", "", "", "", "", "", region, statuscode, israteperstay))
       keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.json".format(Websitecode,datetime.datetime.now(),str(inputid)+'_'+str(RateDate)+'_'+id_update)
       key = bucket.new_key(keyvalue)
       key.set_contents_from_string(json.dumps(value_error))
       return json.dumps(array)
