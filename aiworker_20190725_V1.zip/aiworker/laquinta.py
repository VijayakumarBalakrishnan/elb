# -*- coding: utf-8 -*-
import re
import requests
import datetime
import operator
import json
import time 
import urllib2
 
import sys 
import boto
import random
import gc

import traceback
import aws_insert
#array =[]

def fetchrates(url,inputid,id_update,proxyip):
	array = []
	intime=re.sub(r'\s','T',str(datetime.datetime.now()))
	functionname='Laquinta'
	proxy_arora=proxyip
	israteperstay = ''
	try:
		url_chk = re.sub('&lat.*?lon.*?&','&',url)
		conn = boto.connect_s3(aws_access_key_id= 'AKIAIXEGZVXCWE2FV3SQ',aws_secret_access_key = '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') 
		bucket = conn.get_bucket("rmapi")
		RateDate = ''
		Chekin = re.search(r"indate=(.*?)&",url_chk).group(1)	
		RateDate = Chekin
		Checkin = datetime.datetime.strptime(Chekin,str('%Y-%m-%d')).strftime('%m-%d-%Y')
		chk_re=re.sub(r'-','%2F',Checkin)
		Chekout = re.search(r"outdate=(.*?)&",url_chk).group(1)
		Checkout = datetime.datetime.strptime(Chekout,str('%Y-%m-%d')).strftime('%m-%d-%Y')
		chk_out_re=re.sub(r'-','%2F',Checkout)
		checkin_date='indate='+chk_re+'&'+'outdate='+chk_out_re+'&'
		url=re.sub(r'indate=(.*?)&outdate=(.*?)&',checkin_date,url_chk)
		##print "URl	:",url
		StartDate = datetime.date.today()
		EndDate  = datetime.date.today() + datetime.timedelta(days=29)
		
		
		WebSiteName="lq.com"
		functionname = WebSiteName
		WebSiteCode = '108'
		RoomType = ""
		RateType=''
		Guests = 1
		OnsiteRate = 0
		Closed_up = 'N'
		MealInclusion_Type = " "
		RateDescription = " "
		RoomAmenity_Type = ""
		Netrate=0
		GrossRate=0
		Discount=0
		Isprom=''
		isAvailable=''
		Promotion_Name=''
		MaxOccupancy=''
		Discount=0
		promotion = ''
		statuscode = ''
		Curr=''
		hml=''
		Isprom = 'N'   
		rattypes = ['RAC','AAA','AARP','SENIOR','GOV','MIL']
		keyvalue = "ondemand/{}/{:%Y%m%d}/source/{}-url.txt".format(WebSiteCode,datetime.datetime.now(),str(inputid)+'_'+str(RateDate)+'_'+id_update)
		#print keyvalue
		key = bucket.new_key(keyvalue)
		key.set_contents_from_string(url)
		proxies = {"http": "http://{}".format(proxyip)}
		addquote='"'+str(proxies)+'"'
		proxyadd=re.search("{'http': 'http://media:M3d!Aproxy@(.*?)'}",addquote)
		if proxyadd:
			proxy_arora=proxyadd.group(1)
		try:
			for ratyp in rattypes:
				rates = re.search('specialRates=(.*?)&',url)
				allrates = "specialRates="+ratyp+"&"
				url = re.sub('specialRates=(.*?)&',allrates,url)
				try:
					hml = requests.get(url,headers={'User-Agent':'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:12.0) Gecko/20100101 Firefox/31.0'},proxies=proxies,timeout=50)
				except Exception as e:
					value_error=str(re.sub("'",'',str(e)))
					#value_error=str(es).encode('ascii','ignore')
					stacktrace=sys.exc_traceback.tb_lineno
					try:
						hml = requests.get(url,headers={'User-Agent':'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:12.0) Gecko/20100101 Firefox/31.0'},timeout=50)
					except Exception,e:
						value_error=str(re.sub(r"'",'',str(e)))
						stacktrace=sys.exc_traceback.tb_lineno
						keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(WebSiteCode,datetime.datetime.now(),id_update)
						#print keyvalue
						key = bucket.new_key(keyvalue)
						key.set_contents_from_string(str(e))
						statuscode=5
						Guests='1'
						array.append(aws_insert.insert(id_update, inputid ,functionname,WebSiteCode, "", "", "", "", Guests, "", "", "", "", "",url, url, url, "", "", "", "", "", "",StartDate, EndDate , "", "", "", "", "",  "", "","","","",statuscode, israteperstay))
						return json.dumps(array)
				if (hml.status_code <> 200):
					hml=requests.get(url, headers={'User-Agent':'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:12.0) Gecko/20100101 Firefox/31.0'},proxies=proxies)
				if (hml.status_code == 403 or hml.status_code == 407):
					try:
						proxyresult = requests.get('http://www.gimmeproxy.com/api/getProxy?protocol=http')
						jproxy = json.loads(proxyresult.content)
						proxies = { "http": jproxy["curl"] }
						hml=requests.get(url, headers={'User-Agent':'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:12.0) Gecko/20100101 Firefox/31.0'},proxies=proxies)
						if hml.status_code <> 200:
							hml=requests.get(url, headers={'User-Agent':'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:12.0) Gecko/20100101 Firefox/31.0'})
					except Exception,e:
						value_error=str(re.sub(r"'",'',str(e)))
						stacktrace=sys.exc_traceback.tb_lineno
						keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(WebSiteCode,datetime.datetime.now(),id_update)
						#print keyvalue
						key = bucket.new_key(keyvalue)
						key.set_contents_from_string(str(e))
						statuscode=5
						Guests='1'
						array.append(aws_insert.insert(id_update, inputid ,functionname,WebSiteCode, "", "", "", "", Guests, "", "", "", "", "",url, url, url, "", "", "", "", "", "",StartDate, EndDate , "", "", "", "", "",  "", "","","","",statuscode, israteperstay))
						return json.dumps(array)
				html = hml.text
				html = html.encode('ascii', 'ignore')
				Rtdate = re.sub(r'-/|\-','',str(RateDate))
				keyvalue = "ondemand/{}/{:%Y%m%d}/source/{}.html".format(WebSiteCode,datetime.datetime.now(),str(inputid)+'_'+str(Rtdate)+'_'+id_update)
				#print keyvalue
				key = bucket.new_key(keyvalue)
				key.set_contents_from_string(html)
				reg_blo = re.search(r'<div class="availableRoom">.*?</div>\s*</div>\s*</div>\s*</div>\s*</div>\s*</div>\s*</div>\s*</div>\s*</div>\s*</div>',html,re.DOTALL)
				if reg_blo:
					REGBLOCK=re.compile(r'<div class="availableRoom">.*?</div>\s*</div>\s*</div>\s*</div>\s*</div>\s*</div>\s*</div>\s*</div>\s*</div>\s*</div>',re.DOTALL)
					for block1 in REGBLOCK.findall(html):
						RoomType = ""
						RateType=''
						Guests = 1
						OnsiteRate = 0
						Closed_up = 'N'
						MealInclusion_Type = " "
						RateDescription = " "
						RoomAmenity_Type = ""
						Netrate=0
						GrossRate=0
						Discount=0
						Isprom=''
						isAvailable=''
						Promotion_Name=''
						MaxOccupancy=''
						Discount=0
						promotion = ''
						statuscode = ''
						Curr=''
						price_re = re.search(r"<span class='priceDisplaySign'>\$</span>(.*?)</span>",block1)
						if price_re:
							Price = price_re.group(1)
							OnsiteRate = re.sub(',','',Price)
							GrossRate = OnsiteRate

						curr_re = re.search(r"<span class='priceDisplaySign'>(.*?)</span>.*?</span>",block1)
						if curr_re:
							Currency = curr_re.group(1)
						if "INR" in Currency:
							Curr = "INR"
						if "$" in Currency:
							Curr = "USD"
						##print"Currency   :",Curr
						ratetype_re = re.findall('<input type="hidden" name="rateName" value="(.*?)" />',block1)
						for rate_type in ratetype_re:
							RateType=rate_type
							##print "Rate_Type	:",RateType
							break
						roomtype_re = re.search(r'<h2>(.*?)</h2>',block1)
						if roomtype_re:
							RoomType = roomtype_re.group(1)
							##print"Room_Type   :",RoomType
						RateDescription = RoomType
						amenties_re = re.search(r'<div class="room_desc" >\s*<UL>\s*(.*?)\s*</UL>',block1,re.DOTALL)
						if amenties_re:
							amenties = amenties_re.group(1)
							amenties1 = re.sub(r'</LI>\n',',',amenties)
							amenties2 = re.sub(r',\s*<LI>',',',amenties1)
							amenties3 = '"'+re.sub(r'<LI>|</LI>','',amenties2)+'"'
							RoomAmenity_Type = re.sub(r',','","',amenties3)			
							##print"amenty    :",RoomAmenity_Type
						array.append(aws_insert.insert(id_update, inputid, WebSiteName, WebSiteCode, StartDate, RoomType,1, RateDate, Guests, OnsiteRate, Netrate, OnsiteRate, Curr, RateDescription, url, url, url, RoomAmenity_Type, MealInclusion_Type,MaxOccupancy, Isprom, Closed_up, 48, StartDate, EndDate, intime,isAvailable,None,None,"",None,RateType,Netrate,promotion,"",statuscode, israteperstay))
				else:
					Closed_up = "Y"
					statuscode=2
					array.append(aws_insert.insert(id_update, inputid, WebSiteName, WebSiteCode, StartDate, RoomType,1, RateDate, Guests, OnsiteRate, Netrate, OnsiteRate, Curr, RateDescription, url, url, url, RoomAmenity_Type, MealInclusion_Type,MaxOccupancy, Isprom, Closed_up, 48, StartDate, EndDate, intime,isAvailable,None,None,"",None,RateType,Netrate,promotion,"",statuscode, israteperstay))
		except Exception,e:
			value_error=str(re.sub(r"'",'',str(e)))
			stacktrace=sys.exc_traceback.tb_lineno
			keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(WebSiteCode,datetime.datetime.now(),id_update)
			#print keyvalue
			key = bucket.new_key(keyvalue)
			key.set_contents_from_string(str(e))
			statuscode=5
			Guests='1'
			array.append(aws_insert.insert(id_update, inputid ,functionname,WebSiteCode, "", "", "", "", Guests, "", "", "", "", "",url, url, url, "", "", "", "", "", "",StartDate, EndDate , "", "", "", "", "",  "", "","","","",statuscode, israteperstay))
			return json.dumps(array)
		keyvalue = "ondemand/{}/{:%Y%m%d}/delivery/{}.json".format(WebSiteCode,datetime.datetime.now(),str(inputid)+'_'+str(Rtdate)+'_'+id_update)
		key = bucket.new_key(keyvalue)
		key.set_contents_from_string(json.dumps(array))
		gc.collect()
		return json.dumps(array)
	except Exception,e:
		value_error=str(re.sub(r"'",'"',str(e)))
		stacktrace=sys.exc_traceback.tb_lineno
		insert_value_error=str(value_error)+'Where line number '+str(stacktrace)+str(proxyip)
		statuscode='4'
		WebSitecode='108'
		keyvalue = "ondemand/{}/{:%Y%m%d}/Error/{}.txt".format(WebSiteCode,datetime.datetime.now(),id_update)
		key = bucket.new_key(keyvalue)
		key.set_contents_from_string(insert_value_error)
		Guests='1'
		array.append(aws_insert.insert(id_update, inputid ,functionname,WebSiteCode, "", "", "", "", Guests, "", "", "", "", "",url, url, url, "", "", "", "", "", "",StartDate, EndDate , "", "", "", "", "",  "", "","","","",statuscode, israteperstay))
		return json.dumps(array)
